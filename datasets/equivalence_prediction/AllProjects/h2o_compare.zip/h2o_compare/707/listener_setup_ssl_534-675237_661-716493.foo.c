#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ SSL_CTX *ssl_ctx ;
  yoml_t *certificate_file ;
  yoml_t *key_file ;
  yoml_t *dh_file ;
  yoml_t *min_version ;
  yoml_t *max_version ;
  yoml_t *cipher_suite ;
  yoml_t *ocsp_update_cmd ;
  yoml_t *ocsp_update_interval_node ;
  yoml_t *ocsp_max_failures_node ;
  long ssl_options ;
  uint64_t ocsp_update_interval ;
  unsigned int ocsp_max_failures ;
  int use_neverbleed ;
  int use_picotls ;
  size_t i ;
  yoml_t *key ;
  yoml_t *value ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___8 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___26 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___44 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___62 ;
  int tmp___67 ;
  int tmp___68 ;
  int tmp___69 ;
  int tmp___70 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___80 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___87 ;
  int tmp___88 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___98 ;
  int tmp___103 ;
  int tmp___104 ;
  int tmp___105 ;
  int tmp___106 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___116 ;
  int tmp___121 ;
  int tmp___122 ;
  int tmp___123 ;
  int tmp___124 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___134 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  int tmp___142 ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___152 ;
  int tmp___157 ;
  int tmp___158 ;
  int tmp___159 ;
  int tmp___160 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___170 ;
  int tmp___175 ;
  int tmp___176 ;
  int tmp___177 ;
  int tmp___178 ;
  size_t __s1_len___9 ;
  size_t __s2_len___9 ;
  int tmp___188 ;
  int tmp___193 ;
  int tmp___194 ;
  int tmp___195 ;
  int tmp___196 ;
  int tmp___197 ;
  int tmp___198 ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___208 ;
  int tmp___213 ;
  int tmp___214 ;
  int tmp___215 ;
  int tmp___216 ;
  int tmp___217 ;
  int tmp___218 ;
  size_t __s1_len___11 ;
  size_t __s2_len___11 ;
  int tmp___228 ;
  int tmp___233 ;
  int tmp___234 ;
  int tmp___235 ;
  int tmp___236 ;
  int tmp___237 ;
  int tmp___238 ;
  int tmp___239 ;
  int tmp___240 ;
  int tmp___241 ;
  int tmp___242 ;
  int tmp___243 ;
  int tmp___244 ;
  int tmp___245 ;
  size_t i___0 ;
  struct listener_ssl_config_t *ssl_config ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___255 ;
  int tmp___260 ;
  int tmp___261 ;
  int tmp___262 ;
  int tmp___263 ;
  h2o_configurator_context_t *ctx ;
  yoml_t *ssl_node ;
  struct listener_config_t *listener ;
  int listener_is_new ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  int __dyc_funcallvar_74 ;
  int __dyc_funcallvar_75 ;
  int __dyc_funcallvar_76 ;
  int __dyc_funcallvar_77 ;
  int __dyc_funcallvar_78 ;
  int __dyc_funcallvar_79 ;
  int __dyc_funcallvar_80 ;
  int __dyc_funcallvar_81 ;
  int __dyc_funcallvar_82 ;
  int __dyc_funcallvar_83 ;

  {
  ctx = __dyc_read_ptr__typdef_h2o_configurator_context_t();
  ssl_node = __dyc_read_ptr__typdef_yoml_t();
  listener = __dyc_read_ptr__comp_637listener_config_t();
  listener_is_new = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = __dyc_readpre_byte();
  __dyc_funcallvar_75 = __dyc_readpre_byte();
  __dyc_funcallvar_76 = __dyc_readpre_byte();
  __dyc_funcallvar_77 = __dyc_readpre_byte();
  __dyc_funcallvar_78 = __dyc_readpre_byte();
  __dyc_funcallvar_79 = __dyc_readpre_byte();
  __dyc_funcallvar_80 = __dyc_readpre_byte();
  __dyc_funcallvar_81 = __dyc_readpre_byte();
  __dyc_funcallvar_82 = __dyc_readpre_byte();
  __dyc_funcallvar_83 = __dyc_readpre_byte();
  ssl_ctx = 0;
  certificate_file = 0;
  key_file = 0;
  dh_file = 0;
  min_version = 0;
  max_version = 0;
  cipher_suite = 0;
  ocsp_update_cmd = 0;
  ocsp_update_interval_node = 0;
  ocsp_max_failures_node = 0;
  ssl_options = 0;
  ocsp_update_interval = 0;
  ocsp_max_failures = 0;
  use_neverbleed = 0;
  use_picotls = 0;
  i = 0;
  key = 0;
  value = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___8 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___26 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___44 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___62 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  tmp___70 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___80 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  tmp___88 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___98 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  tmp___106 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___116 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  tmp___124 = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___134 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  tmp___142 = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___152 = 0;
  tmp___157 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___170 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  tmp___178 = 0;
  __s1_len___9 = 0;
  __s2_len___9 = 0;
  tmp___188 = 0;
  tmp___193 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  tmp___196 = 0;
  tmp___197 = 0;
  tmp___198 = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___208 = 0;
  tmp___213 = 0;
  tmp___214 = 0;
  tmp___215 = 0;
  tmp___216 = 0;
  tmp___217 = 0;
  tmp___218 = 0;
  __s1_len___11 = 0;
  __s2_len___11 = 0;
  tmp___228 = 0;
  tmp___233 = 0;
  tmp___234 = 0;
  tmp___235 = 0;
  tmp___236 = 0;
  tmp___237 = 0;
  tmp___238 = 0;
  tmp___239 = 0;
  tmp___240 = 0;
  tmp___241 = 0;
  tmp___242 = 0;
  tmp___243 = 0;
  tmp___244 = 0;
  tmp___245 = 0;
  i___0 = 0;
  ssl_config = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___255 = 0;
  tmp___260 = 0;
  tmp___261 = 0;
  tmp___262 = 0;
  tmp___263 = 0;
  ssl_ctx = (SSL_CTX *)((void *)0);
  certificate_file = (yoml_t *)((void *)0);
  key_file = (yoml_t *)((void *)0);
  dh_file = (yoml_t *)((void *)0);
  min_version = (yoml_t *)((void *)0);
  max_version = (yoml_t *)((void *)0);
  cipher_suite = (yoml_t *)((void *)0);
  ocsp_update_cmd = (yoml_t *)((void *)0);
  ocsp_update_interval_node = (yoml_t *)((void *)0);
  ocsp_max_failures_node = (yoml_t *)((void *)0);
  ssl_options = 2147486719L;
  ocsp_update_interval = (uint64_t )14400;
  ocsp_max_failures = 3U;
  use_neverbleed = 1;
  use_picotls = 1;
  if (! listener_is_new) {
    if (listener->ssl.size != 0UL) {
      if ((unsigned long )ssl_node == (unsigned long )((void *)0)) {
        {

        }
        goto __dyc_dummy_label;
      }
    }
    if (listener->ssl.size == 0UL) {
      if ((unsigned long )ssl_node != (unsigned long )((void *)0)) {
        {

        }
        goto __dyc_dummy_label;
      }
    }
  }
  if ((unsigned long )ssl_node == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  if ((int )ssl_node->type != 2) {
    {

    }
    goto __dyc_dummy_label;
  }
  i = 0UL;
  while (1) {
    while_32_continue:  ;
    if (! (i != ssl_node->data.sequence.size)) {
      goto while_32_break;
    }
    key = ssl_node->data.mapping.elements[i].key;
    value = ssl_node->data.mapping.elements[i].value;
    if ((int )key->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    if (0) {
      {
      tmp___14 = __dyc_funcallvar_1;
      __s1_len = (unsigned long )tmp___14;
      tmp___15 = __dyc_funcallvar_2;
      __s2_len = (unsigned long )tmp___15;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___0;
      } else {
        if (__s1_len >= 4UL) {
          _L___0:  
          if (! ((unsigned long )((void const   *)("certificate-file" + 1)) - (unsigned long )((void const   *)"certificate-file") == 1UL)) {
            tmp___16 = 1;
          } else {
            if (__s2_len >= 4UL) {
              tmp___16 = 1;
            } else {
              tmp___16 = 0;
            }
          }
        } else {
          tmp___16 = 0;
        }
      }
      if (tmp___16) {
        {
        tmp___8 = __dyc_funcallvar_3;
        }
      } else {
        {
        tmp___13 = __dyc_funcallvar_4;
        tmp___8 = tmp___13;
        }
      }
    } else {
      {
      tmp___13 = __dyc_funcallvar_5;
      tmp___8 = tmp___13;
      }
    }
    if (tmp___8 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      certificate_file = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___32 = __dyc_funcallvar_6;
      __s1_len___0 = (unsigned long )tmp___32;
      tmp___33 = __dyc_funcallvar_7;
      __s2_len___0 = (unsigned long )tmp___33;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___2;
      } else {
        if (__s1_len___0 >= 4UL) {
          _L___2:  
          if (! ((unsigned long )((void const   *)("key-file" + 1)) - (unsigned long )((void const   *)"key-file") == 1UL)) {
            tmp___34 = 1;
          } else {
            if (__s2_len___0 >= 4UL) {
              tmp___34 = 1;
            } else {
              tmp___34 = 0;
            }
          }
        } else {
          tmp___34 = 0;
        }
      }
      if (tmp___34) {
        {
        tmp___26 = __dyc_funcallvar_8;
        }
      } else {
        {
        tmp___31 = __dyc_funcallvar_9;
        tmp___26 = tmp___31;
        }
      }
    } else {
      {
      tmp___31 = __dyc_funcallvar_10;
      tmp___26 = tmp___31;
      }
    }
    if (tmp___26 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      key_file = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___50 = __dyc_funcallvar_11;
      __s1_len___1 = (unsigned long )tmp___50;
      tmp___51 = __dyc_funcallvar_12;
      __s2_len___1 = (unsigned long )tmp___51;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___4;
      } else {
        if (__s1_len___1 >= 4UL) {
          _L___4:  
          if (! ((unsigned long )((void const   *)("min-version" + 1)) - (unsigned long )((void const   *)"min-version") == 1UL)) {
            tmp___52 = 1;
          } else {
            if (__s2_len___1 >= 4UL) {
              tmp___52 = 1;
            } else {
              tmp___52 = 0;
            }
          }
        } else {
          tmp___52 = 0;
        }
      }
      if (tmp___52) {
        {
        tmp___44 = __dyc_funcallvar_13;
        }
      } else {
        {
        tmp___49 = __dyc_funcallvar_14;
        tmp___44 = tmp___49;
        }
      }
    } else {
      {
      tmp___49 = __dyc_funcallvar_15;
      tmp___44 = tmp___49;
      }
    }
    if (tmp___44 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      min_version = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___68 = __dyc_funcallvar_16;
      __s1_len___2 = (unsigned long )tmp___68;
      tmp___69 = __dyc_funcallvar_17;
      __s2_len___2 = (unsigned long )tmp___69;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___6;
      } else {
        if (__s1_len___2 >= 4UL) {
          _L___6:  
          if (! ((unsigned long )((void const   *)("minimum-version" + 1)) - (unsigned long )((void const   *)"minimum-version") == 1UL)) {
            tmp___70 = 1;
          } else {
            if (__s2_len___2 >= 4UL) {
              tmp___70 = 1;
            } else {
              tmp___70 = 0;
            }
          }
        } else {
          tmp___70 = 0;
        }
      }
      if (tmp___70) {
        {
        tmp___62 = __dyc_funcallvar_18;
        }
      } else {
        {
        tmp___67 = __dyc_funcallvar_19;
        tmp___62 = tmp___67;
        }
      }
    } else {
      {
      tmp___67 = __dyc_funcallvar_20;
      tmp___62 = tmp___67;
      }
    }
    if (tmp___62 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      min_version = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___86 = __dyc_funcallvar_21;
      __s1_len___3 = (unsigned long )tmp___86;
      tmp___87 = __dyc_funcallvar_22;
      __s2_len___3 = (unsigned long )tmp___87;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___8;
      } else {
        if (__s1_len___3 >= 4UL) {
          _L___8:  
          if (! ((unsigned long )((void const   *)("max-version" + 1)) - (unsigned long )((void const   *)"max-version") == 1UL)) {
            tmp___88 = 1;
          } else {
            if (__s2_len___3 >= 4UL) {
              tmp___88 = 1;
            } else {
              tmp___88 = 0;
            }
          }
        } else {
          tmp___88 = 0;
        }
      }
      if (tmp___88) {
        {
        tmp___80 = __dyc_funcallvar_23;
        }
      } else {
        {
        tmp___85 = __dyc_funcallvar_24;
        tmp___80 = tmp___85;
        }
      }
    } else {
      {
      tmp___85 = __dyc_funcallvar_25;
      tmp___80 = tmp___85;
      }
    }
    if (tmp___80 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      max_version = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___104 = __dyc_funcallvar_26;
      __s1_len___4 = (unsigned long )tmp___104;
      tmp___105 = __dyc_funcallvar_27;
      __s2_len___4 = (unsigned long )tmp___105;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___10;
      } else {
        if (__s1_len___4 >= 4UL) {
          _L___10:  
          if (! ((unsigned long )((void const   *)("maximum-version" + 1)) - (unsigned long )((void const   *)"maximum-version") == 1UL)) {
            tmp___106 = 1;
          } else {
            if (__s2_len___4 >= 4UL) {
              tmp___106 = 1;
            } else {
              tmp___106 = 0;
            }
          }
        } else {
          tmp___106 = 0;
        }
      }
      if (tmp___106) {
        {
        tmp___98 = __dyc_funcallvar_28;
        }
      } else {
        {
        tmp___103 = __dyc_funcallvar_29;
        tmp___98 = tmp___103;
        }
      }
    } else {
      {
      tmp___103 = __dyc_funcallvar_30;
      tmp___98 = tmp___103;
      }
    }
    if (tmp___98 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      max_version = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___122 = __dyc_funcallvar_31;
      __s1_len___5 = (unsigned long )tmp___122;
      tmp___123 = __dyc_funcallvar_32;
      __s2_len___5 = (unsigned long )tmp___123;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___12;
      } else {
        if (__s1_len___5 >= 4UL) {
          _L___12:  
          if (! ((unsigned long )((void const   *)("cipher-suite" + 1)) - (unsigned long )((void const   *)"cipher-suite") == 1UL)) {
            tmp___124 = 1;
          } else {
            if (__s2_len___5 >= 4UL) {
              tmp___124 = 1;
            } else {
              tmp___124 = 0;
            }
          }
        } else {
          tmp___124 = 0;
        }
      }
      if (tmp___124) {
        {
        tmp___116 = __dyc_funcallvar_33;
        }
      } else {
        {
        tmp___121 = __dyc_funcallvar_34;
        tmp___116 = tmp___121;
        }
      }
    } else {
      {
      tmp___121 = __dyc_funcallvar_35;
      tmp___116 = tmp___121;
      }
    }
    if (tmp___116 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      cipher_suite = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___140 = __dyc_funcallvar_36;
      __s1_len___6 = (unsigned long )tmp___140;
      tmp___141 = __dyc_funcallvar_37;
      __s2_len___6 = (unsigned long )tmp___141;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___14;
      } else {
        if (__s1_len___6 >= 4UL) {
          _L___14:  
          if (! ((unsigned long )((void const   *)("ocsp-update-cmd" + 1)) - (unsigned long )((void const   *)"ocsp-update-cmd") == 1UL)) {
            tmp___142 = 1;
          } else {
            if (__s2_len___6 >= 4UL) {
              tmp___142 = 1;
            } else {
              tmp___142 = 0;
            }
          }
        } else {
          tmp___142 = 0;
        }
      }
      if (tmp___142) {
        {
        tmp___134 = __dyc_funcallvar_38;
        }
      } else {
        {
        tmp___139 = __dyc_funcallvar_39;
        tmp___134 = tmp___139;
        }
      }
    } else {
      {
      tmp___139 = __dyc_funcallvar_40;
      tmp___134 = tmp___139;
      }
    }
    if (tmp___134 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      ocsp_update_cmd = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___158 = __dyc_funcallvar_41;
      __s1_len___7 = (unsigned long )tmp___158;
      tmp___159 = __dyc_funcallvar_42;
      __s2_len___7 = (unsigned long )tmp___159;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___16;
      } else {
        if (__s1_len___7 >= 4UL) {
          _L___16:  
          if (! ((unsigned long )((void const   *)("ocsp-update-interval" + 1)) - (unsigned long )((void const   *)"ocsp-update-interval") == 1UL)) {
            tmp___160 = 1;
          } else {
            if (__s2_len___7 >= 4UL) {
              tmp___160 = 1;
            } else {
              tmp___160 = 0;
            }
          }
        } else {
          tmp___160 = 0;
        }
      }
      if (tmp___160) {
        {
        tmp___152 = __dyc_funcallvar_43;
        }
      } else {
        {
        tmp___157 = __dyc_funcallvar_44;
        tmp___152 = tmp___157;
        }
      }
    } else {
      {
      tmp___157 = __dyc_funcallvar_45;
      tmp___152 = tmp___157;
      }
    }
    if (tmp___152 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      ocsp_update_interval_node = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___176 = __dyc_funcallvar_46;
      __s1_len___8 = (unsigned long )tmp___176;
      tmp___177 = __dyc_funcallvar_47;
      __s2_len___8 = (unsigned long )tmp___177;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___18;
      } else {
        if (__s1_len___8 >= 4UL) {
          _L___18:  
          if (! ((unsigned long )((void const   *)("ocsp-max-failures" + 1)) - (unsigned long )((void const   *)"ocsp-max-failures") == 1UL)) {
            tmp___178 = 1;
          } else {
            if (__s2_len___8 >= 4UL) {
              tmp___178 = 1;
            } else {
              tmp___178 = 0;
            }
          }
        } else {
          tmp___178 = 0;
        }
      }
      if (tmp___178) {
        {
        tmp___170 = __dyc_funcallvar_48;
        }
      } else {
        {
        tmp___175 = __dyc_funcallvar_49;
        tmp___170 = tmp___175;
        }
      }
    } else {
      {
      tmp___175 = __dyc_funcallvar_50;
      tmp___170 = tmp___175;
      }
    }
    if (tmp___170 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      ocsp_max_failures_node = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___194 = __dyc_funcallvar_51;
      __s1_len___9 = (unsigned long )tmp___194;
      tmp___195 = __dyc_funcallvar_52;
      __s2_len___9 = (unsigned long )tmp___195;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___20;
      } else {
        if (__s1_len___9 >= 4UL) {
          _L___20:  
          if (! ((unsigned long )((void const   *)("dh-file" + 1)) - (unsigned long )((void const   *)"dh-file") == 1UL)) {
            tmp___196 = 1;
          } else {
            if (__s2_len___9 >= 4UL) {
              tmp___196 = 1;
            } else {
              tmp___196 = 0;
            }
          }
        } else {
          tmp___196 = 0;
        }
      }
      if (tmp___196) {
        {
        tmp___188 = __dyc_funcallvar_53;
        }
      } else {
        {
        tmp___193 = __dyc_funcallvar_54;
        tmp___188 = tmp___193;
        }
      }
    } else {
      {
      tmp___193 = __dyc_funcallvar_55;
      tmp___188 = tmp___193;
      }
    }
    if (tmp___188 == 0) {
      if ((int )value->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      dh_file = value;
      goto __Cont;
    }
    if (0) {
      {
      tmp___214 = __dyc_funcallvar_56;
      __s1_len___10 = (unsigned long )tmp___214;
      tmp___215 = __dyc_funcallvar_57;
      __s2_len___10 = (unsigned long )tmp___215;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___23;
      } else {
        if (__s1_len___10 >= 4UL) {
          _L___23:  
          if (! ((unsigned long )((void const   *)("cipher-preference" + 1)) - (unsigned long )((void const   *)"cipher-preference") == 1UL)) {
            tmp___216 = 1;
          } else {
            if (__s2_len___10 >= 4UL) {
              tmp___216 = 1;
            } else {
              tmp___216 = 0;
            }
          }
        } else {
          tmp___216 = 0;
        }
      }
      if (tmp___216) {
        {
        tmp___208 = __dyc_funcallvar_58;
        }
      } else {
        {
        tmp___213 = __dyc_funcallvar_59;
        tmp___208 = tmp___213;
        }
      }
    } else {
      {
      tmp___213 = __dyc_funcallvar_60;
      tmp___208 = tmp___213;
      }
    }
    if (tmp___208 == 0) {
      if ((int )value->type == 0) {
        {
        tmp___198 = __dyc_funcallvar_61;
        }
        if (tmp___198 == 0) {
          ssl_options &= -4194305L;
        } else {
          goto _L___21;
        }
      } else {
        _L___21:  
        if ((int )value->type == 0) {
          {
          tmp___197 = __dyc_funcallvar_62;
          }
          if (tmp___197 == 0) {
            ssl_options |= 4194304L;
          } else {
            {

            }
            goto __dyc_dummy_label;
          }
        } else {
          {

          }
          goto __dyc_dummy_label;
        }
      }
      goto __Cont;
    }
    if (0) {
      {
      tmp___234 = __dyc_funcallvar_63;
      __s1_len___11 = (unsigned long )tmp___234;
      tmp___235 = __dyc_funcallvar_64;
      __s2_len___11 = (unsigned long )tmp___235;
      }
      if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
        goto _L___26;
      } else {
        if (__s1_len___11 >= 4UL) {
          _L___26:  
          if (! ((unsigned long )((void const   *)("neverbleed" + 1)) - (unsigned long )((void const   *)"neverbleed") == 1UL)) {
            tmp___236 = 1;
          } else {
            if (__s2_len___11 >= 4UL) {
              tmp___236 = 1;
            } else {
              tmp___236 = 0;
            }
          }
        } else {
          tmp___236 = 0;
        }
      }
      if (tmp___236) {
        {
        tmp___228 = __dyc_funcallvar_65;
        }
      } else {
        {
        tmp___233 = __dyc_funcallvar_66;
        tmp___228 = tmp___233;
        }
      }
    } else {
      {
      tmp___233 = __dyc_funcallvar_67;
      tmp___228 = tmp___233;
      }
    }
    if (tmp___228 == 0) {
      if ((int )value->type == 0) {
        {
        tmp___218 = __dyc_funcallvar_68;
        }
        if (tmp___218 == 0) {
          use_neverbleed = 1;
        } else {
          goto _L___24;
        }
      } else {
        _L___24:  
        if ((int )value->type == 0) {
          {
          tmp___217 = __dyc_funcallvar_69;
          }
          if (tmp___217 == 0) {
            use_neverbleed = 0;
          } else {
            {

            }
            goto __dyc_dummy_label;
          }
        } else {
          {

          }
          goto __dyc_dummy_label;
        }
      }
      goto __Cont;
    }
    {

    }
    goto __dyc_dummy_label;
    __Cont:  
    i ++;
  }
  while_32_break:  ;
  if ((unsigned long )certificate_file == (unsigned long )((void *)0)) {
    {

    }
    goto __dyc_dummy_label;
  }
  if ((unsigned long )key_file == (unsigned long )((void *)0)) {
    {

    }
    goto __dyc_dummy_label;
  }
  if ((unsigned long )min_version != (unsigned long )((void *)0)) {
    {
    tmp___237 = __dyc_funcallvar_70;
    }
    if (tmp___237 == 0) {
      ssl_options = ssl_options;
      goto VersionFound;
    }
    {
    tmp___238 = __dyc_funcallvar_71;
    }
    if (tmp___238 == 0) {
      ssl_options |= 16777216L;
      goto VersionFound;
    }
    {
    tmp___239 = __dyc_funcallvar_72;
    }
    if (tmp___239 == 0) {
      ssl_options |= 50331648L;
      goto VersionFound;
    }
    {
    tmp___240 = __dyc_funcallvar_73;
    }
    if (tmp___240 == 0) {
      ssl_options |= 117440512L;
      goto VersionFound;
    }
    {
    tmp___241 = __dyc_funcallvar_74;
    }
    if (tmp___241 == 0) {
      ssl_options |= 385875968L;
      goto VersionFound;
    }
    {
    tmp___242 = __dyc_funcallvar_75;
    }
    if (tmp___242 == 0) {
      ssl_options |= 520093696L;
      goto VersionFound;
    }
    {

    }
    VersionFound: ;
  } else {
    ssl_options |= 50331648L;
  }
  if ((unsigned long )max_version != (unsigned long )((void *)0)) {
    {
    tmp___243 = __dyc_funcallvar_76;
    }
    if (tmp___243 < 0) {
      use_picotls = 0;
    }
  }
  if ((unsigned long )ocsp_update_interval_node != (unsigned long )((void *)0)) {
    {
    tmp___244 = __dyc_funcallvar_77;
    }
    if (tmp___244 != 0) {
      goto __dyc_dummy_label;
    }
  }
  if ((unsigned long )ocsp_max_failures_node != (unsigned long )((void *)0)) {
    {
    tmp___245 = __dyc_funcallvar_78;
    }
    if (tmp___245 != 0) {
      goto __dyc_dummy_label;
    }
  }
  if ((unsigned long )ctx->hostconf != (unsigned long )((void *)0)) {
    i___0 = 0UL;
    {
    while (1) {
      while_33_continue:  ;
      if (! (i___0 != listener->ssl.size)) {
        goto while_33_break;
      }
      ssl_config = *(listener->ssl.entries + i___0);
      if (0) {
        {
        tmp___261 = __dyc_funcallvar_79;
        __s1_len___12 = (unsigned long )tmp___261;
        tmp___262 = __dyc_funcallvar_80;
        __s2_len___12 = (unsigned long )tmp___262;
        }
        if (! ((unsigned long )((void const   *)(ssl_config->certificate_file + 1)) - (unsigned long )((void const   *)ssl_config->certificate_file) == 1UL)) {
          goto _L___28;
        } else {
          if (__s1_len___12 >= 4UL) {
            _L___28:  
            if (! ((unsigned long )((void const   *)(certificate_file->data.scalar + 1)) - (unsigned long )((void const   *)certificate_file->data.scalar) == 1UL)) {
              tmp___263 = 1;
            } else {
              if (__s2_len___12 >= 4UL) {
                tmp___263 = 1;
              } else {
                tmp___263 = 0;
              }
            }
          } else {
            tmp___263 = 0;
          }
        }
        if (tmp___263) {
          {
          tmp___255 = __dyc_funcallvar_81;
          }
        } else {
          {
          tmp___260 = __dyc_funcallvar_82;
          tmp___255 = tmp___260;
          }
        }
      } else {
        {
        tmp___260 = __dyc_funcallvar_83;
        tmp___255 = tmp___260;
        }
      }
      if (tmp___255 == 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      i___0 ++;
    }
    while_33_break:  ;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_SSL_CTX(ssl_ctx);
  __dyc_print_ptr__typdef_yoml_t(certificate_file);
  __dyc_print_ptr__typdef_yoml_t(key_file);
  __dyc_print_ptr__typdef_yoml_t(dh_file);
  __dyc_print_ptr__typdef_yoml_t(min_version);
  __dyc_print_ptr__typdef_yoml_t(max_version);
  __dyc_print_ptr__typdef_yoml_t(cipher_suite);
  __dyc_print_ptr__typdef_yoml_t(ocsp_update_cmd);
  __dyc_print_ptr__typdef_yoml_t(ocsp_update_interval_node);
  __dyc_print_ptr__typdef_yoml_t(ocsp_max_failures_node);
  __dyc_printpre_byte(ssl_options);
  __dyc_printpre_byte(ocsp_update_interval);
  __dyc_printpre_byte(ocsp_max_failures);
  __dyc_printpre_byte(use_neverbleed);
  __dyc_printpre_byte(use_picotls);
  __dyc_print_ptr__typdef_yoml_t(value);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(__s1_len___9);
  __dyc_printpre_byte(__s2_len___9);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___11);
  __dyc_printpre_byte(__s2_len___11);
  __dyc_print_ptr__comp_633listener_ssl_config_t(ssl_config);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
}
}
