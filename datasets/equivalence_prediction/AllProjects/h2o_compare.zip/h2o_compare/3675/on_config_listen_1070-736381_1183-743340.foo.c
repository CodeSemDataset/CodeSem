#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_conf_228 conf ;
  char const   *type ;
  int proxy_protocol ;
  struct sockaddr_un sa ;
  int listener_is_new ;
  struct listener_config_t *listener ;
  size_t tmp___1 ;
  int fd ;
  int tmp___2 ;
  struct addrinfo hints ;
  struct addrinfo *res ;
  struct addrinfo *ai ;
  int error ;
  char const   *tmp___3 ;
  struct listener_config_t *listener___0 ;
  struct listener_config_t *tmp___4 ;
  int listener_is_new___0 ;
  int fd___0 ;
  int tmp___5 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___15 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___33 ;
  char const   *tmp___42 ;
  h2o_configurator_context_t *ctx ;
  size_t __dyc_funcallvar_13 ;
  struct listener_config_t *__dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  struct listener_config_t *__dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  char const   *__dyc_funcallvar_25 ;
  struct listener_config_t *__dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  struct listener_config_t *__dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;

  {
  conf = __dyc_read_comp_643__anonstruct_conf_228();
  type = (char const   *)__dyc_read_ptr__char();
  proxy_protocol = __dyc_readpre_byte();
  res = __dyc_read_ptr__comp_74addrinfo();
  tmp___33 = __dyc_readpre_byte();
  ctx = __dyc_read_ptr__typdef_h2o_configurator_context_t();
  __dyc_funcallvar_13 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_read_ptr__comp_637listener_config_t();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_read_ptr__comp_637listener_config_t();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_26 = __dyc_read_ptr__comp_637listener_config_t();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_read_ptr__comp_637listener_config_t();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  memset(& sa, 0, sizeof(struct sockaddr_un ));
  listener_is_new = 0;
  listener = 0;
  tmp___1 = 0;
  fd = 0;
  tmp___2 = 0;
  memset(& hints, 0, sizeof(struct addrinfo ));
  ai = 0;
  error = 0;
  tmp___3 = 0;
  listener___0 = 0;
  tmp___4 = 0;
  listener_is_new___0 = 0;
  fd___0 = 0;
  tmp___5 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___15 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___42 = 0;
  if (tmp___33 == 0) {
    {

    tmp___1 = __dyc_funcallvar_13;
    }
    if (tmp___1 >= sizeof(char [108])) {
      {

      }
      goto __dyc_dummy_label;
    }
    {
    sa.sun_family = (unsigned short)1;

    listener_is_new = 0;
    listener = __dyc_funcallvar_14;
    }
    if ((unsigned long )listener == (unsigned long )((void *)0)) {
      fd = -1;
      if ((int )conf.run_mode == 0) {
        goto switch_40_0;
      } else {
        {
        goto switch_40_default;
        if (0) {
          switch_40_0:  
          if ((unsigned long )conf.server_starter.fds != (unsigned long )((void *)0)) {
            {
            fd = __dyc_funcallvar_15;
            }
            if (fd == -1) {
              {

              }
              goto __dyc_dummy_label;
            }
          } else {
            {
            fd = __dyc_funcallvar_16;
            }
            if (fd == -1) {
              goto __dyc_dummy_label;
            }
          }
          goto switch_40_break;
          switch_40_default:  ;
          goto switch_40_break;
        } else {
          switch_40_break:  ;
        }
        }
      }
      {
      listener = __dyc_funcallvar_17;
      listener_is_new = 1;
      }
    } else {
      if (listener->proxy_protocol != proxy_protocol) {
        goto ProxyConflict;
      }
    }
    {
    tmp___2 = __dyc_funcallvar_18;
    }
    if (tmp___2 != 0) {
      goto __dyc_dummy_label;
    }
    if ((unsigned long )listener->hosts != (unsigned long )((void *)0)) {
      if ((unsigned long )ctx->hostconf != (unsigned long )((void *)0)) {
        {

        }
      }
    }
  } else {
    if (0) {
      {
      tmp___21 = __dyc_funcallvar_19;
      __s1_len = (unsigned long )tmp___21;
      tmp___22 = __dyc_funcallvar_20;
      __s2_len = (unsigned long )tmp___22;
      }
      if (! ((unsigned long )((void const   *)(type + 1)) - (unsigned long )((void const   *)type) == 1UL)) {
        goto _L___0;
      } else {
        if (__s1_len >= 4UL) {
          _L___0:  
          if (! ((unsigned long )((void const   *)("tcp" + 1)) - (unsigned long )((void const   *)"tcp") == 1UL)) {
            tmp___23 = 1;
          } else {
            if (__s2_len >= 4UL) {
              tmp___23 = 1;
            } else {
              tmp___23 = 0;
            }
          }
        } else {
          tmp___23 = 0;
        }
      }
      if (tmp___23) {
        {
        tmp___15 = __dyc_funcallvar_21;
        }
      } else {
        {
        tmp___20 = __dyc_funcallvar_22;
        tmp___15 = tmp___20;
        }
      }
    } else {
      {
      tmp___20 = __dyc_funcallvar_23;
      tmp___15 = tmp___20;
      }
    }
    if (tmp___15 == 0) {
      {

      hints.ai_socktype = 1;
      hints.ai_protocol = 6;
      hints.ai_flags = 1057;
      error = __dyc_funcallvar_24;
      }
      if (error != 0) {
        {
        tmp___3 = __dyc_funcallvar_25;

        }
        goto __dyc_dummy_label;
      } else {
        if ((unsigned long )res == (unsigned long )((void *)0)) {
          {

          }
          goto __dyc_dummy_label;
        }
      }
      ai = res;
      {
      while (1) {
        while_41_continue:  ;
        if (! ((unsigned long )ai != (unsigned long )((void *)0))) {
          goto while_41_break;
        }
        {
        tmp___4 = __dyc_funcallvar_26;
        listener___0 = tmp___4;
        listener_is_new___0 = 0;
        }
        if ((unsigned long )listener___0 == (unsigned long )((void *)0)) {
          fd___0 = -1;
          if ((int )conf.run_mode == 0) {
            goto switch_42_0;
          } else {
            {
            goto switch_42_default;
            if (0) {
              switch_42_0:  
              if ((unsigned long )conf.server_starter.fds != (unsigned long )((void *)0)) {
                {
                fd___0 = __dyc_funcallvar_27;
                }
                if (fd___0 == -1) {
                  {


                  }
                  goto __dyc_dummy_label;
                }
              } else {
                {
                fd___0 = __dyc_funcallvar_28;
                }
                if (fd___0 == -1) {
                  {

                  }
                  goto __dyc_dummy_label;
                }
              }
              goto switch_42_break;
              switch_42_default:  ;
              goto switch_42_break;
            } else {
              switch_42_break:  ;
            }
            }
          }
          {
          listener___0 = __dyc_funcallvar_29;
          listener_is_new___0 = 1;
          }
        } else {
          if (listener___0->proxy_protocol != proxy_protocol) {
            {

            }
            goto ProxyConflict;
          }
        }
        {
        tmp___5 = __dyc_funcallvar_30;
        }
        if (tmp___5 != 0) {
          {

          }
          goto __dyc_dummy_label;
        }
        if ((unsigned long )listener___0->hosts != (unsigned long )((void *)0)) {
          if ((unsigned long )ctx->hostconf != (unsigned long )((void *)0)) {
            {

            }
          }
        }
        ai = ai->ai_next;
      }
      while_41_break:  ;
      }
      {

      }
    } else {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  goto __dyc_dummy_label;
  ProxyConflict: 
  if (proxy_protocol) {
    tmp___42 = "on";
  } else {
    tmp___42 = "off";
  }

  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_comp_39sockaddr_un(sa);
  __dyc_printpre_byte(listener_is_new);
  __dyc_print_ptr__comp_637listener_config_t(listener);
  __dyc_printpre_byte(fd);
  __dyc_print_comp_74addrinfo(hints);
  __dyc_print_ptr__char(tmp___3);
  __dyc_print_ptr__comp_637listener_config_t(listener___0);
  __dyc_printpre_byte(listener_is_new___0);
  __dyc_printpre_byte(fd___0);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_print_ptr__char(tmp___42);
}
}
