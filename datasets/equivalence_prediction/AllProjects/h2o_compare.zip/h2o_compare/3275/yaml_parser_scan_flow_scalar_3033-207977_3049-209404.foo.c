#include "../include/dycfoo.h"
#include "../include/scanner.i.hd.c.h"
void __dyc_foo(void) 
{ yaml_mark_t start_mark ;
  yaml_string_t string ;
  yaml_string_t leading_break ;
  yaml_string_t trailing_breaks ;
  yaml_string_t whitespaces ;
  int leading_blanks ;
  int tmp___0 ;
  void *tmp___1 ;
  int tmp___3 ;
  void *tmp___4 ;
  int tmp___6 ;
  void *tmp___7 ;
  int tmp___9 ;
  void *tmp___10 ;
  int tmp___15 ;
  int tmp___20 ;
  int tmp___22 ;
  int tmp___24 ;
  int tmp___25 ;
  yaml_char_t *tmp___26 ;
  int tmp___31 ;
  int tmp___39 ;
  int tmp___44 ;
  int tmp___49 ;
  int tmp___57 ;
  size_t code_length ;
  int tmp___62 ;
  int tmp___63 ;
  yaml_char_t *tmp___64 ;
  yaml_char_t *tmp___65 ;
  yaml_char_t *tmp___66 ;
  yaml_char_t *tmp___67 ;
  yaml_char_t *tmp___68 ;
  yaml_char_t *tmp___69 ;
  yaml_char_t *tmp___70 ;
  yaml_char_t *tmp___71 ;
  yaml_char_t *tmp___72 ;
  yaml_char_t *tmp___73 ;
  yaml_char_t *tmp___74 ;
  yaml_char_t *tmp___75 ;
  yaml_char_t *tmp___76 ;
  yaml_char_t *tmp___77 ;
  yaml_char_t *tmp___78 ;
  yaml_char_t *tmp___79 ;
  yaml_char_t *tmp___80 ;
  yaml_char_t *tmp___81 ;
  yaml_char_t *tmp___82 ;
  yaml_char_t *tmp___83 ;
  yaml_char_t *tmp___84 ;
  yaml_char_t *tmp___85 ;
  yaml_char_t *tmp___86 ;
  int tmp___91 ;
  int tmp___99 ;
  unsigned int value ;
  size_t k ;
  int tmp___104 ;
  int tmp___106 ;
  yaml_char_t *tmp___107 ;
  yaml_char_t *tmp___108 ;
  yaml_char_t *tmp___109 ;
  yaml_char_t *tmp___110 ;
  yaml_char_t *tmp___111 ;
  yaml_char_t *tmp___112 ;
  yaml_char_t *tmp___113 ;
  yaml_char_t *tmp___114 ;
  yaml_char_t *tmp___115 ;
  yaml_char_t *tmp___116 ;
  int tmp___121 ;
  int tmp___148 ;
  yaml_char_t *tmp___149 ;
  yaml_char_t *tmp___150 ;
  yaml_char_t *tmp___151 ;
  yaml_char_t *tmp___152 ;
  yaml_char_t *tmp___153 ;
  yaml_char_t *tmp___154 ;
  yaml_char_t *tmp___155 ;
  yaml_char_t *tmp___156 ;
  yaml_char_t *tmp___157 ;
  yaml_char_t *tmp___158 ;
  yaml_char_t *tmp___159 ;
  yaml_char_t *tmp___160 ;
  yaml_char_t *tmp___161 ;
  yaml_char_t *tmp___162 ;
  yaml_char_t *tmp___163 ;
  yaml_char_t *tmp___164 ;
  yaml_char_t *tmp___165 ;
  yaml_char_t *tmp___166 ;
  yaml_char_t *tmp___167 ;
  yaml_char_t *tmp___168 ;
  int tmp___170 ;
  int tmp___171 ;
  int tmp___172 ;
  int tmp___174 ;
  int tmp___175 ;
  int tmp___177 ;
  int tmp___201 ;
  yaml_char_t *tmp___202 ;
  yaml_char_t *tmp___203 ;
  yaml_char_t *tmp___204 ;
  yaml_char_t *tmp___205 ;
  yaml_char_t *tmp___206 ;
  yaml_char_t *tmp___207 ;
  yaml_char_t *tmp___208 ;
  yaml_char_t *tmp___209 ;
  yaml_char_t *tmp___210 ;
  yaml_char_t *tmp___211 ;
  yaml_char_t *tmp___212 ;
  yaml_char_t *tmp___213 ;
  yaml_char_t *tmp___214 ;
  yaml_char_t *tmp___215 ;
  yaml_char_t *tmp___216 ;
  yaml_char_t *tmp___217 ;
  yaml_char_t *tmp___218 ;
  yaml_char_t *tmp___219 ;
  yaml_char_t *tmp___220 ;
  yaml_char_t *tmp___221 ;
  int tmp___223 ;
  int tmp___224 ;
  int tmp___229 ;
  int tmp___234 ;
  int tmp___247 ;
  yaml_char_t *tmp___248 ;
  yaml_char_t *tmp___249 ;
  yaml_char_t *tmp___250 ;
  yaml_char_t *tmp___251 ;
  yaml_char_t *tmp___252 ;
  yaml_char_t *tmp___253 ;
  yaml_char_t *tmp___254 ;
  yaml_char_t *tmp___255 ;
  yaml_char_t *tmp___256 ;
  int tmp___258 ;
  int tmp___259 ;
  int tmp___272 ;
  yaml_char_t *tmp___273 ;
  yaml_char_t *tmp___274 ;
  yaml_char_t *tmp___275 ;
  yaml_char_t *tmp___276 ;
  yaml_char_t *tmp___277 ;
  yaml_char_t *tmp___278 ;
  yaml_char_t *tmp___279 ;
  yaml_char_t *tmp___280 ;
  yaml_char_t *tmp___281 ;
  int tmp___283 ;
  int tmp___284 ;
  int tmp___286 ;
  int tmp___288 ;
  int tmp___289 ;
  yaml_char_t *tmp___290 ;
  int tmp___292 ;
  int tmp___293 ;
  int tmp___295 ;
  int tmp___296 ;
  int tmp___298 ;
  int tmp___299 ;
  int tmp___301 ;
  int tmp___302 ;
  yaml_parser_t *parser ;
  int single ;
  void *__dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;
  void *__dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;

  {
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  single = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = __dyc_read_ptr__void();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  memset(& start_mark, 0, sizeof(yaml_mark_t ));
  memset(& string, 0, sizeof(yaml_string_t ));
  memset(& leading_break, 0, sizeof(yaml_string_t ));
  memset(& trailing_breaks, 0, sizeof(yaml_string_t ));
  memset(& whitespaces, 0, sizeof(yaml_string_t ));
  leading_blanks = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___15 = 0;
  tmp___20 = 0;
  tmp___22 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___31 = 0;
  tmp___39 = 0;
  tmp___44 = 0;
  tmp___49 = 0;
  tmp___57 = 0;
  code_length = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  tmp___66 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  tmp___70 = 0;
  tmp___71 = 0;
  tmp___72 = 0;
  tmp___73 = 0;
  tmp___74 = 0;
  tmp___75 = 0;
  tmp___76 = 0;
  tmp___77 = 0;
  tmp___78 = 0;
  tmp___79 = 0;
  tmp___80 = 0;
  tmp___81 = 0;
  tmp___82 = 0;
  tmp___83 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___91 = 0;
  tmp___99 = 0;
  value = 0;
  k = 0;
  tmp___104 = 0;
  tmp___106 = 0;
  tmp___107 = 0;
  tmp___108 = 0;
  tmp___109 = 0;
  tmp___110 = 0;
  tmp___111 = 0;
  tmp___112 = 0;
  tmp___113 = 0;
  tmp___114 = 0;
  tmp___115 = 0;
  tmp___116 = 0;
  tmp___121 = 0;
  tmp___148 = 0;
  tmp___149 = 0;
  tmp___150 = 0;
  tmp___151 = 0;
  tmp___152 = 0;
  tmp___153 = 0;
  tmp___154 = 0;
  tmp___155 = 0;
  tmp___156 = 0;
  tmp___157 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  tmp___161 = 0;
  tmp___162 = 0;
  tmp___163 = 0;
  tmp___164 = 0;
  tmp___165 = 0;
  tmp___166 = 0;
  tmp___167 = 0;
  tmp___168 = 0;
  tmp___170 = 0;
  tmp___171 = 0;
  tmp___172 = 0;
  tmp___174 = 0;
  tmp___175 = 0;
  tmp___177 = 0;
  tmp___201 = 0;
  tmp___202 = 0;
  tmp___203 = 0;
  tmp___204 = 0;
  tmp___205 = 0;
  tmp___206 = 0;
  tmp___207 = 0;
  tmp___208 = 0;
  tmp___209 = 0;
  tmp___210 = 0;
  tmp___211 = 0;
  tmp___212 = 0;
  tmp___213 = 0;
  tmp___214 = 0;
  tmp___215 = 0;
  tmp___216 = 0;
  tmp___217 = 0;
  tmp___218 = 0;
  tmp___219 = 0;
  tmp___220 = 0;
  tmp___221 = 0;
  tmp___223 = 0;
  tmp___224 = 0;
  tmp___229 = 0;
  tmp___234 = 0;
  tmp___247 = 0;
  tmp___248 = 0;
  tmp___249 = 0;
  tmp___250 = 0;
  tmp___251 = 0;
  tmp___252 = 0;
  tmp___253 = 0;
  tmp___254 = 0;
  tmp___255 = 0;
  tmp___256 = 0;
  tmp___258 = 0;
  tmp___259 = 0;
  tmp___272 = 0;
  tmp___273 = 0;
  tmp___274 = 0;
  tmp___275 = 0;
  tmp___276 = 0;
  tmp___277 = 0;
  tmp___278 = 0;
  tmp___279 = 0;
  tmp___280 = 0;
  tmp___281 = 0;
  tmp___283 = 0;
  tmp___284 = 0;
  tmp___286 = 0;
  tmp___288 = 0;
  tmp___289 = 0;
  tmp___290 = 0;
  tmp___292 = 0;
  tmp___293 = 0;
  tmp___295 = 0;
  tmp___296 = 0;
  tmp___298 = 0;
  tmp___299 = 0;
  tmp___301 = 0;
  tmp___302 = 0;
  whitespaces.pointer = (yaml_char_t *)((void *)0);
  tmp___1 = __dyc_funcallvar_1;
  string.start = (yaml_char_t *)tmp___1;
  if (string.start) {
    {
    string.pointer = string.start;
    string.end = string.start + 16;

    tmp___0 = 1;
    }
  } else {
    parser->error = 1;
    tmp___0 = 0;
  }
  if (! tmp___0) {
    goto __dyc_dummy_label;
  }
  tmp___4 = __dyc_funcallvar_2;
  leading_break.start = (yaml_char_t *)tmp___4;
  if (leading_break.start) {
    {
    leading_break.pointer = leading_break.start;
    leading_break.end = leading_break.start + 16;

    tmp___3 = 1;
    }
  } else {
    parser->error = 1;
    tmp___3 = 0;
  }
  if (! tmp___3) {
    goto __dyc_dummy_label;
  }
  tmp___7 = __dyc_funcallvar_3;
  trailing_breaks.start = (yaml_char_t *)tmp___7;
  if (trailing_breaks.start) {
    {
    trailing_breaks.pointer = trailing_breaks.start;
    trailing_breaks.end = trailing_breaks.start + 16;

    tmp___6 = 1;
    }
  } else {
    parser->error = 1;
    tmp___6 = 0;
  }
  if (! tmp___6) {
    goto __dyc_dummy_label;
  }
  tmp___10 = __dyc_funcallvar_4;
  whitespaces.start = (yaml_char_t *)tmp___10;
  if (whitespaces.start) {
    {
    whitespaces.pointer = whitespaces.start;
    whitespaces.end = whitespaces.start + 16;

    tmp___9 = 1;
    }
  } else {
    parser->error = 1;
    tmp___9 = 0;
  }
  if (! tmp___9) {
    goto __dyc_dummy_label;
  }
  start_mark = parser->mark;
  (parser->mark.index) ++;
  (parser->mark.column) ++;
  (parser->unread) --;
  if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
    tmp___15 = 1;
  } else {
    if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
      tmp___15 = 2;
    } else {
      if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
        tmp___15 = 3;
      } else {
        if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
          tmp___15 = 4;
        } else {
          tmp___15 = 0;
        }
      }
    }
  }
  parser->buffer.pointer += tmp___15;
  while (1) {
    while_25_continue:  ;
    if (parser->unread >= 4UL) {
      tmp___20 = 1;
    } else {
      {
      tmp___20 = __dyc_funcallvar_5;
      }
    }
    if (! tmp___20) {
      goto __dyc_dummy_label;
    }
    if (parser->mark.column == 0UL) {
      if ((int )*(parser->buffer.pointer + 0) == 45) {
        if ((int )*(parser->buffer.pointer + 1) == 45) {
          if ((int )*(parser->buffer.pointer + 2) == 45) {
            goto _L___4;
          } else {
            goto _L___6;
          }
        } else {
          goto _L___6;
        }
      } else {
        _L___6:  
        if ((int )*(parser->buffer.pointer + 0) == 46) {
          if ((int )*(parser->buffer.pointer + 1) == 46) {
            if ((int )*(parser->buffer.pointer + 2) == 46) {
              _L___4:  
              if ((int )*(parser->buffer.pointer + 3) == 32) {
                {

                }
                goto __dyc_dummy_label;
              } else {
                if ((int )*(parser->buffer.pointer + 3) == 9) {
                  {

                  }
                  goto __dyc_dummy_label;
                } else {
                  if ((int )*(parser->buffer.pointer + 3) == 13) {
                    {

                    }
                    goto __dyc_dummy_label;
                  } else {
                    if ((int )*(parser->buffer.pointer + 3) == 10) {
                      {

                      }
                      goto __dyc_dummy_label;
                    } else {
                      if ((int )*(parser->buffer.pointer + 3) == 194) {
                        if ((int )*(parser->buffer.pointer + 4) == 133) {
                          {

                          }
                          goto __dyc_dummy_label;
                        } else {
                          goto _L___3;
                        }
                      } else {
                        _L___3:  
                        if ((int )*(parser->buffer.pointer + 3) == 226) {
                          if ((int )*(parser->buffer.pointer + 4) == 128) {
                            if ((int )*(parser->buffer.pointer + 5) == 168) {
                              {

                              }
                              goto __dyc_dummy_label;
                            } else {
                              goto _L___2;
                            }
                          } else {
                            goto _L___2;
                          }
                        } else {
                          _L___2:  
                          if ((int )*(parser->buffer.pointer + 3) == 226) {
                            if ((int )*(parser->buffer.pointer + 4) == 128) {
                              if ((int )*(parser->buffer.pointer + 5) == 169) {
                                {

                                }
                                goto __dyc_dummy_label;
                              } else {
                                goto _L___0;
                              }
                            } else {
                              goto _L___0;
                            }
                          } else {
                            _L___0:  
                            if ((int )*(parser->buffer.pointer + 3) == 0) {
                              {

                              }
                              goto __dyc_dummy_label;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if ((int )*(parser->buffer.pointer + 0) == 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    if (parser->unread >= 2UL) {
      tmp___22 = 1;
    } else {
      {
      tmp___22 = __dyc_funcallvar_6;
      }
    }
    if (! tmp___22) {
      goto __dyc_dummy_label;
    }
    leading_blanks = 0;
    {
    while (1) {
      while_26_continue:  ;
      if ((int )*(parser->buffer.pointer + 0) == 32) {
        goto while_26_break;
      } else {
        if ((int )*(parser->buffer.pointer + 0) == 9) {
          goto while_26_break;
        } else {
          if ((int )*(parser->buffer.pointer + 0) == 13) {
            goto while_26_break;
          } else {
            if ((int )*(parser->buffer.pointer + 0) == 10) {
              goto while_26_break;
            } else {
              if ((int )*(parser->buffer.pointer + 0) == 194) {
                if ((int )*(parser->buffer.pointer + 1) == 133) {
                  goto while_26_break;
                } else {
                  goto _L___29;
                }
              } else {
                _L___29:  
                if ((int )*(parser->buffer.pointer + 0) == 226) {
                  if ((int )*(parser->buffer.pointer + 1) == 128) {
                    if ((int )*(parser->buffer.pointer + 2) == 168) {
                      goto while_26_break;
                    } else {
                      goto _L___28;
                    }
                  } else {
                    goto _L___28;
                  }
                } else {
                  _L___28:  
                  if ((int )*(parser->buffer.pointer + 0) == 226) {
                    if ((int )*(parser->buffer.pointer + 1) == 128) {
                      if ((int )*(parser->buffer.pointer + 2) == 169) {
                        goto while_26_break;
                      } else {
                        goto _L___26;
                      }
                    } else {
                      goto _L___26;
                    }
                  } else {
                    _L___26:  
                    if ((int )*(parser->buffer.pointer + 0) == 0) {
                      goto while_26_break;
                    }
                  }
                }
              }
            }
          }
        }
      }
      if (single) {
        if ((int )*(parser->buffer.pointer + 0) == 39) {
          if ((int )*(parser->buffer.pointer + 1) == 39) {
            if ((unsigned long )(string.pointer + 5) < (unsigned long )string.end) {
              tmp___24 = 1;
            } else {
              {
              tmp___25 = __dyc_funcallvar_7;
              }
              if (tmp___25) {
                tmp___24 = 1;
              } else {
                parser->error = 1;
                tmp___24 = 0;
              }
            }
            if (! tmp___24) {
              goto __dyc_dummy_label;
            }
            tmp___26 = string.pointer;
            (string.pointer) ++;
            *tmp___26 = (unsigned char )'\'';
            (parser->mark.index) ++;
            (parser->mark.column) ++;
            (parser->unread) --;
            if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
              tmp___31 = 1;
            } else {
              if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                tmp___31 = 2;
              } else {
                if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                  tmp___31 = 3;
                } else {
                  if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                    tmp___31 = 4;
                  } else {
                    tmp___31 = 0;
                  }
                }
              }
            }
            parser->buffer.pointer += tmp___31;
            (parser->mark.index) ++;
            (parser->mark.column) ++;
            (parser->unread) --;
            if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
              tmp___39 = 1;
            } else {
              if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                tmp___39 = 2;
              } else {
                if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                  tmp___39 = 3;
                } else {
                  if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                    tmp___39 = 4;
                  } else {
                    tmp___39 = 0;
                  }
                }
              }
            }
            parser->buffer.pointer += tmp___39;
          } else {
            goto _L___24;
          }
        } else {
          goto _L___24;
        }
      } else {
        _L___24:  
        if (single) {
          tmp___172 = '\'';
        } else {
          tmp___172 = '\"';
        }
        if ((int )*(parser->buffer.pointer + 0) == (int )((unsigned char )tmp___172)) {
          goto while_26_break;
        } else {
          if (! single) {
            if ((int )*(parser->buffer.pointer + 0) == 92) {
              if ((int )*(parser->buffer.pointer + 1) == 13) {
                goto _L___18;
              } else {
                if ((int )*(parser->buffer.pointer + 1) == 10) {
                  goto _L___18;
                } else {
                  if ((int )*(parser->buffer.pointer + 1) == 194) {
                    if ((int )*(parser->buffer.pointer + 2) == 133) {
                      goto _L___18;
                    } else {
                      goto _L___21;
                    }
                  } else {
                    _L___21:  
                    if ((int )*(parser->buffer.pointer + 1) == 226) {
                      if ((int )*(parser->buffer.pointer + 2) == 128) {
                        if ((int )*(parser->buffer.pointer + 3) == 168) {
                          goto _L___18;
                        } else {
                          goto _L___20;
                        }
                      } else {
                        goto _L___20;
                      }
                    } else {
                      _L___20:  
                      if ((int )*(parser->buffer.pointer + 1) == 226) {
                        if ((int )*(parser->buffer.pointer + 2) == 128) {
                          if ((int )*(parser->buffer.pointer + 3) == 169) {
                            _L___18:  
                            if (parser->unread >= 3UL) {
                              tmp___44 = 1;
                            } else {
                              {
                              tmp___44 = __dyc_funcallvar_8;
                              }
                            }
                            if (! tmp___44) {
                              goto __dyc_dummy_label;
                            }
                            (parser->mark.index) ++;
                            (parser->mark.column) ++;
                            (parser->unread) --;
                            if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
                              tmp___49 = 1;
                            } else {
                              if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                                tmp___49 = 2;
                              } else {
                                if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                                  tmp___49 = 3;
                                } else {
                                  if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                                    tmp___49 = 4;
                                  } else {
                                    tmp___49 = 0;
                                  }
                                }
                              }
                            }
                            parser->buffer.pointer += tmp___49;
                            if ((int )*(parser->buffer.pointer + 0) == 13) {
                              if ((int )*(parser->buffer.pointer + 1) == 10) {
                                parser->mark.index += 2UL;
                                parser->mark.column = 0UL;
                                (parser->mark.line) ++;
                                parser->unread -= 2UL;
                                parser->buffer.pointer += 2;
                              } else {
                                goto _L___11;
                              }
                            } else {
                              _L___11:  
                              if ((int )*(parser->buffer.pointer + 0) == 13) {
                                goto _L___7;
                              } else {
                                if ((int )*(parser->buffer.pointer + 0) == 10) {
                                  goto _L___7;
                                } else {
                                  if ((int )*(parser->buffer.pointer + 0) == 194) {
                                    if ((int )*(parser->buffer.pointer + 1) == 133) {
                                      goto _L___7;
                                    } else {
                                      goto _L___10;
                                    }
                                  } else {
                                    _L___10:  
                                    if ((int )*(parser->buffer.pointer + 0) == 226) {
                                      if ((int )*(parser->buffer.pointer + 1) == 128) {
                                        if ((int )*(parser->buffer.pointer + 2) == 168) {
                                          goto _L___7;
                                        } else {
                                          goto _L___9;
                                        }
                                      } else {
                                        goto _L___9;
                                      }
                                    } else {
                                      _L___9:  
                                      if ((int )*(parser->buffer.pointer + 0) == 226) {
                                        if ((int )*(parser->buffer.pointer + 1) == 128) {
                                          if ((int )*(parser->buffer.pointer + 2) == 169) {
                                            _L___7:  
                                            (parser->mark.index) ++;
                                            parser->mark.column = 0UL;
                                            (parser->mark.line) ++;
                                            (parser->unread) --;
                                            if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
                                              tmp___57 = 1;
                                            } else {
                                              if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                                                tmp___57 = 2;
                                              } else {
                                                if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                                                  tmp___57 = 3;
                                                } else {
                                                  if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                                                    tmp___57 = 4;
                                                  } else {
                                                    tmp___57 = 0;
                                                  }
                                                }
                                              }
                                            }
                                            parser->buffer.pointer += tmp___57;
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                            leading_blanks = 1;
                            goto while_26_break;
                          } else {
                            goto _L___22;
                          }
                        } else {
                          goto _L___22;
                        }
                      } else {
                        goto _L___22;
                      }
                    }
                  }
                }
              }
            } else {
              goto _L___22;
            }
          } else {
            _L___22:  
            if (! single) {
              if ((int )*(parser->buffer.pointer + 0) == 92) {
                code_length = (size_t )0;
                if ((unsigned long )(string.pointer + 5) < (unsigned long )string.end) {
                  tmp___62 = 1;
                } else {
                  {
                  tmp___63 = __dyc_funcallvar_9;
                  }
                  if (tmp___63) {
                    tmp___62 = 1;
                  } else {
                    parser->error = 1;
                    tmp___62 = 0;
                  }
                }
                if (! tmp___62) {
                  goto __dyc_dummy_label;
                }
                if ((int )*(parser->buffer.pointer + 1) == 48) {
                  goto switch_27_48;
                } else {
                  if ((int )*(parser->buffer.pointer + 1) == 97) {
                    goto switch_27_97;
                  } else {
                    if ((int )*(parser->buffer.pointer + 1) == 98) {
                      goto switch_27_98;
                    } else {
                      if ((int )*(parser->buffer.pointer + 1) == 116) {
                        goto switch_27_116;
                      } else {
                        if ((int )*(parser->buffer.pointer + 1) == 9) {
                          goto switch_27_116;
                        } else {
                          if ((int )*(parser->buffer.pointer + 1) == 110) {
                            goto switch_27_110;
                          } else {
                            if ((int )*(parser->buffer.pointer + 1) == 118) {
                              goto switch_27_118;
                            } else {
                              if ((int )*(parser->buffer.pointer + 1) == 102) {
                                goto switch_27_102;
                              } else {
                                if ((int )*(parser->buffer.pointer + 1) == 114) {
                                  goto switch_27_114;
                                } else {
                                  if ((int )*(parser->buffer.pointer + 1) == 101) {
                                    goto switch_27_101;
                                  } else {
                                    if ((int )*(parser->buffer.pointer + 1) == 32) {
                                      goto switch_27_32;
                                    } else {
                                      if ((int )*(parser->buffer.pointer + 1) == 34) {
                                        goto switch_27_34;
                                      } else {
                                        if ((int )*(parser->buffer.pointer + 1) == 39) {
                                          goto switch_27_39;
                                        } else {
                                          if ((int )*(parser->buffer.pointer + 1) == 92) {
                                            goto switch_27_92;
                                          } else {
                                            if ((int )*(parser->buffer.pointer + 1) == 78) {
                                              goto switch_27_78;
                                            } else {
                                              if ((int )*(parser->buffer.pointer + 1) == 95) {
                                                goto switch_27_95;
                                              } else {
                                                if ((int )*(parser->buffer.pointer + 1) == 76) {
                                                  goto switch_27_76;
                                                } else {
                                                  if ((int )*(parser->buffer.pointer + 1) == 80) {
                                                    goto switch_27_80;
                                                  } else {
                                                    if ((int )*(parser->buffer.pointer + 1) == 120) {
                                                      goto switch_27_120;
                                                    } else {
                                                      if ((int )*(parser->buffer.pointer + 1) == 117) {
                                                        goto switch_27_117;
                                                      } else {
                                                        if ((int )*(parser->buffer.pointer + 1) == 85) {
                                                          goto switch_27_85;
                                                        } else {
                                                          {
                                                          goto switch_27_default;
                                                          if (0) {
                                                            switch_27_48:  
                                                            tmp___64 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___64 = (unsigned char )'\000';
                                                            goto switch_27_break;
                                                            switch_27_97:  
                                                            tmp___65 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___65 = (unsigned char )'\a';
                                                            goto switch_27_break;
                                                            switch_27_98:  
                                                            tmp___66 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___66 = (unsigned char )'\b';
                                                            goto switch_27_break;
                                                            switch_27_116:  
                                                            switch_27_9:  
                                                            tmp___67 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___67 = (unsigned char )'\t';
                                                            goto switch_27_break;
                                                            switch_27_110:  
                                                            tmp___68 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___68 = (unsigned char )'\n';
                                                            goto switch_27_break;
                                                            switch_27_118:  
                                                            tmp___69 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___69 = (unsigned char )'\v';
                                                            goto switch_27_break;
                                                            switch_27_102:  
                                                            tmp___70 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___70 = (unsigned char )'\f';
                                                            goto switch_27_break;
                                                            switch_27_114:  
                                                            tmp___71 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___71 = (unsigned char )'\r';
                                                            goto switch_27_break;
                                                            switch_27_101:  
                                                            tmp___72 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___72 = (unsigned char )'\033';
                                                            goto switch_27_break;
                                                            switch_27_32:  
                                                            tmp___73 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___73 = (unsigned char )' ';
                                                            goto switch_27_break;
                                                            switch_27_34:  
                                                            tmp___74 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___74 = (unsigned char )'\"';
                                                            goto switch_27_break;
                                                            switch_27_39:  
                                                            tmp___75 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___75 = (unsigned char )'\'';
                                                            goto switch_27_break;
                                                            switch_27_92:  
                                                            tmp___76 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___76 = (unsigned char )'\\';
                                                            goto switch_27_break;
                                                            switch_27_78:  
                                                            tmp___77 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___77 = (unsigned char )'\302';
                                                            tmp___78 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___78 = (unsigned char )'\205';
                                                            goto switch_27_break;
                                                            switch_27_95:  
                                                            tmp___79 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___79 = (unsigned char )'\302';
                                                            tmp___80 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___80 = (unsigned char )'\240';
                                                            goto switch_27_break;
                                                            switch_27_76:  
                                                            tmp___81 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___81 = (unsigned char )'\342';
                                                            tmp___82 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___82 = (unsigned char )'\200';
                                                            tmp___83 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___83 = (unsigned char )'\250';
                                                            goto switch_27_break;
                                                            switch_27_80:  
                                                            tmp___84 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___84 = (unsigned char )'\342';
                                                            tmp___85 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___85 = (unsigned char )'\200';
                                                            tmp___86 = string.pointer;
                                                            (string.pointer) ++;
                                                            *tmp___86 = (unsigned char )'\251';
                                                            goto switch_27_break;
                                                            switch_27_120:  
                                                            code_length = 2UL;
                                                            goto switch_27_break;
                                                            switch_27_117:  
                                                            code_length = 4UL;
                                                            goto switch_27_break;
                                                            switch_27_85:  
                                                            code_length = 8UL;
                                                            goto switch_27_break;
                                                            switch_27_default:  
                                                            {

                                                            }
                                                            goto __dyc_dummy_label;
                                                          } else {
                                                            switch_27_break:  ;
                                                          }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                (parser->mark.index) ++;
                (parser->mark.column) ++;
                (parser->unread) --;
                if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
                  tmp___91 = 1;
                } else {
                  if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                    tmp___91 = 2;
                  } else {
                    if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                      tmp___91 = 3;
                    } else {
                      if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                        tmp___91 = 4;
                      } else {
                        tmp___91 = 0;
                      }
                    }
                  }
                }
                parser->buffer.pointer += tmp___91;
                (parser->mark.index) ++;
                (parser->mark.column) ++;
                (parser->unread) --;
                if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
                  tmp___99 = 1;
                } else {
                  if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                    tmp___99 = 2;
                  } else {
                    if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                      tmp___99 = 3;
                    } else {
                      if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                        tmp___99 = 4;
                      } else {
                        tmp___99 = 0;
                      }
                    }
                  }
                }
                parser->buffer.pointer += tmp___99;
                if (code_length) {
                  value = 0U;
                  if (parser->unread >= code_length) {
                    tmp___104 = 1;
                  } else {
                    {
                    tmp___104 = __dyc_funcallvar_10;
                    }
                  }
                  if (! tmp___104) {
                    goto __dyc_dummy_label;
                  }
                  k = 0UL;
                  {
                  while (1) {
                    while_28_continue:  ;
                    if (! (k < code_length)) {
                      goto while_28_break;
                    }
                    if ((int )*(parser->buffer.pointer + k) >= 48) {
                      if (! ((int )*(parser->buffer.pointer + k) <= 57)) {
                        goto _L___13;
                      }
                    } else {
                      _L___13:  
                      if ((int )*(parser->buffer.pointer + k) >= 65) {
                        if (! ((int )*(parser->buffer.pointer + k) <= 70)) {
                          goto _L___12;
                        }
                      } else {
                        _L___12:  
                        if ((int )*(parser->buffer.pointer + k) >= 97) {
                          if (! ((int )*(parser->buffer.pointer + k) <= 102)) {
                            {

                            }
                            goto __dyc_dummy_label;
                          }
                        } else {
                          {

                          }
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                    if ((int )*(parser->buffer.pointer + k) >= 65) {
                      if ((int )*(parser->buffer.pointer + k) <= 70) {
                        tmp___106 = ((int )*(parser->buffer.pointer + k) - 65) + 10;
                      } else {
                        goto _L___14;
                      }
                    } else {
                      _L___14:  
                      if ((int )*(parser->buffer.pointer + k) >= 97) {
                        if ((int )*(parser->buffer.pointer + k) <= 102) {
                          tmp___106 = ((int )*(parser->buffer.pointer + k) - 97) + 10;
                        } else {
                          tmp___106 = (int )*(parser->buffer.pointer + k) - 48;
                        }
                      } else {
                        tmp___106 = (int )*(parser->buffer.pointer + k) - 48;
                      }
                    }
                    value = (value << 4) + (unsigned int )tmp___106;
                    k ++;
                  }
                  while_28_break:  ;
                  }
                  if (value >= 55296U) {
                    if (value <= 57343U) {
                      {

                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___15;
                    }
                  } else {
                    _L___15:  
                    if (value > 1114111U) {
                      {

                      }
                      goto __dyc_dummy_label;
                    }
                  }
                  if (value <= 127U) {
                    tmp___107 = string.pointer;
                    (string.pointer) ++;
                    *tmp___107 = (unsigned char )value;
                  } else {
                    if (value <= 2047U) {
                      tmp___108 = string.pointer;
                      (string.pointer) ++;
                      *tmp___108 = (unsigned char )(192U + (value >> 6));
                      tmp___109 = string.pointer;
                      (string.pointer) ++;
                      *tmp___109 = (unsigned char )(128U + (value & 63U));
                    } else {
                      if (value <= 65535U) {
                        tmp___110 = string.pointer;
                        (string.pointer) ++;
                        *tmp___110 = (unsigned char )(224U + (value >> 12));
                        tmp___111 = string.pointer;
                        (string.pointer) ++;
                        *tmp___111 = (unsigned char )(128U + ((value >> 6) & 63U));
                        tmp___112 = string.pointer;
                        (string.pointer) ++;
                        *tmp___112 = (unsigned char )(128U + (value & 63U));
                      } else {
                        tmp___113 = string.pointer;
                        (string.pointer) ++;
                        *tmp___113 = (unsigned char )(240U + (value >> 18));
                        tmp___114 = string.pointer;
                        (string.pointer) ++;
                        *tmp___114 = (unsigned char )(128U + ((value >> 12) & 63U));
                        tmp___115 = string.pointer;
                        (string.pointer) ++;
                        *tmp___115 = (unsigned char )(128U + ((value >> 6) & 63U));
                        tmp___116 = string.pointer;
                        (string.pointer) ++;
                        *tmp___116 = (unsigned char )(128U + (value & 63U));
                      }
                    }
                  }
                  k = 0UL;
                  {
                  while (1) {
                    while_29_continue:  ;
                    if (! (k < code_length)) {
                      goto while_29_break;
                    }
                    (parser->mark.index) ++;
                    (parser->mark.column) ++;
                    (parser->unread) --;
                    if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
                      tmp___121 = 1;
                    } else {
                      if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                        tmp___121 = 2;
                      } else {
                        if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                          tmp___121 = 3;
                        } else {
                          if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                            tmp___121 = 4;
                          } else {
                            tmp___121 = 0;
                          }
                        }
                      }
                    }
                    parser->buffer.pointer += tmp___121;
                    k ++;
                  }
                  while_29_break:  ;
                  }
                }
              } else {
                goto _L___16;
              }
            } else {
              _L___16:  
              if ((unsigned long )(string.pointer + 5) < (unsigned long )string.end) {
                tmp___170 = 1;
              } else {
                {
                tmp___171 = __dyc_funcallvar_11;
                }
                if (tmp___171) {
                  tmp___170 = 1;
                } else {
                  parser->error = 1;
                  tmp___170 = 0;
                }
              }
              if (tmp___170) {
                if (((int )*(parser->buffer.pointer) & 128) == 0) {
                  tmp___167 = string.pointer;
                  (string.pointer) ++;
                  tmp___168 = parser->buffer.pointer;
                  (parser->buffer.pointer) ++;
                  *tmp___167 = *tmp___168;
                } else {
                  if (((int )*(parser->buffer.pointer) & 224) == 192) {
                    tmp___163 = string.pointer;
                    (string.pointer) ++;
                    tmp___164 = parser->buffer.pointer;
                    (parser->buffer.pointer) ++;
                    *tmp___163 = *tmp___164;
                    tmp___165 = string.pointer;
                    (string.pointer) ++;
                    tmp___166 = parser->buffer.pointer;
                    (parser->buffer.pointer) ++;
                    *tmp___165 = *tmp___166;
                  } else {
                    if (((int )*(parser->buffer.pointer) & 240) == 224) {
                      tmp___157 = string.pointer;
                      (string.pointer) ++;
                      tmp___158 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___157 = *tmp___158;
                      tmp___159 = string.pointer;
                      (string.pointer) ++;
                      tmp___160 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___159 = *tmp___160;
                      tmp___161 = string.pointer;
                      (string.pointer) ++;
                      tmp___162 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___161 = *tmp___162;
                    } else {
                      if (((int )*(parser->buffer.pointer) & 248) == 240) {
                        tmp___149 = string.pointer;
                        (string.pointer) ++;
                        tmp___150 = parser->buffer.pointer;
                        (parser->buffer.pointer) ++;
                        *tmp___149 = *tmp___150;
                        tmp___151 = string.pointer;
                        (string.pointer) ++;
                        tmp___152 = parser->buffer.pointer;
                        (parser->buffer.pointer) ++;
                        *tmp___151 = *tmp___152;
                        tmp___153 = string.pointer;
                        (string.pointer) ++;
                        tmp___154 = parser->buffer.pointer;
                        (parser->buffer.pointer) ++;
                        *tmp___153 = *tmp___154;
                        tmp___155 = string.pointer;
                        (string.pointer) ++;
                        tmp___156 = parser->buffer.pointer;
                        (parser->buffer.pointer) ++;
                        *tmp___155 = *tmp___156;
                      }
                    }
                  }
                }
                (parser->mark.index) ++;
                (parser->mark.column) ++;
                (parser->unread) --;
                tmp___148 = 1;
              } else {
                tmp___148 = 0;
              }
              if (! tmp___148) {
                goto __dyc_dummy_label;
              }
            }
          }
        }
      }
      if (parser->unread >= 2UL) {
        tmp___174 = 1;
      } else {
        {
        tmp___174 = __dyc_funcallvar_12;
        }
      }
      if (! tmp___174) {
        goto __dyc_dummy_label;
      }
    }
    while_26_break:  ;
    }
    if (single) {
      tmp___175 = '\'';
    } else {
      tmp___175 = '\"';
    }
    if ((int )*(parser->buffer.pointer + 0) == (int )((unsigned char )tmp___175)) {
      goto __dyc_dummy_label;
    }
    if (parser->unread >= 1UL) {
      tmp___177 = 1;
    } else {
      {
      tmp___177 = __dyc_funcallvar_13;
      }
    }
    if (! tmp___177) {
      goto __dyc_dummy_label;
    }
    {
    while (1) {
      while_30_continue:  ;
      if (! ((int )*(parser->buffer.pointer + 0) == 32)) {
        if (! ((int )*(parser->buffer.pointer + 0) == 9)) {
          if (! ((int )*(parser->buffer.pointer + 0) == 13)) {
            if (! ((int )*(parser->buffer.pointer + 0) == 10)) {
              if ((int )*(parser->buffer.pointer + 0) == 194) {
                if (! ((int )*(parser->buffer.pointer + 1) == 133)) {
                  goto _L___49;
                }
              } else {
                _L___49:  
                if ((int )*(parser->buffer.pointer + 0) == 226) {
                  if ((int )*(parser->buffer.pointer + 1) == 128) {
                    if (! ((int )*(parser->buffer.pointer + 2) == 168)) {
                      goto _L___48;
                    }
                  } else {
                    goto _L___48;
                  }
                } else {
                  _L___48:  
                  if ((int )*(parser->buffer.pointer + 0) == 226) {
                    if ((int )*(parser->buffer.pointer + 1) == 128) {
                      if (! ((int )*(parser->buffer.pointer + 2) == 169)) {
                        goto while_30_break;
                      }
                    } else {
                      goto while_30_break;
                    }
                  } else {
                    goto while_30_break;
                  }
                }
              }
            }
          }
        }
      }
      if ((int )*(parser->buffer.pointer + 0) == 32) {
        goto _L___46;
      } else {
        if ((int )*(parser->buffer.pointer + 0) == 9) {
          _L___46:  
          if (! leading_blanks) {
            if ((unsigned long )(whitespaces.pointer + 5) < (unsigned long )whitespaces.end) {
              tmp___223 = 1;
            } else {
              {
              tmp___224 = __dyc_funcallvar_14;
              }
              if (tmp___224) {
                tmp___223 = 1;
              } else {
                parser->error = 1;
                tmp___223 = 0;
              }
            }
            if (tmp___223) {
              if (((int )*(parser->buffer.pointer) & 128) == 0) {
                tmp___220 = whitespaces.pointer;
                (whitespaces.pointer) ++;
                tmp___221 = parser->buffer.pointer;
                (parser->buffer.pointer) ++;
                *tmp___220 = *tmp___221;
              } else {
                if (((int )*(parser->buffer.pointer) & 224) == 192) {
                  tmp___216 = whitespaces.pointer;
                  (whitespaces.pointer) ++;
                  tmp___217 = parser->buffer.pointer;
                  (parser->buffer.pointer) ++;
                  *tmp___216 = *tmp___217;
                  tmp___218 = whitespaces.pointer;
                  (whitespaces.pointer) ++;
                  tmp___219 = parser->buffer.pointer;
                  (parser->buffer.pointer) ++;
                  *tmp___218 = *tmp___219;
                } else {
                  if (((int )*(parser->buffer.pointer) & 240) == 224) {
                    tmp___210 = whitespaces.pointer;
                    (whitespaces.pointer) ++;
                    tmp___211 = parser->buffer.pointer;
                    (parser->buffer.pointer) ++;
                    *tmp___210 = *tmp___211;
                    tmp___212 = whitespaces.pointer;
                    (whitespaces.pointer) ++;
                    tmp___213 = parser->buffer.pointer;
                    (parser->buffer.pointer) ++;
                    *tmp___212 = *tmp___213;
                    tmp___214 = whitespaces.pointer;
                    (whitespaces.pointer) ++;
                    tmp___215 = parser->buffer.pointer;
                    (parser->buffer.pointer) ++;
                    *tmp___214 = *tmp___215;
                  } else {
                    if (((int )*(parser->buffer.pointer) & 248) == 240) {
                      tmp___202 = whitespaces.pointer;
                      (whitespaces.pointer) ++;
                      tmp___203 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___202 = *tmp___203;
                      tmp___204 = whitespaces.pointer;
                      (whitespaces.pointer) ++;
                      tmp___205 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___204 = *tmp___205;
                      tmp___206 = whitespaces.pointer;
                      (whitespaces.pointer) ++;
                      tmp___207 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___206 = *tmp___207;
                      tmp___208 = whitespaces.pointer;
                      (whitespaces.pointer) ++;
                      tmp___209 = parser->buffer.pointer;
                      (parser->buffer.pointer) ++;
                      *tmp___208 = *tmp___209;
                    }
                  }
                }
              }
              (parser->mark.index) ++;
              (parser->mark.column) ++;
              (parser->unread) --;
              tmp___201 = 1;
            } else {
              tmp___201 = 0;
            }
            if (! tmp___201) {
              goto __dyc_dummy_label;
            }
          } else {
            (parser->mark.index) ++;
            (parser->mark.column) ++;
            (parser->unread) --;
            if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
              tmp___229 = 1;
            } else {
              if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
                tmp___229 = 2;
              } else {
                if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
                  tmp___229 = 3;
                } else {
                  if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
                    tmp___229 = 4;
                  } else {
                    tmp___229 = 0;
                  }
                }
              }
            }
            parser->buffer.pointer += tmp___229;
          }
        } else {
          if (parser->unread >= 2UL) {
            tmp___234 = 1;
          } else {
            {
            tmp___234 = __dyc_funcallvar_15;
            }
          }
          if (! tmp___234) {
            goto __dyc_dummy_label;
          }
          if (! leading_blanks) {
            {
            whitespaces.pointer = whitespaces.start;

            }
            if ((unsigned long )(leading_break.pointer + 5) < (unsigned long )leading_break.end) {
              tmp___258 = 1;
            } else {
              {
              tmp___259 = __dyc_funcallvar_16;
              }
              if (tmp___259) {
                tmp___258 = 1;
              } else {
                parser->error = 1;
                tmp___258 = 0;
              }
            }
            if (tmp___258) {
              if ((int )*(parser->buffer.pointer + 0) == 13) {
                if ((int )*(parser->buffer.pointer + 1) == 10) {
                  tmp___256 = leading_break.pointer;
                  (leading_break.pointer) ++;
                  *tmp___256 = (unsigned char )'\n';
                  parser->buffer.pointer += 2;
                  parser->mark.index += 2UL;
                  parser->mark.column = 0UL;
                  (parser->mark.line) ++;
                  parser->unread -= 2UL;
                } else {
                  goto _L___37;
                }
              } else {
                _L___37:  
                if ((int )*(parser->buffer.pointer + 0) == 13) {
                  goto _L___36;
                } else {
                  if ((int )*(parser->buffer.pointer + 0) == 10) {
                    _L___36:  
                    tmp___255 = leading_break.pointer;
                    (leading_break.pointer) ++;
                    *tmp___255 = (unsigned char )'\n';
                    (parser->buffer.pointer) ++;
                    (parser->mark.index) ++;
                    parser->mark.column = 0UL;
                    (parser->mark.line) ++;
                    (parser->unread) --;
                  } else {
                    if ((int )*(parser->buffer.pointer + 0) == 194) {
                      if ((int )*(parser->buffer.pointer + 1) == 133) {
                        tmp___254 = leading_break.pointer;
                        (leading_break.pointer) ++;
                        *tmp___254 = (unsigned char )'\n';
                        parser->buffer.pointer += 2;
                        (parser->mark.index) ++;
                        parser->mark.column = 0UL;
                        (parser->mark.line) ++;
                        (parser->unread) --;
                      } else {
                        goto _L___35;
                      }
                    } else {
                      _L___35:  
                      if ((int )*(parser->buffer.pointer + 0) == 226) {
                        if ((int )*(parser->buffer.pointer + 1) == 128) {
                          if ((int )*(parser->buffer.pointer + 2) == 168) {
                            goto _L___34;
                          } else {
                            if ((int )*(parser->buffer.pointer + 2) == 169) {
                              _L___34:  
                              tmp___248 = leading_break.pointer;
                              (leading_break.pointer) ++;
                              tmp___249 = parser->buffer.pointer;
                              (parser->buffer.pointer) ++;
                              *tmp___248 = *tmp___249;
                              tmp___250 = leading_break.pointer;
                              (leading_break.pointer) ++;
                              tmp___251 = parser->buffer.pointer;
                              (parser->buffer.pointer) ++;
                              *tmp___250 = *tmp___251;
                              tmp___252 = leading_break.pointer;
                              (leading_break.pointer) ++;
                              tmp___253 = parser->buffer.pointer;
                              (parser->buffer.pointer) ++;
                              *tmp___252 = *tmp___253;
                              (parser->mark.index) ++;
                              parser->mark.column = 0UL;
                              (parser->mark.line) ++;
                              (parser->unread) --;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              tmp___247 = 1;
            } else {
              tmp___247 = 0;
            }
            if (! tmp___247) {
              goto __dyc_dummy_label;
            }
            leading_blanks = 1;
          } else {
            if ((unsigned long )(trailing_breaks.pointer + 5) < (unsigned long )trailing_breaks.end) {
              tmp___283 = 1;
            } else {
              {
              tmp___284 = __dyc_funcallvar_17;
              }
              if (tmp___284) {
                tmp___283 = 1;
              } else {
                parser->error = 1;
                tmp___283 = 0;
              }
            }
            if (tmp___283) {
              if ((int )*(parser->buffer.pointer + 0) == 13) {
                if ((int )*(parser->buffer.pointer + 1) == 10) {
                  tmp___281 = trailing_breaks.pointer;
                  (trailing_breaks.pointer) ++;
                  *tmp___281 = (unsigned char )'\n';
                  parser->buffer.pointer += 2;
                  parser->mark.index += 2UL;
                  parser->mark.column = 0UL;
                  (parser->mark.line) ++;
                  parser->unread -= 2UL;
                } else {
                  goto _L___45;
                }
              } else {
                _L___45:  
                if ((int )*(parser->buffer.pointer + 0) == 13) {
                  goto _L___44;
                } else {
                  if ((int )*(parser->buffer.pointer + 0) == 10) {
                    _L___44:  
                    tmp___280 = trailing_breaks.pointer;
                    (trailing_breaks.pointer) ++;
                    *tmp___280 = (unsigned char )'\n';
                    (parser->buffer.pointer) ++;
                    (parser->mark.index) ++;
                    parser->mark.column = 0UL;
                    (parser->mark.line) ++;
                    (parser->unread) --;
                  } else {
                    if ((int )*(parser->buffer.pointer + 0) == 194) {
                      if ((int )*(parser->buffer.pointer + 1) == 133) {
                        tmp___279 = trailing_breaks.pointer;
                        (trailing_breaks.pointer) ++;
                        *tmp___279 = (unsigned char )'\n';
                        parser->buffer.pointer += 2;
                        (parser->mark.index) ++;
                        parser->mark.column = 0UL;
                        (parser->mark.line) ++;
                        (parser->unread) --;
                      } else {
                        goto _L___43;
                      }
                    } else {
                      _L___43:  
                      if ((int )*(parser->buffer.pointer + 0) == 226) {
                        if ((int )*(parser->buffer.pointer + 1) == 128) {
                          if ((int )*(parser->buffer.pointer + 2) == 168) {
                            goto _L___42;
                          } else {
                            if ((int )*(parser->buffer.pointer + 2) == 169) {
                              _L___42:  
                              tmp___273 = trailing_breaks.pointer;
                              (trailing_breaks.pointer) ++;
                              tmp___274 = parser->buffer.pointer;
                              (parser->buffer.pointer) ++;
                              *tmp___273 = *tmp___274;
                              tmp___275 = trailing_breaks.pointer;
                              (trailing_breaks.pointer) ++;
                              tmp___276 = parser->buffer.pointer;
                              (parser->buffer.pointer) ++;
                              *tmp___275 = *tmp___276;
                              tmp___277 = trailing_breaks.pointer;
                              (trailing_breaks.pointer) ++;
                              tmp___278 = parser->buffer.pointer;
                              (parser->buffer.pointer) ++;
                              *tmp___277 = *tmp___278;
                              (parser->mark.index) ++;
                              parser->mark.column = 0UL;
                              (parser->mark.line) ++;
                              (parser->unread) --;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              tmp___272 = 1;
            } else {
              tmp___272 = 0;
            }
            if (! tmp___272) {
              goto __dyc_dummy_label;
            }
          }
        }
      }
      if (parser->unread >= 1UL) {
        tmp___286 = 1;
      } else {
        {
        tmp___286 = __dyc_funcallvar_18;
        }
      }
      if (! tmp___286) {
        goto __dyc_dummy_label;
      }
    }
    while_30_break:  ;
    }
    if (leading_blanks) {
      if ((int )*(leading_break.start + 0) == 10) {
        if ((int )*(trailing_breaks.start + 0) == 0) {
          if ((unsigned long )(string.pointer + 5) < (unsigned long )string.end) {
            tmp___288 = 1;
          } else {
            {
            tmp___289 = __dyc_funcallvar_19;
            }
            if (tmp___289) {
              tmp___288 = 1;
            } else {
              parser->error = 1;
              tmp___288 = 0;
            }
          }
          if (! tmp___288) {
            goto __dyc_dummy_label;
          }
          tmp___290 = string.pointer;
          (string.pointer) ++;
          *tmp___290 = (unsigned char )' ';
        } else {
          {
          tmp___293 = __dyc_funcallvar_20;
          }
          if (tmp___293) {
            trailing_breaks.pointer = trailing_breaks.start;
            tmp___292 = 1;
          } else {
            parser->error = 1;
            tmp___292 = 0;
          }
          if (! tmp___292) {
            goto __dyc_dummy_label;
          }
          {
          trailing_breaks.pointer = trailing_breaks.start;

          }
        }
        {
        leading_break.pointer = leading_break.start;

        }
      } else {
        {
        tmp___296 = __dyc_funcallvar_21;
        }
        if (tmp___296) {
          leading_break.pointer = leading_break.start;
          tmp___295 = 1;
        } else {
          parser->error = 1;
          tmp___295 = 0;
        }
        if (! tmp___295) {
          goto __dyc_dummy_label;
        }
        {
        tmp___299 = __dyc_funcallvar_22;
        }
        if (tmp___299) {
          trailing_breaks.pointer = trailing_breaks.start;
          tmp___298 = 1;
        } else {
          parser->error = 1;
          tmp___298 = 0;
        }
        if (! tmp___298) {
          goto __dyc_dummy_label;
        }
        {
        leading_break.pointer = leading_break.start;

        trailing_breaks.pointer = trailing_breaks.start;

        }
      }
    } else {
      {
      tmp___302 = __dyc_funcallvar_23;
      }
      if (tmp___302) {
        whitespaces.pointer = whitespaces.start;
        tmp___301 = 1;
      } else {
        parser->error = 1;
        tmp___301 = 0;
      }
      if (! tmp___301) {
        goto __dyc_dummy_label;
      }
      {
      whitespaces.pointer = whitespaces.start;

      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_43yaml_mark_s(start_mark);
  __dyc_print_comp_101__anonstruct_yaml_string_t_74(string);
  __dyc_print_comp_101__anonstruct_yaml_string_t_74(leading_break);
  __dyc_print_comp_101__anonstruct_yaml_string_t_74(trailing_breaks);
  __dyc_print_comp_101__anonstruct_yaml_string_t_74(whitespaces);
  __dyc_printpre_byte(leading_blanks);
  __dyc_printpre_byte(code_length);
  __dyc_printpre_byte(value);
}
}
