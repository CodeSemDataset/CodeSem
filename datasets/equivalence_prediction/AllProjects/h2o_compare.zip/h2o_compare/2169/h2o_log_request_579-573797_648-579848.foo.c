#include "../include/dycfoo.h"
#include "../include/logconf.i.hd.c.h"
void __dyc_foo(void) 
{ char *line ;
  char *pos ;
  char *line_end ;
  size_t unsafe_factor ;
  struct tm localt ;
  int should_realloc_on_expand ;
  struct log_element_t *element ;
  char *tmp___3 ;
  size_t tmp___4 ;
  size_t off___10 ;
  size_t size___10 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  size_t off___11 ;
  size_t size___11 ;
  char *tmp___8 ;
  char *tmp___9 ;
  int tmp___10 ;
  size_t bufsz ;
  size_t len___1 ;
  size_t off___12 ;
  size_t size___12 ;
  int tmp___11 ;
  size_t off___13 ;
  size_t size___13 ;
  int tmp___12 ;
  int tmp___13 ;
  size_t off___14 ;
  size_t size___14 ;
  int tmp___14 ;
  int tmp___15 ;
  size_t off___15 ;
  size_t size___15 ;
  int tmp___16 ;
  int tmp___17 ;
  size_t off___16 ;
  size_t size___16 ;
  int tmp___18 ;
  int tmp___19 ;
  size_t off___17 ;
  size_t size___17 ;
  int tmp___20 ;
  size_t path_len ;
  size_t tmp___21 ;
  size_t off___18 ;
  size_t size___18 ;
  h2o_iovec_t *remote_user ;
  h2o_iovec_t *tmp___22 ;
  h2o_req_t *req ;
  char *__dyc_funcallvar_25 ;
  size_t __dyc_funcallvar_26 ;
  char *__dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  char *__dyc_funcallvar_30 ;
  char *__dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  char *__dyc_funcallvar_33 ;
  size_t __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  char *__dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  char *__dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  char *__dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  char *__dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  char *__dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  char *__dyc_funcallvar_50 ;
  char *__dyc_funcallvar_51 ;
  h2o_iovec_t *__dyc_funcallvar_52 ;

  {
  line = __dyc_read_ptr__char();
  pos = __dyc_read_ptr__char();
  line_end = __dyc_read_ptr__char();
  unsafe_factor = (size_t )__dyc_readpre_byte();
  localt = __dyc_read_comp_68tm();
  element = __dyc_read_ptr__comp_477log_element_t();
  req = __dyc_read_ptr__typdef_h2o_req_t();
  __dyc_funcallvar_25 = __dyc_read_ptr__char();
  __dyc_funcallvar_26 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_read_ptr__char();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_read_ptr__char();
  __dyc_funcallvar_31 = __dyc_read_ptr__char();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_read_ptr__char();
  __dyc_funcallvar_34 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_read_ptr__char();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_read_ptr__char();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_read_ptr__char();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_read_ptr__char();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_read_ptr__char();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_read_ptr__char();
  __dyc_funcallvar_51 = __dyc_read_ptr__char();
  __dyc_funcallvar_52 = __dyc_read_ptr__typdef_h2o_iovec_t();
  should_realloc_on_expand = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  off___10 = 0;
  size___10 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  off___11 = 0;
  size___11 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  bufsz = 0;
  len___1 = 0;
  off___12 = 0;
  size___12 = 0;
  tmp___11 = 0;
  off___13 = 0;
  size___13 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  off___14 = 0;
  size___14 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  off___15 = 0;
  size___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  off___16 = 0;
  size___16 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  off___17 = 0;
  size___17 = 0;
  tmp___20 = 0;
  path_len = 0;
  tmp___21 = 0;
  off___18 = 0;
  size___18 = 0;
  remote_user = 0;
  tmp___22 = 0;
  pos = __dyc_funcallvar_25;
  tmp___3 = pos;
  pos ++;
  *tmp___3 = (char )' ';
  tmp___4 = __dyc_funcallvar_26;
  pos += tmp___4;
  goto __dyc_dummy_label;
  while (1) {
    while_67_continue:  ;
    if ((sizeof("-2147483648") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___10 = (size_t )(pos - line);
      size___10 = (size_t )(line_end - line);
      line = __dyc_funcallvar_27;
      pos = line + off___10;
      line_end = line + size___10;
      should_realloc_on_expand = 1;
      }
    }
    goto while_67_break;
  }
  while_67_break:  ;
  if (element->original_response) {
    tmp___5 = req->res.original.status;
  } else {
    tmp___5 = req->res.status;
  }
  tmp___6 = __dyc_funcallvar_28;
  pos += tmp___6;
  goto __dyc_dummy_label;
  tmp___7 = __dyc_funcallvar_29;
  if (tmp___7) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_68_continue:  ;
    if (((sizeof("29/Aug/2014:15:34:38 +0900") - 1UL) + 2UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___11 = (size_t )(pos - line);
      size___11 = (size_t )(line_end - line);
      line = __dyc_funcallvar_30;
      pos = line + off___11;
      line_end = line + size___11;
      should_realloc_on_expand = 1;
      }
    }
    goto while_68_break;
  }
  while_68_break:  ;
  tmp___8 = pos;
  pos ++;
  *tmp___8 = (char )'[';
  pos = __dyc_funcallvar_31;
  tmp___9 = pos;
  pos ++;
  *tmp___9 = (char )']';
  goto __dyc_dummy_label;
  tmp___10 = __dyc_funcallvar_32;
  if (tmp___10) {
    goto __dyc_dummy_label;
  }
  if (localt.tm_year == 0) {
    {

    }
  }
  bufsz = 128UL;
  while (1) {
    while_69_continue:  ;
    {
    while (1) {
      while_70_continue:  ;
      if (bufsz + element->suffix.len > (size_t )(line_end - pos)) {
        {
        off___12 = (size_t )(pos - line);
        size___12 = (size_t )(line_end - line);
        line = __dyc_funcallvar_33;
        pos = line + off___12;
        line_end = line + size___12;
        should_realloc_on_expand = 1;
        }
      }
      goto while_70_break;
    }
    while_70_break:  ;
    }
    {
    len___1 = __dyc_funcallvar_34;
    }
    if (len___1 != 0UL) {
      goto while_69_break;
    }
    bufsz *= 2UL;
  }
  while_69_break:  ;
  pos += len___1;
  goto __dyc_dummy_label;
  tmp___11 = __dyc_funcallvar_35;
  if (tmp___11) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_71_continue:  ;
    if ((sizeof("4294967295") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___13 = (size_t )(pos - line);
      size___13 = (size_t )(line_end - line);
      line = __dyc_funcallvar_36;
      pos = line + off___13;
      line_end = line + size___13;
      should_realloc_on_expand = 1;
      }
    }
    goto while_71_break;
  }
  while_71_break:  ;
  tmp___12 = __dyc_funcallvar_37;
  pos += tmp___12;
  goto __dyc_dummy_label;
  tmp___13 = __dyc_funcallvar_38;
  if (tmp___13) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_72_continue:  ;
    if ((sizeof("18446744073709551615") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___14 = (size_t )(pos - line);
      size___14 = (size_t )(line_end - line);
      line = __dyc_funcallvar_39;
      pos = line + off___14;
      line_end = line + size___14;
      should_realloc_on_expand = 1;
      }
    }
    goto while_72_break;
  }
  while_72_break:  ;
  tmp___14 = __dyc_funcallvar_40;
  pos += tmp___14;
  goto __dyc_dummy_label;
  tmp___15 = __dyc_funcallvar_41;
  if (tmp___15) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_73_continue:  ;
    if ((sizeof("18446744073709551615") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___15 = (size_t )(pos - line);
      size___15 = (size_t )(line_end - line);
      line = __dyc_funcallvar_42;
      pos = line + off___15;
      line_end = line + size___15;
      should_realloc_on_expand = 1;
      }
    }
    goto while_73_break;
  }
  while_73_break:  ;
  tmp___16 = __dyc_funcallvar_43;
  pos += tmp___16;
  goto __dyc_dummy_label;
  tmp___17 = __dyc_funcallvar_44;
  if (tmp___17) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_74_continue:  ;
    if (3UL + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___16 = (size_t )(pos - line);
      size___16 = (size_t )(line_end - line);
      line = __dyc_funcallvar_45;
      pos = line + off___16;
      line_end = line + size___16;
      should_realloc_on_expand = 1;
      }
    }
    goto while_74_break;
  }
  while_74_break:  ;
  tmp___18 = __dyc_funcallvar_46;
  pos += tmp___18;
  goto __dyc_dummy_label;
  tmp___19 = __dyc_funcallvar_47;
  if (tmp___19) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_75_continue:  ;
    if (6UL + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___17 = (size_t )(pos - line);
      size___17 = (size_t )(line_end - line);
      line = __dyc_funcallvar_48;
      pos = line + off___17;
      line_end = line + size___17;
      should_realloc_on_expand = 1;
      }
    }
    goto while_75_break;
  }
  while_75_break:  ;
  tmp___20 = __dyc_funcallvar_49;
  pos += tmp___20;
  goto __dyc_dummy_label;
  switch_55_20:  
  if (req->input.query_at == 0xffffffffUL) {
    tmp___21 = req->input.path.len;
  } else {
    tmp___21 = req->input.query_at;
  }
  path_len = tmp___21;
  while (1) {
    while_76_continue:  ;
    if (path_len * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___18 = (size_t )(pos - line);
      size___18 = (size_t )(line_end - line);
      line = __dyc_funcallvar_50;
      pos = line + off___18;
      line_end = line + size___18;
      should_realloc_on_expand = 1;
      }
    }
    goto while_76_break;
  }
  while_76_break:  ;
  pos = __dyc_funcallvar_51;
  goto __dyc_dummy_label;
  tmp___22 = __dyc_funcallvar_52;
  remote_user = tmp___22;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(pos);
  __dyc_print_ptr__char(line_end);
  __dyc_printpre_byte(should_realloc_on_expand);
  __dyc_printpre_byte(tmp___5);
  __dyc_print_ptr__typdef_h2o_iovec_t(remote_user);
}
}
