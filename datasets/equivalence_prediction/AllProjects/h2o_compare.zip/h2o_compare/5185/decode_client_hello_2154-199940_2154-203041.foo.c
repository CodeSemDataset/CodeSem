#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ uint16_t const   supported_versions[3] ;
  int ret ;
  uint8_t const   *end___4 ;
  size_t _capacity___4 ;
  size_t _block_size___4 ;
  uint8_t const   *tmp___5 ;
  uint8_t const   *end___5 ;
  size_t _capacity___5 ;
  size_t _block_size___5 ;
  uint8_t const   *tmp___6 ;
  uint8_t const   *end___6 ;
  size_t tmp___7 ;
  size_t _capacity___6 ;
  size_t _block_size___6 ;
  uint8_t const   *tmp___8 ;
  uint8_t const   *end___7 ;
  uint16_t id ;
  size_t tmp___9 ;
  size_t _capacity___7 ;
  size_t _block_size___7 ;
  uint8_t const   *tmp___10 ;
  uint8_t const   *end___8 ;
  size_t selected_index ;
  size_t i ;
  uint16_t v ;
  size_t _capacity___8 ;
  size_t _block_size___8 ;
  uint8_t const   *tmp___11 ;
  uint8_t const   *end___9 ;
  size_t _capacity___9 ;
  size_t _block_size___9 ;
  uint8_t const   *tmp___12 ;
  uint8_t const   *end___10 ;
  size_t _capacity___10 ;
  size_t _block_size___10 ;
  uint8_t const   *tmp___13 ;
  uint8_t const   *end___11 ;
  uint8_t const   *tmp___14 ;
  size_t _capacity___11 ;
  size_t _block_size___11 ;
  uint8_t const   *tmp___15 ;
  uint8_t const   *end___12 ;
  struct st_ptls_client_hello_t *ch ;
  uint8_t const   *src ;
  ptls_handshake_properties_t *properties ;
  ptls_iovec_t __dyc_funcallvar_7 ;
  ptls_iovec_t __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  ptls_iovec_t __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  ptls_iovec_t __dyc_funcallvar_12 ;
  ptls_iovec_t __dyc_funcallvar_13 ;
  ptls_iovec_t __dyc_funcallvar_14 ;

  {
  end___4 = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  id = (uint16_t )__dyc_readpre_byte();
  v = (uint16_t )__dyc_readpre_byte();
  ch = __dyc_read_ptr__comp_87st_ptls_client_hello_t();
  src = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  properties = __dyc_read_ptr__typdef_ptls_handshake_properties_t();
  __dyc_funcallvar_7 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_8 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_13 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_14 = __dyc_read_comp_46st_ptls_iovec_t();
  ret = 0;
  _capacity___4 = 0;
  _block_size___4 = 0;
  tmp___5 = 0;
  end___5 = 0;
  _capacity___5 = 0;
  _block_size___5 = 0;
  tmp___6 = 0;
  end___6 = 0;
  tmp___7 = 0;
  _capacity___6 = 0;
  _block_size___6 = 0;
  tmp___8 = 0;
  end___7 = 0;
  tmp___9 = 0;
  _capacity___7 = 0;
  _block_size___7 = 0;
  tmp___10 = 0;
  end___8 = 0;
  selected_index = 0;
  i = 0;
  _capacity___8 = 0;
  _block_size___8 = 0;
  tmp___11 = 0;
  end___9 = 0;
  _capacity___9 = 0;
  _block_size___9 = 0;
  tmp___12 = 0;
  end___10 = 0;
  _capacity___10 = 0;
  _block_size___10 = 0;
  tmp___13 = 0;
  end___11 = 0;
  tmp___14 = 0;
  _capacity___11 = 0;
  _block_size___11 = 0;
  tmp___15 = 0;
  end___12 = 0;
  while (1) {
    while_578_continue:  ;
    {
    while (1) {
      while_579_continue:  ;
      _capacity___4 = (size_t )2;
      if (_capacity___4 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      _block_size___4 = (size_t )0;
      {
      while (1) {
        while_580_continue:  ;
        tmp___5 = src;
        src ++;
        _block_size___4 = (_block_size___4 << 8) | (unsigned long )*tmp___5;
        _capacity___4 --;
        if (! (_capacity___4 != 0UL)) {
          goto while_580_break;
        }
      }
      while_580_break:  ;
      }
      if (_block_size___4 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      {
      while (1) {
        while_581_continue:  ;
        end___5 = src + _block_size___4;
        {
        while (1) {
          while_582_continue:  ;
          {
          while (1) {
            while_583_continue:  ;
            {
            while (1) {
              while_584_continue:  ;
              _capacity___5 = (size_t )1;
              if (_capacity___5 > (unsigned long )(end___5 - src)) {
                ret = 50;
                goto __dyc_dummy_label;
              }
              _block_size___5 = (size_t )0;
              {
              while (1) {
                while_585_continue:  ;
                tmp___6 = src;
                src ++;
                _block_size___5 = (_block_size___5 << 8) | (unsigned long )*tmp___6;
                _capacity___5 --;
                if (! (_capacity___5 != 0UL)) {
                  goto while_585_break;
                }
              }
              while_585_break:  ;
              }
              if (_block_size___5 > (unsigned long )(end___5 - src)) {
                ret = 50;
                goto __dyc_dummy_label;
              }
              {
              while (1) {
                while_586_continue:  ;
                end___6 = src + _block_size___5;
                {
                while (1) {
                  while_587_continue:  ;
                  if (ch->alpn.count < sizeof(ptls_iovec_t [16]) / sizeof(ptls_iovec_t )) {
                    {
                    tmp___7 = ch->alpn.count;
                    (ch->alpn.count) ++;
                    ch->alpn.list[tmp___7] = __dyc_funcallvar_7;
                    }
                  }
                  src = end___6;
                  goto while_587_break;
                }
                while_587_break:  ;
                }
                if ((unsigned long )src != (unsigned long )end___6) {
                  ret = 50;
                  goto __dyc_dummy_label;
                }
                goto while_586_break;
              }
              while_586_break:  ;
              }
              goto while_584_break;
            }
            while_584_break:  ;
            }
            if (! ((unsigned long )src != (unsigned long )end___5)) {
              goto while_583_break;
            }
          }
          while_583_break:  ;
          }
          goto while_582_break;
        }
        while_582_break:  ;
        }
        if ((unsigned long )src != (unsigned long )end___5) {
          ret = 50;
          goto __dyc_dummy_label;
        }
        goto while_581_break;
      }
      while_581_break:  ;
      }
      goto while_579_break;
    }
    while_579_break:  ;
    }
    {
    while (1) {
      while_588_continue:  ;
      if ((unsigned long )src != (unsigned long )end___4) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      goto while_588_break;
    }
    while_588_break:  ;
    }
    goto while_578_break;
  }
  while_578_break:  ;
  goto __dyc_dummy_label;
  ch->negotiated_groups = __dyc_funcallvar_8;
  goto __dyc_dummy_label;
  while (1) {
    while_589_continue:  ;
    {
    while (1) {
      while_590_continue:  ;
      _capacity___6 = (size_t )2;
      if (_capacity___6 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      _block_size___6 = (size_t )0;
      {
      while (1) {
        while_591_continue:  ;
        tmp___8 = src;
        src ++;
        _block_size___6 = (_block_size___6 << 8) | (unsigned long )*tmp___8;
        _capacity___6 --;
        if (! (_capacity___6 != 0UL)) {
          goto while_591_break;
        }
      }
      while_591_break:  ;
      }
      if (_block_size___6 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      {
      while (1) {
        while_592_continue:  ;
        end___7 = src + _block_size___6;
        {
        while (1) {
          while_593_continue:  ;
          {
          while (1) {
            while_594_continue:  ;
            {
            ret = __dyc_funcallvar_9;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            if (ch->signature_algorithms.count < sizeof(uint16_t [16]) / sizeof(uint16_t )) {
              tmp___9 = ch->signature_algorithms.count;
              (ch->signature_algorithms.count) ++;
              ch->signature_algorithms.list[tmp___9] = id;
            }
            if (! ((unsigned long )src != (unsigned long )end___7)) {
              goto while_594_break;
            }
          }
          while_594_break:  ;
          }
          goto while_593_break;
        }
        while_593_break:  ;
        }
        if ((unsigned long )src != (unsigned long )end___7) {
          ret = 50;
          goto __dyc_dummy_label;
        }
        goto while_592_break;
      }
      while_592_break:  ;
      }
      goto while_590_break;
    }
    while_590_break:  ;
    }
    {
    while (1) {
      while_595_continue:  ;
      if ((unsigned long )src != (unsigned long )end___4) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      goto while_595_break;
    }
    while_595_break:  ;
    }
    goto while_589_break;
  }
  while_589_break:  ;
  goto __dyc_dummy_label;
  ch->key_shares = __dyc_funcallvar_10;
  goto __dyc_dummy_label;
  while (1) {
    while_596_continue:  ;
    {
    while (1) {
      while_597_continue:  ;
      _capacity___7 = (size_t )1;
      if (_capacity___7 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      _block_size___7 = (size_t )0;
      {
      while (1) {
        while_598_continue:  ;
        tmp___10 = src;
        src ++;
        _block_size___7 = (_block_size___7 << 8) | (unsigned long )*tmp___10;
        _capacity___7 --;
        if (! (_capacity___7 != 0UL)) {
          goto while_598_break;
        }
      }
      while_598_break:  ;
      }
      if (_block_size___7 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      {
      while (1) {
        while_599_continue:  ;
        end___8 = src + _block_size___7;
        {
        while (1) {
          while_600_continue:  ;
          selected_index = sizeof(uint16_t const   [3]) / sizeof(uint16_t const   );
          {
          while (1) {
            while_601_continue:  ;
            {
            ret = __dyc_funcallvar_11;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            i = 0UL;
            {
            while (1) {
              while_602_continue:  ;
              if (! (i != selected_index)) {
                goto while_602_break;
              }
              if ((int const   )supported_versions[i] == (int const   )v) {
                selected_index = i;
                goto while_602_break;
              }
              i ++;
            }
            while_602_break:  ;
            }
            if (! ((unsigned long )src != (unsigned long )end___8)) {
              goto while_601_break;
            }
          }
          while_601_break:  ;
          }
          if (selected_index != sizeof(uint16_t const   [3]) / sizeof(uint16_t const   )) {
            ch->selected_version = (unsigned short )supported_versions[selected_index];
          }
          goto while_600_break;
        }
        while_600_break:  ;
        }
        if ((unsigned long )src != (unsigned long )end___8) {
          ret = 50;
          goto __dyc_dummy_label;
        }
        goto while_599_break;
      }
      while_599_break:  ;
      }
      goto while_597_break;
    }
    while_597_break:  ;
    }
    {
    while (1) {
      while_603_continue:  ;
      if ((unsigned long )src != (unsigned long )end___4) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      goto while_603_break;
    }
    while_603_break:  ;
    }
    goto while_596_break;
  }
  while_596_break:  ;
  goto __dyc_dummy_label;
  switch_577_44:  
  if ((unsigned long )properties->__annonCompField1.server.cookie.key == (unsigned long )((void *)0)) {
    ret = 47;
    goto __dyc_dummy_label;
  }
  ch->cookie.all = __dyc_funcallvar_12;
  while (1) {
    while_604_continue:  ;
    {
    while (1) {
      while_605_continue:  ;
      _capacity___8 = (size_t )2;
      if (_capacity___8 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      _block_size___8 = (size_t )0;
      {
      while (1) {
        while_606_continue:  ;
        tmp___11 = src;
        src ++;
        _block_size___8 = (_block_size___8 << 8) | (unsigned long )*tmp___11;
        _capacity___8 --;
        if (! (_capacity___8 != 0UL)) {
          goto while_606_break;
        }
      }
      while_606_break:  ;
      }
      if (_block_size___8 > (unsigned long )(end___4 - src)) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      {
      while (1) {
        while_607_continue:  ;
        end___9 = src + _block_size___8;
        {
        while (1) {
          while_608_continue:  ;
          ch->cookie.tbs.base = (uint8_t *)((void *)src);
          {
          while (1) {
            while_609_continue:  ;
            _capacity___9 = (size_t )2;
            if (_capacity___9 > (unsigned long )(end___9 - src)) {
              ret = 50;
              goto __dyc_dummy_label;
            }
            _block_size___9 = (size_t )0;
            {
            while (1) {
              while_610_continue:  ;
              tmp___12 = src;
              src ++;
              _block_size___9 = (_block_size___9 << 8) | (unsigned long )*tmp___12;
              _capacity___9 --;
              if (! (_capacity___9 != 0UL)) {
                goto while_610_break;
              }
            }
            while_610_break:  ;
            }
            if (_block_size___9 > (unsigned long )(end___9 - src)) {
              ret = 50;
              goto __dyc_dummy_label;
            }
            {
            while (1) {
              while_611_continue:  ;
              end___10 = src + _block_size___9;
              {
              while (1) {
                while_612_continue:  ;
                {
                while (1) {
                  while_613_continue:  ;
                  _capacity___10 = (size_t )1;
                  if (_capacity___10 > (unsigned long )(end___10 - src)) {
                    ret = 50;
                    goto __dyc_dummy_label;
                  }
                  _block_size___10 = (size_t )0;
                  {
                  while (1) {
                    while_614_continue:  ;
                    tmp___13 = src;
                    src ++;
                    _block_size___10 = (_block_size___10 << 8) | (unsigned long )*tmp___13;
                    _capacity___10 --;
                    if (! (_capacity___10 != 0UL)) {
                      goto while_614_break;
                    }
                  }
                  while_614_break:  ;
                  }
                  if (_block_size___10 > (unsigned long )(end___10 - src)) {
                    ret = 50;
                    goto __dyc_dummy_label;
                  }
                  {
                  while (1) {
                    while_615_continue:  ;
                    end___11 = src + _block_size___10;
                    {
                    while (1) {
                      while_616_continue:  ;
                      {
                      ch->cookie.ch1_hash = __dyc_funcallvar_13;
                      src = end___11;
                      }
                      goto while_616_break;
                    }
                    while_616_break:  ;
                    }
                    if ((unsigned long )src != (unsigned long )end___11) {
                      ret = 50;
                      goto __dyc_dummy_label;
                    }
                    goto while_615_break;
                  }
                  while_615_break:  ;
                  }
                  goto while_613_break;
                }
                while_613_break:  ;
                }
                if ((unsigned long )src == (unsigned long )end___10) {
                  ret = 50;
                  goto __dyc_dummy_label;
                }
                tmp___14 = src;
                src ++;
                if ((int )*tmp___14 == 0) {
                  goto switch_617_0;
                } else {
                  if ((int )*tmp___14 == 1) {
                    goto switch_617_1;
                  } else {
                    {
                    goto switch_617_default;
                    if (0) {
                      switch_617_0:  
                      if (! (! ch->cookie.sent_key_share)) {
                        {

                        }
                      }
                      goto switch_617_break;
                      switch_617_1:  
                      ch->cookie.sent_key_share = 1U;
                      goto switch_617_break;
                      switch_617_default:  
                      ret = 50;
                      goto __dyc_dummy_label;
                    } else {
                      switch_617_break:  ;
                    }
                    }
                  }
                }
                goto while_612_break;
              }
              while_612_break:  ;
              }
              if ((unsigned long )src != (unsigned long )end___10) {
                ret = 50;
                goto __dyc_dummy_label;
              }
              goto while_611_break;
            }
            while_611_break:  ;
            }
            goto while_609_break;
          }
          while_609_break:  ;
          }
          ch->cookie.tbs.len = (unsigned long )(src - (uint8_t const   *)ch->cookie.tbs.base);
          {
          while (1) {
            while_618_continue:  ;
            {
            while (1) {
              while_619_continue:  ;
              _capacity___11 = (size_t )1;
              if (_capacity___11 > (unsigned long )(end___9 - src)) {
                ret = 50;
                goto __dyc_dummy_label;
              }
              _block_size___11 = (size_t )0;
              {
              while (1) {
                while_620_continue:  ;
                tmp___15 = src;
                src ++;
                _block_size___11 = (_block_size___11 << 8) | (unsigned long )*tmp___15;
                _capacity___11 --;
                if (! (_capacity___11 != 0UL)) {
                  goto while_620_break;
                }
              }
              while_620_break:  ;
              }
              if (_block_size___11 > (unsigned long )(end___9 - src)) {
                ret = 50;
                goto __dyc_dummy_label;
              }
              {
              while (1) {
                while_621_continue:  ;
                end___12 = src + _block_size___11;
                {
                while (1) {
                  while_622_continue:  ;
                  {
                  ch->cookie.signature = __dyc_funcallvar_14;
                  src = end___12;
                  }
                  goto while_622_break;
                }
                while_622_break:  ;
                }
                if ((unsigned long )src != (unsigned long )end___12) {
                  ret = 50;
                  goto __dyc_dummy_label;
                }
                goto while_621_break;
              }
              while_621_break:  ;
              }
              goto while_619_break;
            }
            while_619_break:  ;
            }
            {
            while (1) {
              while_623_continue:  ;
              if ((unsigned long )src != (unsigned long )end___9) {
                ret = 50;
                goto __dyc_dummy_label;
              }
              goto while_623_break;
            }
            while_623_break:  ;
            }
            goto while_618_break;
          }
          while_618_break:  ;
          }
          goto while_608_break;
        }
        while_608_break:  ;
        }
        if ((unsigned long )src != (unsigned long )end___9) {
          ret = 50;
          goto __dyc_dummy_label;
        }
        goto while_607_break;
      }
      while_607_break:  ;
      }
      goto while_605_break;
    }
    while_605_break:  ;
    }
    {
    while (1) {
      while_624_continue:  ;
      if ((unsigned long )src != (unsigned long )end___4) {
        ret = 50;
        goto __dyc_dummy_label;
      }
      goto while_624_break;
    }
    while_624_break:  ;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(ret);
  __dyc_print_ptr__typdef_uint8_t(end___7);
  __dyc_print_ptr__typdef_uint8_t(end___8);
  __dyc_printpre_byte(selected_index);
  __dyc_print_ptr__typdef_uint8_t(src);
}
}
