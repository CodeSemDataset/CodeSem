#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ uint32_t ticket_age_add ;
  int ret ;
  size_t mess_start___1 ;
  uint8_t __constr_expr_7[1] ;
  size_t capacity___2 ;
  size_t body_start___2 ;
  uint32_t _v ;
  uint8_t __constr_expr_9[4] ;
  uint32_t _v___0 ;
  uint8_t __constr_expr_11[4] ;
  size_t capacity___3 ;
  size_t body_start___3 ;
  size_t body_size___1 ;
  size_t capacity___4 ;
  size_t body_start___4 ;
  ptls_iovec_t tmp___2 ;
  size_t body_size___2 ;
  size_t capacity___5 ;
  size_t body_start___5 ;
  uint16_t _v___1 ;
  uint8_t __constr_expr_13[2] ;
  size_t capacity___6 ;
  size_t body_start___6 ;
  uint32_t _v___2 ;
  uint8_t __constr_expr_15[4] ;
  size_t body_size___3 ;
  size_t body_size___4 ;
  size_t body_size___5 ;
  ptls_t *tls ;
  ptls_buffer_t *sendbuf ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  ptls_iovec_t __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;

  {
  ticket_age_add = (uint32_t )__dyc_readpre_byte();
  ret = __dyc_readpre_byte();
  tls = __dyc_read_ptr__typdef_ptls_t();
  sendbuf = __dyc_read_ptr__typdef_ptls_buffer_t();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  mess_start___1 = 0;
  capacity___2 = 0;
  body_start___2 = 0;
  _v = 0;
  _v___0 = 0;
  capacity___3 = 0;
  body_start___3 = 0;
  body_size___1 = 0;
  capacity___4 = 0;
  body_start___4 = 0;
  memset(& tmp___2, 0, sizeof(ptls_iovec_t ));
  body_size___2 = 0;
  capacity___5 = 0;
  body_start___5 = 0;
  _v___1 = 0;
  capacity___6 = 0;
  body_start___6 = 0;
  _v___2 = 0;
  body_size___3 = 0;
  body_size___4 = 0;
  body_size___5 = 0;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  while_159_continue:  ;
  while (1) {
    while_160_continue:  ;
    mess_start___1 = sendbuf->off;
    {
    while (1) {
      while_161_continue:  ;
      {
      __constr_expr_7[0] = (uint8_t )4;
      ret = __dyc_funcallvar_12;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      goto while_161_break;
    }
    while_161_break:  ;
    }
    {
    while (1) {
      while_162_continue:  ;
      capacity___2 = (size_t )3;
      {
      while (1) {
        while_163_continue:  ;
        {
        ret = __dyc_funcallvar_13;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_163_break;
      }
      while_163_break:  ;
      }
      body_start___2 = sendbuf->off;
      {
      while (1) {
        while_164_continue:  ;
        {
        while (1) {
          while_165_continue:  ;
          {
          while (1) {
            while_166_continue:  ;
            _v = (tls->ctx)->ticket_lifetime;
            {
            while (1) {
              while_167_continue:  ;
              {
              __constr_expr_9[0] = (unsigned char )(_v >> 24);
              __constr_expr_9[1] = (unsigned char )(_v >> 16);
              __constr_expr_9[2] = (unsigned char )(_v >> 8);
              __constr_expr_9[3] = (unsigned char )_v;
              ret = __dyc_funcallvar_14;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_167_break;
            }
            while_167_break:  ;
            }
            goto while_166_break;
          }
          while_166_break:  ;
          }
          {
          while (1) {
            while_168_continue:  ;
            _v___0 = ticket_age_add;
            {
            while (1) {
              while_169_continue:  ;
              {
              __constr_expr_11[0] = (unsigned char )(_v___0 >> 24);
              __constr_expr_11[1] = (unsigned char )(_v___0 >> 16);
              __constr_expr_11[2] = (unsigned char )(_v___0 >> 8);
              __constr_expr_11[3] = (unsigned char )_v___0;
              ret = __dyc_funcallvar_15;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_169_break;
            }
            while_169_break:  ;
            }
            goto while_168_break;
          }
          while_168_break:  ;
          }
          {
          while (1) {
            while_170_continue:  ;
            capacity___3 = (size_t )1;
            {
            while (1) {
              while_171_continue:  ;
              {
              ret = __dyc_funcallvar_16;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_171_break;
            }
            while_171_break:  ;
            }
            body_start___3 = sendbuf->off;
            {
            while (1) {
              while_172_continue:  ;
              goto while_172_break;
            }
            while_172_break:  ;
            }
            body_size___1 = sendbuf->off - body_start___3;
            {
            while (1) {
              while_173_continue:  ;
              if (! (capacity___3 != 0UL)) {
                goto while_173_break;
              }
              *(sendbuf->base + (body_start___3 - capacity___3)) = (unsigned char )(body_size___1 >> 8UL * (capacity___3 - 1UL));
              capacity___3 --;
            }
            while_173_break:  ;
            }
            goto while_170_break;
          }
          while_170_break:  ;
          }
          {
          while (1) {
            while_174_continue:  ;
            capacity___4 = (size_t )2;
            {
            while (1) {
              while_175_continue:  ;
              {
              ret = __dyc_funcallvar_17;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_175_break;
            }
            while_175_break:  ;
            }
            body_start___4 = sendbuf->off;
            {
            while (1) {
              while_176_continue:  ;
              {
              tmp___2 = __dyc_funcallvar_18;
              ret = __dyc_funcallvar_19;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_176_break;
            }
            while_176_break:  ;
            }
            body_size___2 = sendbuf->off - body_start___4;
            {
            while (1) {
              while_177_continue:  ;
              if (! (capacity___4 != 0UL)) {
                goto while_177_break;
              }
              *(sendbuf->base + (body_start___4 - capacity___4)) = (unsigned char )(body_size___2 >> 8UL * (capacity___4 - 1UL));
              capacity___4 --;
            }
            while_177_break:  ;
            }
            goto while_174_break;
          }
          while_174_break:  ;
          }
          {
          while (1) {
            while_178_continue:  ;
            capacity___5 = (size_t )2;
            {
            while (1) {
              while_179_continue:  ;
              {
              ret = __dyc_funcallvar_20;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_179_break;
            }
            while_179_break:  ;
            }
            body_start___5 = sendbuf->off;
            {
            while (1) {
              while_180_continue:  ;
              if ((tls->ctx)->max_early_data_size != 0U) {
                {
                while (1) {
                  while_181_continue:  ;
                  {
                  while (1) {
                    while_182_continue:  ;
                    _v___1 = (uint16_t )42;
                    {
                    while (1) {
                      while_183_continue:  ;
                      {
                      __constr_expr_13[0] = (unsigned char )((int )_v___1 >> 8);
                      __constr_expr_13[1] = (unsigned char )_v___1;
                      ret = __dyc_funcallvar_21;
                      }
                      if (ret != 0) {
                        goto __dyc_dummy_label;
                      }
                      goto while_183_break;
                    }
                    while_183_break:  ;
                    }
                    goto while_182_break;
                  }
                  while_182_break:  ;
                  }
                  {
                  while (1) {
                    while_184_continue:  ;
                    capacity___6 = (size_t )2;
                    {
                    while (1) {
                      while_185_continue:  ;
                      {
                      ret = __dyc_funcallvar_22;
                      }
                      if (ret != 0) {
                        goto __dyc_dummy_label;
                      }
                      goto while_185_break;
                    }
                    while_185_break:  ;
                    }
                    body_start___6 = sendbuf->off;
                    {
                    while (1) {
                      while_186_continue:  ;
                      {
                      while (1) {
                        while_187_continue:  ;
                        _v___2 = (tls->ctx)->max_early_data_size;
                        {
                        while (1) {
                          while_188_continue:  ;
                          {
                          __constr_expr_15[0] = (unsigned char )(_v___2 >> 24);
                          __constr_expr_15[1] = (unsigned char )(_v___2 >> 16);
                          __constr_expr_15[2] = (unsigned char )(_v___2 >> 8);
                          __constr_expr_15[3] = (unsigned char )_v___2;
                          ret = __dyc_funcallvar_23;
                          }
                          if (ret != 0) {
                            goto __dyc_dummy_label;
                          }
                          goto while_188_break;
                        }
                        while_188_break:  ;
                        }
                        goto while_187_break;
                      }
                      while_187_break:  ;
                      }
                      goto while_186_break;
                    }
                    while_186_break:  ;
                    }
                    body_size___3 = sendbuf->off - body_start___6;
                    {
                    while (1) {
                      while_189_continue:  ;
                      if (! (capacity___6 != 0UL)) {
                        goto while_189_break;
                      }
                      *(sendbuf->base + (body_start___6 - capacity___6)) = (unsigned char )(body_size___3 >> 8UL * (capacity___6 - 1UL));
                      capacity___6 --;
                    }
                    while_189_break:  ;
                    }
                    goto while_184_break;
                  }
                  while_184_break:  ;
                  }
                  goto while_181_break;
                }
                while_181_break:  ;
                }
              }
              goto while_180_break;
            }
            while_180_break:  ;
            }
            body_size___4 = sendbuf->off - body_start___5;
            {
            while (1) {
              while_190_continue:  ;
              if (! (capacity___5 != 0UL)) {
                goto while_190_break;
              }
              *(sendbuf->base + (body_start___5 - capacity___5)) = (unsigned char )(body_size___4 >> 8UL * (capacity___5 - 1UL));
              capacity___5 --;
            }
            while_190_break:  ;
            }
            goto while_178_break;
          }
          while_178_break:  ;
          }
          goto while_165_break;
        }
        while_165_break:  ;
        }
        goto while_164_break;
      }
      while_164_break:  ;
      }
      body_size___5 = sendbuf->off - body_start___2;
      {
      while (1) {
        while_191_continue:  ;
        if (! (capacity___2 != 0UL)) {
          goto while_191_break;
        }
        *(sendbuf->base + (body_start___2 - capacity___2)) = (unsigned char )(body_size___5 >> 8UL * (capacity___2 - 1UL));
        capacity___2 --;
      }
      while_191_break:  ;
      }
      goto while_162_break;
    }
    while_162_break:  ;
    }
    if ((unsigned long )tls->key_schedule != (unsigned long )((void *)0)) {
      {

      }
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(mess_start___1);
  __dyc_printpre_byte(capacity___2);
  __dyc_printpre_byte(body_start___2);
  __dyc_printpre_byte(capacity___3);
  __dyc_printpre_byte(body_size___1);
  __dyc_printpre_byte(capacity___4);
  __dyc_printpre_byte(body_start___4);
  __dyc_print_comp_46st_ptls_iovec_t(tmp___2);
  __dyc_printpre_byte(body_size___2);
  __dyc_printpre_byte(capacity___5);
  __dyc_printpre_byte(body_start___5);
  __dyc_printpre_byte(capacity___6);
  __dyc_printpre_byte(body_start___6);
  __dyc_printpre_byte(body_size___3);
  __dyc_printpre_byte(body_size___4);
  __dyc_printpre_byte(body_size___5);
}
}
