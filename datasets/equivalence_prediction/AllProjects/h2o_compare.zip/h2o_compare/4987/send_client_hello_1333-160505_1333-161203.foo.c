#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ uint32_t obfuscated_ticket_age ;
  int ret ;
  int is_second_flight ;
  uint16_t _v___16 ;
  uint8_t __constr_expr_47[2] ;
  size_t capacity___24 ;
  size_t body_start___24 ;
  size_t body_size___21 ;
  uint16_t _v___17 ;
  uint8_t __constr_expr_49[2] ;
  size_t capacity___25 ;
  size_t body_start___25 ;
  size_t capacity___26 ;
  size_t body_start___26 ;
  size_t capacity___27 ;
  size_t body_start___27 ;
  size_t body_size___22 ;
  uint32_t _v___18 ;
  uint8_t __constr_expr_51[4] ;
  size_t body_size___23 ;
  size_t capacity___28 ;
  size_t body_start___28 ;
  size_t capacity___29 ;
  size_t body_start___29 ;
  size_t body_size___24 ;
  size_t body_size___25 ;
  size_t body_size___26 ;
  ptls_t *tls ;
  ptls_buffer_t *sendbuf ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;

  {
  obfuscated_ticket_age = (uint32_t )__dyc_readpre_byte();
  is_second_flight = __dyc_readpre_byte();
  tls = __dyc_read_ptr__typdef_ptls_t();
  sendbuf = __dyc_read_ptr__typdef_ptls_buffer_t();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  ret = 0;
  _v___16 = 0;
  capacity___24 = 0;
  body_start___24 = 0;
  body_size___21 = 0;
  _v___17 = 0;
  capacity___25 = 0;
  body_start___25 = 0;
  capacity___26 = 0;
  body_start___26 = 0;
  capacity___27 = 0;
  body_start___27 = 0;
  body_size___22 = 0;
  _v___18 = 0;
  body_size___23 = 0;
  capacity___28 = 0;
  body_start___28 = 0;
  capacity___29 = 0;
  body_start___29 = 0;
  body_size___24 = 0;
  body_size___25 = 0;
  body_size___26 = 0;
  if ((unsigned long )tls->early_data != (unsigned long )((void *)0)) {
    if (! is_second_flight) {
      {
      while (1) {
        while_368_continue:  ;
        {
        while (1) {
          while_369_continue:  ;
          _v___16 = (uint16_t )42;
          {
          while (1) {
            while_370_continue:  ;
            {
            __constr_expr_47[0] = (unsigned char )((int )_v___16 >> 8);
            __constr_expr_47[1] = (unsigned char )_v___16;
            ret = __dyc_funcallvar_63;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_370_break;
          }
          while_370_break:  ;
          }
          goto while_369_break;
        }
        while_369_break:  ;
        }
        {
        while (1) {
          while_371_continue:  ;
          capacity___24 = (size_t )2;
          {
          while (1) {
            while_372_continue:  ;
            {
            ret = __dyc_funcallvar_64;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_372_break;
          }
          while_372_break:  ;
          }
          body_start___24 = sendbuf->off;
          {
          while (1) {
            while_373_continue:  ;
            goto while_373_break;
          }
          while_373_break:  ;
          }
          body_size___21 = sendbuf->off - body_start___24;
          {
          while (1) {
            while_374_continue:  ;
            if (! (capacity___24 != 0UL)) {
              goto while_374_break;
            }
            *(sendbuf->base + (body_start___24 - capacity___24)) = (unsigned char )(body_size___21 >> 8UL * (capacity___24 - 1UL));
            capacity___24 --;
          }
          while_374_break:  ;
          }
          goto while_371_break;
        }
        while_371_break:  ;
        }
        goto while_368_break;
      }
      while_368_break:  ;
      }
    }
  }
  while (1) {
    while_375_continue:  ;
    {
    while (1) {
      while_376_continue:  ;
      _v___17 = (uint16_t )41;
      {
      while (1) {
        while_377_continue:  ;
        {
        __constr_expr_49[0] = (unsigned char )((int )_v___17 >> 8);
        __constr_expr_49[1] = (unsigned char )_v___17;
        ret = __dyc_funcallvar_65;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_377_break;
      }
      while_377_break:  ;
      }
      goto while_376_break;
    }
    while_376_break:  ;
    }
    {
    while (1) {
      while_378_continue:  ;
      capacity___25 = (size_t )2;
      {
      while (1) {
        while_379_continue:  ;
        {
        ret = __dyc_funcallvar_66;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_379_break;
      }
      while_379_break:  ;
      }
      body_start___25 = sendbuf->off;
      {
      while (1) {
        while_380_continue:  ;
        {
        while (1) {
          while_381_continue:  ;
          capacity___26 = (size_t )2;
          {
          while (1) {
            while_382_continue:  ;
            {
            ret = __dyc_funcallvar_67;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_382_break;
          }
          while_382_break:  ;
          }
          body_start___26 = sendbuf->off;
          {
          while (1) {
            while_383_continue:  ;
            {
            while (1) {
              while_384_continue:  ;
              capacity___27 = (size_t )2;
              {
              while (1) {
                while_385_continue:  ;
                {
                ret = __dyc_funcallvar_68;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_385_break;
              }
              while_385_break:  ;
              }
              body_start___27 = sendbuf->off;
              {
              while (1) {
                while_386_continue:  ;
                {
                while (1) {
                  while_387_continue:  ;
                  {
                  ret = __dyc_funcallvar_69;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_387_break;
                }
                while_387_break:  ;
                }
                goto while_386_break;
              }
              while_386_break:  ;
              }
              body_size___22 = sendbuf->off - body_start___27;
              {
              while (1) {
                while_388_continue:  ;
                if (! (capacity___27 != 0UL)) {
                  goto while_388_break;
                }
                *(sendbuf->base + (body_start___27 - capacity___27)) = (unsigned char )(body_size___22 >> 8UL * (capacity___27 - 1UL));
                capacity___27 --;
              }
              while_388_break:  ;
              }
              goto while_384_break;
            }
            while_384_break:  ;
            }
            {
            while (1) {
              while_389_continue:  ;
              _v___18 = obfuscated_ticket_age;
              {
              while (1) {
                while_390_continue:  ;
                {
                __constr_expr_51[0] = (unsigned char )(_v___18 >> 24);
                __constr_expr_51[1] = (unsigned char )(_v___18 >> 16);
                __constr_expr_51[2] = (unsigned char )(_v___18 >> 8);
                __constr_expr_51[3] = (unsigned char )_v___18;
                ret = __dyc_funcallvar_70;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_390_break;
              }
              while_390_break:  ;
              }
              goto while_389_break;
            }
            while_389_break:  ;
            }
            goto while_383_break;
          }
          while_383_break:  ;
          }
          body_size___23 = sendbuf->off - body_start___26;
          {
          while (1) {
            while_391_continue:  ;
            if (! (capacity___26 != 0UL)) {
              goto while_391_break;
            }
            *(sendbuf->base + (body_start___26 - capacity___26)) = (unsigned char )(body_size___23 >> 8UL * (capacity___26 - 1UL));
            capacity___26 --;
          }
          while_391_break:  ;
          }
          goto while_381_break;
        }
        while_381_break:  ;
        }
        {
        while (1) {
          while_392_continue:  ;
          capacity___28 = (size_t )2;
          {
          while (1) {
            while_393_continue:  ;
            {
            ret = __dyc_funcallvar_71;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_393_break;
          }
          while_393_break:  ;
          }
          body_start___28 = sendbuf->off;
          {
          while (1) {
            while_394_continue:  ;
            {
            while (1) {
              while_395_continue:  ;
              capacity___29 = (size_t )1;
              {
              while (1) {
                while_396_continue:  ;
                {
                ret = __dyc_funcallvar_72;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_396_break;
              }
              while_396_break:  ;
              }
              body_start___29 = sendbuf->off;
              {
              while (1) {
                while_397_continue:  ;
                {
                ret = __dyc_funcallvar_73;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                sendbuf->off += (size_t )((tls->key_schedule)->hashes[0].algo)->digest_size;
                goto while_397_break;
              }
              while_397_break:  ;
              }
              body_size___24 = sendbuf->off - body_start___29;
              {
              while (1) {
                while_398_continue:  ;
                if (! (capacity___29 != 0UL)) {
                  goto while_398_break;
                }
                *(sendbuf->base + (body_start___29 - capacity___29)) = (unsigned char )(body_size___24 >> 8UL * (capacity___29 - 1UL));
                capacity___29 --;
              }
              while_398_break:  ;
              }
              goto while_395_break;
            }
            while_395_break:  ;
            }
            goto while_394_break;
          }
          while_394_break:  ;
          }
          body_size___25 = sendbuf->off - body_start___28;
          {
          while (1) {
            while_399_continue:  ;
            if (! (capacity___28 != 0UL)) {
              goto while_399_break;
            }
            *(sendbuf->base + (body_start___28 - capacity___28)) = (unsigned char )(body_size___25 >> 8UL * (capacity___28 - 1UL));
            capacity___28 --;
          }
          while_399_break:  ;
          }
          goto while_392_break;
        }
        while_392_break:  ;
        }
        goto while_380_break;
      }
      while_380_break:  ;
      }
      body_size___26 = sendbuf->off - body_start___25;
      {
      while (1) {
        while_400_continue:  ;
        if (! (capacity___25 != 0UL)) {
          goto while_400_break;
        }
        *(sendbuf->base + (body_start___25 - capacity___25)) = (unsigned char )(body_size___26 >> 8UL * (capacity___25 - 1UL));
        capacity___25 --;
      }
      while_400_break:  ;
      }
      goto while_378_break;
    }
    while_378_break:  ;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(capacity___24);
  __dyc_printpre_byte(body_size___21);
  __dyc_printpre_byte(capacity___25);
  __dyc_printpre_byte(body_start___25);
  __dyc_printpre_byte(capacity___26);
  __dyc_printpre_byte(body_start___26);
  __dyc_printpre_byte(capacity___27);
  __dyc_printpre_byte(body_start___27);
  __dyc_printpre_byte(body_size___22);
  __dyc_printpre_byte(body_size___23);
  __dyc_printpre_byte(capacity___28);
  __dyc_printpre_byte(body_start___28);
  __dyc_printpre_byte(capacity___29);
  __dyc_printpre_byte(body_start___29);
  __dyc_printpre_byte(body_size___24);
  __dyc_printpre_byte(body_size___25);
  __dyc_printpre_byte(body_size___26);
}
}
