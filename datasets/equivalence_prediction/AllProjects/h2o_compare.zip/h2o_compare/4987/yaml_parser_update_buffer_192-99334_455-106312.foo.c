#include "../include/dycfoo.h"
#include "../include/reader.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int value ;
  unsigned int value2 ;
  int incomplete ;
  unsigned char octet ;
  unsigned int width ;
  int low ;
  int high ;
  size_t k ;
  size_t raw_unread ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  yaml_char_t *tmp___25 ;
  yaml_char_t *tmp___26 ;
  yaml_char_t *tmp___27 ;
  yaml_char_t *tmp___28 ;
  yaml_char_t *tmp___29 ;
  yaml_char_t *tmp___30 ;
  yaml_char_t *tmp___31 ;
  yaml_char_t *tmp___32 ;
  yaml_char_t *tmp___33 ;
  yaml_char_t *tmp___34 ;
  yaml_char_t *tmp___35 ;
  yaml_parser_t *parser ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;

  {
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  value = 0;
  value2 = 0;
  incomplete = 0;
  octet = 0;
  width = 0;
  low = 0;
  high = 0;
  k = 0;
  raw_unread = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  while (1) {
    while_2_continue:  ;
    if (! ((unsigned long )parser->raw_buffer.pointer != (unsigned long )parser->raw_buffer.last)) {
      goto while_2_break;
    }
    value = 0U;
    value2 = 0U;
    incomplete = 0;
    width = 0U;
    raw_unread = (size_t )(parser->raw_buffer.last - parser->raw_buffer.pointer);
    if ((int )parser->encoding == 1) {
      goto switch_3_1;
    } else {
      if ((int )parser->encoding == 2) {
        goto switch_3_2;
      } else {
        if ((int )parser->encoding == 3) {
          goto switch_3_2;
        } else {
          {
          goto switch_3_default;
          if (0) {
            switch_3_1:  
            octet = *(parser->raw_buffer.pointer + 0);
            if (((int )octet & 128) == 0) {
              width = 1U;
            } else {
              if (((int )octet & 224) == 192) {
                width = 2U;
              } else {
                if (((int )octet & 240) == 224) {
                  width = 3U;
                } else {
                  if (((int )octet & 248) == 240) {
                    width = 4U;
                  } else {
                    width = 0U;
                  }
                }
              }
            }
            if (! width) {
              {
              tmp___8 = __dyc_funcallvar_3;
              }
              goto __dyc_dummy_label;
            }
            if ((size_t )width > raw_unread) {
              if (parser->eof) {
                {
                tmp___9 = __dyc_funcallvar_4;
                }
                goto __dyc_dummy_label;
              }
              incomplete = 1;
              goto switch_3_break;
            }
            if (((int )octet & 128) == 0) {
              value = (unsigned int )((int )octet & 127);
            } else {
              if (((int )octet & 224) == 192) {
                value = (unsigned int )((int )octet & 31);
              } else {
                if (((int )octet & 240) == 224) {
                  value = (unsigned int )((int )octet & 15);
                } else {
                  if (((int )octet & 248) == 240) {
                    value = (unsigned int )((int )octet & 7);
                  } else {
                    value = 0U;
                  }
                }
              }
            }
            k = 1UL;
            {
            while (1) {
              while_4_continue:  ;
              if (! (k < (size_t )width)) {
                goto while_4_break;
              }
              octet = *(parser->raw_buffer.pointer + k);
              if (((int )octet & 192) != 128) {
                {
                tmp___17 = __dyc_funcallvar_5;
                }
                goto __dyc_dummy_label;
              }
              value = (value << 6) + (unsigned int )((int )octet & 63);
              k ++;
            }
            while_4_break:  ;
            }
            if (! (width == 1U)) {
              if (width == 2U) {
                if (! (value >= 128U)) {
                  goto _L___2;
                }
              } else {
                _L___2:  
                if (width == 3U) {
                  if (! (value >= 2048U)) {
                    goto _L___1;
                  }
                } else {
                  _L___1:  
                  if (width == 4U) {
                    if (! (value >= 65536U)) {
                      {
                      tmp___18 = __dyc_funcallvar_6;
                      }
                      goto __dyc_dummy_label;
                    }
                  } else {
                    {
                    tmp___18 = __dyc_funcallvar_7;
                    }
                    goto __dyc_dummy_label;
                  }
                }
              }
            }
            if (value >= 55296U) {
              if (value <= 57343U) {
                {
                tmp___19 = __dyc_funcallvar_8;
                }
                goto __dyc_dummy_label;
              } else {
                goto _L___3;
              }
            } else {
              _L___3:  
              if (value > 1114111U) {
                {
                tmp___19 = __dyc_funcallvar_9;
                }
                goto __dyc_dummy_label;
              }
            }
            goto switch_3_break;
            switch_3_2:  
            switch_3_3:  
            if ((int )parser->encoding == 2) {
              low = 0;
            } else {
              low = 1;
            }
            if ((int )parser->encoding == 2) {
              high = 1;
            } else {
              high = 0;
            }
            if (raw_unread < 2UL) {
              if (parser->eof) {
                {
                tmp___20 = __dyc_funcallvar_10;
                }
                goto __dyc_dummy_label;
              }
              incomplete = 1;
              goto switch_3_break;
            }
            value = (unsigned int )((int )*(parser->raw_buffer.pointer + low) + ((int )*(parser->raw_buffer.pointer + high) << 8));
            if ((value & 64512U) == 56320U) {
              {
              tmp___21 = __dyc_funcallvar_11;
              }
              goto __dyc_dummy_label;
            }
            if ((value & 64512U) == 55296U) {
              width = 4U;
              if (raw_unread < 4UL) {
                if (parser->eof) {
                  {
                  tmp___22 = __dyc_funcallvar_12;
                  }
                  goto __dyc_dummy_label;
                }
                incomplete = 1;
                goto switch_3_break;
              }
              value2 = (unsigned int )((int )*(parser->raw_buffer.pointer + (low + 2)) + ((int )*(parser->raw_buffer.pointer + (high + 2)) << 8));
              if ((value2 & 64512U) != 56320U) {
                {
                tmp___23 = __dyc_funcallvar_13;
                }
                goto __dyc_dummy_label;
              }
              value = (65536U + ((value & 1023U) << 10)) + (value2 & 1023U);
            } else {
              width = 2U;
            }
            goto switch_3_break;
            switch_3_default:  ;
          } else {
            switch_3_break:  ;
          }
          }
        }
      }
    }
    if (incomplete) {
      goto while_2_break;
    }
    if (! (value == 9U)) {
      if (! (value == 10U)) {
        if (! (value == 13U)) {
          if (value >= 32U) {
            if (! (value <= 126U)) {
              goto _L___6;
            }
          } else {
            _L___6:  
            if (! (value == 133U)) {
              if (value >= 160U) {
                if (! (value <= 55295U)) {
                  goto _L___5;
                }
              } else {
                _L___5:  
                if (value >= 57344U) {
                  if (! (value <= 65533U)) {
                    goto _L___4;
                  }
                } else {
                  _L___4:  
                  if (value >= 65536U) {
                    if (! (value <= 1114111U)) {
                      {
                      tmp___24 = __dyc_funcallvar_14;
                      }
                      goto __dyc_dummy_label;
                    }
                  } else {
                    {
                    tmp___24 = __dyc_funcallvar_15;
                    }
                    goto __dyc_dummy_label;
                  }
                }
              }
            }
          }
        }
      }
    }
    parser->raw_buffer.pointer += width;
    parser->offset += (size_t )width;
    if (value <= 127U) {
      tmp___25 = parser->buffer.last;
      (parser->buffer.last) ++;
      *tmp___25 = (unsigned char )value;
    } else {
      if (value <= 2047U) {
        tmp___26 = parser->buffer.last;
        (parser->buffer.last) ++;
        *tmp___26 = (unsigned char )(192U + (value >> 6));
        tmp___27 = parser->buffer.last;
        (parser->buffer.last) ++;
        *tmp___27 = (unsigned char )(128U + (value & 63U));
      } else {
        if (value <= 65535U) {
          tmp___28 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___28 = (unsigned char )(224U + (value >> 12));
          tmp___29 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___29 = (unsigned char )(128U + ((value >> 6) & 63U));
          tmp___30 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___30 = (unsigned char )(128U + (value & 63U));
        } else {
          tmp___31 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___31 = (unsigned char )(240U + (value >> 18));
          tmp___32 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___32 = (unsigned char )(128U + ((value >> 12) & 63U));
          tmp___33 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___33 = (unsigned char )(128U + ((value >> 6) & 63U));
          tmp___34 = parser->buffer.last;
          (parser->buffer.last) ++;
          *tmp___34 = (unsigned char )(128U + (value & 63U));
        }
      }
    }
    (parser->unread) ++;
  }
  while_2_break:  ;
  if (parser->eof) {
    tmp___35 = parser->buffer.last;
    (parser->buffer.last) ++;
    *tmp___35 = (unsigned char )'\000';
    (parser->unread) ++;
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(value);
  __dyc_printpre_byte(value2);
  __dyc_printpre_byte(incomplete);
  __dyc_printpre_byte(width);
  __dyc_printpre_byte(low);
  __dyc_printpre_byte(high);
  __dyc_printpre_byte(raw_unread);
  __dyc_printpre_byte(tmp___8);
  __dyc_printpre_byte(tmp___9);
  __dyc_printpre_byte(tmp___17);
  __dyc_printpre_byte(tmp___18);
  __dyc_printpre_byte(tmp___19);
  __dyc_printpre_byte(tmp___20);
  __dyc_printpre_byte(tmp___21);
  __dyc_printpre_byte(tmp___22);
  __dyc_printpre_byte(tmp___23);
  __dyc_printpre_byte(tmp___24);
}
}
