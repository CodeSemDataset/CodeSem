#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ uint16_t const   supported_versions[3] ;
  int ret ;
  uint16_t _v___3 ;
  uint8_t __constr_expr_17[2] ;
  size_t capacity___11 ;
  size_t body_start___11 ;
  size_t capacity___12 ;
  size_t body_start___12 ;
  size_t i___0 ;
  uint16_t _v___4 ;
  uint8_t __constr_expr_19[2] ;
  size_t body_size___8 ;
  size_t body_size___9 ;
  uint16_t _v___5 ;
  uint8_t __constr_expr_21[2] ;
  size_t capacity___13 ;
  size_t body_start___13 ;
  size_t capacity___14 ;
  size_t body_start___14 ;
  uint16_t _v___6 ;
  uint8_t __constr_expr_23[2] ;
  uint16_t _v___7 ;
  uint8_t __constr_expr_25[2] ;
  uint16_t _v___8 ;
  uint8_t __constr_expr_27[2] ;
  uint16_t _v___9 ;
  uint8_t __constr_expr_29[2] ;
  size_t body_size___10 ;
  size_t body_size___11 ;
  uint16_t _v___10 ;
  uint8_t __constr_expr_31[2] ;
  size_t capacity___15 ;
  size_t body_start___15 ;
  ptls_key_exchange_algorithm_t **algo ;
  size_t capacity___16 ;
  size_t body_start___16 ;
  uint16_t _v___11 ;
  uint8_t __constr_expr_33[2] ;
  size_t body_size___12 ;
  size_t body_size___13 ;
  ptls_t *tls ;
  ptls_buffer_t *sendbuf ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;

  {
  tls = __dyc_read_ptr__typdef_ptls_t();
  sendbuf = __dyc_read_ptr__typdef_ptls_buffer_t();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  ret = 0;
  _v___3 = 0;
  capacity___11 = 0;
  body_start___11 = 0;
  capacity___12 = 0;
  body_start___12 = 0;
  i___0 = 0;
  _v___4 = 0;
  body_size___8 = 0;
  body_size___9 = 0;
  _v___5 = 0;
  capacity___13 = 0;
  body_start___13 = 0;
  capacity___14 = 0;
  body_start___14 = 0;
  _v___6 = 0;
  _v___7 = 0;
  _v___8 = 0;
  _v___9 = 0;
  body_size___10 = 0;
  body_size___11 = 0;
  _v___10 = 0;
  capacity___15 = 0;
  body_start___15 = 0;
  algo = 0;
  capacity___16 = 0;
  body_start___16 = 0;
  _v___11 = 0;
  body_size___12 = 0;
  body_size___13 = 0;
  while (1) {
    while_278_continue:  ;
    {
    while (1) {
      while_279_continue:  ;
      _v___3 = (uint16_t )43;
      {
      while (1) {
        while_280_continue:  ;
        {
        __constr_expr_17[0] = (unsigned char )((int )_v___3 >> 8);
        __constr_expr_17[1] = (unsigned char )_v___3;
        ret = __dyc_funcallvar_31;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_280_break;
      }
      while_280_break:  ;
      }
      goto while_279_break;
    }
    while_279_break:  ;
    }
    {
    while (1) {
      while_281_continue:  ;
      capacity___11 = (size_t )2;
      {
      while (1) {
        while_282_continue:  ;
        {
        ret = __dyc_funcallvar_32;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_282_break;
      }
      while_282_break:  ;
      }
      body_start___11 = sendbuf->off;
      {
      while (1) {
        while_283_continue:  ;
        {
        while (1) {
          while_284_continue:  ;
          capacity___12 = (size_t )1;
          {
          while (1) {
            while_285_continue:  ;
            {
            ret = __dyc_funcallvar_33;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_285_break;
          }
          while_285_break:  ;
          }
          body_start___12 = sendbuf->off;
          {
          while (1) {
            while_286_continue:  ;
            i___0 = 0UL;
            {
            while (1) {
              while_287_continue:  ;
              if (! (i___0 != sizeof(uint16_t const   [3]) / sizeof(uint16_t const   ))) {
                goto while_287_break;
              }
              {
              while (1) {
                while_288_continue:  ;
                _v___4 = (uint16_t )supported_versions[i___0];
                {
                while (1) {
                  while_289_continue:  ;
                  {
                  __constr_expr_19[0] = (unsigned char )((int )_v___4 >> 8);
                  __constr_expr_19[1] = (unsigned char )_v___4;
                  ret = __dyc_funcallvar_34;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_289_break;
                }
                while_289_break:  ;
                }
                goto while_288_break;
              }
              while_288_break:  ;
              }
              i___0 ++;
            }
            while_287_break:  ;
            }
            goto while_286_break;
          }
          while_286_break:  ;
          }
          body_size___8 = sendbuf->off - body_start___12;
          {
          while (1) {
            while_290_continue:  ;
            if (! (capacity___12 != 0UL)) {
              goto while_290_break;
            }
            *(sendbuf->base + (body_start___12 - capacity___12)) = (unsigned char )(body_size___8 >> 8UL * (capacity___12 - 1UL));
            capacity___12 --;
          }
          while_290_break:  ;
          }
          goto while_284_break;
        }
        while_284_break:  ;
        }
        goto while_283_break;
      }
      while_283_break:  ;
      }
      body_size___9 = sendbuf->off - body_start___11;
      {
      while (1) {
        while_291_continue:  ;
        if (! (capacity___11 != 0UL)) {
          goto while_291_break;
        }
        *(sendbuf->base + (body_start___11 - capacity___11)) = (unsigned char )(body_size___9 >> 8UL * (capacity___11 - 1UL));
        capacity___11 --;
      }
      while_291_break:  ;
      }
      goto while_281_break;
    }
    while_281_break:  ;
    }
    goto while_278_break;
  }
  while_278_break:  ;
  while (1) {
    while_292_continue:  ;
    {
    while (1) {
      while_293_continue:  ;
      _v___5 = (uint16_t )13;
      {
      while (1) {
        while_294_continue:  ;
        {
        __constr_expr_21[0] = (unsigned char )((int )_v___5 >> 8);
        __constr_expr_21[1] = (unsigned char )_v___5;
        ret = __dyc_funcallvar_35;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_294_break;
      }
      while_294_break:  ;
      }
      goto while_293_break;
    }
    while_293_break:  ;
    }
    {
    while (1) {
      while_295_continue:  ;
      capacity___13 = (size_t )2;
      {
      while (1) {
        while_296_continue:  ;
        {
        ret = __dyc_funcallvar_36;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_296_break;
      }
      while_296_break:  ;
      }
      body_start___13 = sendbuf->off;
      {
      while (1) {
        while_297_continue:  ;
        {
        while (1) {
          while_298_continue:  ;
          capacity___14 = (size_t )2;
          {
          while (1) {
            while_299_continue:  ;
            {
            ret = __dyc_funcallvar_37;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_299_break;
          }
          while_299_break:  ;
          }
          body_start___14 = sendbuf->off;
          {
          while (1) {
            while_300_continue:  ;
            {
            while (1) {
              while_301_continue:  ;
              _v___6 = (uint16_t )2052;
              {
              while (1) {
                while_302_continue:  ;
                {
                __constr_expr_23[0] = (unsigned char )((int )_v___6 >> 8);
                __constr_expr_23[1] = (unsigned char )_v___6;
                ret = __dyc_funcallvar_38;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_302_break;
              }
              while_302_break:  ;
              }
              goto while_301_break;
            }
            while_301_break:  ;
            }
            {
            while (1) {
              while_303_continue:  ;
              _v___7 = (uint16_t )1027;
              {
              while (1) {
                while_304_continue:  ;
                {
                __constr_expr_25[0] = (unsigned char )((int )_v___7 >> 8);
                __constr_expr_25[1] = (unsigned char )_v___7;
                ret = __dyc_funcallvar_39;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_304_break;
              }
              while_304_break:  ;
              }
              goto while_303_break;
            }
            while_303_break:  ;
            }
            {
            while (1) {
              while_305_continue:  ;
              _v___8 = (uint16_t )1025;
              {
              while (1) {
                while_306_continue:  ;
                {
                __constr_expr_27[0] = (unsigned char )((int )_v___8 >> 8);
                __constr_expr_27[1] = (unsigned char )_v___8;
                ret = __dyc_funcallvar_40;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_306_break;
              }
              while_306_break:  ;
              }
              goto while_305_break;
            }
            while_305_break:  ;
            }
            {
            while (1) {
              while_307_continue:  ;
              _v___9 = (uint16_t )513;
              {
              while (1) {
                while_308_continue:  ;
                {
                __constr_expr_29[0] = (unsigned char )((int )_v___9 >> 8);
                __constr_expr_29[1] = (unsigned char )_v___9;
                ret = __dyc_funcallvar_41;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_308_break;
              }
              while_308_break:  ;
              }
              goto while_307_break;
            }
            while_307_break:  ;
            }
            goto while_300_break;
          }
          while_300_break:  ;
          }
          body_size___10 = sendbuf->off - body_start___14;
          {
          while (1) {
            while_309_continue:  ;
            if (! (capacity___14 != 0UL)) {
              goto while_309_break;
            }
            *(sendbuf->base + (body_start___14 - capacity___14)) = (unsigned char )(body_size___10 >> 8UL * (capacity___14 - 1UL));
            capacity___14 --;
          }
          while_309_break:  ;
          }
          goto while_298_break;
        }
        while_298_break:  ;
        }
        goto while_297_break;
      }
      while_297_break:  ;
      }
      body_size___11 = sendbuf->off - body_start___13;
      {
      while (1) {
        while_310_continue:  ;
        if (! (capacity___13 != 0UL)) {
          goto while_310_break;
        }
        *(sendbuf->base + (body_start___13 - capacity___13)) = (unsigned char )(body_size___11 >> 8UL * (capacity___13 - 1UL));
        capacity___13 --;
      }
      while_310_break:  ;
      }
      goto while_295_break;
    }
    while_295_break:  ;
    }
    goto while_292_break;
  }
  while_292_break:  ;
  while (1) {
    while_311_continue:  ;
    {
    while (1) {
      while_312_continue:  ;
      _v___10 = (uint16_t )10;
      {
      while (1) {
        while_313_continue:  ;
        {
        __constr_expr_31[0] = (unsigned char )((int )_v___10 >> 8);
        __constr_expr_31[1] = (unsigned char )_v___10;
        ret = __dyc_funcallvar_42;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_313_break;
      }
      while_313_break:  ;
      }
      goto while_312_break;
    }
    while_312_break:  ;
    }
    {
    while (1) {
      while_314_continue:  ;
      capacity___15 = (size_t )2;
      {
      while (1) {
        while_315_continue:  ;
        {
        ret = __dyc_funcallvar_43;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_315_break;
      }
      while_315_break:  ;
      }
      body_start___15 = sendbuf->off;
      {
      while (1) {
        while_316_continue:  ;
        algo = (tls->ctx)->key_exchanges;
        {
        while (1) {
          while_317_continue:  ;
          capacity___16 = (size_t )2;
          {
          while (1) {
            while_318_continue:  ;
            {
            ret = __dyc_funcallvar_44;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_318_break;
          }
          while_318_break:  ;
          }
          body_start___16 = sendbuf->off;
          {
          while (1) {
            while_319_continue:  ;
            {
            while (1) {
              while_320_continue:  ;
              if (! ((unsigned long )*algo != (unsigned long )((void *)0))) {
                goto while_320_break;
              }
              {
              while (1) {
                while_321_continue:  ;
                _v___11 = (uint16_t )(*algo)->id;
                {
                while (1) {
                  while_322_continue:  ;
                  {
                  __constr_expr_33[0] = (unsigned char )((int )_v___11 >> 8);
                  __constr_expr_33[1] = (unsigned char )_v___11;
                  ret = __dyc_funcallvar_45;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_322_break;
                }
                while_322_break:  ;
                }
                goto while_321_break;
              }
              while_321_break:  ;
              }
              algo ++;
            }
            while_320_break:  ;
            }
            goto while_319_break;
          }
          while_319_break:  ;
          }
          body_size___12 = sendbuf->off - body_start___16;
          {
          while (1) {
            while_323_continue:  ;
            if (! (capacity___16 != 0UL)) {
              goto while_323_break;
            }
            *(sendbuf->base + (body_start___16 - capacity___16)) = (unsigned char )(body_size___12 >> 8UL * (capacity___16 - 1UL));
            capacity___16 --;
          }
          while_323_break:  ;
          }
          goto while_317_break;
        }
        while_317_break:  ;
        }
        goto while_316_break;
      }
      while_316_break:  ;
      }
      body_size___13 = sendbuf->off - body_start___15;
      {
      while (1) {
        while_324_continue:  ;
        if (! (capacity___15 != 0UL)) {
          goto while_324_break;
        }
        *(sendbuf->base + (body_start___15 - capacity___15)) = (unsigned char )(body_size___13 >> 8UL * (capacity___15 - 1UL));
        capacity___15 --;
      }
      while_324_break:  ;
      }
      goto while_314_break;
    }
    while_314_break:  ;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(capacity___11);
  __dyc_printpre_byte(body_start___11);
  __dyc_printpre_byte(capacity___12);
  __dyc_printpre_byte(body_start___12);
  __dyc_printpre_byte(body_size___8);
  __dyc_printpre_byte(body_size___9);
  __dyc_printpre_byte(capacity___13);
  __dyc_printpre_byte(body_start___13);
  __dyc_printpre_byte(capacity___14);
  __dyc_printpre_byte(body_start___14);
  __dyc_printpre_byte(body_size___10);
  __dyc_printpre_byte(body_size___11);
  __dyc_printpre_byte(capacity___15);
  __dyc_printpre_byte(body_start___15);
  __dyc_print_ptr__ptr__typdef_ptls_key_exchange_algorithm_t(algo);
  __dyc_printpre_byte(capacity___16);
  __dyc_printpre_byte(body_start___16);
  __dyc_printpre_byte(body_size___12);
  __dyc_printpre_byte(body_size___13);
}
}
