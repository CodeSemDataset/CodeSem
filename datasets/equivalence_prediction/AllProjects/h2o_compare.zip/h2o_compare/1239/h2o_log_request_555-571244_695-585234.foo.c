#include "../include/dycfoo.h"
#include "../include/logconf.i.hd.c.h"
void __dyc_foo(void) 
{ char *line ;
  char *pos ;
  char *line_end ;
  size_t unsafe_factor ;
  struct tm localt ;
  int should_realloc_on_expand ;
  struct log_element_t *element ;
  size_t off___6 ;
  size_t size___6 ;
  h2o_iovec_t *env_var ;
  h2o_iovec_t *tmp___1 ;
  size_t off___7 ;
  size_t size___7 ;
  size_t len___0 ;
  size_t off___8 ;
  size_t size___8 ;
  size_t off___9 ;
  size_t size___9 ;
  char *tmp___2 ;
  char *tmp___3 ;
  size_t tmp___4 ;
  size_t off___10 ;
  size_t size___10 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  size_t off___11 ;
  size_t size___11 ;
  char *tmp___8 ;
  char *tmp___9 ;
  int tmp___10 ;
  size_t bufsz ;
  size_t len___1 ;
  size_t off___12 ;
  size_t size___12 ;
  int tmp___11 ;
  size_t off___13 ;
  size_t size___13 ;
  int tmp___12 ;
  int tmp___13 ;
  size_t off___14 ;
  size_t size___14 ;
  int tmp___14 ;
  int tmp___15 ;
  size_t off___15 ;
  size_t size___15 ;
  int tmp___16 ;
  int tmp___17 ;
  size_t off___16 ;
  size_t size___16 ;
  int tmp___18 ;
  int tmp___19 ;
  size_t off___17 ;
  size_t size___17 ;
  int tmp___20 ;
  size_t path_len ;
  size_t tmp___21 ;
  size_t off___18 ;
  size_t size___18 ;
  h2o_iovec_t *remote_user ;
  h2o_iovec_t *tmp___22 ;
  size_t off___19 ;
  size_t size___19 ;
  size_t off___20 ;
  size_t size___20 ;
  size_t off___21 ;
  size_t size___21 ;
  h2o_headers_t *headers ;
  ssize_t index___0 ;
  int found ;
  size_t off___22 ;
  size_t size___22 ;
  char *tmp___23 ;
  char *tmp___24 ;
  h2o_header_t const   *header ;
  size_t off___23 ;
  size_t size___23 ;
  h2o_headers_t *headers___0 ;
  ssize_t index___1 ;
  int found___0 ;
  size_t off___24 ;
  size_t size___24 ;
  char *tmp___25 ;
  char *tmp___26 ;
  h2o_header_t const   *header___0 ;
  size_t off___25 ;
  size_t size___25 ;
  h2o_headers_t *headers___1 ;
  h2o_headers_t *tmp___27 ;
  ssize_t index___2 ;
  int found___1 ;
  size_t off___26 ;
  size_t size___26 ;
  char *tmp___28 ;
  char *tmp___29 ;
  h2o_header_t const   *header___1 ;
  size_t off___27 ;
  size_t size___27 ;
  h2o_req_t *req ;
  char *__dyc_funcallvar_15 ;
  char *__dyc_funcallvar_16 ;
  char *__dyc_funcallvar_17 ;
  h2o_iovec_t *__dyc_funcallvar_18 ;
  char *__dyc_funcallvar_19 ;
  char *__dyc_funcallvar_20 ;
  char *__dyc_funcallvar_21 ;
  char *__dyc_funcallvar_22 ;
  char *__dyc_funcallvar_23 ;
  char *__dyc_funcallvar_24 ;
  char *__dyc_funcallvar_25 ;
  size_t __dyc_funcallvar_26 ;
  char *__dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  char *__dyc_funcallvar_30 ;
  char *__dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  char *__dyc_funcallvar_33 ;
  size_t __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  char *__dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  char *__dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  char *__dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  char *__dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  char *__dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  char *__dyc_funcallvar_50 ;
  char *__dyc_funcallvar_51 ;
  h2o_iovec_t *__dyc_funcallvar_52 ;
  char *__dyc_funcallvar_53 ;
  char *__dyc_funcallvar_54 ;
  char *__dyc_funcallvar_55 ;
  char *__dyc_funcallvar_56 ;
  char *__dyc_funcallvar_57 ;
  char *__dyc_funcallvar_58 ;
  ssize_t __dyc_funcallvar_59 ;
  char *__dyc_funcallvar_60 ;
  char *__dyc_funcallvar_61 ;
  char *__dyc_funcallvar_62 ;
  ssize_t __dyc_funcallvar_63 ;
  char *__dyc_funcallvar_64 ;
  char *__dyc_funcallvar_65 ;
  char *__dyc_funcallvar_66 ;
  ssize_t __dyc_funcallvar_67 ;
  char *__dyc_funcallvar_68 ;
  char *__dyc_funcallvar_69 ;
  char *__dyc_funcallvar_70 ;

  {
  line = __dyc_read_ptr__char();
  pos = __dyc_read_ptr__char();
  line_end = __dyc_read_ptr__char();
  unsafe_factor = (size_t )__dyc_readpre_byte();
  localt = __dyc_read_comp_68tm();
  element = __dyc_read_ptr__comp_477log_element_t();
  req = __dyc_read_ptr__typdef_h2o_req_t();
  __dyc_funcallvar_15 = __dyc_read_ptr__char();
  __dyc_funcallvar_16 = __dyc_read_ptr__char();
  __dyc_funcallvar_17 = __dyc_read_ptr__char();
  __dyc_funcallvar_18 = __dyc_read_ptr__typdef_h2o_iovec_t();
  __dyc_funcallvar_19 = __dyc_read_ptr__char();
  __dyc_funcallvar_20 = __dyc_read_ptr__char();
  __dyc_funcallvar_21 = __dyc_read_ptr__char();
  __dyc_funcallvar_22 = __dyc_read_ptr__char();
  __dyc_funcallvar_23 = __dyc_read_ptr__char();
  __dyc_funcallvar_24 = __dyc_read_ptr__char();
  __dyc_funcallvar_25 = __dyc_read_ptr__char();
  __dyc_funcallvar_26 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_read_ptr__char();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_read_ptr__char();
  __dyc_funcallvar_31 = __dyc_read_ptr__char();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_read_ptr__char();
  __dyc_funcallvar_34 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_read_ptr__char();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_read_ptr__char();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_read_ptr__char();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_read_ptr__char();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_read_ptr__char();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_read_ptr__char();
  __dyc_funcallvar_51 = __dyc_read_ptr__char();
  __dyc_funcallvar_52 = __dyc_read_ptr__typdef_h2o_iovec_t();
  __dyc_funcallvar_53 = __dyc_read_ptr__char();
  __dyc_funcallvar_54 = __dyc_read_ptr__char();
  __dyc_funcallvar_55 = __dyc_read_ptr__char();
  __dyc_funcallvar_56 = __dyc_read_ptr__char();
  __dyc_funcallvar_57 = __dyc_read_ptr__char();
  __dyc_funcallvar_58 = __dyc_read_ptr__char();
  __dyc_funcallvar_59 = (ssize_t )__dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_read_ptr__char();
  __dyc_funcallvar_61 = __dyc_read_ptr__char();
  __dyc_funcallvar_62 = __dyc_read_ptr__char();
  __dyc_funcallvar_63 = (ssize_t )__dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_read_ptr__char();
  __dyc_funcallvar_65 = __dyc_read_ptr__char();
  __dyc_funcallvar_66 = __dyc_read_ptr__char();
  __dyc_funcallvar_67 = (ssize_t )__dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_read_ptr__char();
  __dyc_funcallvar_69 = __dyc_read_ptr__char();
  __dyc_funcallvar_70 = __dyc_read_ptr__char();
  should_realloc_on_expand = 0;
  off___6 = 0;
  size___6 = 0;
  env_var = 0;
  tmp___1 = 0;
  off___7 = 0;
  size___7 = 0;
  len___0 = 0;
  off___8 = 0;
  size___8 = 0;
  off___9 = 0;
  size___9 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  off___10 = 0;
  size___10 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  off___11 = 0;
  size___11 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  bufsz = 0;
  len___1 = 0;
  off___12 = 0;
  size___12 = 0;
  tmp___11 = 0;
  off___13 = 0;
  size___13 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  off___14 = 0;
  size___14 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  off___15 = 0;
  size___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  off___16 = 0;
  size___16 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  off___17 = 0;
  size___17 = 0;
  tmp___20 = 0;
  path_len = 0;
  tmp___21 = 0;
  off___18 = 0;
  size___18 = 0;
  remote_user = 0;
  tmp___22 = 0;
  off___19 = 0;
  size___19 = 0;
  off___20 = 0;
  size___20 = 0;
  off___21 = 0;
  size___21 = 0;
  headers = 0;
  index___0 = 0;
  found = 0;
  off___22 = 0;
  size___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  header = 0;
  off___23 = 0;
  size___23 = 0;
  headers___0 = 0;
  index___1 = 0;
  found___0 = 0;
  off___24 = 0;
  size___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  header___0 = 0;
  off___25 = 0;
  size___25 = 0;
  headers___1 = 0;
  tmp___27 = 0;
  index___2 = 0;
  found___1 = 0;
  off___26 = 0;
  size___26 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  header___1 = 0;
  off___27 = 0;
  size___27 = 0;
  pos = __dyc_funcallvar_15;
  goto __dyc_dummy_label;
  while (1) {
    while_63_continue:  ;
    if ((sizeof("65535") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___6 = (size_t )(pos - line);
      size___6 = (size_t )(line_end - line);
      line = __dyc_funcallvar_16;
      pos = line + off___6;
      line_end = line + size___6;
      should_realloc_on_expand = 1;
      }
    }
    goto while_63_break;
  }
  while_63_break:  ;
  pos = __dyc_funcallvar_17;
  goto __dyc_dummy_label;
  tmp___1 = __dyc_funcallvar_18;
  env_var = tmp___1;
  if ((unsigned long )env_var == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_64_continue:  ;
    if (env_var->len * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___7 = (size_t )(pos - line);
      size___7 = (size_t )(line_end - line);
      line = __dyc_funcallvar_19;
      pos = line + off___7;
      line_end = line + size___7;
      should_realloc_on_expand = 1;
      }
    }
    goto while_64_break;
  }
  while_64_break:  ;
  pos = __dyc_funcallvar_20;
  goto __dyc_dummy_label;
  switch_55_10:  
  if (req->input.query_at != 0xffffffffUL) {
    len___0 = req->input.path.len - req->input.query_at;
    {
    while (1) {
      while_65_continue:  ;
      if (len___0 * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
        {
        off___8 = (size_t )(pos - line);
        size___8 = (size_t )(line_end - line);
        line = __dyc_funcallvar_21;
        pos = line + off___8;
        line_end = line + size___8;
        should_realloc_on_expand = 1;
        }
      }
      goto while_65_break;
    }
    while_65_break:  ;
    }
    {
    pos = __dyc_funcallvar_22;
    }
  }
  goto __dyc_dummy_label;
  while (1) {
    while_66_continue:  ;
    if (((req->input.method.len + req->input.path.len) * unsafe_factor + sizeof("  HTTP/1.1")) + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___9 = (size_t )(pos - line);
      size___9 = (size_t )(line_end - line);
      line = __dyc_funcallvar_23;
      pos = line + off___9;
      line_end = line + size___9;
      should_realloc_on_expand = 1;
      }
    }
    goto while_66_break;
  }
  while_66_break:  ;
  pos = __dyc_funcallvar_24;
  tmp___2 = pos;
  pos ++;
  *tmp___2 = (char )' ';
  pos = __dyc_funcallvar_25;
  tmp___3 = pos;
  pos ++;
  *tmp___3 = (char )' ';
  tmp___4 = __dyc_funcallvar_26;
  pos += tmp___4;
  goto __dyc_dummy_label;
  while (1) {
    while_67_continue:  ;
    if ((sizeof("-2147483648") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___10 = (size_t )(pos - line);
      size___10 = (size_t )(line_end - line);
      line = __dyc_funcallvar_27;
      pos = line + off___10;
      line_end = line + size___10;
      should_realloc_on_expand = 1;
      }
    }
    goto while_67_break;
  }
  while_67_break:  ;
  if (element->original_response) {
    tmp___5 = req->res.original.status;
  } else {
    tmp___5 = req->res.status;
  }
  tmp___6 = __dyc_funcallvar_28;
  pos += tmp___6;
  goto __dyc_dummy_label;
  tmp___7 = __dyc_funcallvar_29;
  if (tmp___7) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_68_continue:  ;
    if (((sizeof("29/Aug/2014:15:34:38 +0900") - 1UL) + 2UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___11 = (size_t )(pos - line);
      size___11 = (size_t )(line_end - line);
      line = __dyc_funcallvar_30;
      pos = line + off___11;
      line_end = line + size___11;
      should_realloc_on_expand = 1;
      }
    }
    goto while_68_break;
  }
  while_68_break:  ;
  tmp___8 = pos;
  pos ++;
  *tmp___8 = (char )'[';
  pos = __dyc_funcallvar_31;
  tmp___9 = pos;
  pos ++;
  *tmp___9 = (char )']';
  goto __dyc_dummy_label;
  tmp___10 = __dyc_funcallvar_32;
  if (tmp___10) {
    goto __dyc_dummy_label;
  }
  if (localt.tm_year == 0) {
    {

    }
  }
  bufsz = 128UL;
  while (1) {
    while_69_continue:  ;
    {
    while (1) {
      while_70_continue:  ;
      if (bufsz + element->suffix.len > (size_t )(line_end - pos)) {
        {
        off___12 = (size_t )(pos - line);
        size___12 = (size_t )(line_end - line);
        line = __dyc_funcallvar_33;
        pos = line + off___12;
        line_end = line + size___12;
        should_realloc_on_expand = 1;
        }
      }
      goto while_70_break;
    }
    while_70_break:  ;
    }
    {
    len___1 = __dyc_funcallvar_34;
    }
    if (len___1 != 0UL) {
      goto while_69_break;
    }
    bufsz *= 2UL;
  }
  while_69_break:  ;
  pos += len___1;
  goto __dyc_dummy_label;
  tmp___11 = __dyc_funcallvar_35;
  if (tmp___11) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_71_continue:  ;
    if ((sizeof("4294967295") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___13 = (size_t )(pos - line);
      size___13 = (size_t )(line_end - line);
      line = __dyc_funcallvar_36;
      pos = line + off___13;
      line_end = line + size___13;
      should_realloc_on_expand = 1;
      }
    }
    goto while_71_break;
  }
  while_71_break:  ;
  tmp___12 = __dyc_funcallvar_37;
  pos += tmp___12;
  goto __dyc_dummy_label;
  tmp___13 = __dyc_funcallvar_38;
  if (tmp___13) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_72_continue:  ;
    if ((sizeof("18446744073709551615") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___14 = (size_t )(pos - line);
      size___14 = (size_t )(line_end - line);
      line = __dyc_funcallvar_39;
      pos = line + off___14;
      line_end = line + size___14;
      should_realloc_on_expand = 1;
      }
    }
    goto while_72_break;
  }
  while_72_break:  ;
  tmp___14 = __dyc_funcallvar_40;
  pos += tmp___14;
  goto __dyc_dummy_label;
  tmp___15 = __dyc_funcallvar_41;
  if (tmp___15) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_73_continue:  ;
    if ((sizeof("18446744073709551615") - 1UL) + element->suffix.len > (unsigned long )(line_end - pos)) {
      {
      off___15 = (size_t )(pos - line);
      size___15 = (size_t )(line_end - line);
      line = __dyc_funcallvar_42;
      pos = line + off___15;
      line_end = line + size___15;
      should_realloc_on_expand = 1;
      }
    }
    goto while_73_break;
  }
  while_73_break:  ;
  tmp___16 = __dyc_funcallvar_43;
  pos += tmp___16;
  goto __dyc_dummy_label;
  tmp___17 = __dyc_funcallvar_44;
  if (tmp___17) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_74_continue:  ;
    if (3UL + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___16 = (size_t )(pos - line);
      size___16 = (size_t )(line_end - line);
      line = __dyc_funcallvar_45;
      pos = line + off___16;
      line_end = line + size___16;
      should_realloc_on_expand = 1;
      }
    }
    goto while_74_break;
  }
  while_74_break:  ;
  tmp___18 = __dyc_funcallvar_46;
  pos += tmp___18;
  goto __dyc_dummy_label;
  tmp___19 = __dyc_funcallvar_47;
  if (tmp___19) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_75_continue:  ;
    if (6UL + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___17 = (size_t )(pos - line);
      size___17 = (size_t )(line_end - line);
      line = __dyc_funcallvar_48;
      pos = line + off___17;
      line_end = line + size___17;
      should_realloc_on_expand = 1;
      }
    }
    goto while_75_break;
  }
  while_75_break:  ;
  tmp___20 = __dyc_funcallvar_49;
  pos += tmp___20;
  goto __dyc_dummy_label;
  switch_55_20:  
  if (req->input.query_at == 0xffffffffUL) {
    tmp___21 = req->input.path.len;
  } else {
    tmp___21 = req->input.query_at;
  }
  path_len = tmp___21;
  while (1) {
    while_76_continue:  ;
    if (path_len * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___18 = (size_t )(pos - line);
      size___18 = (size_t )(line_end - line);
      line = __dyc_funcallvar_50;
      pos = line + off___18;
      line_end = line + size___18;
      should_realloc_on_expand = 1;
      }
    }
    goto while_76_break;
  }
  while_76_break:  ;
  pos = __dyc_funcallvar_51;
  goto __dyc_dummy_label;
  tmp___22 = __dyc_funcallvar_52;
  remote_user = tmp___22;
  if ((unsigned long )remote_user == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_77_continue:  ;
    if (remote_user->len * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___19 = (size_t )(pos - line);
      size___19 = (size_t )(line_end - line);
      line = __dyc_funcallvar_53;
      pos = line + off___19;
      line_end = line + size___19;
      should_realloc_on_expand = 1;
      }
    }
    goto while_77_break;
  }
  while_77_break:  ;
  pos = __dyc_funcallvar_54;
  goto __dyc_dummy_label;
  while (1) {
    while_78_continue:  ;
    if (req->input.authority.len * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___20 = (size_t )(pos - line);
      size___20 = (size_t )(line_end - line);
      line = __dyc_funcallvar_55;
      pos = line + off___20;
      line_end = line + size___20;
      should_realloc_on_expand = 1;
      }
    }
    goto while_78_break;
  }
  while_78_break:  ;
  pos = __dyc_funcallvar_56;
  goto __dyc_dummy_label;
  while (1) {
    while_79_continue:  ;
    if ((req->hostconf)->authority.hostport.len * unsafe_factor + element->suffix.len > (size_t )(line_end - pos)) {
      {
      off___21 = (size_t )(pos - line);
      size___21 = (size_t )(line_end - line);
      line = __dyc_funcallvar_57;
      pos = line + off___21;
      line_end = line + size___21;
      should_realloc_on_expand = 1;
      }
    }
    goto while_79_break;
  }
  while_79_break:  ;
  pos = __dyc_funcallvar_58;
  goto __dyc_dummy_label;
  while (1) {
    while_80_continue:  ;
    headers = & req->headers;
    index___0 = (ssize_t )-1;
    found = 0;
    {
    while (1) {
      while_81_continue:  ;
      {
      index___0 = __dyc_funcallvar_59;
      }
      if (! (index___0 != -1L)) {
        goto while_81_break;
      }
      if (found) {
        {
        while (1) {
          while_82_continue:  ;
          if (2UL + element->suffix.len > (size_t )(line_end - pos)) {
            {
            off___22 = (size_t )(pos - line);
            size___22 = (size_t )(line_end - line);
            line = __dyc_funcallvar_60;
            pos = line + off___22;
            line_end = line + size___22;
            should_realloc_on_expand = 1;
            }
          }
          goto while_82_break;
        }
        while_82_break:  ;
        }
        tmp___23 = pos;
        pos ++;
        *tmp___23 = (char )',';
        tmp___24 = pos;
        pos ++;
        *tmp___24 = (char )' ';
      } else {
        found = 1;
      }
      header = (h2o_header_t const   *)(headers->entries + index___0);
      {
      while (1) {
        while_83_continue:  ;
        if (header->value.len * (size_t const   )unsafe_factor + (size_t const   )element->suffix.len > (size_t const   )(line_end - pos)) {
          {
          off___23 = (size_t )(pos - line);
          size___23 = (size_t )(line_end - line);
          line = __dyc_funcallvar_61;
          pos = line + off___23;
          line_end = line + size___23;
          should_realloc_on_expand = 1;
          }
        }
        goto while_83_break;
      }
      while_83_break:  ;
      }
      {
      pos = __dyc_funcallvar_62;
      }
      goto while_81_break;
    }
    while_81_break:  ;
    }
    if (! found) {
      goto __dyc_dummy_label;
    }
    goto while_80_break;
  }
  while_80_break:  ;
  goto __dyc_dummy_label;
  while (1) {
    while_84_continue:  ;
    headers___0 = & req->headers;
    index___1 = (ssize_t )-1;
    found___0 = 0;
    {
    while (1) {
      while_85_continue:  ;
      {
      index___1 = __dyc_funcallvar_63;
      }
      if (! (index___1 != -1L)) {
        goto while_85_break;
      }
      if (found___0) {
        {
        while (1) {
          while_86_continue:  ;
          if (2UL + element->suffix.len > (size_t )(line_end - pos)) {
            {
            off___24 = (size_t )(pos - line);
            size___24 = (size_t )(line_end - line);
            line = __dyc_funcallvar_64;
            pos = line + off___24;
            line_end = line + size___24;
            should_realloc_on_expand = 1;
            }
          }
          goto while_86_break;
        }
        while_86_break:  ;
        }
        tmp___25 = pos;
        pos ++;
        *tmp___25 = (char )',';
        tmp___26 = pos;
        pos ++;
        *tmp___26 = (char )' ';
      } else {
        found___0 = 1;
      }
      header___0 = (h2o_header_t const   *)(headers___0->entries + index___1);
      {
      while (1) {
        while_87_continue:  ;
        if (header___0->value.len * (size_t const   )unsafe_factor + (size_t const   )element->suffix.len > (size_t const   )(line_end - pos)) {
          {
          off___25 = (size_t )(pos - line);
          size___25 = (size_t )(line_end - line);
          line = __dyc_funcallvar_65;
          pos = line + off___25;
          line_end = line + size___25;
          should_realloc_on_expand = 1;
          }
        }
        goto while_87_break;
      }
      while_87_break:  ;
      }
      {
      pos = __dyc_funcallvar_66;
      }
      goto while_85_break;
    }
    while_85_break:  ;
    }
    if (! found___0) {
      goto __dyc_dummy_label;
    }
    goto while_84_break;
  }
  while_84_break:  ;
  goto __dyc_dummy_label;
  while (1) {
    while_88_continue:  ;
    if (element->original_response) {
      tmp___27 = & req->res.original.headers;
    } else {
      tmp___27 = & req->res.headers;
    }
    headers___1 = tmp___27;
    index___2 = (ssize_t )-1;
    found___1 = 0;
    {
    while (1) {
      while_89_continue:  ;
      {
      index___2 = __dyc_funcallvar_67;
      }
      if (! (index___2 != -1L)) {
        goto while_89_break;
      }
      if (found___1) {
        {
        while (1) {
          while_90_continue:  ;
          if (2UL + element->suffix.len > (size_t )(line_end - pos)) {
            {
            off___26 = (size_t )(pos - line);
            size___26 = (size_t )(line_end - line);
            line = __dyc_funcallvar_68;
            pos = line + off___26;
            line_end = line + size___26;
            should_realloc_on_expand = 1;
            }
          }
          goto while_90_break;
        }
        while_90_break:  ;
        }
        tmp___28 = pos;
        pos ++;
        *tmp___28 = (char )',';
        tmp___29 = pos;
        pos ++;
        *tmp___29 = (char )' ';
      } else {
        found___1 = 1;
      }
      header___1 = (h2o_header_t const   *)(headers___1->entries + index___2);
      {
      while (1) {
        while_91_continue:  ;
        if (header___1->value.len * (size_t const   )unsafe_factor + (size_t const   )element->suffix.len > (size_t const   )(line_end - pos)) {
          {
          off___27 = (size_t )(pos - line);
          size___27 = (size_t )(line_end - line);
          line = __dyc_funcallvar_69;
          pos = line + off___27;
          line_end = line + size___27;
          should_realloc_on_expand = 1;
          }
        }
        goto while_91_break;
      }
      while_91_break:  ;
      }
      {
      pos = __dyc_funcallvar_70;
      }
      goto while_89_break;
    }
    while_89_break:  ;
    }
    if (! found___1) {
      goto __dyc_dummy_label;
    }
    goto while_88_break;
  }
  while_88_break:  ;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(pos);
  __dyc_print_ptr__char(line_end);
  __dyc_printpre_byte(should_realloc_on_expand);
  __dyc_printpre_byte(tmp___5);
  __dyc_print_ptr__typdef_h2o_headers_t(headers);
  __dyc_print_ptr__typdef_h2o_headers_t(headers___0);
  __dyc_print_ptr__typdef_h2o_headers_t(headers___1);
}
}
