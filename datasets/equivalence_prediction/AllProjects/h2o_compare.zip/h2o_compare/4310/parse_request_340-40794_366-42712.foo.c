#include "../include/dycfoo.h"
#include "../include/picohttpparser.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *tmp ;
  char const   *tok_start ;
  int found2 ;
  long tmp___0 ;
  char const   *tok_start___0 ;
  int found2___0 ;
  long tmp___1 ;
  char const   *tmp___2 ;
  char const   *tmp___3 ;
  char const   *buf ;
  char const   *buf_end ;
  char const   **method ;
  size_t *method_len ;
  char const   **path ;
  size_t *path_len ;
  int *ret ;
  char const   *__dyc_funcallvar_1 ;
  long __dyc_funcallvar_2 ;
  char const   *__dyc_funcallvar_3 ;
  long __dyc_funcallvar_4 ;
  char const   *__dyc_funcallvar_5 ;
  char const   *__dyc_funcallvar_6 ;

  {
  found2 = __dyc_readpre_byte();
  found2___0 = __dyc_readpre_byte();
  buf = (char const   *)__dyc_read_ptr__char();
  buf_end = (char const   *)__dyc_read_ptr__char();
  method = (char const   **)__dyc_read_ptr__ptr__char();
  method_len = __dyc_read_ptr__typdef_size_t();
  path = (char const   **)__dyc_read_ptr__ptr__char();
  path_len = __dyc_read_ptr__typdef_size_t();
  ret = __dyc_read_ptr__int();
  __dyc_funcallvar_1 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_2 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_3 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_4 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_5 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_6 = (char const   *)__dyc_read_ptr__char();
  tmp = 0;
  tok_start = 0;
  tmp___0 = 0;
  tok_start___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  if ((unsigned long )buf == (unsigned long )buf_end) {
    *ret = -2;
    goto __dyc_dummy_label;
  }
  if ((int const   )*buf == 13) {
    buf ++;
    if ((unsigned long )buf == (unsigned long )buf_end) {
      *ret = -2;
      goto __dyc_dummy_label;
    }
    tmp = buf;
    buf ++;
    if ((int const   )*tmp != 10) {
      *ret = -1;
      goto __dyc_dummy_label;
    }
  } else {
    if ((int const   )*buf == 10) {
      buf ++;
    }
  }
  while (1) {
    while_14_continue:  ;
    {
    tok_start = buf;
    buf = __dyc_funcallvar_1;
    }
    if (! found2) {
      if ((unsigned long )buf == (unsigned long )buf_end) {
        *ret = -2;
        goto __dyc_dummy_label;
      }
    }
    {
    while (1) {
      while_15_continue:  ;
      if ((int const   )*buf == 32) {
        goto while_15_break;
      } else {
        {
        tmp___0 = __dyc_funcallvar_2;
        }
        if (tmp___0) {
          if ((int )((unsigned char )*buf) < 32) {
            *ret = -1;
            goto __dyc_dummy_label;
          } else {
            if ((int const   )*buf == 127) {
              *ret = -1;
              goto __dyc_dummy_label;
            }
          }
        }
      }
      buf ++;
      if ((unsigned long )buf == (unsigned long )buf_end) {
        *ret = -2;
        goto __dyc_dummy_label;
      }
    }
    while_15_break:  ;
    }
    *method = tok_start;
    *method_len = (unsigned long )(buf - tok_start);
    goto while_14_break;
  }
  while_14_break:  ;
  buf ++;
  while (1) {
    while_16_continue:  ;
    {
    tok_start___0 = buf;
    buf = __dyc_funcallvar_3;
    }
    if (! found2___0) {
      if ((unsigned long )buf == (unsigned long )buf_end) {
        *ret = -2;
        goto __dyc_dummy_label;
      }
    }
    {
    while (1) {
      while_17_continue:  ;
      if ((int const   )*buf == 32) {
        goto while_17_break;
      } else {
        {
        tmp___1 = __dyc_funcallvar_4;
        }
        if (tmp___1) {
          if ((int )((unsigned char )*buf) < 32) {
            *ret = -1;
            goto __dyc_dummy_label;
          } else {
            if ((int const   )*buf == 127) {
              *ret = -1;
              goto __dyc_dummy_label;
            }
          }
        }
      }
      buf ++;
      if ((unsigned long )buf == (unsigned long )buf_end) {
        *ret = -2;
        goto __dyc_dummy_label;
      }
    }
    while_17_break:  ;
    }
    *path = tok_start___0;
    *path_len = (unsigned long )(buf - tok_start___0);
    goto while_16_break;
  }
  while_16_break:  ;
  buf ++;
  buf = __dyc_funcallvar_5;
  if ((unsigned long )buf == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  if ((int const   )*buf == 13) {
    buf ++;
    if ((unsigned long )buf == (unsigned long )buf_end) {
      *ret = -2;
      goto __dyc_dummy_label;
    }
    tmp___2 = buf;
    buf ++;
    if ((int const   )*tmp___2 != 10) {
      *ret = -1;
      goto __dyc_dummy_label;
    }
  } else {
    if ((int const   )*buf == 10) {
      buf ++;
    } else {
      *ret = -1;
      goto __dyc_dummy_label;
    }
  }
  tmp___3 = __dyc_funcallvar_6;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(tok_start);
  __dyc_print_ptr__char(tok_start___0);
  __dyc_print_ptr__char(tmp___3);
  __dyc_print_ptr__char(buf);
}
}
