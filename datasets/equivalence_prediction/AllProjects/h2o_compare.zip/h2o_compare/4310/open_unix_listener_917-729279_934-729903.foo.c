#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ struct stat st ;
  int fd ;
  struct passwd *owner ;
  int __attribute__((__leaf__))  tmp___3 ;
  int *tmp___4 ;
  char *tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int *tmp___8 ;
  char *tmp___9 ;
  int tmp___10 ;
  int __dyc_funcallvar_10 ;
  int *__dyc_funcallvar_11 ;
  char *__dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int *__dyc_funcallvar_14 ;
  char *__dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int *__dyc_funcallvar_17 ;
  char *__dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int *__dyc_funcallvar_20 ;
  char *__dyc_funcallvar_21 ;

  {
  st = __dyc_read_comp_61stat();
  owner = __dyc_read_ptr__comp_93passwd();
  tmp___3 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_read_ptr__int();
  __dyc_funcallvar_12 = __dyc_read_ptr__char();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_read_ptr__int();
  __dyc_funcallvar_15 = __dyc_read_ptr__char();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_read_ptr__int();
  __dyc_funcallvar_18 = __dyc_read_ptr__char();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_read_ptr__int();
  __dyc_funcallvar_21 = __dyc_read_ptr__char();
  fd = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  if (tmp___3 == (int __attribute__((__leaf__))  )0) {
    if ((st.st_mode & 61440U) == 49152U) {
      {

      }
    } else {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  fd = __dyc_funcallvar_10;
  if (fd == -1) {
    {
    tmp___4 = __dyc_funcallvar_11;
    tmp___5 = __dyc_funcallvar_12;

    }
    goto __dyc_dummy_label;
  } else {
    {
    tmp___6 = __dyc_funcallvar_13;
    }
    if (tmp___6 != 0) {
      {
      tmp___4 = __dyc_funcallvar_14;
      tmp___5 = __dyc_funcallvar_15;

      }
      goto __dyc_dummy_label;
    } else {
      {
      tmp___7 = __dyc_funcallvar_16;
      }
      if (tmp___7 != 0) {
        {
        tmp___4 = __dyc_funcallvar_17;
        tmp___5 = __dyc_funcallvar_18;

        }
        goto __dyc_dummy_label;
      }
    }
  }

  if ((unsigned long )owner != (unsigned long )((void *)0)) {
    {
    tmp___10 = __dyc_funcallvar_19;
    }
    if (tmp___10 != 0) {
      {
      tmp___8 = __dyc_funcallvar_20;
      tmp___9 = __dyc_funcallvar_21;

      }
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__int(tmp___4);
  __dyc_print_ptr__char(tmp___5);
  __dyc_print_ptr__int(tmp___8);
  __dyc_print_ptr__char(tmp___9);
}
}
