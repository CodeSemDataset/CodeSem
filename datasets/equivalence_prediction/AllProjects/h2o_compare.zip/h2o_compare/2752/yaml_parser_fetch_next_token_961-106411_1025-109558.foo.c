#include "../include/dycfoo.h"
#include "../include/scanner.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  yaml_parser_t *parser ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;

  {
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  if ((int )*(parser->buffer.pointer + 0) == 63) {
    if (parser->flow_level) {
      {
      tmp___17 = __dyc_funcallvar_38;
      }
      goto __dyc_dummy_label;
    } else {
      if ((int )*(parser->buffer.pointer + 1) == 32) {
        {
        tmp___17 = __dyc_funcallvar_39;
        }
        goto __dyc_dummy_label;
      } else {
        if ((int )*(parser->buffer.pointer + 1) == 9) {
          {
          tmp___17 = __dyc_funcallvar_40;
          }
          goto __dyc_dummy_label;
        } else {
          if ((int )*(parser->buffer.pointer + 1) == 13) {
            {
            tmp___17 = __dyc_funcallvar_41;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 1) == 10) {
              {
              tmp___17 = __dyc_funcallvar_42;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 1) == 194) {
                if ((int )*(parser->buffer.pointer + 2) == 133) {
                  {
                  tmp___17 = __dyc_funcallvar_43;
                  }
                  goto __dyc_dummy_label;
                } else {
                  goto _L___18;
                }
              } else {
                _L___18:  
                if ((int )*(parser->buffer.pointer + 1) == 226) {
                  if ((int )*(parser->buffer.pointer + 2) == 128) {
                    if ((int )*(parser->buffer.pointer + 3) == 168) {
                      {
                      tmp___17 = __dyc_funcallvar_44;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___17;
                    }
                  } else {
                    goto _L___17;
                  }
                } else {
                  _L___17:  
                  if ((int )*(parser->buffer.pointer + 1) == 226) {
                    if ((int )*(parser->buffer.pointer + 2) == 128) {
                      if ((int )*(parser->buffer.pointer + 3) == 169) {
                        {
                        tmp___17 = __dyc_funcallvar_45;
                        }
                        goto __dyc_dummy_label;
                      } else {
                        goto _L___15;
                      }
                    } else {
                      goto _L___15;
                    }
                  } else {
                    _L___15:  
                    if ((int )*(parser->buffer.pointer + 1) == 0) {
                      {
                      tmp___17 = __dyc_funcallvar_46;
                      }
                      goto __dyc_dummy_label;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ((int )*(parser->buffer.pointer + 0) == 58) {
    if (parser->flow_level) {
      {
      tmp___18 = __dyc_funcallvar_47;
      }
      goto __dyc_dummy_label;
    } else {
      if ((int )*(parser->buffer.pointer + 1) == 32) {
        {
        tmp___18 = __dyc_funcallvar_48;
        }
        goto __dyc_dummy_label;
      } else {
        if ((int )*(parser->buffer.pointer + 1) == 9) {
          {
          tmp___18 = __dyc_funcallvar_49;
          }
          goto __dyc_dummy_label;
        } else {
          if ((int )*(parser->buffer.pointer + 1) == 13) {
            {
            tmp___18 = __dyc_funcallvar_50;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 1) == 10) {
              {
              tmp___18 = __dyc_funcallvar_51;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 1) == 194) {
                if ((int )*(parser->buffer.pointer + 2) == 133) {
                  {
                  tmp___18 = __dyc_funcallvar_52;
                  }
                  goto __dyc_dummy_label;
                } else {
                  goto _L___23;
                }
              } else {
                _L___23:  
                if ((int )*(parser->buffer.pointer + 1) == 226) {
                  if ((int )*(parser->buffer.pointer + 2) == 128) {
                    if ((int )*(parser->buffer.pointer + 3) == 168) {
                      {
                      tmp___18 = __dyc_funcallvar_53;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___22;
                    }
                  } else {
                    goto _L___22;
                  }
                } else {
                  _L___22:  
                  if ((int )*(parser->buffer.pointer + 1) == 226) {
                    if ((int )*(parser->buffer.pointer + 2) == 128) {
                      if ((int )*(parser->buffer.pointer + 3) == 169) {
                        {
                        tmp___18 = __dyc_funcallvar_54;
                        }
                        goto __dyc_dummy_label;
                      } else {
                        goto _L___20;
                      }
                    } else {
                      goto _L___20;
                    }
                  } else {
                    _L___20:  
                    if ((int )*(parser->buffer.pointer + 1) == 0) {
                      {
                      tmp___18 = __dyc_funcallvar_55;
                      }
                      goto __dyc_dummy_label;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ((int )*(parser->buffer.pointer + 0) == 42) {
    {
    tmp___19 = __dyc_funcallvar_56;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 38) {
    {
    tmp___20 = __dyc_funcallvar_57;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 33) {
    {
    tmp___21 = __dyc_funcallvar_58;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 124) {
    if (! parser->flow_level) {
      {
      tmp___22 = __dyc_funcallvar_59;
      }
      goto __dyc_dummy_label;
    }
  }
  if ((int )*(parser->buffer.pointer + 0) == 62) {
    if (! parser->flow_level) {
      {
      tmp___23 = __dyc_funcallvar_60;
      }
      goto __dyc_dummy_label;
    }
  }
  if ((int )*(parser->buffer.pointer + 0) == 39) {
    {
    tmp___24 = __dyc_funcallvar_61;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 34) {
    {
    tmp___25 = __dyc_funcallvar_62;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 32) {
    goto _L___31;
  } else {
    if ((int )*(parser->buffer.pointer + 0) == 9) {
      goto _L___31;
    } else {
      if ((int )*(parser->buffer.pointer + 0) == 13) {
        goto _L___31;
      } else {
        if ((int )*(parser->buffer.pointer + 0) == 10) {
          goto _L___31;
        } else {
          if ((int )*(parser->buffer.pointer + 0) == 194) {
            if ((int )*(parser->buffer.pointer + 1) == 133) {
              goto _L___31;
            } else {
              goto _L___36;
            }
          } else {
            _L___36:  
            if ((int )*(parser->buffer.pointer + 0) == 226) {
              if ((int )*(parser->buffer.pointer + 1) == 128) {
                if ((int )*(parser->buffer.pointer + 2) == 168) {
                  goto _L___31;
                } else {
                  goto _L___35;
                }
              } else {
                goto _L___35;
              }
            } else {
              _L___35:  
              if ((int )*(parser->buffer.pointer + 0) == 226) {
                if ((int )*(parser->buffer.pointer + 1) == 128) {
                  if ((int )*(parser->buffer.pointer + 2) == 169) {
                    goto _L___31;
                  } else {
                    goto _L___33;
                  }
                } else {
                  goto _L___33;
                }
              } else {
                _L___33:  
                if ((int )*(parser->buffer.pointer + 0) == 0) {
                  goto _L___31;
                } else {
                  if ((int )*(parser->buffer.pointer + 0) == 45) {
                    goto _L___31;
                  } else {
                    if ((int )*(parser->buffer.pointer + 0) == 63) {
                      goto _L___31;
                    } else {
                      if ((int )*(parser->buffer.pointer + 0) == 58) {
                        goto _L___31;
                      } else {
                        if ((int )*(parser->buffer.pointer + 0) == 44) {
                          goto _L___31;
                        } else {
                          if ((int )*(parser->buffer.pointer + 0) == 91) {
                            goto _L___31;
                          } else {
                            if ((int )*(parser->buffer.pointer + 0) == 93) {
                              goto _L___31;
                            } else {
                              if ((int )*(parser->buffer.pointer + 0) == 123) {
                                goto _L___31;
                              } else {
                                if ((int )*(parser->buffer.pointer + 0) == 125) {
                                  goto _L___31;
                                } else {
                                  if ((int )*(parser->buffer.pointer + 0) == 35) {
                                    goto _L___31;
                                  } else {
                                    if ((int )*(parser->buffer.pointer + 0) == 38) {
                                      goto _L___31;
                                    } else {
                                      if ((int )*(parser->buffer.pointer + 0) == 42) {
                                        goto _L___31;
                                      } else {
                                        if ((int )*(parser->buffer.pointer + 0) == 33) {
                                          goto _L___31;
                                        } else {
                                          if ((int )*(parser->buffer.pointer + 0) == 124) {
                                            goto _L___31;
                                          } else {
                                            if ((int )*(parser->buffer.pointer + 0) == 62) {
                                              goto _L___31;
                                            } else {
                                              if ((int )*(parser->buffer.pointer + 0) == 39) {
                                                goto _L___31;
                                              } else {
                                                if ((int )*(parser->buffer.pointer + 0) == 34) {
                                                  goto _L___31;
                                                } else {
                                                  if ((int )*(parser->buffer.pointer + 0) == 37) {
                                                    goto _L___31;
                                                  } else {
                                                    if ((int )*(parser->buffer.pointer + 0) == 64) {
                                                      goto _L___31;
                                                    } else {
                                                      if ((int )*(parser->buffer.pointer + 0) == 96) {
                                                        _L___31:  
                                                        if ((int )*(parser->buffer.pointer + 0) == 45) {
                                                          if ((int )*(parser->buffer.pointer + 1) == 32) {
                                                            goto _L___30;
                                                          } else {
                                                            if ((int )*(parser->buffer.pointer + 1) == 9) {
                                                              goto _L___30;
                                                            } else {
                                                              {
                                                              tmp___26 = __dyc_funcallvar_63;
                                                              }
                                                              goto __dyc_dummy_label;
                                                            }
                                                          }
                                                        } else {
                                                          _L___30:  
                                                          if (! parser->flow_level) {
                                                            if ((int )*(parser->buffer.pointer + 0) == 63) {
                                                              goto _L___29;
                                                            } else {
                                                              if ((int )*(parser->buffer.pointer + 0) == 58) {
                                                                _L___29:  
                                                                if (! ((int )*(parser->buffer.pointer + 1) == 32)) {
                                                                  if (! ((int )*(parser->buffer.pointer + 1) == 9)) {
                                                                    if (! ((int )*(parser->buffer.pointer + 1) == 13)) {
                                                                      if (! ((int )*(parser->buffer.pointer + 1) == 10)) {
                                                                        if ((int )*(parser->buffer.pointer + 1) == 194) {
                                                                          if (! ((int )*(parser->buffer.pointer + 2) == 133)) {
                                                                            goto _L___28;
                                                                          }
                                                                        } else {
                                                                          _L___28:  
                                                                          if ((int )*(parser->buffer.pointer + 1) == 226) {
                                                                            if ((int )*(parser->buffer.pointer + 2) == 128) {
                                                                              if (! ((int )*(parser->buffer.pointer + 3) == 168)) {
                                                                                goto _L___27;
                                                                              }
                                                                            } else {
                                                                              goto _L___27;
                                                                            }
                                                                          } else {
                                                                            _L___27:  
                                                                            if ((int )*(parser->buffer.pointer + 1) == 226) {
                                                                              if ((int )*(parser->buffer.pointer + 2) == 128) {
                                                                                if (! ((int )*(parser->buffer.pointer + 3) == 169)) {
                                                                                  goto _L___25;
                                                                                }
                                                                              } else {
                                                                                goto _L___25;
                                                                              }
                                                                            } else {
                                                                              _L___25:  
                                                                              if (! ((int )*(parser->buffer.pointer + 1) == 0)) {
                                                                                {
                                                                                tmp___26 = __dyc_funcallvar_64;
                                                                                }
                                                                                goto __dyc_dummy_label;
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      } else {
                                                        {
                                                        tmp___26 = __dyc_funcallvar_65;
                                                        }
                                                        goto __dyc_dummy_label;
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___17);
  __dyc_printpre_byte(tmp___18);
  __dyc_printpre_byte(tmp___19);
  __dyc_printpre_byte(tmp___20);
  __dyc_printpre_byte(tmp___21);
  __dyc_printpre_byte(tmp___22);
  __dyc_printpre_byte(tmp___23);
  __dyc_printpre_byte(tmp___24);
  __dyc_printpre_byte(tmp___25);
  __dyc_printpre_byte(tmp___26);
}
}
