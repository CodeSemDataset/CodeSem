#include "../include/dycfoo.h"
#include "../include/scanner.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  yaml_parser_t *parser ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;

  {
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  if (! parser->stream_start_produced) {
    {
    tmp___1 = __dyc_funcallvar_2;
    }
    goto __dyc_dummy_label;
  }
  tmp___2 = __dyc_funcallvar_3;
  if (! tmp___2) {
    goto __dyc_dummy_label;
  }
  tmp___3 = __dyc_funcallvar_4;
  if (! tmp___3) {
    goto __dyc_dummy_label;
  }
  tmp___4 = __dyc_funcallvar_5;
  if (! tmp___4) {
    goto __dyc_dummy_label;
  }
  if (parser->unread >= 4UL) {
    tmp___6 = 1;
  } else {
    {
    tmp___6 = __dyc_funcallvar_6;
    }
  }
  if (! tmp___6) {
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 0) {
    {
    tmp___7 = __dyc_funcallvar_7;
    }
    goto __dyc_dummy_label;
  }
  if (parser->mark.column == 0UL) {
    if ((int )*(parser->buffer.pointer + 0) == 37) {
      {
      tmp___8 = __dyc_funcallvar_8;
      }
      goto __dyc_dummy_label;
    }
  }
  if (parser->mark.column == 0UL) {
    if ((int )*(parser->buffer.pointer + 0) == 45) {
      if ((int )*(parser->buffer.pointer + 1) == 45) {
        if ((int )*(parser->buffer.pointer + 2) == 45) {
          if ((int )*(parser->buffer.pointer + 3) == 32) {
            {
            tmp___9 = __dyc_funcallvar_9;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 3) == 9) {
              {
              tmp___9 = __dyc_funcallvar_10;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 3) == 13) {
                {
                tmp___9 = __dyc_funcallvar_11;
                }
                goto __dyc_dummy_label;
              } else {
                if ((int )*(parser->buffer.pointer + 3) == 10) {
                  {
                  tmp___9 = __dyc_funcallvar_12;
                  }
                  goto __dyc_dummy_label;
                } else {
                  if ((int )*(parser->buffer.pointer + 3) == 194) {
                    if ((int )*(parser->buffer.pointer + 4) == 133) {
                      {
                      tmp___9 = __dyc_funcallvar_13;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___3;
                    }
                  } else {
                    _L___3:  
                    if ((int )*(parser->buffer.pointer + 3) == 226) {
                      if ((int )*(parser->buffer.pointer + 4) == 128) {
                        if ((int )*(parser->buffer.pointer + 5) == 168) {
                          {
                          tmp___9 = __dyc_funcallvar_14;
                          }
                          goto __dyc_dummy_label;
                        } else {
                          goto _L___2;
                        }
                      } else {
                        goto _L___2;
                      }
                    } else {
                      _L___2:  
                      if ((int )*(parser->buffer.pointer + 3) == 226) {
                        if ((int )*(parser->buffer.pointer + 4) == 128) {
                          if ((int )*(parser->buffer.pointer + 5) == 169) {
                            {
                            tmp___9 = __dyc_funcallvar_15;
                            }
                            goto __dyc_dummy_label;
                          } else {
                            goto _L___0;
                          }
                        } else {
                          goto _L___0;
                        }
                      } else {
                        _L___0:  
                        if ((int )*(parser->buffer.pointer + 3) == 0) {
                          {
                          tmp___9 = __dyc_funcallvar_16;
                          }
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if (parser->mark.column == 0UL) {
    if ((int )*(parser->buffer.pointer + 0) == 46) {
      if ((int )*(parser->buffer.pointer + 1) == 46) {
        if ((int )*(parser->buffer.pointer + 2) == 46) {
          if ((int )*(parser->buffer.pointer + 3) == 32) {
            {
            tmp___10 = __dyc_funcallvar_17;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 3) == 9) {
              {
              tmp___10 = __dyc_funcallvar_18;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 3) == 13) {
                {
                tmp___10 = __dyc_funcallvar_19;
                }
                goto __dyc_dummy_label;
              } else {
                if ((int )*(parser->buffer.pointer + 3) == 10) {
                  {
                  tmp___10 = __dyc_funcallvar_20;
                  }
                  goto __dyc_dummy_label;
                } else {
                  if ((int )*(parser->buffer.pointer + 3) == 194) {
                    if ((int )*(parser->buffer.pointer + 4) == 133) {
                      {
                      tmp___10 = __dyc_funcallvar_21;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___8;
                    }
                  } else {
                    _L___8:  
                    if ((int )*(parser->buffer.pointer + 3) == 226) {
                      if ((int )*(parser->buffer.pointer + 4) == 128) {
                        if ((int )*(parser->buffer.pointer + 5) == 168) {
                          {
                          tmp___10 = __dyc_funcallvar_22;
                          }
                          goto __dyc_dummy_label;
                        } else {
                          goto _L___7;
                        }
                      } else {
                        goto _L___7;
                      }
                    } else {
                      _L___7:  
                      if ((int )*(parser->buffer.pointer + 3) == 226) {
                        if ((int )*(parser->buffer.pointer + 4) == 128) {
                          if ((int )*(parser->buffer.pointer + 5) == 169) {
                            {
                            tmp___10 = __dyc_funcallvar_23;
                            }
                            goto __dyc_dummy_label;
                          } else {
                            goto _L___5;
                          }
                        } else {
                          goto _L___5;
                        }
                      } else {
                        _L___5:  
                        if ((int )*(parser->buffer.pointer + 3) == 0) {
                          {
                          tmp___10 = __dyc_funcallvar_24;
                          }
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ((int )*(parser->buffer.pointer + 0) == 91) {
    {
    tmp___11 = __dyc_funcallvar_25;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 123) {
    {
    tmp___12 = __dyc_funcallvar_26;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 93) {
    {
    tmp___13 = __dyc_funcallvar_27;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 125) {
    {
    tmp___14 = __dyc_funcallvar_28;
    }
    goto __dyc_dummy_label;
  }
  if ((int )*(parser->buffer.pointer + 0) == 44) {
    {
    tmp___15 = __dyc_funcallvar_29;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___1);
  __dyc_printpre_byte(tmp___7);
  __dyc_printpre_byte(tmp___8);
  __dyc_printpre_byte(tmp___9);
  __dyc_printpre_byte(tmp___10);
  __dyc_printpre_byte(tmp___11);
  __dyc_printpre_byte(tmp___12);
  __dyc_printpre_byte(tmp___13);
  __dyc_printpre_byte(tmp___14);
  __dyc_printpre_byte(tmp___15);
}
}
