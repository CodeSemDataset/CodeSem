#include "../include/dycfoo.h"
#include "../include/neverbleed.i.hd.c.h"
void __dyc_foo(void) 
{ char *cmd ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___19 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___37 ;
  int tmp___42 ;
  int tmp___43 ;
  int tmp___44 ;
  int tmp___45 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___55 ;
  int tmp___60 ;
  int tmp___61 ;
  int tmp___62 ;
  int tmp___63 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___73 ;
  int tmp___78 ;
  int tmp___79 ;
  int tmp___80 ;
  int tmp___81 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___91 ;
  int tmp___96 ;
  int tmp___97 ;
  int tmp___98 ;
  int tmp___99 ;
  int tmp___109 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;

  {
  cmd = __dyc_read_ptr__char();
  tmp___109 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___19 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___37 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___55 = 0;
  tmp___60 = 0;
  tmp___61 = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___73 = 0;
  tmp___78 = 0;
  tmp___79 = 0;
  tmp___80 = 0;
  tmp___81 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___91 = 0;
  tmp___96 = 0;
  tmp___97 = 0;
  tmp___98 = 0;
  tmp___99 = 0;
  if (tmp___109 == 0) {
    {
    tmp___4 = __dyc_funcallvar_12;
    }
    if (tmp___4 != 0) {
      goto __dyc_dummy_label;
    }
  } else {
    if (0) {
      {
      tmp___97 = __dyc_funcallvar_13;
      __s1_len___3 = (unsigned long )tmp___97;
      tmp___98 = __dyc_funcallvar_14;
      __s2_len___3 = (unsigned long )tmp___98;
      }
      if (! ((unsigned long )((void const   *)(cmd + 1)) - (unsigned long )((void const   *)cmd) == 1UL)) {
        goto _L___8;
      } else {
        if (__s1_len___3 >= 4UL) {
          _L___8:  
          if (! ((unsigned long )((void const   *)("priv_dec" + 1)) - (unsigned long )((void const   *)"priv_dec") == 1UL)) {
            tmp___99 = 1;
          } else {
            if (__s2_len___3 >= 4UL) {
              tmp___99 = 1;
            } else {
              tmp___99 = 0;
            }
          }
        } else {
          tmp___99 = 0;
        }
      }
      if (tmp___99) {
        {
        tmp___91 = __dyc_funcallvar_15;
        }
      } else {
        {
        tmp___96 = __dyc_funcallvar_16;
        tmp___91 = tmp___96;
        }
      }
    } else {
      {
      tmp___96 = __dyc_funcallvar_17;
      tmp___91 = tmp___96;
      }
    }
    if (tmp___91 == 0) {
      {
      tmp___5 = __dyc_funcallvar_18;
      }
      if (tmp___5 != 0) {
        goto __dyc_dummy_label;
      }
    } else {
      if (0) {
        {
        tmp___79 = __dyc_funcallvar_19;
        __s1_len___2 = (unsigned long )tmp___79;
        tmp___80 = __dyc_funcallvar_20;
        __s2_len___2 = (unsigned long )tmp___80;
        }
        if (! ((unsigned long )((void const   *)(cmd + 1)) - (unsigned long )((void const   *)cmd) == 1UL)) {
          goto _L___6;
        } else {
          if (__s1_len___2 >= 4UL) {
            _L___6:  
            if (! ((unsigned long )((void const   *)("sign" + 1)) - (unsigned long )((void const   *)"sign") == 1UL)) {
              tmp___81 = 1;
            } else {
              if (__s2_len___2 >= 4UL) {
                tmp___81 = 1;
              } else {
                tmp___81 = 0;
              }
            }
          } else {
            tmp___81 = 0;
          }
        }
        if (tmp___81) {
          {
          tmp___73 = __dyc_funcallvar_21;
          }
        } else {
          {
          tmp___78 = __dyc_funcallvar_22;
          tmp___73 = tmp___78;
          }
        }
      } else {
        {
        tmp___78 = __dyc_funcallvar_23;
        tmp___73 = tmp___78;
        }
      }
      if (tmp___73 == 0) {
        {
        tmp___6 = __dyc_funcallvar_24;
        }
        if (tmp___6 != 0) {
          goto __dyc_dummy_label;
        }
      } else {
        if (0) {
          {
          tmp___61 = __dyc_funcallvar_25;
          __s1_len___1 = (unsigned long )tmp___61;
          tmp___62 = __dyc_funcallvar_26;
          __s2_len___1 = (unsigned long )tmp___62;
          }
          if (! ((unsigned long )((void const   *)(cmd + 1)) - (unsigned long )((void const   *)cmd) == 1UL)) {
            goto _L___4;
          } else {
            if (__s1_len___1 >= 4UL) {
              _L___4:  
              if (! ((unsigned long )((void const   *)("load_key" + 1)) - (unsigned long )((void const   *)"load_key") == 1UL)) {
                tmp___63 = 1;
              } else {
                if (__s2_len___1 >= 4UL) {
                  tmp___63 = 1;
                } else {
                  tmp___63 = 0;
                }
              }
            } else {
              tmp___63 = 0;
            }
          }
          if (tmp___63) {
            {
            tmp___55 = __dyc_funcallvar_27;
            }
          } else {
            {
            tmp___60 = __dyc_funcallvar_28;
            tmp___55 = tmp___60;
            }
          }
        } else {
          {
          tmp___60 = __dyc_funcallvar_29;
          tmp___55 = tmp___60;
          }
        }
        if (tmp___55 == 0) {
          {
          tmp___7 = __dyc_funcallvar_30;
          }
          if (tmp___7 != 0) {
            goto __dyc_dummy_label;
          }
        } else {
          if (0) {
            {
            tmp___43 = __dyc_funcallvar_31;
            __s1_len___0 = (unsigned long )tmp___43;
            tmp___44 = __dyc_funcallvar_32;
            __s2_len___0 = (unsigned long )tmp___44;
            }
            if (! ((unsigned long )((void const   *)(cmd + 1)) - (unsigned long )((void const   *)cmd) == 1UL)) {
              goto _L___2;
            } else {
              if (__s1_len___0 >= 4UL) {
                _L___2:  
                if (! ((unsigned long )((void const   *)("del_rsa_key" + 1)) - (unsigned long )((void const   *)"del_rsa_key") == 1UL)) {
                  tmp___45 = 1;
                } else {
                  if (__s2_len___0 >= 4UL) {
                    tmp___45 = 1;
                  } else {
                    tmp___45 = 0;
                  }
                }
              } else {
                tmp___45 = 0;
              }
            }
            if (tmp___45) {
              {
              tmp___37 = __dyc_funcallvar_33;
              }
            } else {
              {
              tmp___42 = __dyc_funcallvar_34;
              tmp___37 = tmp___42;
              }
            }
          } else {
            {
            tmp___42 = __dyc_funcallvar_35;
            tmp___37 = tmp___42;
            }
          }
          if (tmp___37 == 0) {
            {
            tmp___8 = __dyc_funcallvar_36;
            }
            if (tmp___8 != 0) {
              goto __dyc_dummy_label;
            }
          } else {
            if (0) {
              {
              tmp___25 = __dyc_funcallvar_37;
              __s1_len = (unsigned long )tmp___25;
              tmp___26 = __dyc_funcallvar_38;
              __s2_len = (unsigned long )tmp___26;
              }
              if (! ((unsigned long )((void const   *)(cmd + 1)) - (unsigned long )((void const   *)cmd) == 1UL)) {
                goto _L___0;
              } else {
                if (__s1_len >= 4UL) {
                  _L___0:  
                  if (! ((unsigned long )((void const   *)("setuidgid" + 1)) - (unsigned long )((void const   *)"setuidgid") == 1UL)) {
                    tmp___27 = 1;
                  } else {
                    if (__s2_len >= 4UL) {
                      tmp___27 = 1;
                    } else {
                      tmp___27 = 0;
                    }
                  }
                } else {
                  tmp___27 = 0;
                }
              }
              if (tmp___27) {
                {
                tmp___19 = __dyc_funcallvar_39;
                }
              } else {
                {
                tmp___24 = __dyc_funcallvar_40;
                tmp___19 = tmp___24;
                }
              }
            } else {
              {
              tmp___24 = __dyc_funcallvar_41;
              tmp___19 = tmp___24;
              }
            }
            if (tmp___19 == 0) {
              {
              tmp___9 = __dyc_funcallvar_42;
              }
              if (tmp___9 != 0) {
                goto __dyc_dummy_label;
              }
            } else {
              {

              }
              goto __dyc_dummy_label;
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
}
}
