#include "../include/dycfoo.h"
#include "../include/socket.i.hd.c.h"
void __dyc_foo(void) 
{ struct sockaddr_in *xin ;
  struct sockaddr_in *yin ;
  int tmp___18 ;
  unsigned int __v___1 ;
  unsigned int __x___1 ;
  unsigned int __v___2 ;
  unsigned int __x___2 ;
  unsigned int __v___3 ;
  unsigned int __x___3 ;
  unsigned int __v___4 ;
  unsigned int __x___4 ;
  int tmp___19 ;
  unsigned short __v___7 ;
  unsigned short __x___7 ;
  unsigned short __v___8 ;
  unsigned short __x___8 ;
  unsigned short __v___9 ;
  unsigned short __x___9 ;
  unsigned short __v___10 ;
  unsigned short __x___10 ;
  struct sockaddr_in6 *xin6 ;
  struct sockaddr_in6 *yin6 ;
  int r___0 ;
  int tmp___20 ;
  int tmp___21 ;
  unsigned short __v___13 ;
  unsigned short __x___13 ;
  unsigned short __v___14 ;
  unsigned short __x___14 ;
  unsigned short __v___15 ;
  unsigned short __x___15 ;
  unsigned short __v___16 ;
  unsigned short __x___16 ;
  int tmp___22 ;
  int tmp___23 ;
  struct sockaddr *x ;
  struct sockaddr *y ;
  int __dyc_funcallvar_6 ;

  {
  __v___1 = (unsigned int )__dyc_readpre_byte();
  __v___2 = (unsigned int )__dyc_readpre_byte();
  __v___3 = (unsigned int )__dyc_readpre_byte();
  __v___4 = (unsigned int )__dyc_readpre_byte();
  __v___7 = (unsigned short )__dyc_readpre_byte();
  __v___8 = (unsigned short )__dyc_readpre_byte();
  __v___9 = (unsigned short )__dyc_readpre_byte();
  __v___10 = (unsigned short )__dyc_readpre_byte();
  __v___13 = (unsigned short )__dyc_readpre_byte();
  __v___14 = (unsigned short )__dyc_readpre_byte();
  __v___15 = (unsigned short )__dyc_readpre_byte();
  __v___16 = (unsigned short )__dyc_readpre_byte();
  x = __dyc_read_ptr__comp_27sockaddr();
  y = __dyc_read_ptr__comp_27sockaddr();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  xin = 0;
  yin = 0;
  tmp___18 = 0;
  __x___1 = 0;
  __x___2 = 0;
  __x___3 = 0;
  __x___4 = 0;
  tmp___19 = 0;
  __x___7 = 0;
  __x___8 = 0;
  __x___9 = 0;
  __x___10 = 0;
  xin6 = 0;
  yin6 = 0;
  r___0 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  __x___13 = 0;
  __x___14 = 0;
  __x___15 = 0;
  __x___16 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  if ((int )x->sa_family == 2) {
    xin = (struct sockaddr_in *)((void *)x);
    yin = (struct sockaddr_in *)((void *)y);
    __x___3 = xin->sin_addr.s_addr;
    __x___4 = yin->sin_addr.s_addr;
    if (__v___3 != __v___4) {
      __x___1 = xin->sin_addr.s_addr;
      __x___2 = yin->sin_addr.s_addr;
      if (__v___1 < __v___2) {
        tmp___18 = -1;
      } else {
        tmp___18 = 1;
      }
      goto __dyc_dummy_label;
    }
    __x___9 = xin->sin_port;
    __x___10 = yin->sin_port;
    if ((int )__v___9 != (int )__v___10) {
      __x___7 = xin->sin_port;
      __x___8 = yin->sin_port;
      if ((int )__v___7 < (int )__v___8) {
        tmp___19 = -1;
      } else {
        tmp___19 = 1;
      }
      goto __dyc_dummy_label;
    }
  } else {
    if ((int )x->sa_family == 10) {
      {
      xin6 = (struct sockaddr_in6 *)((void *)x);
      yin6 = (struct sockaddr_in6 *)((void *)y);
      tmp___20 = __dyc_funcallvar_6;
      r___0 = tmp___20;
      }
      if (r___0 != 0) {
        goto __dyc_dummy_label;
      }
      __x___15 = xin6->sin6_port;
      __x___16 = yin6->sin6_port;
      if ((int )__v___15 != (int )__v___16) {
        __x___13 = xin6->sin6_port;
        __x___14 = yin6->sin6_port;
        if ((int )__v___13 < (int )__v___14) {
          tmp___21 = -1;
        } else {
          tmp___21 = 1;
        }
        goto __dyc_dummy_label;
      }
      if (xin6->sin6_flowinfo != yin6->sin6_flowinfo) {
        if (xin6->sin6_flowinfo < yin6->sin6_flowinfo) {
          tmp___22 = -1;
        } else {
          tmp___22 = 1;
        }
        goto __dyc_dummy_label;
      }
      if (xin6->sin6_scope_id != yin6->sin6_scope_id) {
        if (xin6->sin6_scope_id < yin6->sin6_scope_id) {
          tmp___23 = -1;
        } else {
          tmp___23 = 1;
        }
        goto __dyc_dummy_label;
      }
    } else {
      {

      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___18);
  __dyc_printpre_byte(__x___1);
  __dyc_printpre_byte(__x___2);
  __dyc_printpre_byte(__x___3);
  __dyc_printpre_byte(__x___4);
  __dyc_printpre_byte(tmp___19);
  __dyc_printpre_byte(__x___7);
  __dyc_printpre_byte(__x___8);
  __dyc_printpre_byte(__x___9);
  __dyc_printpre_byte(__x___10);
  __dyc_print_ptr__comp_41sockaddr_in6(xin6);
  __dyc_print_ptr__comp_41sockaddr_in6(yin6);
  __dyc_printpre_byte(tmp___21);
  __dyc_printpre_byte(__x___13);
  __dyc_printpre_byte(__x___14);
  __dyc_printpre_byte(__x___15);
  __dyc_printpre_byte(__x___16);
  __dyc_printpre_byte(tmp___22);
  __dyc_printpre_byte(tmp___23);
}
}
