#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ yoml_t *dh_file ;
  yoml_t *ocsp_update_interval_node ;
  yoml_t *ocsp_max_failures_node ;
  long ssl_options ;
  int use_neverbleed ;
  yoml_t *key ;
  yoml_t *value ;
  int tmp___152 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___170 ;
  int tmp___175 ;
  int tmp___176 ;
  int tmp___177 ;
  int tmp___178 ;
  size_t __s1_len___9 ;
  size_t __s2_len___9 ;
  int tmp___188 ;
  int tmp___193 ;
  int tmp___194 ;
  int tmp___195 ;
  int tmp___196 ;
  int tmp___197 ;
  int tmp___198 ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___208 ;
  int tmp___213 ;
  int tmp___214 ;
  int tmp___215 ;
  int tmp___216 ;
  int tmp___217 ;
  int tmp___218 ;
  size_t __s1_len___11 ;
  size_t __s2_len___11 ;
  int tmp___228 ;
  int tmp___233 ;
  int tmp___234 ;
  int tmp___235 ;
  int tmp___236 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;

  {
  ssl_options = (long )__dyc_readpre_byte();
  key = __dyc_read_ptr__typdef_yoml_t();
  value = __dyc_read_ptr__typdef_yoml_t();
  tmp___152 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  dh_file = 0;
  ocsp_update_interval_node = 0;
  ocsp_max_failures_node = 0;
  use_neverbleed = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___170 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  tmp___178 = 0;
  __s1_len___9 = 0;
  __s2_len___9 = 0;
  tmp___188 = 0;
  tmp___193 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  tmp___196 = 0;
  tmp___197 = 0;
  tmp___198 = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___208 = 0;
  tmp___213 = 0;
  tmp___214 = 0;
  tmp___215 = 0;
  tmp___216 = 0;
  tmp___217 = 0;
  tmp___218 = 0;
  __s1_len___11 = 0;
  __s2_len___11 = 0;
  tmp___228 = 0;
  tmp___233 = 0;
  tmp___234 = 0;
  tmp___235 = 0;
  tmp___236 = 0;
  if (tmp___152 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    ocsp_update_interval_node = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___176 = __dyc_funcallvar_46;
    __s1_len___8 = (unsigned long )tmp___176;
    tmp___177 = __dyc_funcallvar_47;
    __s2_len___8 = (unsigned long )tmp___177;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___18;
    } else {
      if (__s1_len___8 >= 4UL) {
        _L___18:  
        if (! ((unsigned long )((void const   *)("ocsp-max-failures" + 1)) - (unsigned long )((void const   *)"ocsp-max-failures") == 1UL)) {
          tmp___178 = 1;
        } else {
          if (__s2_len___8 >= 4UL) {
            tmp___178 = 1;
          } else {
            tmp___178 = 0;
          }
        }
      } else {
        tmp___178 = 0;
      }
    }
    if (tmp___178) {
      {
      tmp___170 = __dyc_funcallvar_48;
      }
    } else {
      {
      tmp___175 = __dyc_funcallvar_49;
      tmp___170 = tmp___175;
      }
    }
  } else {
    {
    tmp___175 = __dyc_funcallvar_50;
    tmp___170 = tmp___175;
    }
  }
  if (tmp___170 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    ocsp_max_failures_node = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___194 = __dyc_funcallvar_51;
    __s1_len___9 = (unsigned long )tmp___194;
    tmp___195 = __dyc_funcallvar_52;
    __s2_len___9 = (unsigned long )tmp___195;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___20;
    } else {
      if (__s1_len___9 >= 4UL) {
        _L___20:  
        if (! ((unsigned long )((void const   *)("dh-file" + 1)) - (unsigned long )((void const   *)"dh-file") == 1UL)) {
          tmp___196 = 1;
        } else {
          if (__s2_len___9 >= 4UL) {
            tmp___196 = 1;
          } else {
            tmp___196 = 0;
          }
        }
      } else {
        tmp___196 = 0;
      }
    }
    if (tmp___196) {
      {
      tmp___188 = __dyc_funcallvar_53;
      }
    } else {
      {
      tmp___193 = __dyc_funcallvar_54;
      tmp___188 = tmp___193;
      }
    }
  } else {
    {
    tmp___193 = __dyc_funcallvar_55;
    tmp___188 = tmp___193;
    }
  }
  if (tmp___188 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    dh_file = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___214 = __dyc_funcallvar_56;
    __s1_len___10 = (unsigned long )tmp___214;
    tmp___215 = __dyc_funcallvar_57;
    __s2_len___10 = (unsigned long )tmp___215;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___23;
    } else {
      if (__s1_len___10 >= 4UL) {
        _L___23:  
        if (! ((unsigned long )((void const   *)("cipher-preference" + 1)) - (unsigned long )((void const   *)"cipher-preference") == 1UL)) {
          tmp___216 = 1;
        } else {
          if (__s2_len___10 >= 4UL) {
            tmp___216 = 1;
          } else {
            tmp___216 = 0;
          }
        }
      } else {
        tmp___216 = 0;
      }
    }
    if (tmp___216) {
      {
      tmp___208 = __dyc_funcallvar_58;
      }
    } else {
      {
      tmp___213 = __dyc_funcallvar_59;
      tmp___208 = tmp___213;
      }
    }
  } else {
    {
    tmp___213 = __dyc_funcallvar_60;
    tmp___208 = tmp___213;
    }
  }
  if (tmp___208 == 0) {
    if ((int )value->type == 0) {
      {
      tmp___198 = __dyc_funcallvar_61;
      }
      if (tmp___198 == 0) {
        ssl_options &= -4194305L;
      } else {
        goto _L___21;
      }
    } else {
      _L___21:  
      if ((int )value->type == 0) {
        {
        tmp___197 = __dyc_funcallvar_62;
        }
        if (tmp___197 == 0) {
          ssl_options |= 4194304L;
        } else {
          {

          }
          goto __dyc_dummy_label;
        }
      } else {
        {

        }
        goto __dyc_dummy_label;
      }
    }
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___234 = __dyc_funcallvar_63;
    __s1_len___11 = (unsigned long )tmp___234;
    tmp___235 = __dyc_funcallvar_64;
    __s2_len___11 = (unsigned long )tmp___235;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___26;
    } else {
      if (__s1_len___11 >= 4UL) {
        _L___26:  
        if (! ((unsigned long )((void const   *)("neverbleed" + 1)) - (unsigned long )((void const   *)"neverbleed") == 1UL)) {
          tmp___236 = 1;
        } else {
          if (__s2_len___11 >= 4UL) {
            tmp___236 = 1;
          } else {
            tmp___236 = 0;
          }
        }
      } else {
        tmp___236 = 0;
      }
    }
    if (tmp___236) {
      {
      tmp___228 = __dyc_funcallvar_65;
      }
    } else {
      {
      tmp___233 = __dyc_funcallvar_66;
      tmp___228 = tmp___233;
      }
    }
  } else {
    {
    tmp___233 = __dyc_funcallvar_67;
    tmp___228 = tmp___233;
    }
  }
  if (tmp___228 == 0) {
    if ((int )value->type == 0) {
      {
      tmp___218 = __dyc_funcallvar_68;
      }
      if (tmp___218 == 0) {
        use_neverbleed = 1;
      } else {
        goto _L___24;
      }
    } else {
      _L___24:  
      if ((int )value->type == 0) {
        {
        tmp___217 = __dyc_funcallvar_69;
        }
        if (tmp___217 == 0) {
          use_neverbleed = 0;
        } else {
          {

          }
          goto __dyc_dummy_label;
        }
      } else {
        {

        }
        goto __dyc_dummy_label;
      }
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_yoml_t(dh_file);
  __dyc_print_ptr__typdef_yoml_t(ocsp_update_interval_node);
  __dyc_print_ptr__typdef_yoml_t(ocsp_max_failures_node);
  __dyc_printpre_byte(ssl_options);
  __dyc_printpre_byte(use_neverbleed);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(__s1_len___9);
  __dyc_printpre_byte(__s2_len___9);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___11);
  __dyc_printpre_byte(__s2_len___11);
}
}
