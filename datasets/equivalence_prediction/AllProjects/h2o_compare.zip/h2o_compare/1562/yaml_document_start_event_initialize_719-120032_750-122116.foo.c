#include "../include/dycfoo.h"
#include "../include/api.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_context_75 context ;
  yaml_mark_t mark ;
  yaml_version_directive_t *version_directive_copy ;
  struct __anonstruct_tag_directives_copy_76 tag_directives_copy ;
  yaml_tag_directive_t value ;
  void *tmp ;
  yaml_tag_directive_t *tag_directive ;
  int tmp___1 ;
  void *tmp___2 ;
  size_t tmp___3 ;
  int tmp___4 ;
  size_t tmp___5 ;
  int tmp___6 ;
  int tmp___9 ;
  yaml_tag_directive_t *tmp___10 ;
  int tmp___11 ;
  yaml_event_t *event ;
  yaml_version_directive_t *version_directive ;
  yaml_tag_directive_t *tag_directives_start ;
  yaml_tag_directive_t *tag_directives_end ;
  int implicit ;
  void *__dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;
  size_t __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  size_t __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  yaml_char_t *__dyc_funcallvar_7 ;
  yaml_char_t *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;

  {
  mark = __dyc_read_comp_43yaml_mark_s();
  version_directive_copy = __dyc_read_ptr__typdef_yaml_version_directive_t();
  tag_directives_copy = __dyc_read_comp_103__anonstruct_tag_directives_copy_76();
  event = __dyc_read_ptr__typdef_yaml_event_t();
  version_directive = __dyc_read_ptr__typdef_yaml_version_directive_t();
  tag_directives_start = __dyc_read_ptr__typdef_yaml_tag_directive_t();
  tag_directives_end = __dyc_read_ptr__typdef_yaml_tag_directive_t();
  implicit = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  __dyc_funcallvar_3 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_read_ptr__typdef_yaml_char_t();
  __dyc_funcallvar_8 = __dyc_read_ptr__typdef_yaml_char_t();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  memset(& context, 0, sizeof(struct __anonstruct_context_75 ));
  memset(& value, 0, sizeof(yaml_tag_directive_t ));
  tmp = 0;
  tag_directive = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  if (version_directive) {
    {
    tmp = __dyc_funcallvar_1;
    version_directive_copy = (yaml_version_directive_t *)tmp;
    }
    if (! version_directive_copy) {
      goto __dyc_dummy_label;
    }
    version_directive_copy->major = version_directive->major;
    version_directive_copy->minor = version_directive->minor;
  }
  if ((unsigned long )tag_directives_start != (unsigned long )tag_directives_end) {
    {
    tmp___2 = __dyc_funcallvar_2;
    tag_directives_copy.start = (yaml_tag_directive_t *)tmp___2;
    }
    if (tag_directives_copy.start) {
      tag_directives_copy.top = tag_directives_copy.start;
      tag_directives_copy.end = tag_directives_copy.start + 16;
      tmp___1 = 1;
    } else {
      context.error = 1;
      tmp___1 = 0;
    }
    if (! tmp___1) {
      goto __dyc_dummy_label;
    }
    tag_directive = tag_directives_start;
    {
    while (1) {
      while_8_continue:  ;
      if (! ((unsigned long )tag_directive != (unsigned long )tag_directives_end)) {
        goto while_8_break;
      }
      if (! tag_directive->handle) {
        {

        }
      }
      if (! tag_directive->prefix) {
        {

        }
      }
      {
      tmp___3 = __dyc_funcallvar_3;
      tmp___4 = __dyc_funcallvar_4;
      }
      if (! tmp___4) {
        goto __dyc_dummy_label;
      }
      {
      tmp___5 = __dyc_funcallvar_5;
      tmp___6 = __dyc_funcallvar_6;
      }
      if (! tmp___6) {
        goto __dyc_dummy_label;
      }
      {
      value.handle = __dyc_funcallvar_7;
      value.prefix = __dyc_funcallvar_8;
      }
      if (! value.handle) {
        goto __dyc_dummy_label;
      } else {
        if (! value.prefix) {
          goto __dyc_dummy_label;
        }
      }
      if ((unsigned long )tag_directives_copy.top != (unsigned long )tag_directives_copy.end) {
        tmp___10 = tag_directives_copy.top;
        (tag_directives_copy.top) ++;
        *tmp___10 = value;
        tmp___9 = 1;
      } else {
        {
        tmp___11 = __dyc_funcallvar_9;
        }
        if (tmp___11) {
          tmp___10 = tag_directives_copy.top;
          (tag_directives_copy.top) ++;
          *tmp___10 = value;
          tmp___9 = 1;
        } else {
          context.error = 1;
          tmp___9 = 0;
        }
      }
      if (! tmp___9) {
        goto __dyc_dummy_label;
      }
      value.handle = (yaml_char_t *)((void *)0);
      value.prefix = (yaml_char_t *)((void *)0);
      tag_directive ++;
    }
    while_8_break:  ;
    }
  }

  event->type = 3;
  event->start_mark = mark;
  event->end_mark = mark;
  event->data.document_start.version_directive = version_directive_copy;
  event->data.document_start.tag_directives.start = tag_directives_copy.start;
  event->data.document_start.tag_directives.end = tag_directives_copy.top;
  event->data.document_start.implicit = implicit;
  __dyc_dummy_label:  ;
  __dyc_print_comp_102__anonstruct_context_75(context);
  __dyc_print_comp_103__anonstruct_tag_directives_copy_76(tag_directives_copy);
  __dyc_print_comp_42yaml_tag_directive_s(value);
  __dyc_printpre_byte(tmp___3);
  __dyc_printpre_byte(tmp___5);
}
}
