#include "../include/dycfoo.h"
#include "../include/api.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_context_77 context ;
  struct __anonstruct_nodes_78 nodes ;
  yaml_version_directive_t *version_directive_copy ;
  struct __anonstruct_tag_directives_copy_79 tag_directives_copy ;
  yaml_tag_directive_t value ;
  yaml_mark_t mark ;
  yaml_tag_directive_t *tag_directive ;
  int tmp___4 ;
  void *tmp___5 ;
  size_t tmp___6 ;
  int tmp___7 ;
  size_t tmp___8 ;
  int tmp___9 ;
  int tmp___12 ;
  yaml_tag_directive_t *tmp___13 ;
  int tmp___14 ;
  yaml_document_t *document ;
  yaml_tag_directive_t *tag_directives_start ;
  yaml_tag_directive_t *tag_directives_end ;
  int start_implicit ;
  int end_implicit ;
  void *__dyc_funcallvar_3 ;
  size_t __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  size_t __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  yaml_char_t *__dyc_funcallvar_8 ;
  yaml_char_t *__dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;

  {
  nodes = __dyc_read_comp_105__anonstruct_nodes_78();
  version_directive_copy = __dyc_read_ptr__typdef_yaml_version_directive_t();
  tag_directives_copy = __dyc_read_comp_106__anonstruct_tag_directives_copy_79();
  mark = __dyc_read_comp_43yaml_mark_s();
  document = __dyc_read_ptr__typdef_yaml_document_t();
  tag_directives_start = __dyc_read_ptr__typdef_yaml_tag_directive_t();
  tag_directives_end = __dyc_read_ptr__typdef_yaml_tag_directive_t();
  start_implicit = __dyc_readpre_byte();
  end_implicit = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_read_ptr__typdef_yaml_char_t();
  __dyc_funcallvar_9 = __dyc_read_ptr__typdef_yaml_char_t();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  memset(& context, 0, sizeof(struct __anonstruct_context_77 ));
  memset(& value, 0, sizeof(yaml_tag_directive_t ));
  tag_directive = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  if ((unsigned long )tag_directives_start != (unsigned long )tag_directives_end) {
    {
    tmp___5 = __dyc_funcallvar_3;
    tag_directives_copy.start = (yaml_tag_directive_t *)tmp___5;
    }
    if (tag_directives_copy.start) {
      tag_directives_copy.top = tag_directives_copy.start;
      tag_directives_copy.end = tag_directives_copy.start + 16;
      tmp___4 = 1;
    } else {
      context.error = 1;
      tmp___4 = 0;
    }
    if (! tmp___4) {
      goto __dyc_dummy_label;
    }
    tag_directive = tag_directives_start;
    {
    while (1) {
      while_12_continue:  ;
      if (! ((unsigned long )tag_directive != (unsigned long )tag_directives_end)) {
        goto while_12_break;
      }
      if (! tag_directive->handle) {
        {

        }
      }
      if (! tag_directive->prefix) {
        {

        }
      }
      {
      tmp___6 = __dyc_funcallvar_4;
      tmp___7 = __dyc_funcallvar_5;
      }
      if (! tmp___7) {
        goto __dyc_dummy_label;
      }
      {
      tmp___8 = __dyc_funcallvar_6;
      tmp___9 = __dyc_funcallvar_7;
      }
      if (! tmp___9) {
        goto __dyc_dummy_label;
      }
      {
      value.handle = __dyc_funcallvar_8;
      value.prefix = __dyc_funcallvar_9;
      }
      if (! value.handle) {
        goto __dyc_dummy_label;
      } else {
        if (! value.prefix) {
          goto __dyc_dummy_label;
        }
      }
      if ((unsigned long )tag_directives_copy.top != (unsigned long )tag_directives_copy.end) {
        tmp___13 = tag_directives_copy.top;
        (tag_directives_copy.top) ++;
        *tmp___13 = value;
        tmp___12 = 1;
      } else {
        {
        tmp___14 = __dyc_funcallvar_10;
        }
        if (tmp___14) {
          tmp___13 = tag_directives_copy.top;
          (tag_directives_copy.top) ++;
          *tmp___13 = value;
          tmp___12 = 1;
        } else {
          context.error = 1;
          tmp___12 = 0;
        }
      }
      if (! tmp___12) {
        goto __dyc_dummy_label;
      }
      value.handle = (yaml_char_t *)((void *)0);
      value.prefix = (yaml_char_t *)((void *)0);
      tag_directive ++;
    }
    while_12_break:  ;
    }
  }

  document->nodes.start = nodes.start;
  document->nodes.end = nodes.end;
  document->nodes.top = nodes.start;
  document->version_directive = version_directive_copy;
  document->tag_directives.start = tag_directives_copy.start;
  document->tag_directives.end = tag_directives_copy.top;
  document->start_implicit = start_implicit;
  document->end_implicit = end_implicit;
  document->start_mark = mark;
  document->end_mark = mark;
  __dyc_dummy_label:  ;
  __dyc_print_comp_104__anonstruct_context_77(context);
  __dyc_print_comp_106__anonstruct_tag_directives_copy_79(tag_directives_copy);
  __dyc_print_comp_42yaml_tag_directive_s(value);
  __dyc_printpre_byte(tmp___6);
  __dyc_printpre_byte(tmp___8);
}
}
