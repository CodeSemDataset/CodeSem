#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ yoml_t *key_file ;
  yoml_t *min_version ;
  yoml_t *max_version ;
  yoml_t *key ;
  yoml_t *value ;
  int tmp___26 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___44 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___62 ;
  int tmp___67 ;
  int tmp___68 ;
  int tmp___69 ;
  int tmp___70 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___80 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___87 ;
  int tmp___88 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___98 ;
  int tmp___103 ;
  int tmp___104 ;
  int tmp___105 ;
  int tmp___106 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;

  {
  key = __dyc_read_ptr__typdef_yoml_t();
  value = __dyc_read_ptr__typdef_yoml_t();
  tmp___26 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  key_file = 0;
  min_version = 0;
  max_version = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___44 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___62 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  tmp___70 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___80 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  tmp___88 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___98 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  tmp___106 = 0;
  if (tmp___26 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    key_file = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___50 = __dyc_funcallvar_11;
    __s1_len___1 = (unsigned long )tmp___50;
    tmp___51 = __dyc_funcallvar_12;
    __s2_len___1 = (unsigned long )tmp___51;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___4;
    } else {
      if (__s1_len___1 >= 4UL) {
        _L___4:  
        if (! ((unsigned long )((void const   *)("min-version" + 1)) - (unsigned long )((void const   *)"min-version") == 1UL)) {
          tmp___52 = 1;
        } else {
          if (__s2_len___1 >= 4UL) {
            tmp___52 = 1;
          } else {
            tmp___52 = 0;
          }
        }
      } else {
        tmp___52 = 0;
      }
    }
    if (tmp___52) {
      {
      tmp___44 = __dyc_funcallvar_13;
      }
    } else {
      {
      tmp___49 = __dyc_funcallvar_14;
      tmp___44 = tmp___49;
      }
    }
  } else {
    {
    tmp___49 = __dyc_funcallvar_15;
    tmp___44 = tmp___49;
    }
  }
  if (tmp___44 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    min_version = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___68 = __dyc_funcallvar_16;
    __s1_len___2 = (unsigned long )tmp___68;
    tmp___69 = __dyc_funcallvar_17;
    __s2_len___2 = (unsigned long )tmp___69;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___6;
    } else {
      if (__s1_len___2 >= 4UL) {
        _L___6:  
        if (! ((unsigned long )((void const   *)("minimum-version" + 1)) - (unsigned long )((void const   *)"minimum-version") == 1UL)) {
          tmp___70 = 1;
        } else {
          if (__s2_len___2 >= 4UL) {
            tmp___70 = 1;
          } else {
            tmp___70 = 0;
          }
        }
      } else {
        tmp___70 = 0;
      }
    }
    if (tmp___70) {
      {
      tmp___62 = __dyc_funcallvar_18;
      }
    } else {
      {
      tmp___67 = __dyc_funcallvar_19;
      tmp___62 = tmp___67;
      }
    }
  } else {
    {
    tmp___67 = __dyc_funcallvar_20;
    tmp___62 = tmp___67;
    }
  }
  if (tmp___62 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    min_version = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___86 = __dyc_funcallvar_21;
    __s1_len___3 = (unsigned long )tmp___86;
    tmp___87 = __dyc_funcallvar_22;
    __s2_len___3 = (unsigned long )tmp___87;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___8;
    } else {
      if (__s1_len___3 >= 4UL) {
        _L___8:  
        if (! ((unsigned long )((void const   *)("max-version" + 1)) - (unsigned long )((void const   *)"max-version") == 1UL)) {
          tmp___88 = 1;
        } else {
          if (__s2_len___3 >= 4UL) {
            tmp___88 = 1;
          } else {
            tmp___88 = 0;
          }
        }
      } else {
        tmp___88 = 0;
      }
    }
    if (tmp___88) {
      {
      tmp___80 = __dyc_funcallvar_23;
      }
    } else {
      {
      tmp___85 = __dyc_funcallvar_24;
      tmp___80 = tmp___85;
      }
    }
  } else {
    {
    tmp___85 = __dyc_funcallvar_25;
    tmp___80 = tmp___85;
    }
  }
  if (tmp___80 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    max_version = value;
    goto __dyc_dummy_label;
  }
  if (0) {
    {
    tmp___104 = __dyc_funcallvar_26;
    __s1_len___4 = (unsigned long )tmp___104;
    tmp___105 = __dyc_funcallvar_27;
    __s2_len___4 = (unsigned long )tmp___105;
    }
    if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
      goto _L___10;
    } else {
      if (__s1_len___4 >= 4UL) {
        _L___10:  
        if (! ((unsigned long )((void const   *)("maximum-version" + 1)) - (unsigned long )((void const   *)"maximum-version") == 1UL)) {
          tmp___106 = 1;
        } else {
          if (__s2_len___4 >= 4UL) {
            tmp___106 = 1;
          } else {
            tmp___106 = 0;
          }
        }
      } else {
        tmp___106 = 0;
      }
    }
    if (tmp___106) {
      {
      tmp___98 = __dyc_funcallvar_28;
      }
    } else {
      {
      tmp___103 = __dyc_funcallvar_29;
      tmp___98 = tmp___103;
      }
    }
  } else {
    {
    tmp___103 = __dyc_funcallvar_30;
    tmp___98 = tmp___103;
    }
  }
  if (tmp___98 == 0) {
    if ((int )value->type != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    max_version = value;
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_yoml_t(key_file);
  __dyc_print_ptr__typdef_yoml_t(min_version);
  __dyc_print_ptr__typdef_yoml_t(max_version);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
}
}
