#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ uint16_t const   supported_versions[3] ;
  int ret ;
  uint16_t _v___1 ;
  uint8_t __constr_expr_11[2] ;
  size_t capacity___5 ;
  size_t body_start___5 ;
  size_t capacity___6 ;
  size_t body_start___6 ;
  uint8_t __constr_expr_13[1] ;
  size_t capacity___7 ;
  size_t body_start___7 ;
  size_t tmp___1 ;
  size_t body_size___2 ;
  size_t body_size___3 ;
  size_t body_size___4 ;
  uint16_t _v___2 ;
  uint8_t __constr_expr_15[2] ;
  size_t capacity___8 ;
  size_t body_start___8 ;
  size_t capacity___9 ;
  size_t body_start___9 ;
  size_t i ;
  size_t capacity___10 ;
  size_t body_start___10 ;
  ptls_iovec_t p ;
  size_t body_size___5 ;
  size_t body_size___6 ;
  size_t body_size___7 ;
  uint16_t _v___3 ;
  uint8_t __constr_expr_17[2] ;
  size_t capacity___11 ;
  size_t body_start___11 ;
  size_t capacity___12 ;
  size_t body_start___12 ;
  size_t i___0 ;
  uint16_t _v___4 ;
  uint8_t __constr_expr_19[2] ;
  size_t body_size___8 ;
  size_t body_size___9 ;
  uint16_t _v___5 ;
  uint8_t __constr_expr_21[2] ;
  size_t capacity___13 ;
  size_t body_start___13 ;
  size_t capacity___14 ;
  size_t body_start___14 ;
  uint16_t _v___6 ;
  uint8_t __constr_expr_23[2] ;
  uint16_t _v___7 ;
  uint8_t __constr_expr_25[2] ;
  uint16_t _v___8 ;
  uint8_t __constr_expr_27[2] ;
  uint16_t _v___9 ;
  uint8_t __constr_expr_29[2] ;
  size_t body_size___10 ;
  size_t body_size___11 ;
  uint16_t _v___10 ;
  uint8_t __constr_expr_31[2] ;
  size_t capacity___15 ;
  size_t body_start___15 ;
  ptls_key_exchange_algorithm_t **algo ;
  size_t capacity___16 ;
  size_t body_start___16 ;
  uint16_t _v___11 ;
  uint8_t __constr_expr_33[2] ;
  size_t body_size___12 ;
  size_t body_size___13 ;
  uint16_t _v___12 ;
  uint8_t __constr_expr_35[2] ;
  size_t capacity___17 ;
  size_t body_start___17 ;
  size_t capacity___18 ;
  size_t body_start___18 ;
  uint16_t _v___13 ;
  uint8_t __constr_expr_37[2] ;
  size_t capacity___19 ;
  size_t body_start___19 ;
  size_t body_size___14 ;
  size_t body_size___15 ;
  size_t body_size___16 ;
  uint16_t _v___14 ;
  uint8_t __constr_expr_39[2] ;
  size_t capacity___20 ;
  size_t body_start___20 ;
  size_t capacity___21 ;
  size_t body_start___21 ;
  size_t body_size___17 ;
  size_t body_size___18 ;
  ptls_t *tls ;
  ptls_buffer_t *sendbuf ;
  ptls_handshake_properties_t *properties ;
  ptls_iovec_t *cookie ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  size_t __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;

  {
  tls = __dyc_read_ptr__typdef_ptls_t();
  sendbuf = __dyc_read_ptr__typdef_ptls_buffer_t();
  properties = __dyc_read_ptr__typdef_ptls_handshake_properties_t();
  cookie = __dyc_read_ptr__typdef_ptls_iovec_t();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  ret = 0;
  _v___1 = 0;
  capacity___5 = 0;
  body_start___5 = 0;
  capacity___6 = 0;
  body_start___6 = 0;
  capacity___7 = 0;
  body_start___7 = 0;
  tmp___1 = 0;
  body_size___2 = 0;
  body_size___3 = 0;
  body_size___4 = 0;
  _v___2 = 0;
  capacity___8 = 0;
  body_start___8 = 0;
  capacity___9 = 0;
  body_start___9 = 0;
  i = 0;
  capacity___10 = 0;
  body_start___10 = 0;
  memset(& p, 0, sizeof(ptls_iovec_t ));
  body_size___5 = 0;
  body_size___6 = 0;
  body_size___7 = 0;
  _v___3 = 0;
  capacity___11 = 0;
  body_start___11 = 0;
  capacity___12 = 0;
  body_start___12 = 0;
  i___0 = 0;
  _v___4 = 0;
  body_size___8 = 0;
  body_size___9 = 0;
  _v___5 = 0;
  capacity___13 = 0;
  body_start___13 = 0;
  capacity___14 = 0;
  body_start___14 = 0;
  _v___6 = 0;
  _v___7 = 0;
  _v___8 = 0;
  _v___9 = 0;
  body_size___10 = 0;
  body_size___11 = 0;
  _v___10 = 0;
  capacity___15 = 0;
  body_start___15 = 0;
  algo = 0;
  capacity___16 = 0;
  body_start___16 = 0;
  _v___11 = 0;
  body_size___12 = 0;
  body_size___13 = 0;
  _v___12 = 0;
  capacity___17 = 0;
  body_start___17 = 0;
  capacity___18 = 0;
  body_start___18 = 0;
  _v___13 = 0;
  capacity___19 = 0;
  body_start___19 = 0;
  body_size___14 = 0;
  body_size___15 = 0;
  body_size___16 = 0;
  _v___14 = 0;
  capacity___20 = 0;
  body_start___20 = 0;
  capacity___21 = 0;
  body_start___21 = 0;
  body_size___17 = 0;
  body_size___18 = 0;
  if ((unsigned long )tls->server_name != (unsigned long )((void *)0)) {
    {
    while (1) {
      while_244_continue:  ;
      {
      while (1) {
        while_245_continue:  ;
        _v___1 = (uint16_t )0;
        {
        while (1) {
          while_246_continue:  ;
          {
          __constr_expr_11[0] = (unsigned char )((int )_v___1 >> 8);
          __constr_expr_11[1] = (unsigned char )_v___1;
          ret = __dyc_funcallvar_19;
          }
          if (ret != 0) {
            goto __dyc_dummy_label;
          }
          goto while_246_break;
        }
        while_246_break:  ;
        }
        goto while_245_break;
      }
      while_245_break:  ;
      }
      {
      while (1) {
        while_247_continue:  ;
        capacity___5 = (size_t )2;
        {
        while (1) {
          while_248_continue:  ;
          {
          ret = __dyc_funcallvar_20;
          }
          if (ret != 0) {
            goto __dyc_dummy_label;
          }
          goto while_248_break;
        }
        while_248_break:  ;
        }
        body_start___5 = sendbuf->off;
        {
        while (1) {
          while_249_continue:  ;
          {
          while (1) {
            while_250_continue:  ;
            capacity___6 = (size_t )2;
            {
            while (1) {
              while_251_continue:  ;
              {
              ret = __dyc_funcallvar_21;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_251_break;
            }
            while_251_break:  ;
            }
            body_start___6 = sendbuf->off;
            {
            while (1) {
              while_252_continue:  ;
              {
              while (1) {
                while_253_continue:  ;
                {
                __constr_expr_13[0] = (uint8_t )0;
                ret = __dyc_funcallvar_22;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_253_break;
              }
              while_253_break:  ;
              }
              {
              while (1) {
                while_254_continue:  ;
                capacity___7 = (size_t )2;
                {
                while (1) {
                  while_255_continue:  ;
                  {
                  ret = __dyc_funcallvar_23;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_255_break;
                }
                while_255_break:  ;
                }
                body_start___7 = sendbuf->off;
                {
                while (1) {
                  while_256_continue:  ;
                  {
                  while (1) {
                    while_257_continue:  ;
                    {
                    tmp___1 = __dyc_funcallvar_24;
                    ret = __dyc_funcallvar_25;
                    }
                    if (ret != 0) {
                      goto __dyc_dummy_label;
                    }
                    goto while_257_break;
                  }
                  while_257_break:  ;
                  }
                  goto while_256_break;
                }
                while_256_break:  ;
                }
                body_size___2 = sendbuf->off - body_start___7;
                {
                while (1) {
                  while_258_continue:  ;
                  if (! (capacity___7 != 0UL)) {
                    goto while_258_break;
                  }
                  *(sendbuf->base + (body_start___7 - capacity___7)) = (unsigned char )(body_size___2 >> 8UL * (capacity___7 - 1UL));
                  capacity___7 --;
                }
                while_258_break:  ;
                }
                goto while_254_break;
              }
              while_254_break:  ;
              }
              goto while_252_break;
            }
            while_252_break:  ;
            }
            body_size___3 = sendbuf->off - body_start___6;
            {
            while (1) {
              while_259_continue:  ;
              if (! (capacity___6 != 0UL)) {
                goto while_259_break;
              }
              *(sendbuf->base + (body_start___6 - capacity___6)) = (unsigned char )(body_size___3 >> 8UL * (capacity___6 - 1UL));
              capacity___6 --;
            }
            while_259_break:  ;
            }
            goto while_250_break;
          }
          while_250_break:  ;
          }
          goto while_249_break;
        }
        while_249_break:  ;
        }
        body_size___4 = sendbuf->off - body_start___5;
        {
        while (1) {
          while_260_continue:  ;
          if (! (capacity___5 != 0UL)) {
            goto while_260_break;
          }
          *(sendbuf->base + (body_start___5 - capacity___5)) = (unsigned char )(body_size___4 >> 8UL * (capacity___5 - 1UL));
          capacity___5 --;
        }
        while_260_break:  ;
        }
        goto while_247_break;
      }
      while_247_break:  ;
      }
      goto while_244_break;
    }
    while_244_break:  ;
    }
  }
  if ((unsigned long )properties != (unsigned long )((void *)0)) {
    if (properties->__annonCompField1.client.negotiated_protocols.count != 0UL) {
      {
      while (1) {
        while_261_continue:  ;
        {
        while (1) {
          while_262_continue:  ;
          _v___2 = (uint16_t )16;
          {
          while (1) {
            while_263_continue:  ;
            {
            __constr_expr_15[0] = (unsigned char )((int )_v___2 >> 8);
            __constr_expr_15[1] = (unsigned char )_v___2;
            ret = __dyc_funcallvar_26;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_263_break;
          }
          while_263_break:  ;
          }
          goto while_262_break;
        }
        while_262_break:  ;
        }
        {
        while (1) {
          while_264_continue:  ;
          capacity___8 = (size_t )2;
          {
          while (1) {
            while_265_continue:  ;
            {
            ret = __dyc_funcallvar_27;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_265_break;
          }
          while_265_break:  ;
          }
          body_start___8 = sendbuf->off;
          {
          while (1) {
            while_266_continue:  ;
            {
            while (1) {
              while_267_continue:  ;
              capacity___9 = (size_t )2;
              {
              while (1) {
                while_268_continue:  ;
                {
                ret = __dyc_funcallvar_28;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_268_break;
              }
              while_268_break:  ;
              }
              body_start___9 = sendbuf->off;
              {
              while (1) {
                while_269_continue:  ;
                i = 0UL;
                {
                while (1) {
                  while_270_continue:  ;
                  if (! (i != properties->__annonCompField1.client.negotiated_protocols.count)) {
                    goto while_270_break;
                  }
                  {
                  while (1) {
                    while_271_continue:  ;
                    capacity___10 = (size_t )1;
                    {
                    while (1) {
                      while_272_continue:  ;
                      {
                      ret = __dyc_funcallvar_29;
                      }
                      if (ret != 0) {
                        goto __dyc_dummy_label;
                      }
                      goto while_272_break;
                    }
                    while_272_break:  ;
                    }
                    body_start___10 = sendbuf->off;
                    {
                    while (1) {
                      while_273_continue:  ;
                      p = *(properties->__annonCompField1.client.negotiated_protocols.list + i);
                      {
                      while (1) {
                        while_274_continue:  ;
                        {
                        ret = __dyc_funcallvar_30;
                        }
                        if (ret != 0) {
                          goto __dyc_dummy_label;
                        }
                        goto while_274_break;
                      }
                      while_274_break:  ;
                      }
                      goto while_273_break;
                    }
                    while_273_break:  ;
                    }
                    body_size___5 = sendbuf->off - body_start___10;
                    {
                    while (1) {
                      while_275_continue:  ;
                      if (! (capacity___10 != 0UL)) {
                        goto while_275_break;
                      }
                      *(sendbuf->base + (body_start___10 - capacity___10)) = (unsigned char )(body_size___5 >> 8UL * (capacity___10 - 1UL));
                      capacity___10 --;
                    }
                    while_275_break:  ;
                    }
                    goto while_271_break;
                  }
                  while_271_break:  ;
                  }
                  i ++;
                }
                while_270_break:  ;
                }
                goto while_269_break;
              }
              while_269_break:  ;
              }
              body_size___6 = sendbuf->off - body_start___9;
              {
              while (1) {
                while_276_continue:  ;
                if (! (capacity___9 != 0UL)) {
                  goto while_276_break;
                }
                *(sendbuf->base + (body_start___9 - capacity___9)) = (unsigned char )(body_size___6 >> 8UL * (capacity___9 - 1UL));
                capacity___9 --;
              }
              while_276_break:  ;
              }
              goto while_267_break;
            }
            while_267_break:  ;
            }
            goto while_266_break;
          }
          while_266_break:  ;
          }
          body_size___7 = sendbuf->off - body_start___8;
          {
          while (1) {
            while_277_continue:  ;
            if (! (capacity___8 != 0UL)) {
              goto while_277_break;
            }
            *(sendbuf->base + (body_start___8 - capacity___8)) = (unsigned char )(body_size___7 >> 8UL * (capacity___8 - 1UL));
            capacity___8 --;
          }
          while_277_break:  ;
          }
          goto while_264_break;
        }
        while_264_break:  ;
        }
        goto while_261_break;
      }
      while_261_break:  ;
      }
    }
  }
  while (1) {
    while_278_continue:  ;
    {
    while (1) {
      while_279_continue:  ;
      _v___3 = (uint16_t )43;
      {
      while (1) {
        while_280_continue:  ;
        {
        __constr_expr_17[0] = (unsigned char )((int )_v___3 >> 8);
        __constr_expr_17[1] = (unsigned char )_v___3;
        ret = __dyc_funcallvar_31;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_280_break;
      }
      while_280_break:  ;
      }
      goto while_279_break;
    }
    while_279_break:  ;
    }
    {
    while (1) {
      while_281_continue:  ;
      capacity___11 = (size_t )2;
      {
      while (1) {
        while_282_continue:  ;
        {
        ret = __dyc_funcallvar_32;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_282_break;
      }
      while_282_break:  ;
      }
      body_start___11 = sendbuf->off;
      {
      while (1) {
        while_283_continue:  ;
        {
        while (1) {
          while_284_continue:  ;
          capacity___12 = (size_t )1;
          {
          while (1) {
            while_285_continue:  ;
            {
            ret = __dyc_funcallvar_33;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_285_break;
          }
          while_285_break:  ;
          }
          body_start___12 = sendbuf->off;
          {
          while (1) {
            while_286_continue:  ;
            i___0 = 0UL;
            {
            while (1) {
              while_287_continue:  ;
              if (! (i___0 != sizeof(uint16_t const   [3]) / sizeof(uint16_t const   ))) {
                goto while_287_break;
              }
              {
              while (1) {
                while_288_continue:  ;
                _v___4 = (uint16_t )supported_versions[i___0];
                {
                while (1) {
                  while_289_continue:  ;
                  {
                  __constr_expr_19[0] = (unsigned char )((int )_v___4 >> 8);
                  __constr_expr_19[1] = (unsigned char )_v___4;
                  ret = __dyc_funcallvar_34;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_289_break;
                }
                while_289_break:  ;
                }
                goto while_288_break;
              }
              while_288_break:  ;
              }
              i___0 ++;
            }
            while_287_break:  ;
            }
            goto while_286_break;
          }
          while_286_break:  ;
          }
          body_size___8 = sendbuf->off - body_start___12;
          {
          while (1) {
            while_290_continue:  ;
            if (! (capacity___12 != 0UL)) {
              goto while_290_break;
            }
            *(sendbuf->base + (body_start___12 - capacity___12)) = (unsigned char )(body_size___8 >> 8UL * (capacity___12 - 1UL));
            capacity___12 --;
          }
          while_290_break:  ;
          }
          goto while_284_break;
        }
        while_284_break:  ;
        }
        goto while_283_break;
      }
      while_283_break:  ;
      }
      body_size___9 = sendbuf->off - body_start___11;
      {
      while (1) {
        while_291_continue:  ;
        if (! (capacity___11 != 0UL)) {
          goto while_291_break;
        }
        *(sendbuf->base + (body_start___11 - capacity___11)) = (unsigned char )(body_size___9 >> 8UL * (capacity___11 - 1UL));
        capacity___11 --;
      }
      while_291_break:  ;
      }
      goto while_281_break;
    }
    while_281_break:  ;
    }
    goto while_278_break;
  }
  while_278_break:  ;
  while (1) {
    while_292_continue:  ;
    {
    while (1) {
      while_293_continue:  ;
      _v___5 = (uint16_t )13;
      {
      while (1) {
        while_294_continue:  ;
        {
        __constr_expr_21[0] = (unsigned char )((int )_v___5 >> 8);
        __constr_expr_21[1] = (unsigned char )_v___5;
        ret = __dyc_funcallvar_35;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_294_break;
      }
      while_294_break:  ;
      }
      goto while_293_break;
    }
    while_293_break:  ;
    }
    {
    while (1) {
      while_295_continue:  ;
      capacity___13 = (size_t )2;
      {
      while (1) {
        while_296_continue:  ;
        {
        ret = __dyc_funcallvar_36;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_296_break;
      }
      while_296_break:  ;
      }
      body_start___13 = sendbuf->off;
      {
      while (1) {
        while_297_continue:  ;
        {
        while (1) {
          while_298_continue:  ;
          capacity___14 = (size_t )2;
          {
          while (1) {
            while_299_continue:  ;
            {
            ret = __dyc_funcallvar_37;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_299_break;
          }
          while_299_break:  ;
          }
          body_start___14 = sendbuf->off;
          {
          while (1) {
            while_300_continue:  ;
            {
            while (1) {
              while_301_continue:  ;
              _v___6 = (uint16_t )2052;
              {
              while (1) {
                while_302_continue:  ;
                {
                __constr_expr_23[0] = (unsigned char )((int )_v___6 >> 8);
                __constr_expr_23[1] = (unsigned char )_v___6;
                ret = __dyc_funcallvar_38;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_302_break;
              }
              while_302_break:  ;
              }
              goto while_301_break;
            }
            while_301_break:  ;
            }
            {
            while (1) {
              while_303_continue:  ;
              _v___7 = (uint16_t )1027;
              {
              while (1) {
                while_304_continue:  ;
                {
                __constr_expr_25[0] = (unsigned char )((int )_v___7 >> 8);
                __constr_expr_25[1] = (unsigned char )_v___7;
                ret = __dyc_funcallvar_39;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_304_break;
              }
              while_304_break:  ;
              }
              goto while_303_break;
            }
            while_303_break:  ;
            }
            {
            while (1) {
              while_305_continue:  ;
              _v___8 = (uint16_t )1025;
              {
              while (1) {
                while_306_continue:  ;
                {
                __constr_expr_27[0] = (unsigned char )((int )_v___8 >> 8);
                __constr_expr_27[1] = (unsigned char )_v___8;
                ret = __dyc_funcallvar_40;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_306_break;
              }
              while_306_break:  ;
              }
              goto while_305_break;
            }
            while_305_break:  ;
            }
            {
            while (1) {
              while_307_continue:  ;
              _v___9 = (uint16_t )513;
              {
              while (1) {
                while_308_continue:  ;
                {
                __constr_expr_29[0] = (unsigned char )((int )_v___9 >> 8);
                __constr_expr_29[1] = (unsigned char )_v___9;
                ret = __dyc_funcallvar_41;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_308_break;
              }
              while_308_break:  ;
              }
              goto while_307_break;
            }
            while_307_break:  ;
            }
            goto while_300_break;
          }
          while_300_break:  ;
          }
          body_size___10 = sendbuf->off - body_start___14;
          {
          while (1) {
            while_309_continue:  ;
            if (! (capacity___14 != 0UL)) {
              goto while_309_break;
            }
            *(sendbuf->base + (body_start___14 - capacity___14)) = (unsigned char )(body_size___10 >> 8UL * (capacity___14 - 1UL));
            capacity___14 --;
          }
          while_309_break:  ;
          }
          goto while_298_break;
        }
        while_298_break:  ;
        }
        goto while_297_break;
      }
      while_297_break:  ;
      }
      body_size___11 = sendbuf->off - body_start___13;
      {
      while (1) {
        while_310_continue:  ;
        if (! (capacity___13 != 0UL)) {
          goto while_310_break;
        }
        *(sendbuf->base + (body_start___13 - capacity___13)) = (unsigned char )(body_size___11 >> 8UL * (capacity___13 - 1UL));
        capacity___13 --;
      }
      while_310_break:  ;
      }
      goto while_295_break;
    }
    while_295_break:  ;
    }
    goto while_292_break;
  }
  while_292_break:  ;
  while (1) {
    while_311_continue:  ;
    {
    while (1) {
      while_312_continue:  ;
      _v___10 = (uint16_t )10;
      {
      while (1) {
        while_313_continue:  ;
        {
        __constr_expr_31[0] = (unsigned char )((int )_v___10 >> 8);
        __constr_expr_31[1] = (unsigned char )_v___10;
        ret = __dyc_funcallvar_42;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_313_break;
      }
      while_313_break:  ;
      }
      goto while_312_break;
    }
    while_312_break:  ;
    }
    {
    while (1) {
      while_314_continue:  ;
      capacity___15 = (size_t )2;
      {
      while (1) {
        while_315_continue:  ;
        {
        ret = __dyc_funcallvar_43;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_315_break;
      }
      while_315_break:  ;
      }
      body_start___15 = sendbuf->off;
      {
      while (1) {
        while_316_continue:  ;
        algo = (tls->ctx)->key_exchanges;
        {
        while (1) {
          while_317_continue:  ;
          capacity___16 = (size_t )2;
          {
          while (1) {
            while_318_continue:  ;
            {
            ret = __dyc_funcallvar_44;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_318_break;
          }
          while_318_break:  ;
          }
          body_start___16 = sendbuf->off;
          {
          while (1) {
            while_319_continue:  ;
            {
            while (1) {
              while_320_continue:  ;
              if (! ((unsigned long )*algo != (unsigned long )((void *)0))) {
                goto while_320_break;
              }
              {
              while (1) {
                while_321_continue:  ;
                _v___11 = (uint16_t )(*algo)->id;
                {
                while (1) {
                  while_322_continue:  ;
                  {
                  __constr_expr_33[0] = (unsigned char )((int )_v___11 >> 8);
                  __constr_expr_33[1] = (unsigned char )_v___11;
                  ret = __dyc_funcallvar_45;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_322_break;
                }
                while_322_break:  ;
                }
                goto while_321_break;
              }
              while_321_break:  ;
              }
              algo ++;
            }
            while_320_break:  ;
            }
            goto while_319_break;
          }
          while_319_break:  ;
          }
          body_size___12 = sendbuf->off - body_start___16;
          {
          while (1) {
            while_323_continue:  ;
            if (! (capacity___16 != 0UL)) {
              goto while_323_break;
            }
            *(sendbuf->base + (body_start___16 - capacity___16)) = (unsigned char )(body_size___12 >> 8UL * (capacity___16 - 1UL));
            capacity___16 --;
          }
          while_323_break:  ;
          }
          goto while_317_break;
        }
        while_317_break:  ;
        }
        goto while_316_break;
      }
      while_316_break:  ;
      }
      body_size___13 = sendbuf->off - body_start___15;
      {
      while (1) {
        while_324_continue:  ;
        if (! (capacity___15 != 0UL)) {
          goto while_324_break;
        }
        *(sendbuf->base + (body_start___15 - capacity___15)) = (unsigned char )(body_size___13 >> 8UL * (capacity___15 - 1UL));
        capacity___15 --;
      }
      while_324_break:  ;
      }
      goto while_314_break;
    }
    while_314_break:  ;
    }
    goto while_311_break;
  }
  while_311_break:  ;
  while (1) {
    while_325_continue:  ;
    {
    while (1) {
      while_326_continue:  ;
      _v___12 = (uint16_t )51;
      {
      while (1) {
        while_327_continue:  ;
        {
        __constr_expr_35[0] = (unsigned char )((int )_v___12 >> 8);
        __constr_expr_35[1] = (unsigned char )_v___12;
        ret = __dyc_funcallvar_46;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_327_break;
      }
      while_327_break:  ;
      }
      goto while_326_break;
    }
    while_326_break:  ;
    }
    {
    while (1) {
      while_328_continue:  ;
      capacity___17 = (size_t )2;
      {
      while (1) {
        while_329_continue:  ;
        {
        ret = __dyc_funcallvar_47;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_329_break;
      }
      while_329_break:  ;
      }
      body_start___17 = sendbuf->off;
      {
      while (1) {
        while_330_continue:  ;
        {
        while (1) {
          while_331_continue:  ;
          capacity___18 = (size_t )2;
          {
          while (1) {
            while_332_continue:  ;
            {
            ret = __dyc_funcallvar_48;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_332_break;
          }
          while_332_break:  ;
          }
          body_start___18 = sendbuf->off;
          {
          while (1) {
            while_333_continue:  ;
            if ((unsigned long )tls->key_share != (unsigned long )((void *)0)) {
              {
              ret = __dyc_funcallvar_49;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              {
              while (1) {
                while_334_continue:  ;
                _v___13 = (uint16_t )(tls->key_share)->id;
                {
                while (1) {
                  while_335_continue:  ;
                  {
                  __constr_expr_37[0] = (unsigned char )((int )_v___13 >> 8);
                  __constr_expr_37[1] = (unsigned char )_v___13;
                  ret = __dyc_funcallvar_50;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_335_break;
                }
                while_335_break:  ;
                }
                goto while_334_break;
              }
              while_334_break:  ;
              }
              {
              while (1) {
                while_336_continue:  ;
                capacity___19 = (size_t )2;
                {
                while (1) {
                  while_337_continue:  ;
                  {
                  ret = __dyc_funcallvar_51;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_337_break;
                }
                while_337_break:  ;
                }
                body_start___19 = sendbuf->off;
                {
                while (1) {
                  while_338_continue:  ;
                  {
                  while (1) {
                    while_339_continue:  ;
                    {
                    ret = __dyc_funcallvar_52;
                    }
                    if (ret != 0) {
                      goto __dyc_dummy_label;
                    }
                    goto while_339_break;
                  }
                  while_339_break:  ;
                  }
                  goto while_338_break;
                }
                while_338_break:  ;
                }
                body_size___14 = sendbuf->off - body_start___19;
                {
                while (1) {
                  while_340_continue:  ;
                  if (! (capacity___19 != 0UL)) {
                    goto while_340_break;
                  }
                  *(sendbuf->base + (body_start___19 - capacity___19)) = (unsigned char )(body_size___14 >> 8UL * (capacity___19 - 1UL));
                  capacity___19 --;
                }
                while_340_break:  ;
                }
                goto while_336_break;
              }
              while_336_break:  ;
              }
            }
            goto while_333_break;
          }
          while_333_break:  ;
          }
          body_size___15 = sendbuf->off - body_start___18;
          {
          while (1) {
            while_341_continue:  ;
            if (! (capacity___18 != 0UL)) {
              goto while_341_break;
            }
            *(sendbuf->base + (body_start___18 - capacity___18)) = (unsigned char )(body_size___15 >> 8UL * (capacity___18 - 1UL));
            capacity___18 --;
          }
          while_341_break:  ;
          }
          goto while_331_break;
        }
        while_331_break:  ;
        }
        goto while_330_break;
      }
      while_330_break:  ;
      }
      body_size___16 = sendbuf->off - body_start___17;
      {
      while (1) {
        while_342_continue:  ;
        if (! (capacity___17 != 0UL)) {
          goto while_342_break;
        }
        *(sendbuf->base + (body_start___17 - capacity___17)) = (unsigned char )(body_size___16 >> 8UL * (capacity___17 - 1UL));
        capacity___17 --;
      }
      while_342_break:  ;
      }
      goto while_328_break;
    }
    while_328_break:  ;
    }
    goto while_325_break;
  }
  while_325_break:  ;
  if ((unsigned long )cookie != (unsigned long )((void *)0)) {
    if ((unsigned long )cookie->base != (unsigned long )((void *)0)) {
      {
      while (1) {
        while_343_continue:  ;
        {
        while (1) {
          while_344_continue:  ;
          _v___14 = (uint16_t )44;
          {
          while (1) {
            while_345_continue:  ;
            {
            __constr_expr_39[0] = (unsigned char )((int )_v___14 >> 8);
            __constr_expr_39[1] = (unsigned char )_v___14;
            ret = __dyc_funcallvar_53;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_345_break;
          }
          while_345_break:  ;
          }
          goto while_344_break;
        }
        while_344_break:  ;
        }
        {
        while (1) {
          while_346_continue:  ;
          capacity___20 = (size_t )2;
          {
          while (1) {
            while_347_continue:  ;
            {
            ret = __dyc_funcallvar_54;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_347_break;
          }
          while_347_break:  ;
          }
          body_start___20 = sendbuf->off;
          {
          while (1) {
            while_348_continue:  ;
            {
            while (1) {
              while_349_continue:  ;
              capacity___21 = (size_t )2;
              {
              while (1) {
                while_350_continue:  ;
                {
                ret = __dyc_funcallvar_55;
                }
                if (ret != 0) {
                  goto __dyc_dummy_label;
                }
                goto while_350_break;
              }
              while_350_break:  ;
              }
              body_start___21 = sendbuf->off;
              {
              while (1) {
                while_351_continue:  ;
                {
                while (1) {
                  while_352_continue:  ;
                  {
                  ret = __dyc_funcallvar_56;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_352_break;
                }
                while_352_break:  ;
                }
                goto while_351_break;
              }
              while_351_break:  ;
              }
              body_size___17 = sendbuf->off - body_start___21;
              {
              while (1) {
                while_353_continue:  ;
                if (! (capacity___21 != 0UL)) {
                  goto while_353_break;
                }
                *(sendbuf->base + (body_start___21 - capacity___21)) = (unsigned char )(body_size___17 >> 8UL * (capacity___21 - 1UL));
                capacity___21 --;
              }
              while_353_break:  ;
              }
              goto while_349_break;
            }
            while_349_break:  ;
            }
            goto while_348_break;
          }
          while_348_break:  ;
          }
          body_size___18 = sendbuf->off - body_start___20;
          {
          while (1) {
            while_354_continue:  ;
            if (! (capacity___20 != 0UL)) {
              goto while_354_break;
            }
            *(sendbuf->base + (body_start___20 - capacity___20)) = (unsigned char )(body_size___18 >> 8UL * (capacity___20 - 1UL));
            capacity___20 --;
          }
          while_354_break:  ;
          }
          goto while_346_break;
        }
        while_346_break:  ;
        }
        goto while_343_break;
      }
      while_343_break:  ;
      }
    }
  }
  ret = __dyc_funcallvar_57;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(capacity___5);
  __dyc_printpre_byte(body_start___5);
  __dyc_printpre_byte(capacity___6);
  __dyc_printpre_byte(body_start___6);
  __dyc_printpre_byte(capacity___7);
  __dyc_printpre_byte(body_start___7);
  __dyc_printpre_byte(tmp___1);
  __dyc_printpre_byte(body_size___2);
  __dyc_printpre_byte(body_size___3);
  __dyc_printpre_byte(body_size___4);
  __dyc_printpre_byte(capacity___8);
  __dyc_printpre_byte(body_start___8);
  __dyc_printpre_byte(capacity___9);
  __dyc_printpre_byte(body_start___9);
  __dyc_printpre_byte(capacity___10);
  __dyc_printpre_byte(body_start___10);
  __dyc_print_comp_46st_ptls_iovec_t(p);
  __dyc_printpre_byte(body_size___5);
  __dyc_printpre_byte(body_size___6);
  __dyc_printpre_byte(body_size___7);
  __dyc_printpre_byte(capacity___11);
  __dyc_printpre_byte(body_start___11);
  __dyc_printpre_byte(capacity___12);
  __dyc_printpre_byte(body_start___12);
  __dyc_printpre_byte(body_size___8);
  __dyc_printpre_byte(body_size___9);
  __dyc_printpre_byte(capacity___13);
  __dyc_printpre_byte(body_start___13);
  __dyc_printpre_byte(capacity___14);
  __dyc_printpre_byte(body_start___14);
  __dyc_printpre_byte(body_size___10);
  __dyc_printpre_byte(body_size___11);
  __dyc_printpre_byte(capacity___15);
  __dyc_printpre_byte(body_start___15);
  __dyc_print_ptr__ptr__typdef_ptls_key_exchange_algorithm_t(algo);
  __dyc_printpre_byte(capacity___16);
  __dyc_printpre_byte(body_start___16);
  __dyc_printpre_byte(body_size___12);
  __dyc_printpre_byte(body_size___13);
  __dyc_printpre_byte(capacity___17);
  __dyc_printpre_byte(body_start___17);
  __dyc_printpre_byte(capacity___18);
  __dyc_printpre_byte(body_start___18);
  __dyc_printpre_byte(capacity___19);
  __dyc_printpre_byte(body_start___19);
  __dyc_printpre_byte(body_size___14);
  __dyc_printpre_byte(body_size___15);
  __dyc_printpre_byte(body_size___16);
  __dyc_printpre_byte(capacity___20);
  __dyc_printpre_byte(body_start___20);
  __dyc_printpre_byte(capacity___21);
  __dyc_printpre_byte(body_start___21);
  __dyc_printpre_byte(body_size___17);
  __dyc_printpre_byte(body_size___18);
}
}
