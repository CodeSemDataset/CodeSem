#include "../include/dycfoo.h"
#include "../include/neverbleed.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_daemon_vars_66 daemon_vars ;
  int pipe_fds[2] ;
  int listen_fd ;
  int *tmp___16 ;
  char *tmp___17 ;
  int *tmp___18 ;
  char *tmp___19 ;
  int tmp___20 ;
  int *tmp___21 ;
  char *tmp___22 ;
  int tmp___23 ;
  int *tmp___24 ;
  char *tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  int tmp___28 ;
  neverbleed_t *nb ;
  int *__dyc_funcallvar_10 ;
  char *__dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int *__dyc_funcallvar_13 ;
  char *__dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int *__dyc_funcallvar_16 ;
  char *__dyc_funcallvar_17 ;
  __pid_t __dyc_funcallvar_18 ;
  int *__dyc_funcallvar_19 ;
  char *__dyc_funcallvar_20 ;
  ENGINE *__dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;

  {
  listen_fd = __dyc_readpre_byte();
  nb = __dyc_read_ptr__typdef_neverbleed_t();
  __dyc_funcallvar_10 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_11 = __dyc_read_ptr__char();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_14 = __dyc_read_ptr__char();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_17 = __dyc_read_ptr__char();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_20 = __dyc_read_ptr__char();
  __dyc_funcallvar_21 = (ENGINE *)__dyc_read_ptr__typdef_ENGINE();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  memset(& daemon_vars, 0, sizeof(struct __anonstruct_daemon_vars_66 ));
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  if (listen_fd == -1) {
    {
    tmp___16 = __dyc_funcallvar_10;
    tmp___17 = __dyc_funcallvar_11;

    }
    goto __dyc_dummy_label;
  }
  tmp___20 = __dyc_funcallvar_12;
  if (tmp___20 != 0) {
    {
    tmp___18 = __dyc_funcallvar_13;
    tmp___19 = __dyc_funcallvar_14;

    }
    goto __dyc_dummy_label;
  }
  tmp___23 = __dyc_funcallvar_15;
  if (tmp___23 != 0) {
    {
    tmp___21 = __dyc_funcallvar_16;
    tmp___22 = __dyc_funcallvar_17;

    }
    goto __dyc_dummy_label;
  }
  nb->daemon_pid = __dyc_funcallvar_18;
  if (nb->daemon_pid == -1) {
    goto switch_17_neg_1;
  } else {
    if (nb->daemon_pid == 0) {
      goto switch_17_0;
    } else {
      {
      goto switch_17_default;
      if (0) {
        switch_17_neg_1:  
        {
        tmp___24 = __dyc_funcallvar_19;
        tmp___25 = __dyc_funcallvar_20;

        }
        goto __dyc_dummy_label;
        switch_17_0:  
        {


        daemon_vars.nb = nb;

        }
        goto switch_17_break;
        switch_17_default:  ;
        goto switch_17_break;
      } else {
        switch_17_break:  ;
      }
      }
    }
  }

  listen_fd = -1;

  pipe_fds[0] = -1;
  nb->engine = __dyc_funcallvar_21;
  if ((unsigned long )nb->engine == (unsigned long )((void *)0)) {
    {

    }
    goto __dyc_dummy_label;
  } else {
    {
    tmp___26 = __dyc_funcallvar_22;
    }
    if (tmp___26) {
      {
      tmp___27 = __dyc_funcallvar_23;
      }
      if (tmp___27) {
        {
        tmp___28 = __dyc_funcallvar_24;
        }
        if (! tmp___28) {
          {

          }
          goto __dyc_dummy_label;
        }
      } else {
        {

        }
        goto __dyc_dummy_label;
      }
    } else {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_329__anonstruct_daemon_vars_66(daemon_vars);
  __dyc_printpre_byte(listen_fd);
  __dyc_print_ptr__int(tmp___16);
  __dyc_print_ptr__char(tmp___17);
  __dyc_print_ptr__int(tmp___18);
  __dyc_print_ptr__char(tmp___19);
  __dyc_print_ptr__int(tmp___21);
  __dyc_print_ptr__char(tmp___22);
  __dyc_print_ptr__int(tmp___24);
  __dyc_print_ptr__char(tmp___25);
}
}
