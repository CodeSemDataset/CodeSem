#include "../include/dycfoo.h"
#include "../include/fastcgi.i.hd.c.h"
void __dyc_foo(void) 
{ int listen_fd ;
  int pipe_fds[2] ;
  int *tmp___4 ;
  char *tmp___5 ;
  int tmp___6 ;
  int *tmp___7 ;
  char *tmp___8 ;
  int tmp___9 ;
  int *tmp___10 ;
  char *tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int mapped_fds[5] ;
  pid_t pid ;
  pid_t tmp___14 ;
  int *tmp___15 ;
  char *tmp___16 ;
  struct passwd *pw ;
  int *__dyc_funcallvar_9 ;
  char *__dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int *__dyc_funcallvar_12 ;
  char *__dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int *__dyc_funcallvar_15 ;
  char *__dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  pid_t __dyc_funcallvar_18 ;
  int *__dyc_funcallvar_19 ;
  char *__dyc_funcallvar_20 ;

  {
  listen_fd = __dyc_readpre_byte();
  tmp___6 = __dyc_readpre_byte();
  pw = __dyc_read_ptr__comp_67passwd();
  __dyc_funcallvar_9 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_13 = __dyc_read_ptr__char();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_16 = __dyc_read_ptr__char();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_20 = __dyc_read_ptr__char();
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  pid = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  if (tmp___6 != 0) {
    {
    tmp___4 = __dyc_funcallvar_9;
    tmp___5 = __dyc_funcallvar_10;

    }
    goto __dyc_dummy_label;
  }
  if ((unsigned long )pw != (unsigned long )((void *)0)) {
    {
    tmp___9 = __dyc_funcallvar_11;
    }
    if (tmp___9 != 0) {
      {
      tmp___7 = __dyc_funcallvar_12;
      tmp___8 = __dyc_funcallvar_13;

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___12 = __dyc_funcallvar_14;
  if (tmp___12 != 0) {
    {
    tmp___10 = __dyc_funcallvar_15;
    tmp___11 = __dyc_funcallvar_16;

    pipe_fds[0] = -1;
    pipe_fds[1] = -1;
    }
    goto __dyc_dummy_label;
  }
  tmp___13 = __dyc_funcallvar_17;
  if (tmp___13 < 0) {
    goto __dyc_dummy_label;
  }
  mapped_fds[0] = listen_fd;
  mapped_fds[1] = 0;
  mapped_fds[2] = pipe_fds[0];
  mapped_fds[3] = 5;
  mapped_fds[4] = -1;
  tmp___14 = __dyc_funcallvar_18;
  pid = tmp___14;
  if (pid == -1) {
    {
    tmp___15 = __dyc_funcallvar_19;
    tmp___16 = __dyc_funcallvar_20;

    }
    goto __dyc_dummy_label;
  }

  listen_fd = -1;

  pipe_fds[0] = -1;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(listen_fd);
  __dyc_print_ptr__int(tmp___4);
  __dyc_print_ptr__char(tmp___5);
  __dyc_print_ptr__int(tmp___7);
  __dyc_print_ptr__char(tmp___8);
  __dyc_print_ptr__int(tmp___10);
  __dyc_print_ptr__char(tmp___11);
  __dyc_print_ptr__int(tmp___15);
  __dyc_print_ptr__char(tmp___16);
}
}
