#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ struct stat st ;
  int fd ;
  struct passwd *owner ;
  unsigned int mode ;
  yoml_t *t ;
  int *tmp ;
  char *tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int __attribute__((__leaf__))  tmp___3 ;
  int *tmp___4 ;
  char *tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int *tmp___8 ;
  char *tmp___9 ;
  int tmp___10 ;
  int *tmp___11 ;
  char *tmp___12 ;
  int tmp___13 ;
  yoml_t *__dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  int *__dyc_funcallvar_5 ;
  char *__dyc_funcallvar_6 ;
  yoml_t *__dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __attribute__((__leaf__))  __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int *__dyc_funcallvar_11 ;
  char *__dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int *__dyc_funcallvar_14 ;
  char *__dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int *__dyc_funcallvar_17 ;
  char *__dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int *__dyc_funcallvar_20 ;
  char *__dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int *__dyc_funcallvar_23 ;
  char *__dyc_funcallvar_24 ;

  {
  st = __dyc_read_comp_61stat();
  fd = __dyc_readpre_byte();
  owner = __dyc_read_ptr__comp_93passwd();
  __dyc_funcallvar_1 = __dyc_read_ptr__typdef_yoml_t();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__int();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  __dyc_funcallvar_5 = __dyc_read_ptr__int();
  __dyc_funcallvar_6 = __dyc_read_ptr__char();
  __dyc_funcallvar_7 = __dyc_read_ptr__typdef_yoml_t();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_read_ptr__int();
  __dyc_funcallvar_12 = __dyc_read_ptr__char();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_read_ptr__int();
  __dyc_funcallvar_15 = __dyc_read_ptr__char();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_read_ptr__int();
  __dyc_funcallvar_18 = __dyc_read_ptr__char();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_read_ptr__int();
  __dyc_funcallvar_21 = __dyc_read_ptr__char();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_read_ptr__int();
  __dyc_funcallvar_24 = __dyc_read_ptr__char();
  mode = 0;
  t = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  mode = 4294967295U;
  t = __dyc_funcallvar_1;
  if ((unsigned long )t != (unsigned long )((void *)0)) {
    if ((int )t->type != 0) {
      {

      }
      goto ErrorExit;
    }
    {
    tmp___1 = __dyc_funcallvar_2;
    }
    if (tmp___1 != 0) {
      {
      tmp = __dyc_funcallvar_3;
      tmp___0 = __dyc_funcallvar_4;

      }
      goto ErrorExit;
    } else {
      if ((unsigned long )owner == (unsigned long )((void *)0)) {
        {
        tmp = __dyc_funcallvar_5;
        tmp___0 = __dyc_funcallvar_6;

        }
        goto ErrorExit;
      }
    }
  }
  t = __dyc_funcallvar_7;
  if ((unsigned long )t != (unsigned long )((void *)0)) {
    if ((int )t->type != 0) {
      {

      }
      goto ErrorExit;
    } else {
      {
      tmp___2 = __dyc_funcallvar_8;
      }
      if (tmp___2 != 1) {
        {

        }
        goto ErrorExit;
      }
    }
  }
  tmp___3 = __dyc_funcallvar_9;
  if (tmp___3 == (int __attribute__((__leaf__))  )0) {
    if ((st.st_mode & 61440U) == 49152U) {
      {

      }
    } else {
      {

      }
      goto ErrorExit;
    }
  }
  fd = __dyc_funcallvar_10;
  if (fd == -1) {
    {
    tmp___4 = __dyc_funcallvar_11;
    tmp___5 = __dyc_funcallvar_12;

    }
    goto ErrorExit;
  } else {
    {
    tmp___6 = __dyc_funcallvar_13;
    }
    if (tmp___6 != 0) {
      {
      tmp___4 = __dyc_funcallvar_14;
      tmp___5 = __dyc_funcallvar_15;

      }
      goto ErrorExit;
    } else {
      {
      tmp___7 = __dyc_funcallvar_16;
      }
      if (tmp___7 != 0) {
        {
        tmp___4 = __dyc_funcallvar_17;
        tmp___5 = __dyc_funcallvar_18;

        }
        goto ErrorExit;
      }
    }
  }

  if ((unsigned long )owner != (unsigned long )((void *)0)) {
    {
    tmp___10 = __dyc_funcallvar_19;
    }
    if (tmp___10 != 0) {
      {
      tmp___8 = __dyc_funcallvar_20;
      tmp___9 = __dyc_funcallvar_21;

      }
      goto ErrorExit;
    }
  }
  if (mode != 4294967295U) {
    {
    tmp___13 = __dyc_funcallvar_22;
    }
    if (tmp___13 != 0) {
      {
      tmp___11 = __dyc_funcallvar_23;
      tmp___12 = __dyc_funcallvar_24;

      }
      goto ErrorExit;
    }
  }
  goto __dyc_dummy_label;
  ErrorExit: 
  if (fd != -1) {
    {

    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(mode);
  __dyc_print_ptr__int(tmp);
  __dyc_print_ptr__char(tmp___0);
  __dyc_print_ptr__int(tmp___4);
  __dyc_print_ptr__char(tmp___5);
  __dyc_print_ptr__int(tmp___8);
  __dyc_print_ptr__char(tmp___9);
  __dyc_print_ptr__int(tmp___11);
  __dyc_print_ptr__char(tmp___12);
}
}
