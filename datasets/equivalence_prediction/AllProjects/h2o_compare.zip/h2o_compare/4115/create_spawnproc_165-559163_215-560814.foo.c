#include "../include/dycfoo.h"
#include "../include/fastcgi.i.hd.c.h"
void __dyc_foo(void) 
{ int listen_fd ;
  int pipe_fds[2] ;
  int *tmp ;
  char *tmp___0 ;
  int *tmp___1 ;
  char *tmp___2 ;
  int tmp___3 ;
  int *tmp___4 ;
  char *tmp___5 ;
  int tmp___6 ;
  int *tmp___7 ;
  char *tmp___8 ;
  int tmp___9 ;
  int *tmp___10 ;
  char *tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int mapped_fds[5] ;
  pid_t pid ;
  pid_t tmp___14 ;
  int *tmp___15 ;
  char *tmp___16 ;
  struct passwd *pw ;
  int *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int *__dyc_funcallvar_6 ;
  char *__dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int *__dyc_funcallvar_9 ;
  char *__dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int *__dyc_funcallvar_12 ;
  char *__dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int *__dyc_funcallvar_15 ;
  char *__dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  pid_t __dyc_funcallvar_18 ;
  int *__dyc_funcallvar_19 ;
  char *__dyc_funcallvar_20 ;

  {
  listen_fd = __dyc_readpre_byte();
  pw = __dyc_read_ptr__comp_67passwd();
  __dyc_funcallvar_3 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_7 = __dyc_read_ptr__char();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_13 = __dyc_read_ptr__char();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_16 = __dyc_read_ptr__char();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_20 = __dyc_read_ptr__char();
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  pid = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  if (listen_fd == -1) {
    {
    tmp = __dyc_funcallvar_3;
    tmp___0 = __dyc_funcallvar_4;

    }
    goto Error;
  }
  tmp___3 = __dyc_funcallvar_5;
  if (tmp___3 != 0) {
    {
    tmp___1 = __dyc_funcallvar_6;
    tmp___2 = __dyc_funcallvar_7;

    }
    goto Error;
  }
  tmp___6 = __dyc_funcallvar_8;
  if (tmp___6 != 0) {
    {
    tmp___4 = __dyc_funcallvar_9;
    tmp___5 = __dyc_funcallvar_10;

    }
    goto Error;
  }
  if ((unsigned long )pw != (unsigned long )((void *)0)) {
    {
    tmp___9 = __dyc_funcallvar_11;
    }
    if (tmp___9 != 0) {
      {
      tmp___7 = __dyc_funcallvar_12;
      tmp___8 = __dyc_funcallvar_13;

      }
      goto Error;
    }
  }
  tmp___12 = __dyc_funcallvar_14;
  if (tmp___12 != 0) {
    {
    tmp___10 = __dyc_funcallvar_15;
    tmp___11 = __dyc_funcallvar_16;

    pipe_fds[0] = -1;
    pipe_fds[1] = -1;
    }
    goto Error;
  }
  tmp___13 = __dyc_funcallvar_17;
  if (tmp___13 < 0) {
    goto Error;
  }
  mapped_fds[0] = listen_fd;
  mapped_fds[1] = 0;
  mapped_fds[2] = pipe_fds[0];
  mapped_fds[3] = 5;
  mapped_fds[4] = -1;
  tmp___14 = __dyc_funcallvar_18;
  pid = tmp___14;
  if (pid == -1) {
    {
    tmp___15 = __dyc_funcallvar_19;
    tmp___16 = __dyc_funcallvar_20;

    }
    goto Error;
  }

  listen_fd = -1;

  pipe_fds[0] = -1;
  goto __dyc_dummy_label;
  Error: 
  if (pipe_fds[0] != -1) {
    {

    }
  }
  if (pipe_fds[1]) {
    {

    }
  }
  if (listen_fd != -1) {
    {

    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(listen_fd);
  __dyc_print_ptr__int(tmp);
  __dyc_print_ptr__char(tmp___0);
  __dyc_print_ptr__int(tmp___1);
  __dyc_print_ptr__char(tmp___2);
  __dyc_print_ptr__int(tmp___4);
  __dyc_print_ptr__char(tmp___5);
  __dyc_print_ptr__int(tmp___7);
  __dyc_print_ptr__char(tmp___8);
  __dyc_print_ptr__int(tmp___10);
  __dyc_print_ptr__char(tmp___11);
  __dyc_print_ptr__int(tmp___15);
  __dyc_print_ptr__char(tmp___16);
}
}
