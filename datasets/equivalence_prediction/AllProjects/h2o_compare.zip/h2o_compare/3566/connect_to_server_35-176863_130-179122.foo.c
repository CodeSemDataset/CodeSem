#include "../include/dycfoo.h"
#include "../include/connect.i.hd.c.h"
void __dyc_foo(void) 
{ long fl ;
  struct addrinfo hint ;
  int e ;
  int tmp ;
  int s ;
  int tmp___0 ;
  int *tmp___1 ;
  int *tmp___2 ;
  int *tmp___3 ;
  int *tmp___4 ;
  int *tmp___5 ;
  struct pollfd fds ;
  int n ;
  int tmp___6 ;
  int *tmp___7 ;
  int *tmp___8 ;
  socklen_t l ;
  int tmp___9 ;
  int *tmp___10 ;
  int tmp___11 ;
  int *tmp___12 ;
  int *tmp___13 ;
  int tmp___14 ;
  int ok ;
  int *tmp___15 ;
  int *tmp___16 ;
  int tmp___17 ;
  int *server_fd ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int *__dyc_funcallvar_7 ;
  int *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int *__dyc_funcallvar_10 ;
  int *__dyc_funcallvar_11 ;
  int *__dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int *__dyc_funcallvar_14 ;
  int *__dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int *__dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int *__dyc_funcallvar_20 ;
  int *__dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int *__dyc_funcallvar_23 ;
  int *__dyc_funcallvar_24 ;

  {
  server_fd = __dyc_read_ptr__int();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_read_ptr__int();
  __dyc_funcallvar_8 = __dyc_read_ptr__int();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_read_ptr__int();
  __dyc_funcallvar_11 = __dyc_read_ptr__int();
  __dyc_funcallvar_12 = __dyc_read_ptr__int();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_read_ptr__int();
  __dyc_funcallvar_15 = __dyc_read_ptr__int();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_read_ptr__int();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_read_ptr__int();
  __dyc_funcallvar_21 = __dyc_read_ptr__int();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_read_ptr__int();
  __dyc_funcallvar_24 = __dyc_read_ptr__int();
  fl = 0;
  memset(& hint, 0, sizeof(struct addrinfo ));
  e = 0;
  tmp = 0;
  s = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  memset(& fds, 0, sizeof(struct pollfd ));
  n = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  l = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  ok = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  hint.ai_flags = 1056;
  tmp = __dyc_funcallvar_1;
  e = tmp;
  if (e == -6) {
    {
    hint.ai_family = 10;
    hint.ai_flags = 1032;
    e = __dyc_funcallvar_2;
    }
  } else {
    if (e == -2) {
      {
      hint.ai_family = 10;
      hint.ai_flags = 1032;
      e = __dyc_funcallvar_3;
      }
    } else {
      if (e == -9) {
        {
        hint.ai_family = 10;
        hint.ai_flags = 1032;
        e = __dyc_funcallvar_4;
        }
      } else {
        if (e == -5) {
          {
          hint.ai_family = 10;
          hint.ai_flags = 1032;
          e = __dyc_funcallvar_5;
          }
        }
      }
    }
  }
  if (e == -11) {
    goto __dyc_dummy_label;
  } else {
    if (e != 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___0 = __dyc_funcallvar_6;
  s = tmp___0;
  if (s == -1) {
    {
    tmp___1 = __dyc_funcallvar_7;
    e = *tmp___1;

    tmp___2 = __dyc_funcallvar_8;
    *tmp___2 = e;
    }
    goto __dyc_dummy_label;
  }
  e = __dyc_funcallvar_9;

  if (e == -1) {
    {
    tmp___5 = __dyc_funcallvar_10;
    }
    if (*tmp___5 != 115) {
      {
      tmp___3 = __dyc_funcallvar_11;
      e = *tmp___3;

      tmp___4 = __dyc_funcallvar_12;
      *tmp___4 = e;
      }
      goto __dyc_dummy_label;
    }
  }
  if (e != 0) {
    {
    fds.fd = s;
    fds.events = (short)4;
    tmp___6 = __dyc_funcallvar_13;
    n = tmp___6;
    }
    if (n == 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    if (n == -1) {
      {
      tmp___7 = __dyc_funcallvar_14;
      e = *tmp___7;

      tmp___8 = __dyc_funcallvar_15;
      *tmp___8 = e;
      }
      goto __dyc_dummy_label;
    }
    if ((int )fds.revents & 56) {
      {

      }
      goto __dyc_dummy_label;
    }
    {
    l = (socklen_t )sizeof(int );
    tmp___9 = __dyc_funcallvar_16;
    }
    if (tmp___9 == -1) {
      {

      }
      goto __dyc_dummy_label;
    }
    if (e != 0) {
      {

      tmp___10 = __dyc_funcallvar_17;
      *tmp___10 = e;
      }
      goto __dyc_dummy_label;
    }
  }
  tmp___11 = __dyc_funcallvar_18;
  fl = (long )tmp___11;
  tmp___14 = __dyc_funcallvar_19;
  if (tmp___14 == -1) {
    {
    tmp___12 = __dyc_funcallvar_20;
    e = *tmp___12;

    tmp___13 = __dyc_funcallvar_21;
    *tmp___13 = e;
    }
    goto __dyc_dummy_label;
  }
  ok = 1;
  tmp___17 = __dyc_funcallvar_22;
  if (tmp___17 == -1) {
    {
    tmp___15 = __dyc_funcallvar_23;
    e = *tmp___15;

    tmp___16 = __dyc_funcallvar_24;
    *tmp___16 = e;
    }
    goto __dyc_dummy_label;
  }
  *server_fd = s;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(fl);
  __dyc_print_comp_91addrinfo(hint);
  __dyc_print_comp_96pollfd(fds);
  __dyc_printpre_byte(l);
  __dyc_printpre_byte(ok);
}
}
