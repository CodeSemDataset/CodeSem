#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ SSL_CTX *ssl_ctx ;
  yoml_t *certificate_file ;
  yoml_t *min_version ;
  yoml_t *max_version ;
  yoml_t *ocsp_update_interval_node ;
  yoml_t *ocsp_max_failures_node ;
  long ssl_options ;
  int use_picotls ;
  int tmp___237 ;
  int tmp___238 ;
  int tmp___239 ;
  int tmp___240 ;
  int tmp___241 ;
  int tmp___242 ;
  int tmp___243 ;
  int tmp___244 ;
  int tmp___245 ;
  size_t i___0 ;
  struct listener_ssl_config_t *ssl_config ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___255 ;
  int tmp___260 ;
  int tmp___261 ;
  int tmp___262 ;
  int tmp___263 ;
  SSL_METHOD const   *tmp___264 ;
  h2o_configurator_context_t *ctx ;
  struct listener_config_t *listener ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  int __dyc_funcallvar_74 ;
  int __dyc_funcallvar_75 ;
  int __dyc_funcallvar_76 ;
  int __dyc_funcallvar_77 ;
  int __dyc_funcallvar_78 ;
  int __dyc_funcallvar_79 ;
  int __dyc_funcallvar_80 ;
  int __dyc_funcallvar_81 ;
  int __dyc_funcallvar_82 ;
  int __dyc_funcallvar_83 ;
  SSL_METHOD const   *__dyc_funcallvar_84 ;
  SSL_CTX *__dyc_funcallvar_85 ;

  {
  certificate_file = __dyc_read_ptr__typdef_yoml_t();
  min_version = __dyc_read_ptr__typdef_yoml_t();
  max_version = __dyc_read_ptr__typdef_yoml_t();
  ocsp_update_interval_node = __dyc_read_ptr__typdef_yoml_t();
  ocsp_max_failures_node = __dyc_read_ptr__typdef_yoml_t();
  ssl_options = (long )__dyc_readpre_byte();
  ctx = __dyc_read_ptr__typdef_h2o_configurator_context_t();
  listener = __dyc_read_ptr__comp_637listener_config_t();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = __dyc_readpre_byte();
  __dyc_funcallvar_75 = __dyc_readpre_byte();
  __dyc_funcallvar_76 = __dyc_readpre_byte();
  __dyc_funcallvar_77 = __dyc_readpre_byte();
  __dyc_funcallvar_78 = __dyc_readpre_byte();
  __dyc_funcallvar_79 = __dyc_readpre_byte();
  __dyc_funcallvar_80 = __dyc_readpre_byte();
  __dyc_funcallvar_81 = __dyc_readpre_byte();
  __dyc_funcallvar_82 = __dyc_readpre_byte();
  __dyc_funcallvar_83 = __dyc_readpre_byte();
  __dyc_funcallvar_84 = (SSL_METHOD const   *)__dyc_read_ptr__typdef_SSL_METHOD();
  __dyc_funcallvar_85 = __dyc_read_ptr__typdef_SSL_CTX();
  ssl_ctx = 0;
  use_picotls = 0;
  tmp___237 = 0;
  tmp___238 = 0;
  tmp___239 = 0;
  tmp___240 = 0;
  tmp___241 = 0;
  tmp___242 = 0;
  tmp___243 = 0;
  tmp___244 = 0;
  tmp___245 = 0;
  i___0 = 0;
  ssl_config = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___255 = 0;
  tmp___260 = 0;
  tmp___261 = 0;
  tmp___262 = 0;
  tmp___263 = 0;
  tmp___264 = 0;
  if ((unsigned long )min_version != (unsigned long )((void *)0)) {
    {
    tmp___237 = __dyc_funcallvar_70;
    }
    if (tmp___237 == 0) {
      ssl_options = ssl_options;
      goto VersionFound;
    }
    {
    tmp___238 = __dyc_funcallvar_71;
    }
    if (tmp___238 == 0) {
      ssl_options |= 16777216L;
      goto VersionFound;
    }
    {
    tmp___239 = __dyc_funcallvar_72;
    }
    if (tmp___239 == 0) {
      ssl_options |= 50331648L;
      goto VersionFound;
    }
    {
    tmp___240 = __dyc_funcallvar_73;
    }
    if (tmp___240 == 0) {
      ssl_options |= 117440512L;
      goto VersionFound;
    }
    {
    tmp___241 = __dyc_funcallvar_74;
    }
    if (tmp___241 == 0) {
      ssl_options |= 385875968L;
      goto VersionFound;
    }
    {
    tmp___242 = __dyc_funcallvar_75;
    }
    if (tmp___242 == 0) {
      ssl_options |= 520093696L;
      goto VersionFound;
    }
    {

    }
    VersionFound: ;
  } else {
    ssl_options |= 50331648L;
  }
  if ((unsigned long )max_version != (unsigned long )((void *)0)) {
    {
    tmp___243 = __dyc_funcallvar_76;
    }
    if (tmp___243 < 0) {
      use_picotls = 0;
    }
  }
  if ((unsigned long )ocsp_update_interval_node != (unsigned long )((void *)0)) {
    {
    tmp___244 = __dyc_funcallvar_77;
    }
    if (tmp___244 != 0) {
      goto __dyc_dummy_label;
    }
  }
  if ((unsigned long )ocsp_max_failures_node != (unsigned long )((void *)0)) {
    {
    tmp___245 = __dyc_funcallvar_78;
    }
    if (tmp___245 != 0) {
      goto __dyc_dummy_label;
    }
  }
  if ((unsigned long )ctx->hostconf != (unsigned long )((void *)0)) {
    i___0 = 0UL;
    {
    while (1) {
      while_33_continue:  ;
      if (! (i___0 != listener->ssl.size)) {
        goto while_33_break;
      }
      ssl_config = *(listener->ssl.entries + i___0);
      if (0) {
        {
        tmp___261 = __dyc_funcallvar_79;
        __s1_len___12 = (unsigned long )tmp___261;
        tmp___262 = __dyc_funcallvar_80;
        __s2_len___12 = (unsigned long )tmp___262;
        }
        if (! ((unsigned long )((void const   *)(ssl_config->certificate_file + 1)) - (unsigned long )((void const   *)ssl_config->certificate_file) == 1UL)) {
          goto _L___28;
        } else {
          if (__s1_len___12 >= 4UL) {
            _L___28:  
            if (! ((unsigned long )((void const   *)(certificate_file->data.scalar + 1)) - (unsigned long )((void const   *)certificate_file->data.scalar) == 1UL)) {
              tmp___263 = 1;
            } else {
              if (__s2_len___12 >= 4UL) {
                tmp___263 = 1;
              } else {
                tmp___263 = 0;
              }
            }
          } else {
            tmp___263 = 0;
          }
        }
        if (tmp___263) {
          {
          tmp___255 = __dyc_funcallvar_81;
          }
        } else {
          {
          tmp___260 = __dyc_funcallvar_82;
          tmp___255 = tmp___260;
          }
        }
      } else {
        {
        tmp___260 = __dyc_funcallvar_83;
        tmp___255 = tmp___260;
        }
      }
      if (tmp___255 == 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      i___0 ++;
    }
    while_33_break:  ;
    }
  }
  ssl_options |= 131072L;
  tmp___264 = __dyc_funcallvar_84;
  ssl_ctx = __dyc_funcallvar_85;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_SSL_CTX(ssl_ctx);
  __dyc_printpre_byte(ssl_options);
  __dyc_printpre_byte(use_picotls);
  __dyc_print_ptr__comp_633listener_ssl_config_t(ssl_config);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
  __dyc_print_ptr__typdef_SSL_METHOD(tmp___264);
}
}
