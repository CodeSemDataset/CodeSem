#include "../include/dycfoo.h"
#include "../include/configurator.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_deferred_146 deferred ;
  struct __anonstruct_deferred_146 semi_deferred ;
  int ret ;
  size_t i ;
  yoml_t *key ;
  yoml_t *value ;
  h2o_configurator_command_t *cmd ;
  size_t i___0 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___9 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  size_t tmp___18 ;
  struct st_cmd_value_t __constr_expr_0 ;
  size_t tmp___19 ;
  struct st_cmd_value_t __constr_expr_1 ;
  int tmp___20 ;
  struct st_cmd_value_t *pair ;
  int tmp___21 ;
  struct st_cmd_value_t *pair___0 ;
  int tmp___22 ;
  int tmp___23 ;
  yoml_t *node ;
  int flags_mask ;
  char const   **ignore_commands ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  h2o_configurator_command_t *__dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;

  {
  deferred = __dyc_read_comp_489__anonstruct_deferred_146();
  semi_deferred = __dyc_read_comp_489__anonstruct_deferred_146();
  node = __dyc_read_ptr__typdef_yoml_t();
  flags_mask = __dyc_readpre_byte();
  ignore_commands = (char const   **)__dyc_read_ptr__ptr__char();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_read_ptr__typdef_h2o_configurator_command_t();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  ret = 0;
  i = 0;
  key = 0;
  value = 0;
  cmd = 0;
  i___0 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___9 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  memset(& __constr_expr_0, 0, sizeof(struct st_cmd_value_t ));
  tmp___19 = 0;
  memset(& __constr_expr_1, 0, sizeof(struct st_cmd_value_t ));
  tmp___20 = 0;
  pair = 0;
  tmp___21 = 0;
  pair___0 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  if ((unsigned long )node != (unsigned long )((void *)0)) {
    i = 0UL;
    {
    while (1) {
      while_5_continue:  ;
      if (! (i != node->data.mapping.size)) {
        goto while_5_break;
      }
      key = node->data.mapping.elements[i].key;
      value = node->data.mapping.elements[i].value;
      if ((int )key->type != 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      if ((unsigned long )ignore_commands != (unsigned long )((void *)0)) {
        i___0 = 0UL;
        {
        while (1) {
          while_6_continue:  ;
          if (! ((unsigned long )*(ignore_commands + i___0) != (unsigned long )((void *)0))) {
            goto while_6_break;
          }
          if (0) {
            {
            tmp___15 = __dyc_funcallvar_2;
            __s1_len = (unsigned long )tmp___15;
            tmp___16 = __dyc_funcallvar_3;
            __s2_len = (unsigned long )tmp___16;
            }
            if (! ((unsigned long )((void const   *)(*(ignore_commands + i___0) + 1)) - (unsigned long )((void const   *)*(ignore_commands + i___0)) == 1UL)) {
              goto _L___0;
            } else {
              if (__s1_len >= 4UL) {
                _L___0:  
                if (! ((unsigned long )((void const   *)(key->data.scalar + 1)) - (unsigned long )((void const   *)key->data.scalar) == 1UL)) {
                  tmp___17 = 1;
                } else {
                  if (__s2_len >= 4UL) {
                    tmp___17 = 1;
                  } else {
                    tmp___17 = 0;
                  }
                }
              } else {
                tmp___17 = 0;
              }
            }
            if (tmp___17) {
              {
              tmp___9 = __dyc_funcallvar_4;
              }
            } else {
              {
              tmp___14 = __dyc_funcallvar_5;
              tmp___9 = tmp___14;
              }
            }
          } else {
            {
            tmp___14 = __dyc_funcallvar_6;
            tmp___9 = tmp___14;
            }
          }
          if (tmp___9 == 0) {
            goto SkipCommand;
          }
          i___0 ++;
        }
        while_6_break:  ;
        }
      }
      {
      cmd = __dyc_funcallvar_7;
      }
      if ((unsigned long )cmd == (unsigned long )((void *)0)) {
        {

        }
        goto __dyc_dummy_label;
      }
      if ((cmd->flags & flags_mask) == 0) {
        {

        }
        goto __dyc_dummy_label;
      }
      if ((cmd->flags & 1792) != 0) {
        if ((int )value->type == 0) {
          goto switch_7_0;
        } else {
          if ((int )value->type == 1) {
            goto switch_7_1;
          } else {
            if ((int )value->type == 2) {
              goto switch_7_2;
            } else {
              {
              goto switch_7_default;
              if (0) {
                switch_7_0:  
                if ((cmd->flags & 256) == 0) {
                  {

                  }
                  goto __dyc_dummy_label;
                }
                goto switch_7_break;
                switch_7_1:  
                if ((cmd->flags & 512) == 0) {
                  {

                  }
                  goto __dyc_dummy_label;
                }
                goto switch_7_break;
                switch_7_2:  
                if ((cmd->flags & 1024) == 0) {
                  {

                  }
                  goto __dyc_dummy_label;
                }
                goto switch_7_break;
                switch_7_default:  
                {

                }
                goto switch_7_break;
              } else {
                switch_7_break:  ;
              }
              }
            }
          }
        }
      }
      if ((cmd->flags & 8192) != 0) {
        {

        tmp___18 = semi_deferred.size;
        (semi_deferred.size) ++;
        __constr_expr_0.cmd = cmd;
        __constr_expr_0.value = value;
        *(semi_deferred.entries + tmp___18) = __constr_expr_0;
        }
      } else {
        if ((cmd->flags & 4096) != 0) {
          {

          tmp___19 = deferred.size;
          (deferred.size) ++;
          __constr_expr_1.cmd = cmd;
          __constr_expr_1.value = value;
          *(deferred.entries + tmp___19) = __constr_expr_1;
          }
        } else {
          {
          tmp___20 = __dyc_funcallvar_8;
          }
          if (tmp___20 != 0) {
            goto __dyc_dummy_label;
          }
        }
      }
      SkipCommand: 
      i ++;
    }
    while_5_break:  ;
    }
    i = 0UL;
    {
    while (1) {
      while_8_continue:  ;
      if (! (i != semi_deferred.size)) {
        goto while_8_break;
      }
      {
      pair = semi_deferred.entries + i;
      tmp___21 = __dyc_funcallvar_9;
      }
      if (tmp___21 != 0) {
        goto __dyc_dummy_label;
      }
      i ++;
    }
    while_8_break:  ;
    }
    i = 0UL;
    {
    while (1) {
      while_9_continue:  ;
      if (! (i != deferred.size)) {
        goto while_9_break;
      }
      {
      pair___0 = deferred.entries + i;
      tmp___22 = __dyc_funcallvar_10;
      }
      if (tmp___22 != 0) {
        goto __dyc_dummy_label;
      }
      i ++;
    }
    while_9_break:  ;
    }
  }
  tmp___23 = __dyc_funcallvar_11;
  if (tmp___23 != 0) {
    goto __dyc_dummy_label;
  }
  ret = 0;


  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(ret);
  __dyc_print_ptr__typdef_yoml_t(value);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_print_ptr__comp_488st_cmd_value_t(pair);
  __dyc_print_ptr__comp_488st_cmd_value_t(pair___0);
}
}
