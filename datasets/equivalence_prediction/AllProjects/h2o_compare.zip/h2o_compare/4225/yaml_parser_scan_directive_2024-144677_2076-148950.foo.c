#include "../include/dycfoo.h"
#include "../include/scanner.i.hd.c.h"
void __dyc_foo(void) 
{ yaml_mark_t start_mark ;
  yaml_mark_t end_mark ;
  yaml_char_t *name ;
  int major ;
  int minor ;
  yaml_char_t *handle ;
  yaml_char_t *prefix ;
  int tmp___8 ;
  int tmp___9 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___19 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  int tmp___37 ;
  int tmp___47 ;
  int tmp___52 ;
  int tmp___57 ;
  int tmp___62 ;
  int tmp___67 ;
  yaml_parser_t *parser ;
  yaml_token_t *token ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;

  {
  start_mark = __dyc_read_comp_43yaml_mark_s();
  name = __dyc_read_ptr__typdef_yaml_char_t();
  major = __dyc_readpre_byte();
  minor = __dyc_readpre_byte();
  handle = __dyc_read_ptr__typdef_yaml_char_t();
  prefix = __dyc_read_ptr__typdef_yaml_char_t();
  tmp___37 = __dyc_readpre_byte();
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  token = __dyc_read_ptr__typdef_yaml_token_t();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  memset(& end_mark, 0, sizeof(yaml_mark_t ));
  tmp___8 = 0;
  tmp___9 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___19 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___47 = 0;
  tmp___52 = 0;
  tmp___57 = 0;
  tmp___62 = 0;
  tmp___67 = 0;
  if (tmp___37 == 0) {
    {
    tmp___8 = __dyc_funcallvar_7;
    }
    if (! tmp___8) {
      goto __dyc_dummy_label;
    }
    {
    end_mark = parser->mark;

    token->type = 3;
    token->start_mark = start_mark;
    token->end_mark = end_mark;
    token->data.version_directive.major = major;
    token->data.version_directive.minor = minor;
    }
  } else {
    if (0) {
      {
      tmp___25 = __dyc_funcallvar_8;
      __s1_len = (unsigned long )tmp___25;
      tmp___26 = __dyc_funcallvar_9;
      __s2_len = (unsigned long )tmp___26;
      }
      if (! ((unsigned long )((void const   *)((char *)name + 1)) - (unsigned long )((void const   *)((char *)name)) == 1UL)) {
        goto _L___0;
      } else {
        if (__s1_len >= 4UL) {
          _L___0:  
          if (! ((unsigned long )((void const   *)("TAG" + 1)) - (unsigned long )((void const   *)"TAG") == 1UL)) {
            tmp___27 = 1;
          } else {
            if (__s2_len >= 4UL) {
              tmp___27 = 1;
            } else {
              tmp___27 = 0;
            }
          }
        } else {
          tmp___27 = 0;
        }
      }
      if (tmp___27) {
        {
        tmp___19 = __dyc_funcallvar_10;
        }
      } else {
        {
        tmp___24 = __dyc_funcallvar_11;
        tmp___19 = tmp___24;
        }
      }
    } else {
      {
      tmp___24 = __dyc_funcallvar_12;
      tmp___19 = tmp___24;
      }
    }
    if (tmp___19 == 0) {
      {
      tmp___9 = __dyc_funcallvar_13;
      }
      if (! tmp___9) {
        goto __dyc_dummy_label;
      }
      {
      end_mark = parser->mark;

      token->type = 4;
      token->start_mark = start_mark;
      token->end_mark = end_mark;
      token->data.tag_directive.handle = handle;
      token->data.tag_directive.prefix = prefix;
      }
    } else {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  if (parser->unread >= 1UL) {
    tmp___47 = 1;
  } else {
    {
    tmp___47 = __dyc_funcallvar_14;
    }
  }
  if (! tmp___47) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_7_continue:  ;
    if (! ((int )*(parser->buffer.pointer + 0) == 32)) {
      if (! ((int )*(parser->buffer.pointer + 0) == 9)) {
        goto while_7_break;
      }
    }
    (parser->mark.index) ++;
    (parser->mark.column) ++;
    (parser->unread) --;
    if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
      tmp___52 = 1;
    } else {
      if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
        tmp___52 = 2;
      } else {
        if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
          tmp___52 = 3;
        } else {
          if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
            tmp___52 = 4;
          } else {
            tmp___52 = 0;
          }
        }
      }
    }
    parser->buffer.pointer += tmp___52;
    if (parser->unread >= 1UL) {
      tmp___57 = 1;
    } else {
      {
      tmp___57 = __dyc_funcallvar_15;
      }
    }
    if (! tmp___57) {
      goto __dyc_dummy_label;
    }
  }
  while_7_break:  ;
  if ((int )*(parser->buffer.pointer + 0) == 35) {
    {
    while (1) {
      while_8_continue:  ;
      if ((int )*(parser->buffer.pointer + 0) == 13) {
        goto while_8_break;
      } else {
        if ((int )*(parser->buffer.pointer + 0) == 10) {
          goto while_8_break;
        } else {
          if ((int )*(parser->buffer.pointer + 0) == 194) {
            if ((int )*(parser->buffer.pointer + 1) == 133) {
              goto while_8_break;
            } else {
              goto _L___7;
            }
          } else {
            _L___7:  
            if ((int )*(parser->buffer.pointer + 0) == 226) {
              if ((int )*(parser->buffer.pointer + 1) == 128) {
                if ((int )*(parser->buffer.pointer + 2) == 168) {
                  goto while_8_break;
                } else {
                  goto _L___6;
                }
              } else {
                goto _L___6;
              }
            } else {
              _L___6:  
              if ((int )*(parser->buffer.pointer + 0) == 226) {
                if ((int )*(parser->buffer.pointer + 1) == 128) {
                  if ((int )*(parser->buffer.pointer + 2) == 169) {
                    goto while_8_break;
                  } else {
                    goto _L___4;
                  }
                } else {
                  goto _L___4;
                }
              } else {
                _L___4:  
                if ((int )*(parser->buffer.pointer + 0) == 0) {
                  goto while_8_break;
                }
              }
            }
          }
        }
      }
      (parser->mark.index) ++;
      (parser->mark.column) ++;
      (parser->unread) --;
      if (((int )*(parser->buffer.pointer + 0) & 128) == 0) {
        tmp___62 = 1;
      } else {
        if (((int )*(parser->buffer.pointer + 0) & 224) == 192) {
          tmp___62 = 2;
        } else {
          if (((int )*(parser->buffer.pointer + 0) & 240) == 224) {
            tmp___62 = 3;
          } else {
            if (((int )*(parser->buffer.pointer + 0) & 248) == 240) {
              tmp___62 = 4;
            } else {
              tmp___62 = 0;
            }
          }
        }
      }
      parser->buffer.pointer += tmp___62;
      if (parser->unread >= 1UL) {
        tmp___67 = 1;
      } else {
        {
        tmp___67 = __dyc_funcallvar_16;
        }
      }
      if (! tmp___67) {
        goto __dyc_dummy_label;
      }
    }
    while_8_break:  ;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
}
}
