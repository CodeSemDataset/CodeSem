#include "../include/dycfoo.h"
#include "../include/scanner.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp___9 ;
  int tmp___10 ;
  yaml_parser_t *parser ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;

  {
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  tmp___9 = 0;
  tmp___10 = 0;
  if (parser->mark.column == 0UL) {
    if ((int )*(parser->buffer.pointer + 0) == 45) {
      if ((int )*(parser->buffer.pointer + 1) == 45) {
        if ((int )*(parser->buffer.pointer + 2) == 45) {
          if ((int )*(parser->buffer.pointer + 3) == 32) {
            {
            tmp___9 = __dyc_funcallvar_9;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 3) == 9) {
              {
              tmp___9 = __dyc_funcallvar_10;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 3) == 13) {
                {
                tmp___9 = __dyc_funcallvar_11;
                }
                goto __dyc_dummy_label;
              } else {
                if ((int )*(parser->buffer.pointer + 3) == 10) {
                  {
                  tmp___9 = __dyc_funcallvar_12;
                  }
                  goto __dyc_dummy_label;
                } else {
                  if ((int )*(parser->buffer.pointer + 3) == 194) {
                    if ((int )*(parser->buffer.pointer + 4) == 133) {
                      {
                      tmp___9 = __dyc_funcallvar_13;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___3;
                    }
                  } else {
                    _L___3:  
                    if ((int )*(parser->buffer.pointer + 3) == 226) {
                      if ((int )*(parser->buffer.pointer + 4) == 128) {
                        if ((int )*(parser->buffer.pointer + 5) == 168) {
                          {
                          tmp___9 = __dyc_funcallvar_14;
                          }
                          goto __dyc_dummy_label;
                        } else {
                          goto _L___2;
                        }
                      } else {
                        goto _L___2;
                      }
                    } else {
                      _L___2:  
                      if ((int )*(parser->buffer.pointer + 3) == 226) {
                        if ((int )*(parser->buffer.pointer + 4) == 128) {
                          if ((int )*(parser->buffer.pointer + 5) == 169) {
                            {
                            tmp___9 = __dyc_funcallvar_15;
                            }
                            goto __dyc_dummy_label;
                          } else {
                            goto _L___0;
                          }
                        } else {
                          goto _L___0;
                        }
                      } else {
                        _L___0:  
                        if ((int )*(parser->buffer.pointer + 3) == 0) {
                          {
                          tmp___9 = __dyc_funcallvar_16;
                          }
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if (parser->mark.column == 0UL) {
    if ((int )*(parser->buffer.pointer + 0) == 46) {
      if ((int )*(parser->buffer.pointer + 1) == 46) {
        if ((int )*(parser->buffer.pointer + 2) == 46) {
          if ((int )*(parser->buffer.pointer + 3) == 32) {
            {
            tmp___10 = __dyc_funcallvar_17;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 3) == 9) {
              {
              tmp___10 = __dyc_funcallvar_18;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 3) == 13) {
                {
                tmp___10 = __dyc_funcallvar_19;
                }
                goto __dyc_dummy_label;
              } else {
                if ((int )*(parser->buffer.pointer + 3) == 10) {
                  {
                  tmp___10 = __dyc_funcallvar_20;
                  }
                  goto __dyc_dummy_label;
                } else {
                  if ((int )*(parser->buffer.pointer + 3) == 194) {
                    if ((int )*(parser->buffer.pointer + 4) == 133) {
                      {
                      tmp___10 = __dyc_funcallvar_21;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___8;
                    }
                  } else {
                    _L___8:  
                    if ((int )*(parser->buffer.pointer + 3) == 226) {
                      if ((int )*(parser->buffer.pointer + 4) == 128) {
                        if ((int )*(parser->buffer.pointer + 5) == 168) {
                          {
                          tmp___10 = __dyc_funcallvar_22;
                          }
                          goto __dyc_dummy_label;
                        } else {
                          goto _L___7;
                        }
                      } else {
                        goto _L___7;
                      }
                    } else {
                      _L___7:  
                      if ((int )*(parser->buffer.pointer + 3) == 226) {
                        if ((int )*(parser->buffer.pointer + 4) == 128) {
                          if ((int )*(parser->buffer.pointer + 5) == 169) {
                            {
                            tmp___10 = __dyc_funcallvar_23;
                            }
                            goto __dyc_dummy_label;
                          } else {
                            goto _L___5;
                          }
                        } else {
                          goto _L___5;
                        }
                      } else {
                        _L___5:  
                        if ((int )*(parser->buffer.pointer + 3) == 0) {
                          {
                          tmp___10 = __dyc_funcallvar_24;
                          }
                          goto __dyc_dummy_label;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___9);
  __dyc_printpre_byte(tmp___10);
}
}
