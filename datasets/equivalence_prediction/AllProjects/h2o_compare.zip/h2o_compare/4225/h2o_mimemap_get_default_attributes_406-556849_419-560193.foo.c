#include "../include/dycfoo.h"
#include "../include/mimemap.i.hd.c.h"
void __dyc_foo(void) 
{ char *mime ;
  h2o_mime_attributes_t __constr_expr_0 ;
  int tmp___4 ;
  int tmp___26 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___36 ;
  int tmp___41 ;
  int tmp___42 ;
  int tmp___43 ;
  int tmp___44 ;
  size_t tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  h2o_mime_attributes_t *attr ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  size_t __dyc_funcallvar_17 ;

  {
  mime = __dyc_read_ptr__char();
  __constr_expr_0 = __dyc_read_comp_424st_h2o_mime_attributes_t();
  attr = __dyc_read_ptr__typdef_h2o_mime_attributes_t();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = (size_t )__dyc_readpre_byte();
  tmp___4 = 0;
  tmp___26 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___36 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___47 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  *attr = __constr_expr_0;
  tmp___48 = __dyc_funcallvar_5;
  if (tmp___48) {
    attr->is_compressible = (char)1;
    attr->priority = 1;
  } else {
    {
    tmp___49 = __dyc_funcallvar_6;
    }
    if (tmp___49) {
      attr->is_compressible = (char)1;
      attr->priority = 1;
    } else {
      {
      tmp___50 = __dyc_funcallvar_7;
      }
      if (tmp___50) {
        attr->is_compressible = (char)1;
        attr->priority = 1;
      } else {
        {
        tmp___51 = __dyc_funcallvar_8;
        }
        if (tmp___51) {
          attr->is_compressible = (char)1;
          attr->priority = 1;
        } else {
          {
          tmp___52 = __dyc_funcallvar_9;
          }
          if (tmp___52) {
            attr->is_compressible = (char)1;
            attr->priority = 1;
          } else {
            {
            tmp___4 = __dyc_funcallvar_10;
            }
            if (tmp___4) {
              attr->is_compressible = (char)1;
            } else {
              if (0) {
                if (0) {
                  {
                  tmp___42 = __dyc_funcallvar_11;
                  __s1_len___0 = (unsigned long )tmp___42;
                  tmp___43 = __dyc_funcallvar_12;
                  __s2_len___0 = (unsigned long )tmp___43;
                  }
                  if (! ((unsigned long )((void const   *)(mime + 1)) - (unsigned long )((void const   *)mime) == 1UL)) {
                    goto _L___2;
                  } else {
                    if (__s1_len___0 >= 4UL) {
                      _L___2:  
                      if (! ((unsigned long )((void const   *)("text/" + 1)) - (unsigned long )((void const   *)"text/") == 1UL)) {
                        tmp___44 = 1;
                      } else {
                        if (__s2_len___0 >= 4UL) {
                          tmp___44 = 1;
                        } else {
                          tmp___44 = 0;
                        }
                      }
                    } else {
                      tmp___44 = 0;
                    }
                  }
                  if (tmp___44) {
                    {
                    tmp___36 = __dyc_funcallvar_13;
                    }
                  } else {
                    {
                    tmp___41 = __dyc_funcallvar_14;
                    tmp___36 = tmp___41;
                    }
                  }
                } else {
                  {
                  tmp___41 = __dyc_funcallvar_15;
                  tmp___36 = tmp___41;
                  }
                }
                tmp___26 = tmp___36;
              } else {
                {
                tmp___26 = __dyc_funcallvar_16;
                }
              }
              if (tmp___26 == 0) {
                attr->is_compressible = (char)1;
              } else {
                {
                tmp___47 = __dyc_funcallvar_17;
                }
                if (tmp___47 != 0xffffffffUL) {
                  attr->is_compressible = (char)1;
                }
              }
            }
          }
        }
      }
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
}
}
