#include "../include/dycfoo.h"
#include "../include/scanner.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp___16 ;
  int tmp___17 ;
  yaml_parser_t *parser ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;

  {
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  tmp___16 = 0;
  tmp___17 = 0;
  if ((int )*(parser->buffer.pointer + 0) == 45) {
    if ((int )*(parser->buffer.pointer + 1) == 32) {
      {
      tmp___16 = __dyc_funcallvar_30;
      }
      goto __dyc_dummy_label;
    } else {
      if ((int )*(parser->buffer.pointer + 1) == 9) {
        {
        tmp___16 = __dyc_funcallvar_31;
        }
        goto __dyc_dummy_label;
      } else {
        if ((int )*(parser->buffer.pointer + 1) == 13) {
          {
          tmp___16 = __dyc_funcallvar_32;
          }
          goto __dyc_dummy_label;
        } else {
          if ((int )*(parser->buffer.pointer + 1) == 10) {
            {
            tmp___16 = __dyc_funcallvar_33;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 1) == 194) {
              if ((int )*(parser->buffer.pointer + 2) == 133) {
                {
                tmp___16 = __dyc_funcallvar_34;
                }
                goto __dyc_dummy_label;
              } else {
                goto _L___13;
              }
            } else {
              _L___13:  
              if ((int )*(parser->buffer.pointer + 1) == 226) {
                if ((int )*(parser->buffer.pointer + 2) == 128) {
                  if ((int )*(parser->buffer.pointer + 3) == 168) {
                    {
                    tmp___16 = __dyc_funcallvar_35;
                    }
                    goto __dyc_dummy_label;
                  } else {
                    goto _L___12;
                  }
                } else {
                  goto _L___12;
                }
              } else {
                _L___12:  
                if ((int )*(parser->buffer.pointer + 1) == 226) {
                  if ((int )*(parser->buffer.pointer + 2) == 128) {
                    if ((int )*(parser->buffer.pointer + 3) == 169) {
                      {
                      tmp___16 = __dyc_funcallvar_36;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___10;
                    }
                  } else {
                    goto _L___10;
                  }
                } else {
                  _L___10:  
                  if ((int )*(parser->buffer.pointer + 1) == 0) {
                    {
                    tmp___16 = __dyc_funcallvar_37;
                    }
                    goto __dyc_dummy_label;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ((int )*(parser->buffer.pointer + 0) == 63) {
    if (parser->flow_level) {
      {
      tmp___17 = __dyc_funcallvar_38;
      }
      goto __dyc_dummy_label;
    } else {
      if ((int )*(parser->buffer.pointer + 1) == 32) {
        {
        tmp___17 = __dyc_funcallvar_39;
        }
        goto __dyc_dummy_label;
      } else {
        if ((int )*(parser->buffer.pointer + 1) == 9) {
          {
          tmp___17 = __dyc_funcallvar_40;
          }
          goto __dyc_dummy_label;
        } else {
          if ((int )*(parser->buffer.pointer + 1) == 13) {
            {
            tmp___17 = __dyc_funcallvar_41;
            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*(parser->buffer.pointer + 1) == 10) {
              {
              tmp___17 = __dyc_funcallvar_42;
              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*(parser->buffer.pointer + 1) == 194) {
                if ((int )*(parser->buffer.pointer + 2) == 133) {
                  {
                  tmp___17 = __dyc_funcallvar_43;
                  }
                  goto __dyc_dummy_label;
                } else {
                  goto _L___18;
                }
              } else {
                _L___18:  
                if ((int )*(parser->buffer.pointer + 1) == 226) {
                  if ((int )*(parser->buffer.pointer + 2) == 128) {
                    if ((int )*(parser->buffer.pointer + 3) == 168) {
                      {
                      tmp___17 = __dyc_funcallvar_44;
                      }
                      goto __dyc_dummy_label;
                    } else {
                      goto _L___17;
                    }
                  } else {
                    goto _L___17;
                  }
                } else {
                  _L___17:  
                  if ((int )*(parser->buffer.pointer + 1) == 226) {
                    if ((int )*(parser->buffer.pointer + 2) == 128) {
                      if ((int )*(parser->buffer.pointer + 3) == 169) {
                        {
                        tmp___17 = __dyc_funcallvar_45;
                        }
                        goto __dyc_dummy_label;
                      } else {
                        goto _L___15;
                      }
                    } else {
                      goto _L___15;
                    }
                  } else {
                    _L___15:  
                    if ((int )*(parser->buffer.pointer + 1) == 0) {
                      {
                      tmp___17 = __dyc_funcallvar_46;
                      }
                      goto __dyc_dummy_label;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___16);
  __dyc_printpre_byte(tmp___17);
}
}
