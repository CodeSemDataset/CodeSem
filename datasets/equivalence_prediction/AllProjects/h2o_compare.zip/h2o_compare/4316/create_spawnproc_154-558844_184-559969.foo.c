#include "../include/dycfoo.h"
#include "../include/fastcgi.i.hd.c.h"
void __dyc_foo(void) 
{ int ret ;
  int listen_fd ;
  int pipe_fds[2] ;
  int *tmp ;
  char *tmp___0 ;
  int *tmp___1 ;
  char *tmp___2 ;
  int tmp___3 ;
  int *tmp___4 ;
  char *tmp___5 ;
  int tmp___6 ;
  int *tmp___7 ;
  char *tmp___8 ;
  int tmp___9 ;
  int *tmp___10 ;
  char *tmp___11 ;
  int tmp___12 ;
  struct sockaddr_un *sa ;
  struct passwd *pw ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int *__dyc_funcallvar_6 ;
  char *__dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int *__dyc_funcallvar_9 ;
  char *__dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int *__dyc_funcallvar_12 ;
  char *__dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int *__dyc_funcallvar_15 ;
  char *__dyc_funcallvar_16 ;

  {
  sa = __dyc_read_ptr__comp_39sockaddr_un();
  pw = __dyc_read_ptr__comp_67passwd();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_7 = __dyc_read_ptr__char();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_13 = __dyc_read_ptr__char();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_16 = __dyc_read_ptr__char();
  ret = 0;
  listen_fd = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  pipe_fds[1] = -1;
  sa->sun_family = (unsigned short)1;
  ret = __dyc_funcallvar_1;
  if (ret < 0) {
    {

    }
    goto __dyc_dummy_label;
  } else {
    if ((unsigned long )ret >= sizeof(char [108])) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  listen_fd = __dyc_funcallvar_2;
  if (listen_fd == -1) {
    {
    tmp = __dyc_funcallvar_3;
    tmp___0 = __dyc_funcallvar_4;

    }
    goto __dyc_dummy_label;
  }
  tmp___3 = __dyc_funcallvar_5;
  if (tmp___3 != 0) {
    {
    tmp___1 = __dyc_funcallvar_6;
    tmp___2 = __dyc_funcallvar_7;

    }
    goto __dyc_dummy_label;
  }
  tmp___6 = __dyc_funcallvar_8;
  if (tmp___6 != 0) {
    {
    tmp___4 = __dyc_funcallvar_9;
    tmp___5 = __dyc_funcallvar_10;

    }
    goto __dyc_dummy_label;
  }
  if ((unsigned long )pw != (unsigned long )((void *)0)) {
    {
    tmp___9 = __dyc_funcallvar_11;
    }
    if (tmp___9 != 0) {
      {
      tmp___7 = __dyc_funcallvar_12;
      tmp___8 = __dyc_funcallvar_13;

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___12 = __dyc_funcallvar_14;
  if (tmp___12 != 0) {
    {
    tmp___10 = __dyc_funcallvar_15;
    tmp___11 = __dyc_funcallvar_16;

    pipe_fds[0] = -1;
    pipe_fds[1] = -1;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__int(tmp);
  __dyc_print_ptr__char(tmp___0);
  __dyc_print_ptr__int(tmp___1);
  __dyc_print_ptr__char(tmp___2);
  __dyc_print_ptr__int(tmp___4);
  __dyc_print_ptr__char(tmp___5);
  __dyc_print_ptr__int(tmp___7);
  __dyc_print_ptr__char(tmp___8);
  __dyc_print_ptr__int(tmp___10);
  __dyc_print_ptr__char(tmp___11);
}
}
