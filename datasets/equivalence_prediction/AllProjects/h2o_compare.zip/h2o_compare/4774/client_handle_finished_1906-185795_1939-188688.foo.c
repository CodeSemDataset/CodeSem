#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ int ret ;
  ptls_iovec_t tmp ;
  size_t rec_start ;
  uint8_t __constr_expr_1[3] ;
  size_t capacity ;
  size_t body_start ;
  size_t mess_start ;
  uint8_t __constr_expr_3[1] ;
  size_t capacity___0 ;
  size_t body_start___0 ;
  size_t body_size ;
  size_t body_size___0 ;
  ptls_t *tls ;
  ptls_buffer_t *sendbuf ;
  ptls_iovec_t __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;

  {
  ret = __dyc_readpre_byte();
  tls = __dyc_read_ptr__typdef_ptls_t();
  sendbuf = __dyc_read_ptr__typdef_ptls_buffer_t();
  __dyc_funcallvar_2 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  memset(& tmp, 0, sizeof(ptls_iovec_t ));
  rec_start = 0;
  capacity = 0;
  body_start = 0;
  mess_start = 0;
  capacity___0 = 0;
  body_start___0 = 0;
  body_size = 0;
  body_size___0 = 0;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }

  tmp = __dyc_funcallvar_2;
  ret = __dyc_funcallvar_3;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  ret = __dyc_funcallvar_4;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  ret = __dyc_funcallvar_5;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  ret = __dyc_funcallvar_6;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  if ((unsigned long )tls->early_data != (unsigned long )((void *)0)) {
    if (! ((unsigned long )tls->traffic_protection.enc.aead != (unsigned long )((void *)0))) {
      {

      }
    }
    if (! tls->skip_early_data) {
      {
      while (1) {
        while_489_continue:  ;
        rec_start = sendbuf->off;
        {
        while (1) {
          while_490_continue:  ;
          {
          while (1) {
            while_491_continue:  ;
            {
            __constr_expr_1[0] = (uint8_t )22;
            __constr_expr_1[1] = (uint8_t )3;
            __constr_expr_1[2] = (uint8_t )3;
            ret = __dyc_funcallvar_7;
            }
            if (ret != 0) {
              goto __dyc_dummy_label;
            }
            goto while_491_break;
          }
          while_491_break:  ;
          }
          {
          while (1) {
            while_492_continue:  ;
            capacity = (size_t )2;
            {
            while (1) {
              while_493_continue:  ;
              {
              ret = __dyc_funcallvar_8;
              }
              if (ret != 0) {
                goto __dyc_dummy_label;
              }
              goto while_493_break;
            }
            while_493_break:  ;
            }
            body_start = sendbuf->off;
            {
            while (1) {
              while_494_continue:  ;
              {
              while (1) {
                while_495_continue:  ;
                mess_start = sendbuf->off;
                {
                while (1) {
                  while_496_continue:  ;
                  {
                  __constr_expr_3[0] = (uint8_t )5;
                  ret = __dyc_funcallvar_9;
                  }
                  if (ret != 0) {
                    goto __dyc_dummy_label;
                  }
                  goto while_496_break;
                }
                while_496_break:  ;
                }
                {
                while (1) {
                  while_497_continue:  ;
                  capacity___0 = (size_t )3;
                  {
                  while (1) {
                    while_498_continue:  ;
                    {
                    ret = __dyc_funcallvar_10;
                    }
                    if (ret != 0) {
                      goto __dyc_dummy_label;
                    }
                    goto while_498_break;
                  }
                  while_498_break:  ;
                  }
                  body_start___0 = sendbuf->off;
                  {
                  while (1) {
                    while_499_continue:  ;
                    {
                    while (1) {
                      while_500_continue:  ;
                      goto while_500_break;
                    }
                    while_500_break:  ;
                    }
                    goto while_499_break;
                  }
                  while_499_break:  ;
                  }
                  body_size = sendbuf->off - body_start___0;
                  {
                  while (1) {
                    while_501_continue:  ;
                    if (! (capacity___0 != 0UL)) {
                      goto while_501_break;
                    }
                    *(sendbuf->base + (body_start___0 - capacity___0)) = (unsigned char )(body_size >> 8UL * (capacity___0 - 1UL));
                    capacity___0 --;
                  }
                  while_501_break:  ;
                  }
                  goto while_497_break;
                }
                while_497_break:  ;
                }
                if ((unsigned long )tls->key_schedule != (unsigned long )((void *)0)) {
                  {

                  }
                }
                goto while_495_break;
              }
              while_495_break:  ;
              }
              goto while_494_break;
            }
            while_494_break:  ;
            }
            body_size___0 = sendbuf->off - body_start;
            {
            while (1) {
              while_502_continue:  ;
              if (! (capacity != 0UL)) {
                goto while_502_break;
              }
              *(sendbuf->base + (body_start - capacity)) = (unsigned char )(body_size___0 >> 8UL * (capacity - 1UL));
              capacity --;
            }
            while_502_break:  ;
            }
            goto while_492_break;
          }
          while_492_break:  ;
          }
          goto while_490_break;
        }
        while_490_break:  ;
        }
        if ((unsigned long )(& tls->traffic_protection.enc) != (unsigned long )((void *)0)) {
          {
          ret = __dyc_funcallvar_11;
          }
          if (ret != 0) {
            goto __dyc_dummy_label;
          }
        }
        goto while_489_break;
      }
      while_489_break:  ;
      }
    }
    {
    ret = __dyc_funcallvar_12;
    }
    if (ret != 0) {
      goto __dyc_dummy_label;
    }
  }
  ret = __dyc_funcallvar_13;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  ret = __dyc_funcallvar_14;

  ret = __dyc_funcallvar_15;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  tls->state = 11;
  __dyc_dummy_label:  ;
  __dyc_print_comp_46st_ptls_iovec_t(tmp);
  __dyc_printpre_byte(rec_start);
  __dyc_printpre_byte(capacity);
  __dyc_printpre_byte(body_start);
  __dyc_printpre_byte(mess_start);
  __dyc_printpre_byte(capacity___0);
  __dyc_printpre_byte(body_size);
  __dyc_printpre_byte(body_size___0);
}
}
