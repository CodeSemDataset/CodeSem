#include "../include/dycfoo.h"
#include "../include/neverbleed.i.hd.c.h"
void __dyc_foo(void) 
{ struct __anonstruct_daemon_vars_66 daemon_vars ;
  RSA_METHOD static_rsa_method ;
  int pipe_fds[2] ;
  int listen_fd ;
  char *tempdir ;
  RSA_METHOD const   *default_method ;
  RSA_METHOD const   *tmp ;
  RSA_METHOD *rsa_method ;
  int *tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  char *tmp___12 ;
  int *tmp___13 ;
  char *tmp___14 ;
  char *tmp___15 ;
  int *tmp___16 ;
  char *tmp___17 ;
  int *tmp___18 ;
  char *tmp___19 ;
  int tmp___20 ;
  int *tmp___21 ;
  char *tmp___22 ;
  int tmp___23 ;
  int *tmp___24 ;
  char *tmp___25 ;
  neverbleed_t *nb ;
  RSA_METHOD const   *__dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  char *__dyc_funcallvar_5 ;
  char *__dyc_funcallvar_6 ;
  int *__dyc_funcallvar_7 ;
  char *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int *__dyc_funcallvar_10 ;
  char *__dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int *__dyc_funcallvar_13 ;
  char *__dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int *__dyc_funcallvar_16 ;
  char *__dyc_funcallvar_17 ;
  __pid_t __dyc_funcallvar_18 ;
  int *__dyc_funcallvar_19 ;
  char *__dyc_funcallvar_20 ;

  {
  static_rsa_method = __dyc_read_comp_111rsa_meth_st();
  nb = __dyc_read_ptr__typdef_neverbleed_t();
  __dyc_funcallvar_1 = (RSA_METHOD const   *)__dyc_read_ptr__typdef_RSA_METHOD();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  __dyc_funcallvar_5 = __dyc_read_ptr__char();
  __dyc_funcallvar_6 = __dyc_read_ptr__char();
  __dyc_funcallvar_7 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_8 = __dyc_read_ptr__char();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_11 = __dyc_read_ptr__char();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_14 = __dyc_read_ptr__char();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_17 = __dyc_read_ptr__char();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = (int *)__dyc_read_ptr__int();
  __dyc_funcallvar_20 = __dyc_read_ptr__char();
  memset(& daemon_vars, 0, sizeof(struct __anonstruct_daemon_vars_66 ));
  listen_fd = 0;
  tempdir = 0;
  default_method = 0;
  tmp = 0;
  rsa_method = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tempdir = (char *)((void *)0);
  tmp = __dyc_funcallvar_1;
  default_method = tmp;
  rsa_method = & static_rsa_method;
  rsa_method->rsa_pub_enc = (int (*)(int flen , unsigned char const   *from ,
                                     unsigned char *to , RSA *rsa , int padding ))default_method->rsa_pub_enc;
  rsa_method->rsa_pub_dec = (int (*)(int flen , unsigned char const   *from ,
                                     unsigned char *to , RSA *rsa , int padding ))default_method->rsa_pub_dec;
  rsa_method->rsa_verify = (int (*)(int dtype , unsigned char const   *m ,
                                    unsigned int m_length ,
                                    unsigned char const   *sigbuf ,
                                    unsigned int siglen , RSA const   *rsa ))default_method->rsa_verify;
  tmp___2 = __dyc_funcallvar_2;
  if (tmp___2 != 0) {
    {
    tmp___0 = __dyc_funcallvar_3;
    tmp___1 = __dyc_funcallvar_4;

    }
    goto __dyc_dummy_label;
  }

  tmp___12 = __dyc_funcallvar_5;
  tempdir = tmp___12;
  if ((unsigned long )tempdir == (unsigned long )((void *)0)) {
    {

    }
    goto __dyc_dummy_label;
  }
  tmp___15 = __dyc_funcallvar_6;
  if ((unsigned long )tmp___15 == (unsigned long )((void *)0)) {
    {
    tmp___13 = __dyc_funcallvar_7;
    tmp___14 = __dyc_funcallvar_8;

    }
    goto __dyc_dummy_label;
  }

  nb->sun_.sun_family = (unsigned short)1;


  listen_fd = __dyc_funcallvar_9;
  if (listen_fd == -1) {
    {
    tmp___16 = __dyc_funcallvar_10;
    tmp___17 = __dyc_funcallvar_11;

    }
    goto __dyc_dummy_label;
  }
  tmp___20 = __dyc_funcallvar_12;
  if (tmp___20 != 0) {
    {
    tmp___18 = __dyc_funcallvar_13;
    tmp___19 = __dyc_funcallvar_14;

    }
    goto __dyc_dummy_label;
  }
  tmp___23 = __dyc_funcallvar_15;
  if (tmp___23 != 0) {
    {
    tmp___21 = __dyc_funcallvar_16;
    tmp___22 = __dyc_funcallvar_17;

    }
    goto __dyc_dummy_label;
  }
  nb->daemon_pid = __dyc_funcallvar_18;
  if (nb->daemon_pid == -1) {
    goto switch_17_neg_1;
  } else {
    if (nb->daemon_pid == 0) {
      goto switch_17_0;
    } else {
      {
      goto switch_17_default;
      if (0) {
        switch_17_neg_1:  
        {
        tmp___24 = __dyc_funcallvar_19;
        tmp___25 = __dyc_funcallvar_20;

        }
        goto __dyc_dummy_label;
        switch_17_0:  
        {


        daemon_vars.nb = nb;

        }
        goto switch_17_break;
        switch_17_default:  ;
        goto switch_17_break;
      } else {
        switch_17_break:  ;
      }
      }
    }
  }

  listen_fd = -1;

  pipe_fds[0] = -1;
  __dyc_dummy_label:  ;
  __dyc_print_comp_329__anonstruct_daemon_vars_66(daemon_vars);
  __dyc_printpre_byte(listen_fd);
  __dyc_print_ptr__char(tempdir);
  __dyc_print_ptr__int(tmp___0);
  __dyc_print_ptr__char(tmp___1);
  __dyc_print_ptr__int(tmp___13);
  __dyc_print_ptr__char(tmp___14);
  __dyc_print_ptr__int(tmp___16);
  __dyc_print_ptr__char(tmp___17);
  __dyc_print_ptr__int(tmp___18);
  __dyc_print_ptr__char(tmp___19);
  __dyc_print_ptr__int(tmp___21);
  __dyc_print_ptr__char(tmp___22);
  __dyc_print_ptr__int(tmp___24);
  __dyc_print_ptr__char(tmp___25);
}
}
