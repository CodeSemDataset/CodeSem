#include "../include/dycfoo.h"
#include "../include/reader.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int value ;
  unsigned int value2 ;
  int incomplete ;
  unsigned char octet ;
  unsigned int width ;
  int low ;
  int high ;
  size_t k ;
  size_t raw_unread ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  yaml_parser_t *parser ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;

  {
  octet = (unsigned char )__dyc_readpre_byte();
  raw_unread = (size_t )__dyc_readpre_byte();
  parser = __dyc_read_ptr__typdef_yaml_parser_t();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  value = 0;
  value2 = 0;
  incomplete = 0;
  width = 0;
  low = 0;
  high = 0;
  k = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  if (((int )octet & 128) == 0) {
    width = 1U;
  } else {
    if (((int )octet & 224) == 192) {
      width = 2U;
    } else {
      if (((int )octet & 240) == 224) {
        width = 3U;
      } else {
        if (((int )octet & 248) == 240) {
          width = 4U;
        } else {
          width = 0U;
        }
      }
    }
  }
  if (! width) {
    {
    tmp___8 = __dyc_funcallvar_3;
    }
    goto __dyc_dummy_label;
  }
  if ((size_t )width > raw_unread) {
    if (parser->eof) {
      {
      tmp___9 = __dyc_funcallvar_4;
      }
      goto __dyc_dummy_label;
    }
    incomplete = 1;
    goto __dyc_dummy_label;
  }
  if (((int )octet & 128) == 0) {
    value = (unsigned int )((int )octet & 127);
  } else {
    if (((int )octet & 224) == 192) {
      value = (unsigned int )((int )octet & 31);
    } else {
      if (((int )octet & 240) == 224) {
        value = (unsigned int )((int )octet & 15);
      } else {
        if (((int )octet & 248) == 240) {
          value = (unsigned int )((int )octet & 7);
        } else {
          value = 0U;
        }
      }
    }
  }
  k = 1UL;
  while (1) {
    while_4_continue:  ;
    if (! (k < (size_t )width)) {
      goto while_4_break;
    }
    octet = *(parser->raw_buffer.pointer + k);
    if (((int )octet & 192) != 128) {
      {
      tmp___17 = __dyc_funcallvar_5;
      }
      goto __dyc_dummy_label;
    }
    value = (value << 6) + (unsigned int )((int )octet & 63);
    k ++;
  }
  while_4_break:  ;
  if (! (width == 1U)) {
    if (width == 2U) {
      if (! (value >= 128U)) {
        goto _L___2;
      }
    } else {
      _L___2:  
      if (width == 3U) {
        if (! (value >= 2048U)) {
          goto _L___1;
        }
      } else {
        _L___1:  
        if (width == 4U) {
          if (! (value >= 65536U)) {
            {
            tmp___18 = __dyc_funcallvar_6;
            }
            goto __dyc_dummy_label;
          }
        } else {
          {
          tmp___18 = __dyc_funcallvar_7;
          }
          goto __dyc_dummy_label;
        }
      }
    }
  }
  if (value >= 55296U) {
    if (value <= 57343U) {
      {
      tmp___19 = __dyc_funcallvar_8;
      }
      goto __dyc_dummy_label;
    } else {
      goto _L___3;
    }
  } else {
    _L___3:  
    if (value > 1114111U) {
      {
      tmp___19 = __dyc_funcallvar_9;
      }
      goto __dyc_dummy_label;
    }
  }
  goto __dyc_dummy_label;
  switch_3_2:  
  switch_3_3:  
  if ((int )parser->encoding == 2) {
    low = 0;
  } else {
    low = 1;
  }
  if ((int )parser->encoding == 2) {
    high = 1;
  } else {
    high = 0;
  }
  if (raw_unread < 2UL) {
    if (parser->eof) {
      {
      tmp___20 = __dyc_funcallvar_10;
      }
      goto __dyc_dummy_label;
    }
    incomplete = 1;
    goto __dyc_dummy_label;
  }
  value = (unsigned int )((int )*(parser->raw_buffer.pointer + low) + ((int )*(parser->raw_buffer.pointer + high) << 8));
  if ((value & 64512U) == 56320U) {
    {
    tmp___21 = __dyc_funcallvar_11;
    }
    goto __dyc_dummy_label;
  }
  if ((value & 64512U) == 55296U) {
    width = 4U;
    if (raw_unread < 4UL) {
      if (parser->eof) {
        {
        tmp___22 = __dyc_funcallvar_12;
        }
        goto __dyc_dummy_label;
      }
      incomplete = 1;
      goto __dyc_dummy_label;
    }
    value2 = (unsigned int )((int )*(parser->raw_buffer.pointer + (low + 2)) + ((int )*(parser->raw_buffer.pointer + (high + 2)) << 8));
    if ((value2 & 64512U) != 56320U) {
      {
      tmp___23 = __dyc_funcallvar_13;
      }
      goto __dyc_dummy_label;
    }
    value = (65536U + ((value & 1023U) << 10)) + (value2 & 1023U);
  } else {
    width = 2U;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(value);
  __dyc_printpre_byte(incomplete);
  __dyc_printpre_byte(width);
  __dyc_printpre_byte(low);
  __dyc_printpre_byte(high);
  __dyc_printpre_byte(tmp___8);
  __dyc_printpre_byte(tmp___9);
  __dyc_printpre_byte(tmp___17);
  __dyc_printpre_byte(tmp___18);
  __dyc_printpre_byte(tmp___19);
  __dyc_printpre_byte(tmp___20);
  __dyc_printpre_byte(tmp___21);
  __dyc_printpre_byte(tmp___22);
  __dyc_printpre_byte(tmp___23);
}
}
