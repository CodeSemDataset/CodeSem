#include "../include/dycfoo.h"
#include "../include/emitter.i.hd.c.h"
void __dyc_foo(void) 
{ yaml_string_t string ;
  int spaces ;
  int tmp ;
  unsigned char octet ;
  unsigned int width ;
  unsigned int value___0 ;
  int k ;
  int tmp___14 ;
  yaml_char_t *tmp___15 ;
  int tmp___16 ;
  yaml_char_t *tmp___17 ;
  int tmp___18 ;
  yaml_char_t *tmp___19 ;
  int tmp___20 ;
  yaml_char_t *tmp___21 ;
  int tmp___22 ;
  yaml_char_t *tmp___23 ;
  int tmp___24 ;
  yaml_char_t *tmp___25 ;
  int tmp___26 ;
  yaml_char_t *tmp___27 ;
  int tmp___28 ;
  yaml_char_t *tmp___29 ;
  int tmp___30 ;
  yaml_char_t *tmp___31 ;
  int tmp___32 ;
  yaml_char_t *tmp___33 ;
  int tmp___34 ;
  yaml_char_t *tmp___35 ;
  int tmp___36 ;
  yaml_char_t *tmp___37 ;
  int tmp___38 ;
  yaml_char_t *tmp___39 ;
  int tmp___40 ;
  yaml_char_t *tmp___41 ;
  int tmp___42 ;
  yaml_char_t *tmp___43 ;
  int tmp___44 ;
  yaml_char_t *tmp___45 ;
  int tmp___46 ;
  yaml_char_t *tmp___47 ;
  int tmp___48 ;
  yaml_char_t *tmp___49 ;
  int tmp___50 ;
  yaml_char_t *tmp___51 ;
  int digit ;
  int tmp___52 ;
  yaml_char_t *tmp___53 ;
  int tmp___54 ;
  int tmp___55 ;
  int tmp___56 ;
  yaml_char_t *tmp___57 ;
  int tmp___62 ;
  int tmp___66 ;
  yaml_char_t *tmp___67 ;
  yaml_char_t *tmp___68 ;
  yaml_char_t *tmp___69 ;
  yaml_char_t *tmp___70 ;
  yaml_char_t *tmp___71 ;
  yaml_char_t *tmp___72 ;
  yaml_char_t *tmp___73 ;
  yaml_char_t *tmp___74 ;
  yaml_char_t *tmp___75 ;
  yaml_char_t *tmp___76 ;
  yaml_char_t *tmp___77 ;
  yaml_char_t *tmp___78 ;
  yaml_char_t *tmp___79 ;
  yaml_char_t *tmp___80 ;
  yaml_char_t *tmp___81 ;
  yaml_char_t *tmp___82 ;
  yaml_char_t *tmp___83 ;
  yaml_char_t *tmp___84 ;
  yaml_char_t *tmp___85 ;
  yaml_char_t *tmp___86 ;
  int tmp___87 ;
  yaml_char_t *tmp___88 ;
  yaml_char_t *tmp___89 ;
  yaml_char_t *tmp___90 ;
  yaml_char_t *tmp___91 ;
  yaml_char_t *tmp___92 ;
  yaml_char_t *tmp___93 ;
  yaml_char_t *tmp___94 ;
  yaml_char_t *tmp___95 ;
  yaml_char_t *tmp___96 ;
  yaml_char_t *tmp___97 ;
  yaml_char_t *tmp___98 ;
  yaml_char_t *tmp___99 ;
  yaml_char_t *tmp___100 ;
  yaml_char_t *tmp___101 ;
  yaml_char_t *tmp___102 ;
  yaml_char_t *tmp___103 ;
  yaml_char_t *tmp___104 ;
  yaml_char_t *tmp___105 ;
  yaml_char_t *tmp___106 ;
  yaml_char_t *tmp___107 ;
  int tmp___108 ;
  yaml_emitter_t *emitter ;
  yaml_char_t *value ;
  int allow_breaks ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;

  {
  spaces = __dyc_readpre_byte();
  emitter = __dyc_read_ptr__typdef_yaml_emitter_t();
  value = __dyc_read_ptr__typdef_yaml_char_t();
  allow_breaks = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  memset(& string, 0, sizeof(yaml_string_t ));
  tmp = 0;
  octet = 0;
  width = 0;
  value___0 = 0;
  k = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  tmp___21 = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  tmp___36 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  tmp___46 = 0;
  tmp___47 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  digit = 0;
  tmp___52 = 0;
  tmp___53 = 0;
  tmp___54 = 0;
  tmp___55 = 0;
  tmp___56 = 0;
  tmp___57 = 0;
  tmp___62 = 0;
  tmp___66 = 0;
  tmp___67 = 0;
  tmp___68 = 0;
  tmp___69 = 0;
  tmp___70 = 0;
  tmp___71 = 0;
  tmp___72 = 0;
  tmp___73 = 0;
  tmp___74 = 0;
  tmp___75 = 0;
  tmp___76 = 0;
  tmp___77 = 0;
  tmp___78 = 0;
  tmp___79 = 0;
  tmp___80 = 0;
  tmp___81 = 0;
  tmp___82 = 0;
  tmp___83 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  tmp___88 = 0;
  tmp___89 = 0;
  tmp___90 = 0;
  tmp___91 = 0;
  tmp___92 = 0;
  tmp___93 = 0;
  tmp___94 = 0;
  tmp___95 = 0;
  tmp___96 = 0;
  tmp___97 = 0;
  tmp___98 = 0;
  tmp___99 = 0;
  tmp___100 = 0;
  tmp___101 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  tmp___106 = 0;
  tmp___107 = 0;
  tmp___108 = 0;
  string.pointer = value;
  tmp = __dyc_funcallvar_1;
  if (! tmp) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_26_continue:  ;
    if (! ((unsigned long )string.pointer != (unsigned long )string.end)) {
      goto while_26_break;
    }
    if ((int )*(string.pointer + 0) == 10) {
      goto _L___16;
    } else {
      if ((int )*(string.pointer + 0) >= 32) {
        if ((int )*(string.pointer + 0) <= 126) {
          goto _L___16;
        } else {
          goto _L___21;
        }
      } else {
        _L___21:  
        if ((int )*(string.pointer + 0) == 194) {
          if ((int )*(string.pointer + 1) >= 160) {
            goto _L___16;
          } else {
            goto _L___20;
          }
        } else {
          _L___20:  
          if ((int )*(string.pointer + 0) > 194) {
            if ((int )*(string.pointer + 0) < 237) {
              goto _L___16;
            } else {
              goto _L___19;
            }
          } else {
            _L___19:  
            if ((int )*(string.pointer + 0) == 237) {
              if ((int )*(string.pointer + 1) < 160) {
                goto _L___16;
              } else {
                goto _L___18;
              }
            } else {
              _L___18:  
              if ((int )*(string.pointer + 0) == 238) {
                goto _L___16;
              } else {
                if ((int )*(string.pointer + 0) == 239) {
                  if ((int )*(string.pointer + 1) == 187) {
                    if ((int )*(string.pointer + 2) == 191) {
                      goto _L___6;
                    } else {
                      goto _L___17;
                    }
                  } else {
                    _L___17:  
                    if ((int )*(string.pointer + 1) == 191) {
                      if ((int )*(string.pointer + 2) == 190) {
                        goto _L___6;
                      } else {
                        if ((int )*(string.pointer + 2) == 191) {
                          goto _L___6;
                        } else {
                          goto _L___16;
                        }
                      }
                    } else {
                      _L___16:  
                      if (! emitter->unicode) {
                        if (! ((int )*(string.pointer + 0) <= 127)) {
                          goto _L___6;
                        } else {
                          goto _L___14;
                        }
                      } else {
                        _L___14:  
                        if ((int )*(string.pointer + 0) == 239) {
                          if ((int )*(string.pointer + 1) == 187) {
                            if ((int )*(string.pointer + 2) == 191) {
                              goto _L___6;
                            } else {
                              goto _L___13;
                            }
                          } else {
                            goto _L___13;
                          }
                        } else {
                          _L___13:  
                          if ((int )*(string.pointer + 0) == 13) {
                            goto _L___6;
                          } else {
                            if ((int )*(string.pointer + 0) == 10) {
                              goto _L___6;
                            } else {
                              if ((int )*(string.pointer + 0) == 194) {
                                if ((int )*(string.pointer + 1) == 133) {
                                  goto _L___6;
                                } else {
                                  goto _L___11;
                                }
                              } else {
                                _L___11:  
                                if ((int )*(string.pointer + 0) == 226) {
                                  if ((int )*(string.pointer + 1) == 128) {
                                    if ((int )*(string.pointer + 2) == 168) {
                                      goto _L___6;
                                    } else {
                                      goto _L___10;
                                    }
                                  } else {
                                    goto _L___10;
                                  }
                                } else {
                                  _L___10:  
                                  if ((int )*(string.pointer + 0) == 226) {
                                    if ((int )*(string.pointer + 1) == 128) {
                                      if ((int )*(string.pointer + 2) == 169) {
                                        goto _L___6;
                                      } else {
                                        goto _L___8;
                                      }
                                    } else {
                                      goto _L___8;
                                    }
                                  } else {
                                    _L___8:  
                                    if ((int )*(string.pointer + 0) == 34) {
                                      goto _L___6;
                                    } else {
                                      if ((int )*(string.pointer + 0) == 92) {
                                        _L___6:  
                                        octet = *(string.pointer + 0);
                                        if (((int )octet & 128) == 0) {
                                          width = 1U;
                                        } else {
                                          if (((int )octet & 224) == 192) {
                                            width = 2U;
                                          } else {
                                            if (((int )octet & 240) == 224) {
                                              width = 3U;
                                            } else {
                                              if (((int )octet & 248) == 240) {
                                                width = 4U;
                                              } else {
                                                width = 0U;
                                              }
                                            }
                                          }
                                        }
                                        if (((int )octet & 128) == 0) {
                                          value___0 = (unsigned int )((int )octet & 127);
                                        } else {
                                          if (((int )octet & 224) == 192) {
                                            value___0 = (unsigned int )((int )octet & 31);
                                          } else {
                                            if (((int )octet & 240) == 224) {
                                              value___0 = (unsigned int )((int )octet & 15);
                                            } else {
                                              if (((int )octet & 248) == 240) {
                                                value___0 = (unsigned int )((int )octet & 7);
                                              } else {
                                                value___0 = 0U;
                                              }
                                            }
                                          }
                                        }
                                        k = 1;
                                        {
                                        while (1) {
                                          while_27_continue:  ;
                                          if (! (k < (int )width)) {
                                            goto while_27_break;
                                          }
                                          octet = *(string.pointer + k);
                                          value___0 = (value___0 << 6) + (unsigned int )((int )octet & 63);
                                          k ++;
                                        }
                                        while_27_break:  ;
                                        }
                                        string.pointer += width;
                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                          tmp___15 = emitter->buffer.pointer;
                                          (emitter->buffer.pointer) ++;
                                          *tmp___15 = (unsigned char )'\\';
                                          (emitter->column) ++;
                                        } else {
                                          {
                                          tmp___14 = __dyc_funcallvar_2;
                                          }
                                          if (tmp___14) {
                                            tmp___15 = emitter->buffer.pointer;
                                            (emitter->buffer.pointer) ++;
                                            *tmp___15 = (unsigned char )'\\';
                                            (emitter->column) ++;
                                          } else {
                                            goto __dyc_dummy_label;
                                          }
                                        }
                                        if ((int )value___0 == 0) {
                                          goto switch_28_0;
                                        } else {
                                          if ((int )value___0 == 7) {
                                            goto switch_28_7;
                                          } else {
                                            if ((int )value___0 == 8) {
                                              goto switch_28_8;
                                            } else {
                                              if ((int )value___0 == 9) {
                                                goto switch_28_9;
                                              } else {
                                                if ((int )value___0 == 10) {
                                                  goto switch_28_10;
                                                } else {
                                                  if ((int )value___0 == 11) {
                                                    goto switch_28_11;
                                                  } else {
                                                    if ((int )value___0 == 12) {
                                                      goto switch_28_12;
                                                    } else {
                                                      if ((int )value___0 == 13) {
                                                        goto switch_28_13;
                                                      } else {
                                                        if ((int )value___0 == 27) {
                                                          goto switch_28_27;
                                                        } else {
                                                          if ((int )value___0 == 34) {
                                                            goto switch_28_34;
                                                          } else {
                                                            if ((int )value___0 == 92) {
                                                              goto switch_28_92;
                                                            } else {
                                                              if ((int )value___0 == 133) {
                                                                goto switch_28_133;
                                                              } else {
                                                                if ((int )value___0 == 160) {
                                                                  goto switch_28_160;
                                                                } else {
                                                                  if ((int )value___0 == 8232) {
                                                                    goto switch_28_8232;
                                                                  } else {
                                                                    if ((int )value___0 == 8233) {
                                                                      goto switch_28_8233;
                                                                    } else {
                                                                      {
                                                                      goto switch_28_default;
                                                                      if (0) {
                                                                        switch_28_0:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___17 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___17 = (unsigned char )'0';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___16 = __dyc_funcallvar_3;
                                                                          }
                                                                          if (tmp___16) {
                                                                            tmp___17 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___17 = (unsigned char )'0';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_7:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___19 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___19 = (unsigned char )'a';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___18 = __dyc_funcallvar_4;
                                                                          }
                                                                          if (tmp___18) {
                                                                            tmp___19 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___19 = (unsigned char )'a';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_8:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___21 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___21 = (unsigned char )'b';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___20 = __dyc_funcallvar_5;
                                                                          }
                                                                          if (tmp___20) {
                                                                            tmp___21 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___21 = (unsigned char )'b';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_9:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___23 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___23 = (unsigned char )'t';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___22 = __dyc_funcallvar_6;
                                                                          }
                                                                          if (tmp___22) {
                                                                            tmp___23 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___23 = (unsigned char )'t';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_10:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___25 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___25 = (unsigned char )'n';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___24 = __dyc_funcallvar_7;
                                                                          }
                                                                          if (tmp___24) {
                                                                            tmp___25 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___25 = (unsigned char )'n';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_11:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___27 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___27 = (unsigned char )'v';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___26 = __dyc_funcallvar_8;
                                                                          }
                                                                          if (tmp___26) {
                                                                            tmp___27 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___27 = (unsigned char )'v';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_12:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___29 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___29 = (unsigned char )'f';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___28 = __dyc_funcallvar_9;
                                                                          }
                                                                          if (tmp___28) {
                                                                            tmp___29 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___29 = (unsigned char )'f';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_13:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___31 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___31 = (unsigned char )'r';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___30 = __dyc_funcallvar_10;
                                                                          }
                                                                          if (tmp___30) {
                                                                            tmp___31 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___31 = (unsigned char )'r';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_27:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___33 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___33 = (unsigned char )'e';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___32 = __dyc_funcallvar_11;
                                                                          }
                                                                          if (tmp___32) {
                                                                            tmp___33 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___33 = (unsigned char )'e';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_34:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___35 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___35 = (unsigned char )'\"';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___34 = __dyc_funcallvar_12;
                                                                          }
                                                                          if (tmp___34) {
                                                                            tmp___35 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___35 = (unsigned char )'\"';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_92:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___37 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___37 = (unsigned char )'\\';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___36 = __dyc_funcallvar_13;
                                                                          }
                                                                          if (tmp___36) {
                                                                            tmp___37 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___37 = (unsigned char )'\\';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_133:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___39 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___39 = (unsigned char )'N';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___38 = __dyc_funcallvar_14;
                                                                          }
                                                                          if (tmp___38) {
                                                                            tmp___39 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___39 = (unsigned char )'N';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_160:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___41 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___41 = (unsigned char )'_';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___40 = __dyc_funcallvar_15;
                                                                          }
                                                                          if (tmp___40) {
                                                                            tmp___41 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___41 = (unsigned char )'_';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_8232:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___43 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___43 = (unsigned char )'L';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___42 = __dyc_funcallvar_16;
                                                                          }
                                                                          if (tmp___42) {
                                                                            tmp___43 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___43 = (unsigned char )'L';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_8233:  
                                                                        if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                          tmp___45 = emitter->buffer.pointer;
                                                                          (emitter->buffer.pointer) ++;
                                                                          *tmp___45 = (unsigned char )'P';
                                                                          (emitter->column) ++;
                                                                        } else {
                                                                          {
                                                                          tmp___44 = __dyc_funcallvar_17;
                                                                          }
                                                                          if (tmp___44) {
                                                                            tmp___45 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___45 = (unsigned char )'P';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            goto __dyc_dummy_label;
                                                                          }
                                                                        }
                                                                        goto switch_28_break;
                                                                        switch_28_default:  ;
                                                                        if (value___0 <= 255U) {
                                                                          if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                            tmp___47 = emitter->buffer.pointer;
                                                                            (emitter->buffer.pointer) ++;
                                                                            *tmp___47 = (unsigned char )'x';
                                                                            (emitter->column) ++;
                                                                          } else {
                                                                            {
                                                                            tmp___46 = __dyc_funcallvar_18;
                                                                            }
                                                                            if (tmp___46) {
                                                                              tmp___47 = emitter->buffer.pointer;
                                                                              (emitter->buffer.pointer) ++;
                                                                              *tmp___47 = (unsigned char )'x';
                                                                              (emitter->column) ++;
                                                                            } else {
                                                                              goto __dyc_dummy_label;
                                                                            }
                                                                          }
                                                                          width = 2U;
                                                                        } else {
                                                                          if (value___0 <= 65535U) {
                                                                            if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                              tmp___49 = emitter->buffer.pointer;
                                                                              (emitter->buffer.pointer) ++;
                                                                              *tmp___49 = (unsigned char )'u';
                                                                              (emitter->column) ++;
                                                                            } else {
                                                                              {
                                                                              tmp___48 = __dyc_funcallvar_19;
                                                                              }
                                                                              if (tmp___48) {
                                                                                tmp___49 = emitter->buffer.pointer;
                                                                                (emitter->buffer.pointer) ++;
                                                                                *tmp___49 = (unsigned char )'u';
                                                                                (emitter->column) ++;
                                                                              } else {
                                                                                goto __dyc_dummy_label;
                                                                              }
                                                                            }
                                                                            width = 4U;
                                                                          } else {
                                                                            if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                              tmp___51 = emitter->buffer.pointer;
                                                                              (emitter->buffer.pointer) ++;
                                                                              *tmp___51 = (unsigned char )'U';
                                                                              (emitter->column) ++;
                                                                            } else {
                                                                              {
                                                                              tmp___50 = __dyc_funcallvar_20;
                                                                              }
                                                                              if (tmp___50) {
                                                                                tmp___51 = emitter->buffer.pointer;
                                                                                (emitter->buffer.pointer) ++;
                                                                                *tmp___51 = (unsigned char )'U';
                                                                                (emitter->column) ++;
                                                                              } else {
                                                                                goto __dyc_dummy_label;
                                                                              }
                                                                            }
                                                                            width = 8U;
                                                                          }
                                                                        }
                                                                        k = (int )((width - 1U) * 4U);
                                                                        {
                                                                        while (1) {
                                                                          while_29_continue:  ;
                                                                          if (! (k >= 0)) {
                                                                            goto while_29_break;
                                                                          }
                                                                          digit = (int )((value___0 >> k) & 15U);
                                                                          if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                                            goto _L;
                                                                          } else {
                                                                            {
                                                                            tmp___52 = __dyc_funcallvar_21;
                                                                            }
                                                                            if (tmp___52) {
                                                                              _L:  
                                                                              tmp___53 = emitter->buffer.pointer;
                                                                              (emitter->buffer.pointer) ++;
                                                                              if (digit < 10) {
                                                                                tmp___54 = '0';
                                                                              } else {
                                                                                tmp___54 = 55;
                                                                              }
                                                                              *tmp___53 = (unsigned char )(digit + tmp___54);
                                                                              (emitter->column) ++;
                                                                            } else {
                                                                              goto __dyc_dummy_label;
                                                                            }
                                                                          }
                                                                          k -= 4;
                                                                        }
                                                                        while_29_break:  ;
                                                                        }
                                                                      } else {
                                                                        switch_28_break:  ;
                                                                      }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                        spaces = 0;
                                      } else {
                                        if ((int )*(string.pointer + 0) == 32) {
                                          if (allow_breaks) {
                                            if (! spaces) {
                                              if (emitter->column > emitter->best_width) {
                                                if ((unsigned long )string.pointer != (unsigned long )string.start) {
                                                  if ((unsigned long )string.pointer != (unsigned long )(string.end - 1)) {
                                                    {
                                                    tmp___55 = __dyc_funcallvar_22;
                                                    }
                                                    if (! tmp___55) {
                                                      goto __dyc_dummy_label;
                                                    }
                                                    if ((int )*(string.pointer + 1) == 32) {
                                                      if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                                        tmp___57 = emitter->buffer.pointer;
                                                        (emitter->buffer.pointer) ++;
                                                        *tmp___57 = (unsigned char )'\\';
                                                        (emitter->column) ++;
                                                      } else {
                                                        {
                                                        tmp___56 = __dyc_funcallvar_23;
                                                        }
                                                        if (tmp___56) {
                                                          tmp___57 = emitter->buffer.pointer;
                                                          (emitter->buffer.pointer) ++;
                                                          *tmp___57 = (unsigned char )'\\';
                                                          (emitter->column) ++;
                                                        } else {
                                                          goto __dyc_dummy_label;
                                                        }
                                                      }
                                                    }
                                                    if (((int )*(string.pointer + 0) & 128) == 0) {
                                                      tmp___62 = 1;
                                                    } else {
                                                      if (((int )*(string.pointer + 0) & 224) == 192) {
                                                        tmp___62 = 2;
                                                      } else {
                                                        if (((int )*(string.pointer + 0) & 240) == 224) {
                                                          tmp___62 = 3;
                                                        } else {
                                                          if (((int )*(string.pointer + 0) & 248) == 240) {
                                                            tmp___62 = 4;
                                                          } else {
                                                            tmp___62 = 0;
                                                          }
                                                        }
                                                      }
                                                    }
                                                    string.pointer += tmp___62;
                                                  } else {
                                                    goto _L___4;
                                                  }
                                                } else {
                                                  goto _L___4;
                                                }
                                              } else {
                                                goto _L___4;
                                              }
                                            } else {
                                              goto _L___4;
                                            }
                                          } else {
                                            _L___4:  
                                            if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                              goto _L___0;
                                            } else {
                                              {
                                              tmp___66 = __dyc_funcallvar_24;
                                              }
                                              if (tmp___66) {
                                                _L___0:  
                                                if (((int )*(string.pointer) & 128) == 0) {
                                                  tmp___85 = emitter->buffer.pointer;
                                                  (emitter->buffer.pointer) ++;
                                                  tmp___86 = string.pointer;
                                                  (string.pointer) ++;
                                                  *tmp___85 = *tmp___86;
                                                } else {
                                                  if (((int )*(string.pointer) & 224) == 192) {
                                                    tmp___81 = emitter->buffer.pointer;
                                                    (emitter->buffer.pointer) ++;
                                                    tmp___82 = string.pointer;
                                                    (string.pointer) ++;
                                                    *tmp___81 = *tmp___82;
                                                    tmp___83 = emitter->buffer.pointer;
                                                    (emitter->buffer.pointer) ++;
                                                    tmp___84 = string.pointer;
                                                    (string.pointer) ++;
                                                    *tmp___83 = *tmp___84;
                                                  } else {
                                                    if (((int )*(string.pointer) & 240) == 224) {
                                                      tmp___75 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___76 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___75 = *tmp___76;
                                                      tmp___77 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___78 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___77 = *tmp___78;
                                                      tmp___79 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___80 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___79 = *tmp___80;
                                                    } else {
                                                      if (((int )*(string.pointer) & 248) == 240) {
                                                        tmp___67 = emitter->buffer.pointer;
                                                        (emitter->buffer.pointer) ++;
                                                        tmp___68 = string.pointer;
                                                        (string.pointer) ++;
                                                        *tmp___67 = *tmp___68;
                                                        tmp___69 = emitter->buffer.pointer;
                                                        (emitter->buffer.pointer) ++;
                                                        tmp___70 = string.pointer;
                                                        (string.pointer) ++;
                                                        *tmp___69 = *tmp___70;
                                                        tmp___71 = emitter->buffer.pointer;
                                                        (emitter->buffer.pointer) ++;
                                                        tmp___72 = string.pointer;
                                                        (string.pointer) ++;
                                                        *tmp___71 = *tmp___72;
                                                        tmp___73 = emitter->buffer.pointer;
                                                        (emitter->buffer.pointer) ++;
                                                        tmp___74 = string.pointer;
                                                        (string.pointer) ++;
                                                        *tmp___73 = *tmp___74;
                                                      }
                                                    }
                                                  }
                                                }
                                                (emitter->column) ++;
                                              } else {
                                                goto __dyc_dummy_label;
                                              }
                                            }
                                          }
                                          spaces = 1;
                                        } else {
                                          if ((unsigned long )(emitter->buffer.pointer + 5) < (unsigned long )emitter->buffer.end) {
                                            goto _L___5;
                                          } else {
                                            {
                                            tmp___87 = __dyc_funcallvar_25;
                                            }
                                            if (tmp___87) {
                                              _L___5:  
                                              if (((int )*(string.pointer) & 128) == 0) {
                                                tmp___106 = emitter->buffer.pointer;
                                                (emitter->buffer.pointer) ++;
                                                tmp___107 = string.pointer;
                                                (string.pointer) ++;
                                                *tmp___106 = *tmp___107;
                                              } else {
                                                if (((int )*(string.pointer) & 224) == 192) {
                                                  tmp___102 = emitter->buffer.pointer;
                                                  (emitter->buffer.pointer) ++;
                                                  tmp___103 = string.pointer;
                                                  (string.pointer) ++;
                                                  *tmp___102 = *tmp___103;
                                                  tmp___104 = emitter->buffer.pointer;
                                                  (emitter->buffer.pointer) ++;
                                                  tmp___105 = string.pointer;
                                                  (string.pointer) ++;
                                                  *tmp___104 = *tmp___105;
                                                } else {
                                                  if (((int )*(string.pointer) & 240) == 224) {
                                                    tmp___96 = emitter->buffer.pointer;
                                                    (emitter->buffer.pointer) ++;
                                                    tmp___97 = string.pointer;
                                                    (string.pointer) ++;
                                                    *tmp___96 = *tmp___97;
                                                    tmp___98 = emitter->buffer.pointer;
                                                    (emitter->buffer.pointer) ++;
                                                    tmp___99 = string.pointer;
                                                    (string.pointer) ++;
                                                    *tmp___98 = *tmp___99;
                                                    tmp___100 = emitter->buffer.pointer;
                                                    (emitter->buffer.pointer) ++;
                                                    tmp___101 = string.pointer;
                                                    (string.pointer) ++;
                                                    *tmp___100 = *tmp___101;
                                                  } else {
                                                    if (((int )*(string.pointer) & 248) == 240) {
                                                      tmp___88 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___89 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___88 = *tmp___89;
                                                      tmp___90 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___91 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___90 = *tmp___91;
                                                      tmp___92 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___93 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___92 = *tmp___93;
                                                      tmp___94 = emitter->buffer.pointer;
                                                      (emitter->buffer.pointer) ++;
                                                      tmp___95 = string.pointer;
                                                      (string.pointer) ++;
                                                      *tmp___94 = *tmp___95;
                                                    }
                                                  }
                                                }
                                              }
                                              (emitter->column) ++;
                                            } else {
                                              goto __dyc_dummy_label;
                                            }
                                          }
                                          spaces = 0;
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  goto _L___6;
                }
              }
            }
          }
        }
      }
    }
  }
  while_26_break:  ;
  tmp___108 = __dyc_funcallvar_26;
  if (tmp___108) {

  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_101__anonstruct_yaml_string_t_74(string);
  __dyc_printpre_byte(spaces);
  __dyc_printpre_byte(value___0);
  __dyc_printpre_byte(digit);
}
}
