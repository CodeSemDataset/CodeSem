#include "../include/dycfoo.h"
#include "../include/picotls.i.hd.c.h"
void __dyc_foo(void) 
{ int ret ;
  ptls_buffer_t ticket_buf ;
  uint64_t _v ;
  uint64_t tmp ;
  uint8_t __constr_expr_1[8] ;
  uint16_t _v___0 ;
  uint8_t __constr_expr_3[2] ;
  uint16_t _v___1 ;
  uint8_t __constr_expr_5[2] ;
  size_t capacity ;
  size_t body_start ;
  size_t body_size ;
  size_t capacity___0 ;
  size_t body_start___0 ;
  size_t body_size___0 ;
  ptls_iovec_t tmp___0 ;
  ptls_t *tls ;
  uint64_t __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  ptls_iovec_t __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;

  {
  ret = __dyc_readpre_byte();
  ticket_buf = __dyc_read_comp_47st_ptls_buffer_t();
  tls = __dyc_read_ptr__typdef_ptls_t();
  __dyc_funcallvar_2 = (uint64_t )__dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_read_comp_46st_ptls_iovec_t();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  _v = 0;
  tmp = 0;
  _v___0 = 0;
  _v___1 = 0;
  capacity = 0;
  body_start = 0;
  body_size = 0;
  capacity___0 = 0;
  body_start___0 = 0;
  body_size___0 = 0;
  memset(& tmp___0, 0, sizeof(ptls_iovec_t ));
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  if ((unsigned long )(tls->ctx)->save_ticket == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }

  while (1) {
    while_503_continue:  ;
    {
    tmp = __dyc_funcallvar_2;
    _v = tmp;
    }
    {
    while (1) {
      while_504_continue:  ;
      {
      __constr_expr_1[0] = (unsigned char )(_v >> 56);
      __constr_expr_1[1] = (unsigned char )(_v >> 48);
      __constr_expr_1[2] = (unsigned char )(_v >> 40);
      __constr_expr_1[3] = (unsigned char )(_v >> 32);
      __constr_expr_1[4] = (unsigned char )(_v >> 24);
      __constr_expr_1[5] = (unsigned char )(_v >> 16);
      __constr_expr_1[6] = (unsigned char )(_v >> 8);
      __constr_expr_1[7] = (unsigned char )_v;
      ret = __dyc_funcallvar_3;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      goto while_504_break;
    }
    while_504_break:  ;
    }
    goto while_503_break;
  }
  while_503_break:  ;
  while (1) {
    while_505_continue:  ;
    _v___0 = (uint16_t )(tls->key_share)->id;
    {
    while (1) {
      while_506_continue:  ;
      {
      __constr_expr_3[0] = (unsigned char )((int )_v___0 >> 8);
      __constr_expr_3[1] = (unsigned char )_v___0;
      ret = __dyc_funcallvar_4;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      goto while_506_break;
    }
    while_506_break:  ;
    }
    goto while_505_break;
  }
  while_505_break:  ;
  while (1) {
    while_507_continue:  ;
    _v___1 = (uint16_t )(tls->cipher_suite)->id;
    {
    while (1) {
      while_508_continue:  ;
      {
      __constr_expr_5[0] = (unsigned char )((int )_v___1 >> 8);
      __constr_expr_5[1] = (unsigned char )_v___1;
      ret = __dyc_funcallvar_5;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      goto while_508_break;
    }
    while_508_break:  ;
    }
    goto while_507_break;
  }
  while_507_break:  ;
  while (1) {
    while_509_continue:  ;
    capacity = (size_t )3;
    {
    while (1) {
      while_510_continue:  ;
      {
      ret = __dyc_funcallvar_6;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      goto while_510_break;
    }
    while_510_break:  ;
    }
    body_start = ticket_buf.off;
    {
    while (1) {
      while_511_continue:  ;
      {
      while (1) {
        while_512_continue:  ;
        {
        ret = __dyc_funcallvar_7;
        }
        if (ret != 0) {
          goto __dyc_dummy_label;
        }
        goto while_512_break;
      }
      while_512_break:  ;
      }
      goto while_511_break;
    }
    while_511_break:  ;
    }
    body_size = ticket_buf.off - body_start;
    {
    while (1) {
      while_513_continue:  ;
      if (! (capacity != 0UL)) {
        goto while_513_break;
      }
      *(ticket_buf.base + (body_start - capacity)) = (unsigned char )(body_size >> 8UL * (capacity - 1UL));
      capacity --;
    }
    while_513_break:  ;
    }
    goto while_509_break;
  }
  while_509_break:  ;
  while (1) {
    while_514_continue:  ;
    capacity___0 = (size_t )2;
    {
    while (1) {
      while_515_continue:  ;
      {
      ret = __dyc_funcallvar_8;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      goto while_515_break;
    }
    while_515_break:  ;
    }
    body_start___0 = ticket_buf.off;
    {
    while (1) {
      while_516_continue:  ;
      {
      ret = __dyc_funcallvar_9;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      {
      ret = __dyc_funcallvar_10;
      }
      if (ret != 0) {
        goto __dyc_dummy_label;
      }
      ticket_buf.off += (size_t )((tls->key_schedule)->hashes[0].algo)->digest_size;
      goto while_516_break;
    }
    while_516_break:  ;
    }
    body_size___0 = ticket_buf.off - body_start___0;
    {
    while (1) {
      while_517_continue:  ;
      if (! (capacity___0 != 0UL)) {
        goto while_517_break;
      }
      *(ticket_buf.base + (body_start___0 - capacity___0)) = (unsigned char )(body_size___0 >> 8UL * (capacity___0 - 1UL));
      capacity___0 --;
    }
    while_517_break:  ;
    }
    goto while_514_break;
  }
  while_514_break:  ;
  tmp___0 = __dyc_funcallvar_11;
  ret = __dyc_funcallvar_12;
  if (ret != 0) {
    goto __dyc_dummy_label;
  }
  ret = 0;

  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(ret);
  __dyc_printpre_byte(capacity);
  __dyc_printpre_byte(body_start);
  __dyc_printpre_byte(body_size);
  __dyc_printpre_byte(capacity___0);
  __dyc_printpre_byte(body_start___0);
  __dyc_printpre_byte(body_size___0);
  __dyc_print_comp_46st_ptls_iovec_t(tmp___0);
}
}
