#line 160 "lzfP.h"
typedef unsigned char u8;
#line 164 "lzfP.h"
typedef unsigned int LZF_HSLOT;
#line 170 "lzfP.h"
typedef LZF_HSLOT LZF_STATE[1 << 16];
#line 175 "lzfP.h"
typedef unsigned short u16;
extern u16 __dyc_random_typdef_u16(unsigned int __dyc_exp ) ;
extern u16 __dyc_read_typdef_u16(void) ;
extern void __dyc_print_typdef_u16(u16 __dyc_thistype ) ;
extern u8 *__dyc_random_ptr__typdef_u8(unsigned int __dyc_exp ) ;
extern u8 *__dyc_read_ptr__typdef_u8(void) ;
extern void __dyc_print_ptr__typdef_u8(u8 const   *__dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern LZF_HSLOT __dyc_random_typdef_LZF_HSLOT(unsigned int __dyc_exp ) ;
extern LZF_HSLOT __dyc_read_typdef_LZF_HSLOT(void) ;
extern void __dyc_print_typdef_LZF_HSLOT(LZF_HSLOT __dyc_thistype ) ;
extern u8 __dyc_random_typdef_u8(unsigned int __dyc_exp ) ;
extern u8 __dyc_read_typdef_u8(void) ;
extern void __dyc_print_typdef_u8(u8 __dyc_thistype ) ;
extern u16 *__dyc_random_ptr__typdef_u16(unsigned int __dyc_exp ) ;
extern u16 *__dyc_read_ptr__typdef_u16(void) ;
extern void __dyc_print_ptr__typdef_u16(u16 const   *__dyc_thistype ) ;
extern LZF_HSLOT *__dyc_random_ptr__typdef_LZF_HSLOT(unsigned int __dyc_exp ) ;
extern LZF_HSLOT *__dyc_read_ptr__typdef_LZF_HSLOT(void) ;
extern void __dyc_print_ptr__typdef_LZF_HSLOT(LZF_HSLOT const   *__dyc_thistype ) ;
