#include "../include/dycfoo.h"
#include "../include/ldblib.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *options ;
  lua_Integer tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  char *tmp___9 ;
  char *tmp___11 ;
  char *tmp___13 ;
  char *tmp___15 ;
  char *tmp___17 ;
  char *tmp___19 ;
  lua_Integer __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  char const   *__dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  char *__dyc_funcallvar_11 ;
  char *__dyc_funcallvar_12 ;
  char *__dyc_funcallvar_13 ;
  char *__dyc_funcallvar_14 ;
  char *__dyc_funcallvar_15 ;
  char *__dyc_funcallvar_16 ;

  {
  tmp___5 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = (lua_Integer )__dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_read_ptr__char();
  __dyc_funcallvar_12 = __dyc_read_ptr__char();
  __dyc_funcallvar_13 = __dyc_read_ptr__char();
  __dyc_funcallvar_14 = __dyc_read_ptr__char();
  __dyc_funcallvar_15 = __dyc_read_ptr__char();
  __dyc_funcallvar_16 = __dyc_read_ptr__char();
  options = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___9 = 0;
  tmp___11 = 0;
  tmp___13 = 0;
  tmp___15 = 0;
  tmp___17 = 0;
  tmp___19 = 0;
  if (tmp___5) {
    {
    tmp___1 = __dyc_funcallvar_4;
    tmp___2 = __dyc_funcallvar_5;
    }
    if (! tmp___2) {
      {

      }
      goto __dyc_dummy_label;
    }
  } else {
    {
    tmp___4 = __dyc_funcallvar_6;
    }
    if (tmp___4 == 6) {
      {

      options = __dyc_funcallvar_7;


      }
    } else {
      {
      tmp___3 = __dyc_funcallvar_8;
      }
      goto __dyc_dummy_label;
    }
  }
  tmp___7 = __dyc_funcallvar_9;
  if (! tmp___7) {
    {
    tmp___6 = __dyc_funcallvar_10;
    }
    goto __dyc_dummy_label;
  }

  tmp___9 = __dyc_funcallvar_11;
  if (tmp___9) {
    {





    }
  }
  tmp___11 = __dyc_funcallvar_12;
  if (tmp___11) {
    {

    }
  }
  tmp___13 = __dyc_funcallvar_13;
  if (tmp___13) {
    {

    }
  }
  tmp___15 = __dyc_funcallvar_14;
  if (tmp___15) {
    {


    }
  }
  tmp___17 = __dyc_funcallvar_15;
  if (tmp___17) {
    {

    }
  }
  tmp___19 = __dyc_funcallvar_16;
  if (tmp___19) {
    {

    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(options);
  __dyc_printpre_byte(tmp___1);
  __dyc_printpre_byte(tmp___3);
  __dyc_printpre_byte(tmp___6);
}
}
