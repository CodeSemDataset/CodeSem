#include "../include/dycfoo.h"
#include "../include/simple-object.i.hd.c.h"
void __dyc_foo(void) 
{ char *newname ;
  int tmp___26 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___36 ;
  int tmp___41 ;
  int tmp___42 ;
  int tmp___43 ;
  int tmp___44 ;
  int tmp___68 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) tmp___90 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) tmp___92 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) tmp___93 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) tmp___94 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) tmp___95 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) tmp___96 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___106 ;
  int tmp___111 ;
  int tmp___112 ;
  int tmp___113 ;
  int tmp___114 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___124 ;
  int tmp___129 ;
  int tmp___130 ;
  int tmp___131 ;
  int tmp___132 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___142 ;
  int tmp___147 ;
  int tmp___148 ;
  int tmp___149 ;
  int tmp___150 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___160 ;
  int tmp___165 ;
  int tmp___166 ;
  int tmp___167 ;
  int tmp___168 ;
  int tmp___190 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___200 ;
  int tmp___205 ;
  int tmp___206 ;
  int tmp___207 ;
  int tmp___208 ;
  int tmp___232 ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___242 ;
  int tmp___247 ;
  int tmp___248 ;
  int tmp___249 ;
  int tmp___250 ;
  char const   *name ;
  int rename___0 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  char __attribute__((__artificial__))  * __attribute__((__leaf__)) __dyc_funcallvar_53 ;

  {
  newname = __dyc_read_ptr__char();
  tmp___68 = __dyc_readpre_byte();
  name = (char const   *)__dyc_read_ptr__char();
  rename___0 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )__dyc_read_ptr__char();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )__dyc_read_ptr__char();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )__dyc_read_ptr__char();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )__dyc_read_ptr__char();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )__dyc_read_ptr__char();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )__dyc_read_ptr__char();
  tmp___26 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___36 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___90 = 0;
  tmp___92 = 0;
  tmp___93 = 0;
  tmp___94 = 0;
  tmp___95 = 0;
  tmp___96 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___106 = 0;
  tmp___111 = 0;
  tmp___112 = 0;
  tmp___113 = 0;
  tmp___114 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___124 = 0;
  tmp___129 = 0;
  tmp___130 = 0;
  tmp___131 = 0;
  tmp___132 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___142 = 0;
  tmp___147 = 0;
  tmp___148 = 0;
  tmp___149 = 0;
  tmp___150 = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___160 = 0;
  tmp___165 = 0;
  tmp___166 = 0;
  tmp___167 = 0;
  tmp___168 = 0;
  tmp___190 = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___200 = 0;
  tmp___205 = 0;
  tmp___206 = 0;
  tmp___207 = 0;
  tmp___208 = 0;
  tmp___232 = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___242 = 0;
  tmp___247 = 0;
  tmp___248 = 0;
  tmp___249 = 0;
  tmp___250 = 0;
  if (tmp___68 == 0) {
    if (rename___0) {
      {

      }
    }
    name += sizeof(".rela") - 1UL;
  } else {
    if (0) {
      if (0) {
        {
        tmp___42 = __dyc_funcallvar_10;
        __s1_len___0 = (unsigned long )tmp___42;
        tmp___43 = __dyc_funcallvar_11;
        __s2_len___0 = (unsigned long )tmp___43;
        }
        if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
          goto _L___2;
        } else {
          if (__s1_len___0 >= 4UL) {
            _L___2:  
            if (! ((unsigned long )((void const   *)(".rel" + 1)) - (unsigned long )((void const   *)".rel") == 1UL)) {
              tmp___44 = 1;
            } else {
              if (__s2_len___0 >= 4UL) {
                tmp___44 = 1;
              } else {
                tmp___44 = 0;
              }
            }
          } else {
            tmp___44 = 0;
          }
        }
        if (tmp___44) {
          {
          tmp___36 = __dyc_funcallvar_12;
          }
        } else {
          {
          tmp___41 = __dyc_funcallvar_13;
          tmp___36 = tmp___41;
          }
        }
      } else {
        {
        tmp___41 = __dyc_funcallvar_14;
        tmp___36 = tmp___41;
        }
      }
      tmp___26 = tmp___36;
    } else {
      {
      tmp___26 = __dyc_funcallvar_15;
      }
    }
    if (tmp___26 == 0) {
      if (rename___0) {
        {

        }
      }
      name += sizeof(".rel") - 1UL;
    }
  }
  if (0) {
    if (0) {
      {
      tmp___248 = __dyc_funcallvar_16;
      __s1_len___10 = (unsigned long )tmp___248;
      tmp___249 = __dyc_funcallvar_17;
      __s2_len___10 = (unsigned long )tmp___249;
      }
      if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
        goto _L___22;
      } else {
        if (__s1_len___10 >= 4UL) {
          _L___22:  
          if (! ((unsigned long )((void const   *)(".gnu.debuglto_" + 1)) - (unsigned long )((void const   *)".gnu.debuglto_") == 1UL)) {
            tmp___250 = 1;
          } else {
            if (__s2_len___10 >= 4UL) {
              tmp___250 = 1;
            } else {
              tmp___250 = 0;
            }
          }
        } else {
          tmp___250 = 0;
        }
      }
      if (tmp___250) {
        {
        tmp___242 = __dyc_funcallvar_18;
        }
      } else {
        {
        tmp___247 = __dyc_funcallvar_19;
        tmp___242 = tmp___247;
        }
      }
    } else {
      {
      tmp___247 = __dyc_funcallvar_20;
      tmp___242 = tmp___247;
      }
    }
    tmp___232 = tmp___242;
  } else {
    {
    tmp___232 = __dyc_funcallvar_21;
    }
  }
  if (tmp___232 == 0) {
    if (rename___0) {
      {
      tmp___90 = __dyc_funcallvar_22;
      }
    } else {
      tmp___90 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )newname;
    }
    goto __dyc_dummy_label;
  } else {
    if (0) {
      if (0) {
        {
        tmp___206 = __dyc_funcallvar_23;
        __s1_len___8 = (unsigned long )tmp___206;
        tmp___207 = __dyc_funcallvar_24;
        __s2_len___8 = (unsigned long )tmp___207;
        }
        if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
          goto _L___18;
        } else {
          if (__s1_len___8 >= 4UL) {
            _L___18:  
            if (! ((unsigned long )((void const   *)(".gnu.lto_.debug_" + 1)) - (unsigned long )((void const   *)".gnu.lto_.debug_") == 1UL)) {
              tmp___208 = 1;
            } else {
              if (__s2_len___8 >= 4UL) {
                tmp___208 = 1;
              } else {
                tmp___208 = 0;
              }
            }
          } else {
            tmp___208 = 0;
          }
        }
        if (tmp___208) {
          {
          tmp___200 = __dyc_funcallvar_25;
          }
        } else {
          {
          tmp___205 = __dyc_funcallvar_26;
          tmp___200 = tmp___205;
          }
        }
      } else {
        {
        tmp___205 = __dyc_funcallvar_27;
        tmp___200 = tmp___205;
        }
      }
      tmp___190 = tmp___200;
    } else {
      {
      tmp___190 = __dyc_funcallvar_28;
      }
    }
    if (tmp___190 == 0) {
      if (rename___0) {
        {
        tmp___92 = __dyc_funcallvar_29;
        }
      } else {
        tmp___92 = (char __attribute__((__artificial__))  * __attribute__((__leaf__)) )newname;
      }
      goto __dyc_dummy_label;
    } else {
      if (0) {
        {
        tmp___166 = __dyc_funcallvar_30;
        __s1_len___6 = (unsigned long )tmp___166;
        tmp___167 = __dyc_funcallvar_31;
        __s2_len___6 = (unsigned long )tmp___167;
        }
        if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
          goto _L___14;
        } else {
          if (__s1_len___6 >= 4UL) {
            _L___14:  
            if (! ((unsigned long )((void const   *)(".note.GNU-stack" + 1)) - (unsigned long )((void const   *)".note.GNU-stack") == 1UL)) {
              tmp___168 = 1;
            } else {
              if (__s2_len___6 >= 4UL) {
                tmp___168 = 1;
              } else {
                tmp___168 = 0;
              }
            }
          } else {
            tmp___168 = 0;
          }
        }
        if (tmp___168) {
          {
          tmp___160 = __dyc_funcallvar_32;
          }
        } else {
          {
          tmp___165 = __dyc_funcallvar_33;
          tmp___160 = tmp___165;
          }
        }
      } else {
        {
        tmp___165 = __dyc_funcallvar_34;
        tmp___160 = tmp___165;
        }
      }
      if (tmp___160 == 0) {
        {
        tmp___93 = __dyc_funcallvar_35;
        }
        goto __dyc_dummy_label;
      } else {
        if (0) {
          {
          tmp___148 = __dyc_funcallvar_36;
          __s1_len___5 = (unsigned long )tmp___148;
          tmp___149 = __dyc_funcallvar_37;
          __s2_len___5 = (unsigned long )tmp___149;
          }
          if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
            goto _L___12;
          } else {
            if (__s1_len___5 >= 4UL) {
              _L___12:  
              if (! ((unsigned long )((void const   *)(".note.gnu.property" + 1)) - (unsigned long )((void const   *)".note.gnu.property") == 1UL)) {
                tmp___150 = 1;
              } else {
                if (__s2_len___5 >= 4UL) {
                  tmp___150 = 1;
                } else {
                  tmp___150 = 0;
                }
              }
            } else {
              tmp___150 = 0;
            }
          }
          if (tmp___150) {
            {
            tmp___142 = __dyc_funcallvar_38;
            }
          } else {
            {
            tmp___147 = __dyc_funcallvar_39;
            tmp___142 = tmp___147;
            }
          }
        } else {
          {
          tmp___147 = __dyc_funcallvar_40;
          tmp___142 = tmp___147;
          }
        }
        if (tmp___142 == 0) {
          {
          tmp___94 = __dyc_funcallvar_41;
          }
          goto __dyc_dummy_label;
        } else {
          if (0) {
            {
            tmp___130 = __dyc_funcallvar_42;
            __s1_len___4 = (unsigned long )tmp___130;
            tmp___131 = __dyc_funcallvar_43;
            __s2_len___4 = (unsigned long )tmp___131;
            }
            if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
              goto _L___10;
            } else {
              if (__s1_len___4 >= 4UL) {
                _L___10:  
                if (! ((unsigned long )((void const   *)(".comment" + 1)) - (unsigned long )((void const   *)".comment") == 1UL)) {
                  tmp___132 = 1;
                } else {
                  if (__s2_len___4 >= 4UL) {
                    tmp___132 = 1;
                  } else {
                    tmp___132 = 0;
                  }
                }
              } else {
                tmp___132 = 0;
              }
            }
            if (tmp___132) {
              {
              tmp___124 = __dyc_funcallvar_44;
              }
            } else {
              {
              tmp___129 = __dyc_funcallvar_45;
              tmp___124 = tmp___129;
              }
            }
          } else {
            {
            tmp___129 = __dyc_funcallvar_46;
            tmp___124 = tmp___129;
            }
          }
          if (tmp___124 == 0) {
            {
            tmp___95 = __dyc_funcallvar_47;
            }
            goto __dyc_dummy_label;
          } else {
            if (0) {
              {
              tmp___112 = __dyc_funcallvar_48;
              __s1_len___3 = (unsigned long )tmp___112;
              tmp___113 = __dyc_funcallvar_49;
              __s2_len___3 = (unsigned long )tmp___113;
              }
              if (! ((unsigned long )((void const   *)(name + 1)) - (unsigned long )((void const   *)name) == 1UL)) {
                goto _L___8;
              } else {
                if (__s1_len___3 >= 4UL) {
                  _L___8:  
                  if (! ((unsigned long )((void const   *)(".GCC.command.line" + 1)) - (unsigned long )((void const   *)".GCC.command.line") == 1UL)) {
                    tmp___114 = 1;
                  } else {
                    if (__s2_len___3 >= 4UL) {
                      tmp___114 = 1;
                    } else {
                      tmp___114 = 0;
                    }
                  }
                } else {
                  tmp___114 = 0;
                }
              }
              if (tmp___114) {
                {
                tmp___106 = __dyc_funcallvar_50;
                }
              } else {
                {
                tmp___111 = __dyc_funcallvar_51;
                tmp___106 = tmp___111;
                }
              }
            } else {
              {
              tmp___111 = __dyc_funcallvar_52;
              tmp___106 = tmp___111;
              }
            }
            if (tmp___106 == 0) {
              {
              tmp___96 = __dyc_funcallvar_53;
              }
              goto __dyc_dummy_label;
            }
          }
        }
      }
    }
  }

  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_print_ptr__char(tmp___90);
  __dyc_print_ptr__char(tmp___92);
  __dyc_print_ptr__char(tmp___93);
  __dyc_print_ptr__char(tmp___94);
  __dyc_print_ptr__char(tmp___95);
  __dyc_print_ptr__char(tmp___96);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_print_ptr__char(name);
}
}
