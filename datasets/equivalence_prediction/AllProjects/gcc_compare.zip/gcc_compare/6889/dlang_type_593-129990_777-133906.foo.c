#include "../include/dycfoo.h"
#include "../include/d-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ size_t sztype ;
  int tmp ;
  int tmp___0 ;
  char const   *tmp___1 ;
  size_t szmods ;
  int tmp___2 ;
  char const   *tmp___3 ;
  char const   *mangled ;
  char const   *__dyc_funcallvar_7 ;
  char const   *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  char const   *__dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  char const   *__dyc_funcallvar_12 ;
  char const   *__dyc_funcallvar_13 ;
  char const   *__dyc_funcallvar_14 ;
  char const   *__dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  char const   *__dyc_funcallvar_17 ;
  char const   *__dyc_funcallvar_18 ;

  {
  mangled = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_7 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_8 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_13 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_14 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_15 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_18 = (char const   *)__dyc_read_ptr__char();
  sztype = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  szmods = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  mangled = __dyc_funcallvar_7;



  goto __dyc_dummy_label;
  mangled ++;

  mangled = __dyc_funcallvar_8;
  tmp = __dyc_funcallvar_9;
  sztype = (unsigned long )tmp;
  mangled = __dyc_funcallvar_10;




  goto __dyc_dummy_label;
  mangled ++;
  tmp___0 = __dyc_funcallvar_11;
  if (! tmp___0) {
    {
    mangled = __dyc_funcallvar_12;

    }
    goto __dyc_dummy_label;
  }
  mangled = __dyc_funcallvar_13;

  goto __dyc_dummy_label;
  mangled ++;
  tmp___1 = __dyc_funcallvar_14;
  goto __dyc_dummy_label;
  mangled ++;

  mangled = __dyc_funcallvar_15;
  tmp___2 = __dyc_funcallvar_16;
  szmods = (unsigned long )tmp___2;
  mangled = __dyc_funcallvar_17;



  goto __dyc_dummy_label;
  mangled ++;
  tmp___3 = __dyc_funcallvar_18;
  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  mangled ++;

  goto __dyc_dummy_label;
  switch_10_122:  
  mangled ++;
  if ((int )*mangled == 105) {
    goto switch_12_105;
  } else {
    if ((int )*mangled == 107) {
      goto switch_12_107;
    } else {
      if (0) {
        switch_12_105:  
        {
        mangled ++;

        }
        goto __dyc_dummy_label;
        switch_12_107:  
        {
        mangled ++;

        }
        goto __dyc_dummy_label;
      } else {
        switch_12_break:  ;
      }
    }
  }
  goto __dyc_dummy_label;
  switch_10_default:  ;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(sztype);
  __dyc_print_ptr__char(tmp___1);
  __dyc_printpre_byte(szmods);
  __dyc_print_ptr__char(tmp___3);
  __dyc_print_ptr__char(mangled);
}
}
