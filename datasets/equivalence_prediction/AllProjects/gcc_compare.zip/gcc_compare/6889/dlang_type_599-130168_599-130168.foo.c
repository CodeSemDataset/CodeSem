#include "../include/dycfoo.h"
#include "../include/d-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned short const   _sch_istable[256] ;
  char const   *numptr ;
  size_t num ;
  size_t sztype ;
  int tmp ;
  int tmp___0 ;
  char const   *tmp___1 ;
  size_t szmods ;
  int tmp___2 ;
  char const   *tmp___3 ;
  char const   *mangled ;
  char const   *__dyc_funcallvar_1 ;
  char const   *__dyc_funcallvar_2 ;
  char const   *__dyc_funcallvar_3 ;
  char const   *__dyc_funcallvar_4 ;
  char const   *__dyc_funcallvar_5 ;
  char const   *__dyc_funcallvar_6 ;
  char const   *__dyc_funcallvar_7 ;
  char const   *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  char const   *__dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  char const   *__dyc_funcallvar_12 ;
  char const   *__dyc_funcallvar_13 ;
  char const   *__dyc_funcallvar_14 ;
  char const   *__dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  char const   *__dyc_funcallvar_17 ;
  char const   *__dyc_funcallvar_18 ;

  {
  mangled = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_8 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_13 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_14 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_15 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_18 = (char const   *)__dyc_read_ptr__char();
  numptr = 0;
  num = 0;
  sztype = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  szmods = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  __dyc_funcallvar_1 = 0;
  __dyc_funcallvar_2 = 0;
  __dyc_funcallvar_3 = 0;
  __dyc_funcallvar_4 = 0;
  __dyc_funcallvar_5 = 0;
  __dyc_funcallvar_6 = 0;
  __dyc_funcallvar_7 = 0;
  if ((int )*mangled == 72) {
    goto switch_10_72;
  } else {
    if ((int )*mangled == 80) {
      goto switch_10_80;
    } else {
      if ((int )*mangled == 70) {
        goto switch_10_70;
      } else {
        if ((int )*mangled == 85) {
          goto switch_10_70;
        } else {
          if ((int )*mangled == 87) {
            goto switch_10_70;
          } else {
            if ((int )*mangled == 86) {
              goto switch_10_70;
            } else {
              if ((int )*mangled == 82) {
                goto switch_10_70;
              } else {
                if ((int )*mangled == 89) {
                  goto switch_10_70;
                } else {
                  if ((int )*mangled == 73) {
                    goto switch_10_73;
                  } else {
                    if ((int )*mangled == 67) {
                      goto switch_10_73;
                    } else {
                      if ((int )*mangled == 83) {
                        goto switch_10_73;
                      } else {
                        if ((int )*mangled == 69) {
                          goto switch_10_73;
                        } else {
                          if ((int )*mangled == 84) {
                            goto switch_10_73;
                          } else {
                            if ((int )*mangled == 68) {
                              goto switch_10_68;
                            } else {
                              if ((int )*mangled == 66) {
                                goto switch_10_66;
                              } else {
                                if ((int )*mangled == 110) {
                                  goto switch_10_110;
                                } else {
                                  if ((int )*mangled == 118) {
                                    goto switch_10_118;
                                  } else {
                                    if ((int )*mangled == 103) {
                                      goto switch_10_103;
                                    } else {
                                      if ((int )*mangled == 104) {
                                        goto switch_10_104;
                                      } else {
                                        if ((int )*mangled == 115) {
                                          goto switch_10_115;
                                        } else {
                                          if ((int )*mangled == 116) {
                                            goto switch_10_116;
                                          } else {
                                            if ((int )*mangled == 105) {
                                              goto switch_10_105;
                                            } else {
                                              if ((int )*mangled == 107) {
                                                goto switch_10_107;
                                              } else {
                                                if ((int )*mangled == 108) {
                                                  goto switch_10_108;
                                                } else {
                                                  if ((int )*mangled == 109) {
                                                    goto switch_10_109;
                                                  } else {
                                                    if ((int )*mangled == 102) {
                                                      goto switch_10_102;
                                                    } else {
                                                      if ((int )*mangled == 100) {
                                                        goto switch_10_100;
                                                      } else {
                                                        if ((int )*mangled == 101) {
                                                          goto switch_10_101;
                                                        } else {
                                                          if ((int )*mangled == 111) {
                                                            goto switch_10_111;
                                                          } else {
                                                            if ((int )*mangled == 112) {
                                                              goto switch_10_112;
                                                            } else {
                                                              if ((int )*mangled == 106) {
                                                                goto switch_10_106;
                                                              } else {
                                                                if ((int )*mangled == 113) {
                                                                  goto switch_10_113;
                                                                } else {
                                                                  if ((int )*mangled == 114) {
                                                                    goto switch_10_114;
                                                                  } else {
                                                                    if ((int )*mangled == 99) {
                                                                      goto switch_10_99;
                                                                    } else {
                                                                      if ((int )*mangled == 98) {
                                                                        goto switch_10_98;
                                                                      } else {
                                                                        if ((int )*mangled == 97) {
                                                                          goto switch_10_97;
                                                                        } else {
                                                                          if ((int )*mangled == 117) {
                                                                            goto switch_10_117;
                                                                          } else {
                                                                            if ((int )*mangled == 119) {
                                                                              goto switch_10_119;
                                                                            } else {
                                                                              if ((int )*mangled == 122) {
                                                                                goto switch_10_122;
                                                                              } else {
                                                                                {
                                                                                goto switch_10_default;
                                                                                if (0) {
                                                                                  switch_10_79:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  mangled = __dyc_funcallvar_1;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_120:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  mangled = __dyc_funcallvar_2;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_121:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  mangled = __dyc_funcallvar_3;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_78:  
                                                                                  mangled ++;
                                                                                  if ((int const   )*mangled == 103) {
                                                                                    {
                                                                                    mangled ++;

                                                                                    mangled = __dyc_funcallvar_4;

                                                                                    }
                                                                                    goto __dyc_dummy_label;
                                                                                  } else {
                                                                                    if ((int const   )*mangled == 104) {
                                                                                      {
                                                                                      mangled ++;

                                                                                      mangled = __dyc_funcallvar_5;

                                                                                      }
                                                                                      goto __dyc_dummy_label;
                                                                                    } else {
                                                                                      goto __dyc_dummy_label;
                                                                                    }
                                                                                  }
                                                                                  switch_10_65:  
                                                                                  {
                                                                                  mangled ++;
                                                                                  mangled = __dyc_funcallvar_6;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_71:  
                                                                                  num = (size_t )0;
                                                                                  mangled ++;
                                                                                  numptr = mangled;
                                                                                  {
                                                                                  while (1) {
                                                                                    while_11_continue:  ;
                                                                                    if (! ((int const   )_sch_istable[(int const   )*mangled & 255] & 4)) {
                                                                                      goto while_11_break;
                                                                                    }
                                                                                    num ++;
                                                                                    mangled ++;
                                                                                  }
                                                                                  while_11_break:  ;
                                                                                  }
                                                                                  {
                                                                                  mangled = __dyc_funcallvar_7;



                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_72:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  mangled = __dyc_funcallvar_8;
                                                                                  tmp = __dyc_funcallvar_9;
                                                                                  sztype = (unsigned long )tmp;
                                                                                  mangled = __dyc_funcallvar_10;




                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_80:  
                                                                                  {
                                                                                  mangled ++;
                                                                                  tmp___0 = __dyc_funcallvar_11;
                                                                                  }
                                                                                  if (! tmp___0) {
                                                                                    {
                                                                                    mangled = __dyc_funcallvar_12;

                                                                                    }
                                                                                    goto __dyc_dummy_label;
                                                                                  }
                                                                                  switch_10_70:  
                                                                                  switch_10_85:  
                                                                                  switch_10_87:  
                                                                                  switch_10_86:  
                                                                                  switch_10_82:  
                                                                                  switch_10_89:  
                                                                                  {
                                                                                  mangled = __dyc_funcallvar_13;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_73:  
                                                                                  switch_10_67:  
                                                                                  switch_10_83:  
                                                                                  switch_10_69:  
                                                                                  switch_10_84:  
                                                                                  {
                                                                                  mangled ++;
                                                                                  tmp___1 = __dyc_funcallvar_14;
                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_68:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  mangled = __dyc_funcallvar_15;
                                                                                  tmp___2 = __dyc_funcallvar_16;
                                                                                  szmods = (unsigned long )tmp___2;
                                                                                  mangled = __dyc_funcallvar_17;



                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_66:  
                                                                                  {
                                                                                  mangled ++;
                                                                                  tmp___3 = __dyc_funcallvar_18;
                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_110:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_118:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_103:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_104:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_115:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_116:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_105:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_107:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_108:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_109:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_102:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_100:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_101:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_111:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_112:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_106:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_113:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_114:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_99:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_98:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_97:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_117:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_119:  
                                                                                  {
                                                                                  mangled ++;

                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_122:  
                                                                                  mangled ++;
                                                                                  if ((int )*mangled == 105) {
                                                                                    goto switch_12_105;
                                                                                  } else {
                                                                                    if ((int )*mangled == 107) {
                                                                                      goto switch_12_107;
                                                                                    } else {
                                                                                      if (0) {
                                                                                        switch_12_105:  
                                                                                        {
                                                                                        mangled ++;

                                                                                        }
                                                                                        goto __dyc_dummy_label;
                                                                                        switch_12_107:  
                                                                                        {
                                                                                        mangled ++;

                                                                                        }
                                                                                        goto __dyc_dummy_label;
                                                                                      } else {
                                                                                        switch_12_break:  ;
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                  goto __dyc_dummy_label;
                                                                                  switch_10_default:  ;
                                                                                  goto __dyc_dummy_label;
                                                                                } else {
                                                                                  switch_10_break:  ;
                                                                                }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(sztype);
  __dyc_print_ptr__char(tmp___1);
  __dyc_printpre_byte(szmods);
  __dyc_print_ptr__char(tmp___3);
  __dyc_print_ptr__char(mangled);
}
}
