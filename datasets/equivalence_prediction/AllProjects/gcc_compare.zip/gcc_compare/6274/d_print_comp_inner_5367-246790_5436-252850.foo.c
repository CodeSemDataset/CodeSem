#include "../include/dycfoo.h"
#include "../include/cp-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ struct demangle_component *type ;
  struct demangle_component *list ;
  struct demangle_operator_info  const  *op ;
  int len___0 ;
  struct demangle_component *op___0 ;
  struct demangle_component *operand ;
  char const   *code ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___58 ;
  int tmp___63 ;
  int tmp___64 ;
  int tmp___65 ;
  int tmp___66 ;
  struct demangle_component *a___1 ;
  struct demangle_component *tmp___67 ;
  int len___1 ;
  int tmp___68 ;
  int len___2 ;
  int tmp___69 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___79 ;
  int tmp___84 ;
  int tmp___85 ;
  int tmp___86 ;
  int tmp___87 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___97 ;
  int tmp___102 ;
  int tmp___103 ;
  int tmp___104 ;
  int tmp___105 ;
  struct demangle_component *dc ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  struct demangle_component *__dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;

  {
  dc = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  type = 0;
  list = 0;
  op = 0;
  len___0 = 0;
  op___0 = 0;
  operand = 0;
  code = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___58 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  tmp___66 = 0;
  a___1 = 0;
  tmp___67 = 0;
  len___1 = 0;
  tmp___68 = 0;
  len___2 = 0;
  tmp___69 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___79 = 0;
  tmp___84 = 0;
  tmp___85 = 0;
  tmp___86 = 0;
  tmp___87 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___97 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  tmp___104 = 0;
  tmp___105 = 0;
  switch_50_49:  
  type = dc->u.s_binary.left;
  list = dc->u.s_binary.right;
  if (type) {
    {

    }
  }



  goto __dyc_dummy_label;
  op = dc->u.s_operator.op;
  len___0 = (int )op->len;

  if ((int const   )*(op->name + 0) >= 97) {
    if ((int const   )*(op->name + 0) <= 122) {
      {

      }
    }
  }
  if ((int const   )*(op->name + (len___0 - 1)) == 32) {
    len___0 --;
  }

  goto __dyc_dummy_label;


  goto __dyc_dummy_label;


  goto __dyc_dummy_label;

  goto __dyc_dummy_label;
  switch_50_55:  
  op___0 = dc->u.s_binary.left;
  operand = dc->u.s_binary.right;
  code = (char const   *)((void *)0);
  if ((int )op___0->type == 50) {
    code = (char const   *)(op___0->u.s_operator.op)->code;
    if (0) {
      {
      tmp___64 = __dyc_funcallvar_18;
      __s1_len___1 = (unsigned long )tmp___64;
      tmp___65 = __dyc_funcallvar_19;
      __s2_len___1 = (unsigned long )tmp___65;
      }
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___8;
      } else {
        if (__s1_len___1 >= 4UL) {
          _L___8:  
          if (! ((unsigned long )((void const   *)("ad" + 1)) - (unsigned long )((void const   *)"ad") == 1UL)) {
            tmp___66 = 1;
          } else {
            if (__s2_len___1 >= 4UL) {
              tmp___66 = 1;
            } else {
              tmp___66 = 0;
            }
          }
        } else {
          tmp___66 = 0;
        }
      }
      if (tmp___66) {
        {
        tmp___58 = __dyc_funcallvar_20;
        }
      } else {
        {
        tmp___63 = __dyc_funcallvar_21;
        tmp___58 = tmp___63;
        }
      }
    } else {
      {
      tmp___63 = __dyc_funcallvar_22;
      tmp___58 = tmp___63;
      }
    }
    if (! tmp___58) {
      if ((int )operand->type == 3) {
        if ((int )(operand->u.s_binary.left)->type == 1) {
          if ((int )(operand->u.s_binary.right)->type == 41) {
            operand = operand->u.s_binary.left;
          }
        }
      }
    }
    if ((int )operand->type == 57) {
      {
      operand = operand->u.s_binary.left;


      }
      goto __dyc_dummy_label;
    }
  }
  if (code) {
    if (0) {
      {
      tmp___103 = __dyc_funcallvar_23;
      __s1_len___3 = (unsigned long )tmp___103;
      tmp___104 = __dyc_funcallvar_24;
      __s2_len___3 = (unsigned long )tmp___104;
      }
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___12;
      } else {
        if (__s1_len___3 >= 4UL) {
          _L___12:  
          if (! ((unsigned long )((void const   *)("sZ" + 1)) - (unsigned long )((void const   *)"sZ") == 1UL)) {
            tmp___105 = 1;
          } else {
            if (__s2_len___3 >= 4UL) {
              tmp___105 = 1;
            } else {
              tmp___105 = 0;
            }
          }
        } else {
          tmp___105 = 0;
        }
      }
      if (tmp___105) {
        {
        tmp___97 = __dyc_funcallvar_25;
        }
      } else {
        {
        tmp___102 = __dyc_funcallvar_26;
        tmp___97 = tmp___102;
        }
      }
    } else {
      {
      tmp___102 = __dyc_funcallvar_27;
      tmp___97 = tmp___102;
      }
    }
    if (tmp___97) {
      goto _L___13;
    } else {
      {
      tmp___67 = __dyc_funcallvar_28;
      a___1 = tmp___67;
      tmp___68 = __dyc_funcallvar_29;
      len___1 = tmp___68;

      }
      goto __dyc_dummy_label;
    }
  } else {
    _L___13:  
    if (code) {
      if (0) {
        {
        tmp___85 = __dyc_funcallvar_30;
        __s1_len___2 = (unsigned long )tmp___85;
        tmp___86 = __dyc_funcallvar_31;
        __s2_len___2 = (unsigned long )tmp___86;
        }
        if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
          goto _L___10;
        } else {
          if (__s1_len___2 >= 4UL) {
            _L___10:  
            if (! ((unsigned long )((void const   *)("sP" + 1)) - (unsigned long )((void const   *)"sP") == 1UL)) {
              tmp___87 = 1;
            } else {
              if (__s2_len___2 >= 4UL) {
                tmp___87 = 1;
              } else {
                tmp___87 = 0;
              }
            }
          } else {
            tmp___87 = 0;
          }
        }
        if (tmp___87) {
          {
          tmp___79 = __dyc_funcallvar_32;
          }
        } else {
          {
          tmp___84 = __dyc_funcallvar_33;
          tmp___79 = tmp___84;
          }
        }
      } else {
        {
        tmp___84 = __dyc_funcallvar_34;
        tmp___79 = tmp___84;
        }
      }
      if (! tmp___79) {
        {
        tmp___69 = __dyc_funcallvar_35;
        len___2 = tmp___69;

        }
        goto __dyc_dummy_label;
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__comp_46demangle_component(list);
  __dyc_printpre_byte(len___0);
  __dyc_print_ptr__comp_46demangle_component(operand);
  __dyc_print_ptr__char(code);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_print_ptr__comp_46demangle_component(a___1);
  __dyc_printpre_byte(len___1);
  __dyc_printpre_byte(len___2);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
}
}
