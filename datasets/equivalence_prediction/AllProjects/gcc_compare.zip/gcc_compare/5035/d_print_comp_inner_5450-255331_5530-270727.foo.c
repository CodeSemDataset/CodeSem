#include "../include/dycfoo.h"
#include "../include/cp-demangle.i.hd.c.h"
void __dyc_foo(void) 
{ struct demangle_component *op___0 ;
  char const   *code ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___115 ;
  int tmp___120 ;
  int tmp___121 ;
  int tmp___122 ;
  int tmp___123 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___133 ;
  int tmp___138 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  int tmp___142 ;
  int tmp___143 ;
  struct demangle_component  const  *func ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___153 ;
  int tmp___158 ;
  int tmp___159 ;
  int tmp___160 ;
  int tmp___161 ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___171 ;
  int tmp___176 ;
  int tmp___177 ;
  int tmp___178 ;
  int tmp___179 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___189 ;
  int tmp___194 ;
  int tmp___195 ;
  int tmp___196 ;
  int tmp___197 ;
  struct demangle_component *dc ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;

  {
  op___0 = __dyc_read_ptr__comp_46demangle_component();
  code = (char const   *)__dyc_read_ptr__char();
  dc = __dyc_read_ptr__comp_46demangle_component();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___115 = 0;
  tmp___120 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  tmp___123 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___133 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  tmp___142 = 0;
  tmp___143 = 0;
  func = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___153 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  tmp___161 = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___171 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  tmp___178 = 0;
  tmp___179 = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___189 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  tmp___196 = 0;
  tmp___197 = 0;
  if ((int )op___0->type != 52) {
    {

    }
  } else {
    {



    }
  }
  if (code) {
    if (0) {
      {
      tmp___139 = __dyc_funcallvar_36;
      __s1_len___5 = (unsigned long )tmp___139;
      tmp___140 = __dyc_funcallvar_37;
      __s2_len___5 = (unsigned long )tmp___140;
      }
      if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
        goto _L___17;
      } else {
        if (__s1_len___5 >= 4UL) {
          _L___17:  
          if (! ((unsigned long )((void const   *)("gs" + 1)) - (unsigned long )((void const   *)"gs") == 1UL)) {
            tmp___141 = 1;
          } else {
            if (__s2_len___5 >= 4UL) {
              tmp___141 = 1;
            } else {
              tmp___141 = 0;
            }
          }
        } else {
          tmp___141 = 0;
        }
      }
      if (tmp___141) {
        {
        tmp___133 = __dyc_funcallvar_38;
        }
      } else {
        {
        tmp___138 = __dyc_funcallvar_39;
        tmp___133 = tmp___138;
        }
      }
    } else {
      {
      tmp___138 = __dyc_funcallvar_40;
      tmp___133 = tmp___138;
      }
    }
    if (tmp___133) {
      goto _L___18;
    } else {
      {

      }
    }
  } else {
    _L___18:  
    if (code) {
      if (0) {
        {
        tmp___121 = __dyc_funcallvar_41;
        __s1_len___4 = (unsigned long )tmp___121;
        tmp___122 = __dyc_funcallvar_42;
        __s2_len___4 = (unsigned long )tmp___122;
        }
        if (! ((unsigned long )((void const   *)(code + 1)) - (unsigned long )((void const   *)code) == 1UL)) {
          goto _L___15;
        } else {
          if (__s1_len___4 >= 4UL) {
            _L___15:  
            if (! ((unsigned long )((void const   *)("st" + 1)) - (unsigned long )((void const   *)"st") == 1UL)) {
              tmp___123 = 1;
            } else {
              if (__s2_len___4 >= 4UL) {
                tmp___123 = 1;
              } else {
                tmp___123 = 0;
              }
            }
          } else {
            tmp___123 = 0;
          }
        }
        if (tmp___123) {
          {
          tmp___115 = __dyc_funcallvar_43;
          }
        } else {
          {
          tmp___120 = __dyc_funcallvar_44;
          tmp___115 = tmp___120;
          }
        }
      } else {
        {
        tmp___120 = __dyc_funcallvar_45;
        tmp___115 = tmp___120;
        }
      }
      if (tmp___115) {
        {

        }
      } else {
        {



        }
      }
    } else {
      {

      }
    }
  }
  goto __dyc_dummy_label;
  switch_50_56:  
  if ((int )(dc->u.s_binary.right)->type != 57) {
    {

    }
    goto __dyc_dummy_label;
  }
  tmp___142 = __dyc_funcallvar_46;
  if (tmp___142) {
    {






    }
    goto __dyc_dummy_label;
  }
  tmp___143 = __dyc_funcallvar_47;
  if (tmp___143) {
    goto __dyc_dummy_label;
  }
  if ((int )(dc->u.s_binary.left)->type == 50) {
    if (((dc->u.s_binary.left)->u.s_operator.op)->len == 1) {
      if ((int const   )*(((dc->u.s_binary.left)->u.s_operator.op)->name + 0) == 62) {
        {

        }
      }
    }
  }
  if (0) {
    {
    tmp___159 = __dyc_funcallvar_48;
    __s1_len___6 = (unsigned long )tmp___159;
    tmp___160 = __dyc_funcallvar_49;
    __s2_len___6 = (unsigned long )tmp___160;
    }
    if (! ((unsigned long )((void const   *)(((dc->u.s_binary.left)->u.s_operator.op)->code + 1)) - (unsigned long )((void const   *)((dc->u.s_binary.left)->u.s_operator.op)->code) == 1UL)) {
      goto _L___20;
    } else {
      if (__s1_len___6 >= 4UL) {
        _L___20:  
        if (! ((unsigned long )((void const   *)("cl" + 1)) - (unsigned long )((void const   *)"cl") == 1UL)) {
          tmp___161 = 1;
        } else {
          if (__s2_len___6 >= 4UL) {
            tmp___161 = 1;
          } else {
            tmp___161 = 0;
          }
        }
      } else {
        tmp___161 = 0;
      }
    }
    if (tmp___161) {
      {
      tmp___153 = __dyc_funcallvar_50;
      }
    } else {
      {
      tmp___158 = __dyc_funcallvar_51;
      tmp___153 = tmp___158;
      }
    }
  } else {
    {
    tmp___158 = __dyc_funcallvar_52;
    tmp___153 = tmp___158;
    }
  }
  if (tmp___153 == 0) {
    if ((int )((dc->u.s_binary.right)->u.s_binary.left)->type == 3) {
      func = (struct demangle_component  const  *)(dc->u.s_binary.right)->u.s_binary.left;
      if ((int )(func->u.s_binary.right)->type != 41) {
        {

        }
      }
      {

      }
    } else {
      {

      }
    }
  } else {
    {

    }
  }
  if (0) {
    {
    tmp___195 = __dyc_funcallvar_53;
    __s1_len___8 = (unsigned long )tmp___195;
    tmp___196 = __dyc_funcallvar_54;
    __s2_len___8 = (unsigned long )tmp___196;
    }
    if (! ((unsigned long )((void const   *)(((dc->u.s_binary.left)->u.s_operator.op)->code + 1)) - (unsigned long )((void const   *)((dc->u.s_binary.left)->u.s_operator.op)->code) == 1UL)) {
      goto _L___24;
    } else {
      if (__s1_len___8 >= 4UL) {
        _L___24:  
        if (! ((unsigned long )((void const   *)("ix" + 1)) - (unsigned long )((void const   *)"ix") == 1UL)) {
          tmp___197 = 1;
        } else {
          if (__s2_len___8 >= 4UL) {
            tmp___197 = 1;
          } else {
            tmp___197 = 0;
          }
        }
      } else {
        tmp___197 = 0;
      }
    }
    if (tmp___197) {
      {
      tmp___189 = __dyc_funcallvar_55;
      }
    } else {
      {
      tmp___194 = __dyc_funcallvar_56;
      tmp___189 = tmp___194;
      }
    }
  } else {
    {
    tmp___194 = __dyc_funcallvar_57;
    tmp___189 = tmp___194;
    }
  }
  if (tmp___189 == 0) {
    {



    }
  } else {
    if (0) {
      {
      tmp___177 = __dyc_funcallvar_58;
      __s1_len___7 = (unsigned long )tmp___177;
      tmp___178 = __dyc_funcallvar_59;
      __s2_len___7 = (unsigned long )tmp___178;
      }
      if (! ((unsigned long )((void const   *)(((dc->u.s_binary.left)->u.s_operator.op)->code + 1)) - (unsigned long )((void const   *)((dc->u.s_binary.left)->u.s_operator.op)->code) == 1UL)) {
        goto _L___22;
      } else {
        if (__s1_len___7 >= 4UL) {
          _L___22:  
          if (! ((unsigned long )((void const   *)("cl" + 1)) - (unsigned long )((void const   *)"cl") == 1UL)) {
            tmp___179 = 1;
          } else {
            if (__s2_len___7 >= 4UL) {
              tmp___179 = 1;
            } else {
              tmp___179 = 0;
            }
          }
        } else {
          tmp___179 = 0;
        }
      }
      if (tmp___179) {
        {
        tmp___171 = __dyc_funcallvar_60;
        }
      } else {
        {
        tmp___176 = __dyc_funcallvar_61;
        tmp___171 = tmp___176;
        }
      }
    } else {
      {
      tmp___176 = __dyc_funcallvar_62;
      tmp___171 = tmp___176;
      }
    }
    if (tmp___171 != 0) {
      {

      }
    }
    {

    }
  }
  if ((int )(dc->u.s_binary.left)->type == 50) {
    if (((dc->u.s_binary.left)->u.s_operator.op)->len == 1) {
      if ((int const   )*(((dc->u.s_binary.left)->u.s_operator.op)->name + 0) == 62) {
        {

        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
}
}
