#include "../include/dycfoo.h"
#include "../include/hmac.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char hmac_ipad ;
  unsigned char hmac_opad ;
  size_t i ;
  struct HMAC_context *ctxt ;
  unsigned char *hkey ;
  unsigned char b ;
  void *tmp ;
  unsigned char const   *tmp___0 ;
  struct HMAC_params  const  *hashparams ;
  unsigned char const   *key ;
  unsigned int keylen ;

  {
  hmac_ipad = (unsigned char const   )__dyc_readpre_byte();
  hmac_opad = (unsigned char const   )__dyc_readpre_byte();
  tmp = __dyc_read_ptr__void();
  hashparams = (struct HMAC_params  const  *)__dyc_read_ptr__comp_77HMAC_params();
  key = (unsigned char const   *)__dyc_read_ptr__char();
  keylen = (unsigned int )__dyc_readpre_byte();
  i = 0;
  ctxt = 0;
  hkey = 0;
  b = 0;
  tmp___0 = 0;
  ctxt = (struct HMAC_context *)tmp;
  if (! ctxt) {
    goto __dyc_dummy_label;
  }
  ctxt->hmac_hash = hashparams;
  ctxt->hmac_hashctxt1 = (void *)(ctxt + 1);
  ctxt->hmac_hashctxt2 = (void *)((char *)ctxt->hmac_hashctxt1 + hashparams->hmac_ctxtsize);
  if (keylen > (unsigned int )hashparams->hmac_maxkeylen) {
    {


    hkey = (unsigned char *)ctxt->hmac_hashctxt2 + hashparams->hmac_ctxtsize;

    key = (unsigned char const   *)hkey;
    keylen = (unsigned int )hashparams->hmac_resultlen;
    }
  }


  i = 0UL;
  while (1) {
    while_0_continue:  ;
    if (! (i < (size_t )keylen)) {
      goto while_0_break;
    }
    {
    b = (unsigned char )((int const   )*key ^ (int const   )hmac_ipad);

    tmp___0 = key;
    key ++;
    b = (unsigned char )((int const   )*tmp___0 ^ (int const   )hmac_opad);

    i ++;
    }
  }
  while_0_break:  ;
  while (1) {
    while_1_continue:  ;
    if (! (i < (size_t )hashparams->hmac_maxkeylen)) {
      goto __dyc_dummy_label;
    }
    {


    i ++;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(b);
  __dyc_print_ptr__char(key);
}
}
