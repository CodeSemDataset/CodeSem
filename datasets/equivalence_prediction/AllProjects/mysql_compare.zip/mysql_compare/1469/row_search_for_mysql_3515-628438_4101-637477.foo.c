#include "../include/dycfoo.h"
#include "../include/row0sel.i.hd.c.h"
void __dyc_foo(void) 
{ ulint srv_locks_unsafe_for_binlog ;
  ulint srv_force_recovery ;
  dict_index_t *index___0 ;
  ulint comp ;
  btr_pcur_t *pcur ;
  trx_t *trx ;
  dict_index_t *clust_index ;
  que_thr_t *thr ;
  rec_t *rec ;
  rec_t *result_rec ;
  rec_t *clust_rec ;
  rec_t *old_vers ;
  ulint err ;
  ulint unique_search ;
  ulint unique_search_from_clust_index ;
  ulint mtr_has_extra_clust_latch ;
  ulint moves_up ;
  ulint set_also_gap_locks ;
  ulint next_offs ;
  ulint same_user_rec ;
  ulint *offsets ;
  ulint tmp___21 ;
  ulint tmp___22 ;
  long tmp___23 ;
  long tmp___24 ;
  buf_frame_t *tmp___25 ;
  buf_block_t *tmp___26 ;
  ulint tmp___27 ;
  ulint tmp___28 ;
  ulint tmp___29 ;
  ulint tmp___30 ;
  long tmp___31 ;
  ulint tmp___32 ;
  ulint tmp___33 ;
  ulint tmp___34 ;
  ulint tmp___35 ;
  long tmp___36 ;
  int tmp___37 ;
  ulint tmp___38 ;
  ulint lock_type ;
  ulint tmp___39 ;
  long tmp___40 ;
  ulint tmp___41 ;
  ulint tmp___42 ;
  int tmp___43 ;
  long tmp___44 ;
  ulint tmp___45 ;
  ulint tmp___46 ;
  ulint tmp___47 ;
  long tmp___48 ;
  ulint tmp___49 ;
  long tmp___50 ;
  ulint tmp___51 ;
  ulint tmp___52 ;
  ulint tmp___53 ;
  ulint tmp___54 ;
  ulint tmp___55 ;
  long tmp___56 ;
  ulint tmp___57 ;
  int tmp___58 ;
  long tmp___59 ;
  ulint tmp___60 ;
  int tmp___61 ;
  long tmp___62 ;
  ulint tmp___63 ;
  ulint mode ;
  row_prebuilt_t *prebuilt ;
  ulint match_mode ;
  ulint direction ;
  ulint __dyc_funcallvar_27 ;
  ulint *__dyc_funcallvar_28 ;
  ulint __dyc_funcallvar_29 ;
  ulint __dyc_funcallvar_30 ;
  long __dyc_funcallvar_31 ;
  ulint __dyc_funcallvar_32 ;
  long __dyc_funcallvar_33 ;
  long __dyc_funcallvar_34 ;
  buf_frame_t *__dyc_funcallvar_35 ;
  buf_block_t *__dyc_funcallvar_36 ;
  ulint __dyc_funcallvar_37 ;
  ulint __dyc_funcallvar_38 ;
  ulint __dyc_funcallvar_39 ;
  ulint __dyc_funcallvar_40 ;
  ulint *__dyc_funcallvar_41 ;
  long __dyc_funcallvar_42 ;
  ulint __dyc_funcallvar_43 ;
  ulint __dyc_funcallvar_44 ;
  ulint __dyc_funcallvar_45 ;
  ulint __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  ulint __dyc_funcallvar_48 ;
  ulint __dyc_funcallvar_49 ;
  ulint __dyc_funcallvar_50 ;
  ulint __dyc_funcallvar_51 ;
  long __dyc_funcallvar_52 ;
  ulint __dyc_funcallvar_53 ;
  ulint __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  ulint __dyc_funcallvar_56 ;
  long __dyc_funcallvar_57 ;
  ulint __dyc_funcallvar_58 ;
  ulint __dyc_funcallvar_59 ;
  ulint __dyc_funcallvar_60 ;
  ulint __dyc_funcallvar_61 ;
  long __dyc_funcallvar_62 ;
  ulint __dyc_funcallvar_63 ;
  ulint __dyc_funcallvar_64 ;
  long __dyc_funcallvar_65 ;
  ulint *__dyc_funcallvar_66 ;
  ulint __dyc_funcallvar_67 ;
  ulint __dyc_funcallvar_68 ;
  ulint __dyc_funcallvar_69 ;
  ulint __dyc_funcallvar_70 ;
  ulint *__dyc_funcallvar_71 ;
  long __dyc_funcallvar_72 ;
  ulint __dyc_funcallvar_73 ;
  ulint __dyc_funcallvar_74 ;
  long __dyc_funcallvar_75 ;
  ulint __dyc_funcallvar_76 ;
  long __dyc_funcallvar_77 ;
  ulint __dyc_funcallvar_78 ;

  {
  srv_locks_unsafe_for_binlog = (ulint )__dyc_readpre_byte();
  srv_force_recovery = (ulint )__dyc_readpre_byte();
  index___0 = __dyc_read_ptr__typdef_dict_index_t();
  comp = (ulint )__dyc_readpre_byte();
  pcur = __dyc_read_ptr__typdef_btr_pcur_t();
  trx = __dyc_read_ptr__typdef_trx_t();
  clust_index = __dyc_read_ptr__typdef_dict_index_t();
  thr = __dyc_read_ptr__typdef_que_thr_t();
  rec = __dyc_read_ptr__typdef_rec_t();
  clust_rec = __dyc_read_ptr__typdef_rec_t();
  old_vers = __dyc_read_ptr__typdef_rec_t();
  unique_search = (ulint )__dyc_readpre_byte();
  unique_search_from_clust_index = (ulint )__dyc_readpre_byte();
  moves_up = (ulint )__dyc_readpre_byte();
  set_also_gap_locks = (ulint )__dyc_readpre_byte();
  same_user_rec = (ulint )__dyc_readpre_byte();
  tmp___21 = (ulint )__dyc_readpre_byte();
  mode = (ulint )__dyc_readpre_byte();
  prebuilt = __dyc_read_ptr__typdef_row_prebuilt_t();
  match_mode = (ulint )__dyc_readpre_byte();
  direction = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_27 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_read_ptr__typdef_ulint();
  __dyc_funcallvar_29 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_30 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_31 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_32 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_33 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_34 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_read_ptr__typdef_buf_frame_t();
  __dyc_funcallvar_36 = __dyc_read_ptr__typdef_buf_block_t();
  __dyc_funcallvar_37 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_38 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_39 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_40 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_read_ptr__typdef_ulint();
  __dyc_funcallvar_42 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_43 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_44 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_45 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_46 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_49 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_50 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_51 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_52 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_53 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_54 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_57 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_58 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_59 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_60 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_61 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_62 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_63 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_64 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_65 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_read_ptr__typdef_ulint();
  __dyc_funcallvar_67 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_68 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_69 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_70 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_read_ptr__typdef_ulint();
  __dyc_funcallvar_72 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_73 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_74 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_75 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_76 = (ulint )__dyc_readpre_byte();
  __dyc_funcallvar_77 = (long )__dyc_readpre_byte();
  __dyc_funcallvar_78 = (ulint )__dyc_readpre_byte();
  result_rec = 0;
  err = 0;
  mtr_has_extra_clust_latch = 0;
  next_offs = 0;
  offsets = 0;
  tmp___22 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  tmp___36 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  lock_type = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  tmp___46 = 0;
  tmp___47 = 0;
  tmp___48 = 0;
  tmp___49 = 0;
  tmp___50 = 0;
  tmp___51 = 0;
  tmp___52 = 0;
  tmp___53 = 0;
  tmp___54 = 0;
  tmp___55 = 0;
  tmp___56 = 0;
  tmp___57 = 0;
  tmp___58 = 0;
  tmp___59 = 0;
  tmp___60 = 0;
  tmp___61 = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  if (tmp___21) {
    goto __dyc_dummy_label;
  }
  tmp___22 = __dyc_funcallvar_27;
  if (tmp___22) {
    if (set_also_gap_locks) {
      if (! srv_locks_unsafe_for_binlog) {
        if (prebuilt->select_lock_type != 0UL) {
          {
          offsets = __dyc_funcallvar_28;
          err = __dyc_funcallvar_29;
          }
          if (err != 10UL) {
            goto __dyc_dummy_label;
          }
        }
      }
    }
    goto __dyc_dummy_label;
  }
  if (comp) {
    {
    next_offs = __dyc_funcallvar_30;
    tmp___23 = __dyc_funcallvar_31;
    }
    if (tmp___23) {
      goto wrong_offs;
    }
  } else {
    {
    next_offs = __dyc_funcallvar_32;
    tmp___24 = __dyc_funcallvar_33;
    }
    if (tmp___24) {
      goto wrong_offs;
    }
  }
  tmp___31 = __dyc_funcallvar_34;
  if (tmp___31) {
    wrong_offs: 
    if (srv_force_recovery == 0UL) {
      goto _L___0;
    } else {
      if (moves_up == 0UL) {
        _L___0:  
        {

        tmp___25 = __dyc_funcallvar_35;

        tmp___26 = __dyc_funcallvar_36;

        tmp___27 = __dyc_funcallvar_37;
        tmp___28 = __dyc_funcallvar_38;



        err = 39UL;
        }
        goto __dyc_dummy_label;
      } else {
        {
        tmp___29 = __dyc_funcallvar_39;
        tmp___30 = __dyc_funcallvar_40;




        }
        goto __dyc_dummy_label;
      }
    }
  }
  offsets = __dyc_funcallvar_41;
  tmp___36 = __dyc_funcallvar_42;
  if (tmp___36) {
    {
    tmp___34 = __dyc_funcallvar_43;
    }
    if (tmp___34) {
      {
      tmp___35 = __dyc_funcallvar_44;
      }
      if (! tmp___35) {
        _L___1:  
        {
        tmp___32 = __dyc_funcallvar_45;
        tmp___33 = __dyc_funcallvar_46;



        }
        goto __dyc_dummy_label;
      }
    } else {
      goto _L___1;
    }
  }
  if (match_mode == 1UL) {
    {
    tmp___37 = __dyc_funcallvar_47;
    }
    if (0 != tmp___37) {
      if (set_also_gap_locks) {
        if (! srv_locks_unsafe_for_binlog) {
          if (prebuilt->select_lock_type != 0UL) {
            {
            err = __dyc_funcallvar_48;
            }
            if (err != 10UL) {
              goto __dyc_dummy_label;
            }
          }
        }
      }
      {

      err = 1500UL;
      }
      goto __dyc_dummy_label;
    }
  } else {
    if (match_mode == 2UL) {
      {
      tmp___38 = __dyc_funcallvar_49;
      }
      if (! tmp___38) {
        if (set_also_gap_locks) {
          if (! srv_locks_unsafe_for_binlog) {
            if (prebuilt->select_lock_type != 0UL) {
              {
              err = __dyc_funcallvar_50;
              }
              if (err != 10UL) {
                goto __dyc_dummy_label;
              }
            }
          }
        }
        {

        err = 1500UL;
        }
        goto __dyc_dummy_label;
      }
    }
  }
  if (prebuilt->select_lock_type != 0UL) {
    if (! set_also_gap_locks) {
      goto no_gap_lock;
    } else {
      if (srv_locks_unsafe_for_binlog) {
        goto no_gap_lock;
      } else {
        if (unique_search) {
          {
          tmp___39 = __dyc_funcallvar_51;
          tmp___40 = __dyc_funcallvar_52;
          }
          if (tmp___40) {
            lock_type = 0UL;
          } else {
            goto no_gap_lock;
          }
        } else {
          lock_type = 0UL;
        }
      }
    }
    if ((unsigned long )index___0 == (unsigned long )clust_index) {
      if (mode == 2UL) {
        if (direction == 0UL) {
          {
          tmp___41 = __dyc_funcallvar_53;
          tmp___42 = __dyc_funcallvar_54;
          }
          if (tmp___41 == tmp___42) {
            {
            tmp___43 = __dyc_funcallvar_55;
            }
            if (0 == tmp___43) {
              no_gap_lock: 
              lock_type = 1024UL;
            }
          }
        }
      }
    }
    {
    err = __dyc_funcallvar_56;
    }
    if (err != 10UL) {
      goto __dyc_dummy_label;
    }
  } else {
    if (! (trx->isolation_level == 1UL)) {
      if ((unsigned long )index___0 == (unsigned long )clust_index) {
        {
        tmp___44 = __dyc_funcallvar_57;
        }
        if (tmp___44) {
          {
          tmp___45 = __dyc_funcallvar_58;
          }
          if (! tmp___45) {
            {
            err = __dyc_funcallvar_59;
            }
            if (err != 10UL) {
              goto __dyc_dummy_label;
            }
            if ((unsigned long )old_vers == (unsigned long )((void *)0)) {
              goto __dyc_dummy_label;
            }
            rec = old_vers;
          }
        }
      } else {
        {
        tmp___46 = __dyc_funcallvar_60;
        }
        if (! tmp___46) {
          goto requires_clust_rec;
        }
      }
    }
  }
  tmp___47 = __dyc_funcallvar_61;
  tmp___48 = __dyc_funcallvar_62;
  if (tmp___48) {
    if (srv_locks_unsafe_for_binlog) {
      if (prebuilt->select_lock_type != 0UL) {
        {


        }
      }
    }
    goto __dyc_dummy_label;
  }
  if ((unsigned long )index___0 != (unsigned long )clust_index) {
    if (prebuilt->need_to_access_clustered) {
      requires_clust_rec: 
      {
      mtr_has_extra_clust_latch = 1UL;
      err = __dyc_funcallvar_63;
      }
      if (err != 10UL) {
        goto __dyc_dummy_label;
      }
      if ((unsigned long )clust_rec == (unsigned long )((void *)0)) {
        goto __dyc_dummy_label;
      }
      {
      tmp___49 = __dyc_funcallvar_64;
      tmp___50 = __dyc_funcallvar_65;
      }
      if (tmp___50) {
        if (srv_locks_unsafe_for_binlog) {
          if (prebuilt->select_lock_type != 0UL) {
            {


            }
          }
        }
        goto __dyc_dummy_label;
      }
      if (prebuilt->need_to_access_clustered) {
        result_rec = clust_rec;
      } else {
        {
        offsets = __dyc_funcallvar_66;
        result_rec = rec;
        }
      }
    } else {
      result_rec = rec;
    }
  } else {
    result_rec = rec;
  }
  if (match_mode == 1UL) {
    goto _L___7;
  } else {
    if (prebuilt->n_rows_fetched >= 4UL) {
      _L___7:  
      if (prebuilt->select_lock_type == 0UL) {
        if (! prebuilt->templ_contains_blob) {
          if (! prebuilt->clust_index_was_generated) {
            if (! prebuilt->used_in_HANDLER) {
              if (prebuilt->template_type != 3UL) {
                {

                }
                if (prebuilt->n_fetch_cached == 8UL) {
                  goto got_row;
                }
                goto __dyc_dummy_label;
              } else {
                goto _L___6;
              }
            } else {
              goto _L___6;
            }
          } else {
            goto _L___6;
          }
        } else {
          goto _L___6;
        }
      } else {
        goto _L___6;
      }
    } else {
      _L___6:  
      if (prebuilt->template_type == 3UL) {
        {
        tmp___51 = __dyc_funcallvar_67;
        tmp___52 = __dyc_funcallvar_68;

        tmp___53 = __dyc_funcallvar_69;

        }
      } else {
        {
        tmp___54 = __dyc_funcallvar_70;
        }
        if (! tmp___54) {
          err = 34UL;
          goto __dyc_dummy_label;
        }
      }
      if (prebuilt->clust_index_was_generated) {
        if ((unsigned long )result_rec != (unsigned long )rec) {
          {
          offsets = __dyc_funcallvar_71;
          }
        }
        {

        }
      }
    }
  }
  got_row: 
  if (! unique_search_from_clust_index) {
    {

    }
  } else {
    if (prebuilt->select_lock_type != 0UL) {
      {

      }
    } else {
      if (prebuilt->used_in_HANDLER) {
        {

        }
      }
    }
  }
  err = 10UL;
  goto __dyc_dummy_label;
  tmp___56 = __dyc_funcallvar_72;
  if (tmp___56) {
    {


    mtr_has_extra_clust_latch = 0UL;

    tmp___55 = __dyc_funcallvar_73;
    }
    if (tmp___55) {
      goto __dyc_dummy_label;
    }
  }
  if (moves_up) {
    {
    tmp___57 = __dyc_funcallvar_74;
    }
    if (tmp___57) {
      tmp___58 = 0;
    } else {
      tmp___58 = 1;
    }
    {
    tmp___59 = __dyc_funcallvar_75;
    }
    if (tmp___59) {
      not_moved: 
      {

      }
      if (match_mode != 0UL) {
        err = 1500UL;
      } else {
        err = 1501UL;
      }
      goto __dyc_dummy_label;
    }
  } else {
    {
    tmp___60 = __dyc_funcallvar_76;
    }
    if (tmp___60) {
      tmp___61 = 0;
    } else {
      tmp___61 = 1;
    }
    {
    tmp___62 = __dyc_funcallvar_77;
    }
    if (tmp___62) {
      goto not_moved;
    }
  }
  goto __dyc_dummy_label;


  mtr_has_extra_clust_latch = 0UL;
  trx->error_state = err;

  thr->lock_state = 1UL;
  tmp___63 = __dyc_funcallvar_78;
  if (tmp___63) {
    {
    thr->lock_state = 0UL;


    }
    if (srv_locks_unsafe_for_binlog) {
      if (! same_user_rec) {
        {

        }
      }
    }
    mode = pcur->search_mode;
    goto __dyc_dummy_label;
  }
  thr->lock_state = 0UL;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_rec_t(rec);
  __dyc_print_ptr__typdef_rec_t(result_rec);
  __dyc_printpre_byte(err);
  __dyc_printpre_byte(mtr_has_extra_clust_latch);
  __dyc_printpre_byte(next_offs);
  __dyc_print_ptr__typdef_ulint(offsets);
  __dyc_print_ptr__typdef_buf_frame_t(tmp___25);
  __dyc_print_ptr__typdef_buf_block_t(tmp___26);
  __dyc_printpre_byte(tmp___27);
  __dyc_printpre_byte(tmp___28);
  __dyc_printpre_byte(tmp___29);
  __dyc_printpre_byte(tmp___30);
  __dyc_printpre_byte(tmp___32);
  __dyc_printpre_byte(tmp___33);
  __dyc_printpre_byte(lock_type);
  __dyc_printpre_byte(tmp___39);
  __dyc_printpre_byte(tmp___47);
  __dyc_printpre_byte(tmp___49);
  __dyc_printpre_byte(tmp___51);
  __dyc_printpre_byte(tmp___52);
  __dyc_printpre_byte(tmp___53);
  __dyc_printpre_byte(tmp___58);
  __dyc_printpre_byte(tmp___61);
  __dyc_printpre_byte(mode);
}
}
