#include "../include/dycfoo.h"
#include "../include/format.i.hd.c.h"
void __dyc_foo(void) 
{ struct window_pane *wp ;
  char const   *copy ;
  char const   *cp ;
  char *condition ;
  char *found ;
  char *new ;
  char *value ;
  char *left ;
  char *right ;
  struct format_modifier *cmp ;
  struct format_modifier *mexp ;
  int tmp___126 ;
  int tmp___127 ;
  int tmp___128 ;
  int tmp___129 ;
  int tmp___130 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___140 ;
  int tmp___145 ;
  int tmp___146 ;
  int tmp___147 ;
  int tmp___148 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___158 ;
  int tmp___163 ;
  int tmp___164 ;
  int tmp___165 ;
  int tmp___166 ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___176 ;
  int tmp___181 ;
  int tmp___182 ;
  int tmp___183 ;
  int tmp___184 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___194 ;
  int tmp___199 ;
  int tmp___200 ;
  int tmp___201 ;
  int tmp___202 ;
  size_t __s1_len___9 ;
  size_t __s2_len___9 ;
  int tmp___212 ;
  int tmp___217 ;
  int tmp___218 ;
  int tmp___219 ;
  int tmp___220 ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___230 ;
  int tmp___235 ;
  int tmp___236 ;
  int tmp___237 ;
  int tmp___238 ;
  size_t __s1_len___11 ;
  size_t __s2_len___11 ;
  int tmp___248 ;
  int tmp___253 ;
  int tmp___254 ;
  int tmp___255 ;
  int tmp___256 ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___266 ;
  int tmp___271 ;
  int tmp___272 ;
  int tmp___273 ;
  int tmp___274 ;
  size_t __s1_len___13 ;
  size_t __s2_len___13 ;
  int tmp___284 ;
  int tmp___289 ;
  int tmp___290 ;
  int tmp___291 ;
  int tmp___292 ;
  size_t __s1_len___14 ;
  size_t __s2_len___14 ;
  int tmp___302 ;
  int tmp___307 ;
  int tmp___308 ;
  int tmp___309 ;
  int tmp___310 ;
  size_t __s1_len___15 ;
  size_t __s2_len___15 ;
  int tmp___320 ;
  int tmp___325 ;
  int tmp___326 ;
  int tmp___327 ;
  int tmp___328 ;
  size_t __s1_len___16 ;
  size_t __s2_len___16 ;
  int tmp___338 ;
  int tmp___343 ;
  int tmp___344 ;
  int tmp___345 ;
  int tmp___346 ;
  size_t __s1_len___17 ;
  size_t __s2_len___17 ;
  int tmp___356 ;
  int tmp___361 ;
  int tmp___362 ;
  int tmp___363 ;
  int tmp___364 ;
  size_t __s1_len___18 ;
  size_t __s2_len___18 ;
  int tmp___374 ;
  int tmp___379 ;
  int tmp___380 ;
  int tmp___381 ;
  int tmp___382 ;
  size_t __s1_len___19 ;
  size_t __s2_len___19 ;
  int tmp___392 ;
  int tmp___397 ;
  int tmp___398 ;
  int tmp___399 ;
  int tmp___400 ;
  size_t __s1_len___20 ;
  size_t __s2_len___20 ;
  int tmp___410 ;
  int tmp___415 ;
  int tmp___416 ;
  int tmp___417 ;
  int tmp___418 ;
  int tmp___419 ;
  int tmp___420 ;
  char *tmp___421 ;
  char *__dyc_funcallvar_53 ;
  char *__dyc_funcallvar_54 ;
  char *__dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  char *__dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  char *__dyc_funcallvar_65 ;
  char *__dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  char *__dyc_funcallvar_74 ;
  char *__dyc_funcallvar_75 ;
  char *__dyc_funcallvar_76 ;
  int __dyc_funcallvar_77 ;
  int __dyc_funcallvar_78 ;
  int __dyc_funcallvar_79 ;
  int __dyc_funcallvar_80 ;
  int __dyc_funcallvar_81 ;
  int __dyc_funcallvar_82 ;
  int __dyc_funcallvar_83 ;
  int __dyc_funcallvar_84 ;
  int __dyc_funcallvar_85 ;
  int __dyc_funcallvar_86 ;
  char *__dyc_funcallvar_87 ;
  char *__dyc_funcallvar_88 ;
  int __dyc_funcallvar_89 ;
  int __dyc_funcallvar_90 ;
  int __dyc_funcallvar_91 ;
  int __dyc_funcallvar_92 ;
  int __dyc_funcallvar_93 ;
  int __dyc_funcallvar_94 ;
  int __dyc_funcallvar_95 ;
  int __dyc_funcallvar_96 ;
  int __dyc_funcallvar_97 ;
  int __dyc_funcallvar_98 ;
  char *__dyc_funcallvar_99 ;
  char *__dyc_funcallvar_100 ;
  int __dyc_funcallvar_101 ;
  int __dyc_funcallvar_102 ;
  int __dyc_funcallvar_103 ;
  int __dyc_funcallvar_104 ;
  int __dyc_funcallvar_105 ;
  int __dyc_funcallvar_106 ;
  int __dyc_funcallvar_107 ;
  int __dyc_funcallvar_108 ;
  int __dyc_funcallvar_109 ;
  int __dyc_funcallvar_110 ;
  char *__dyc_funcallvar_111 ;
  char *__dyc_funcallvar_112 ;
  int __dyc_funcallvar_113 ;
  int __dyc_funcallvar_114 ;
  int __dyc_funcallvar_115 ;
  int __dyc_funcallvar_116 ;
  int __dyc_funcallvar_117 ;
  int __dyc_funcallvar_118 ;
  int __dyc_funcallvar_119 ;
  int __dyc_funcallvar_120 ;
  int __dyc_funcallvar_121 ;
  int __dyc_funcallvar_122 ;
  char *__dyc_funcallvar_123 ;
  char *__dyc_funcallvar_124 ;
  int __dyc_funcallvar_125 ;
  int __dyc_funcallvar_126 ;
  int __dyc_funcallvar_127 ;
  int __dyc_funcallvar_128 ;
  int __dyc_funcallvar_129 ;
  int __dyc_funcallvar_130 ;
  int __dyc_funcallvar_131 ;
  int __dyc_funcallvar_132 ;
  int __dyc_funcallvar_133 ;
  int __dyc_funcallvar_134 ;
  char *__dyc_funcallvar_135 ;
  char *__dyc_funcallvar_136 ;
  int __dyc_funcallvar_137 ;
  int __dyc_funcallvar_138 ;
  int __dyc_funcallvar_139 ;
  int __dyc_funcallvar_140 ;
  int __dyc_funcallvar_141 ;
  int __dyc_funcallvar_142 ;
  int __dyc_funcallvar_143 ;
  int __dyc_funcallvar_144 ;
  int __dyc_funcallvar_145 ;
  int __dyc_funcallvar_146 ;
  char *__dyc_funcallvar_147 ;
  char *__dyc_funcallvar_148 ;
  int __dyc_funcallvar_149 ;
  int __dyc_funcallvar_150 ;
  int __dyc_funcallvar_151 ;
  int __dyc_funcallvar_152 ;
  int __dyc_funcallvar_153 ;
  char *__dyc_funcallvar_154 ;
  char const   *__dyc_funcallvar_155 ;
  char *__dyc_funcallvar_156 ;
  char *__dyc_funcallvar_157 ;
  char *__dyc_funcallvar_158 ;
  int __dyc_funcallvar_159 ;
  int __dyc_funcallvar_160 ;
  int __dyc_funcallvar_161 ;
  int __dyc_funcallvar_162 ;
  int __dyc_funcallvar_163 ;
  char *__dyc_funcallvar_164 ;
  int __dyc_funcallvar_165 ;
  int __dyc_funcallvar_166 ;
  char *__dyc_funcallvar_167 ;
  char *__dyc_funcallvar_168 ;
  char *__dyc_funcallvar_169 ;
  char *__dyc_funcallvar_170 ;
  char *__dyc_funcallvar_171 ;
  char *__dyc_funcallvar_172 ;
  char *__dyc_funcallvar_173 ;
  char *__dyc_funcallvar_174 ;

  {
  wp = __dyc_read_ptr__comp_224window_pane();
  copy = (char const   *)__dyc_read_ptr__char();
  left = (char *)__dyc_read_ptr__char();
  right = (char *)__dyc_read_ptr__char();
  cmp = __dyc_read_ptr__comp_303format_modifier();
  mexp = __dyc_read_ptr__comp_303format_modifier();
  __dyc_funcallvar_53 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_54 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_55 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_66 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_75 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_76 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_77 = __dyc_readpre_byte();
  __dyc_funcallvar_78 = __dyc_readpre_byte();
  __dyc_funcallvar_79 = __dyc_readpre_byte();
  __dyc_funcallvar_80 = __dyc_readpre_byte();
  __dyc_funcallvar_81 = __dyc_readpre_byte();
  __dyc_funcallvar_82 = __dyc_readpre_byte();
  __dyc_funcallvar_83 = __dyc_readpre_byte();
  __dyc_funcallvar_84 = __dyc_readpre_byte();
  __dyc_funcallvar_85 = __dyc_readpre_byte();
  __dyc_funcallvar_86 = __dyc_readpre_byte();
  __dyc_funcallvar_87 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_88 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_89 = __dyc_readpre_byte();
  __dyc_funcallvar_90 = __dyc_readpre_byte();
  __dyc_funcallvar_91 = __dyc_readpre_byte();
  __dyc_funcallvar_92 = __dyc_readpre_byte();
  __dyc_funcallvar_93 = __dyc_readpre_byte();
  __dyc_funcallvar_94 = __dyc_readpre_byte();
  __dyc_funcallvar_95 = __dyc_readpre_byte();
  __dyc_funcallvar_96 = __dyc_readpre_byte();
  __dyc_funcallvar_97 = __dyc_readpre_byte();
  __dyc_funcallvar_98 = __dyc_readpre_byte();
  __dyc_funcallvar_99 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_100 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_101 = __dyc_readpre_byte();
  __dyc_funcallvar_102 = __dyc_readpre_byte();
  __dyc_funcallvar_103 = __dyc_readpre_byte();
  __dyc_funcallvar_104 = __dyc_readpre_byte();
  __dyc_funcallvar_105 = __dyc_readpre_byte();
  __dyc_funcallvar_106 = __dyc_readpre_byte();
  __dyc_funcallvar_107 = __dyc_readpre_byte();
  __dyc_funcallvar_108 = __dyc_readpre_byte();
  __dyc_funcallvar_109 = __dyc_readpre_byte();
  __dyc_funcallvar_110 = __dyc_readpre_byte();
  __dyc_funcallvar_111 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_112 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_113 = __dyc_readpre_byte();
  __dyc_funcallvar_114 = __dyc_readpre_byte();
  __dyc_funcallvar_115 = __dyc_readpre_byte();
  __dyc_funcallvar_116 = __dyc_readpre_byte();
  __dyc_funcallvar_117 = __dyc_readpre_byte();
  __dyc_funcallvar_118 = __dyc_readpre_byte();
  __dyc_funcallvar_119 = __dyc_readpre_byte();
  __dyc_funcallvar_120 = __dyc_readpre_byte();
  __dyc_funcallvar_121 = __dyc_readpre_byte();
  __dyc_funcallvar_122 = __dyc_readpre_byte();
  __dyc_funcallvar_123 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_124 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_125 = __dyc_readpre_byte();
  __dyc_funcallvar_126 = __dyc_readpre_byte();
  __dyc_funcallvar_127 = __dyc_readpre_byte();
  __dyc_funcallvar_128 = __dyc_readpre_byte();
  __dyc_funcallvar_129 = __dyc_readpre_byte();
  __dyc_funcallvar_130 = __dyc_readpre_byte();
  __dyc_funcallvar_131 = __dyc_readpre_byte();
  __dyc_funcallvar_132 = __dyc_readpre_byte();
  __dyc_funcallvar_133 = __dyc_readpre_byte();
  __dyc_funcallvar_134 = __dyc_readpre_byte();
  __dyc_funcallvar_135 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_136 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_137 = __dyc_readpre_byte();
  __dyc_funcallvar_138 = __dyc_readpre_byte();
  __dyc_funcallvar_139 = __dyc_readpre_byte();
  __dyc_funcallvar_140 = __dyc_readpre_byte();
  __dyc_funcallvar_141 = __dyc_readpre_byte();
  __dyc_funcallvar_142 = __dyc_readpre_byte();
  __dyc_funcallvar_143 = __dyc_readpre_byte();
  __dyc_funcallvar_144 = __dyc_readpre_byte();
  __dyc_funcallvar_145 = __dyc_readpre_byte();
  __dyc_funcallvar_146 = __dyc_readpre_byte();
  __dyc_funcallvar_147 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_148 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_149 = __dyc_readpre_byte();
  __dyc_funcallvar_150 = __dyc_readpre_byte();
  __dyc_funcallvar_151 = __dyc_readpre_byte();
  __dyc_funcallvar_152 = __dyc_readpre_byte();
  __dyc_funcallvar_153 = __dyc_readpre_byte();
  __dyc_funcallvar_154 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_155 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_156 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_157 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_158 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_159 = __dyc_readpre_byte();
  __dyc_funcallvar_160 = __dyc_readpre_byte();
  __dyc_funcallvar_161 = __dyc_readpre_byte();
  __dyc_funcallvar_162 = __dyc_readpre_byte();
  __dyc_funcallvar_163 = __dyc_readpre_byte();
  __dyc_funcallvar_164 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_165 = __dyc_readpre_byte();
  __dyc_funcallvar_166 = __dyc_readpre_byte();
  __dyc_funcallvar_167 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_168 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_169 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_170 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_171 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_172 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_173 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_174 = (char *)__dyc_read_ptr__char();
  cp = 0;
  condition = 0;
  found = 0;
  new = 0;
  value = 0;
  tmp___126 = 0;
  tmp___127 = 0;
  tmp___128 = 0;
  tmp___129 = 0;
  tmp___130 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___140 = 0;
  tmp___145 = 0;
  tmp___146 = 0;
  tmp___147 = 0;
  tmp___148 = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___158 = 0;
  tmp___163 = 0;
  tmp___164 = 0;
  tmp___165 = 0;
  tmp___166 = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___176 = 0;
  tmp___181 = 0;
  tmp___182 = 0;
  tmp___183 = 0;
  tmp___184 = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___194 = 0;
  tmp___199 = 0;
  tmp___200 = 0;
  tmp___201 = 0;
  tmp___202 = 0;
  __s1_len___9 = 0;
  __s2_len___9 = 0;
  tmp___212 = 0;
  tmp___217 = 0;
  tmp___218 = 0;
  tmp___219 = 0;
  tmp___220 = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___230 = 0;
  tmp___235 = 0;
  tmp___236 = 0;
  tmp___237 = 0;
  tmp___238 = 0;
  __s1_len___11 = 0;
  __s2_len___11 = 0;
  tmp___248 = 0;
  tmp___253 = 0;
  tmp___254 = 0;
  tmp___255 = 0;
  tmp___256 = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___266 = 0;
  tmp___271 = 0;
  tmp___272 = 0;
  tmp___273 = 0;
  tmp___274 = 0;
  __s1_len___13 = 0;
  __s2_len___13 = 0;
  tmp___284 = 0;
  tmp___289 = 0;
  tmp___290 = 0;
  tmp___291 = 0;
  tmp___292 = 0;
  __s1_len___14 = 0;
  __s2_len___14 = 0;
  tmp___302 = 0;
  tmp___307 = 0;
  tmp___308 = 0;
  tmp___309 = 0;
  tmp___310 = 0;
  __s1_len___15 = 0;
  __s2_len___15 = 0;
  tmp___320 = 0;
  tmp___325 = 0;
  tmp___326 = 0;
  tmp___327 = 0;
  tmp___328 = 0;
  __s1_len___16 = 0;
  __s2_len___16 = 0;
  tmp___338 = 0;
  tmp___343 = 0;
  tmp___344 = 0;
  tmp___345 = 0;
  tmp___346 = 0;
  __s1_len___17 = 0;
  __s2_len___17 = 0;
  tmp___356 = 0;
  tmp___361 = 0;
  tmp___362 = 0;
  tmp___363 = 0;
  tmp___364 = 0;
  __s1_len___18 = 0;
  __s2_len___18 = 0;
  tmp___374 = 0;
  tmp___379 = 0;
  tmp___380 = 0;
  tmp___381 = 0;
  tmp___382 = 0;
  __s1_len___19 = 0;
  __s2_len___19 = 0;
  tmp___392 = 0;
  tmp___397 = 0;
  tmp___398 = 0;
  tmp___399 = 0;
  tmp___400 = 0;
  __s1_len___20 = 0;
  __s2_len___20 = 0;
  tmp___410 = 0;
  tmp___415 = 0;
  tmp___416 = 0;
  tmp___417 = 0;
  tmp___418 = 0;
  tmp___419 = 0;
  tmp___420 = 0;
  tmp___421 = 0;
  new = __dyc_funcallvar_53;
  if ((unsigned long )wp == (unsigned long )((void *)0)) {
    {

    value = __dyc_funcallvar_54;
    }
  } else {
    {

    value = __dyc_funcallvar_55;
    }
  }

  if ((unsigned long )cmp != (unsigned long )((void *)0)) {
    {
    tmp___126 = __dyc_funcallvar_56;
    }
    if (tmp___126 != 0) {
      {

      }
      goto __dyc_dummy_label;
    }
    {


    }
    if (0) {
      {
      tmp___398 = __dyc_funcallvar_57;
      __s1_len___19 = (unsigned long )tmp___398;
      tmp___399 = __dyc_funcallvar_58;
      __s2_len___19 = (unsigned long )tmp___399;
      }
      if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
        goto _L___40;
      } else {
        if (__s1_len___19 >= 4UL) {
          _L___40:  
          if (! ((unsigned long )((void const   *)("||" + 1)) - (unsigned long )((void const   *)"||") == 1UL)) {
            tmp___400 = 1;
          } else {
            if (__s2_len___19 >= 4UL) {
              tmp___400 = 1;
            } else {
              tmp___400 = 0;
            }
          }
        } else {
          tmp___400 = 0;
        }
      }
      if (tmp___400) {
        {
        tmp___392 = __dyc_funcallvar_59;
        }
      } else {
        {
        tmp___397 = __dyc_funcallvar_60;
        tmp___392 = tmp___397;
        }
      }
    } else {
      {
      tmp___397 = __dyc_funcallvar_61;
      tmp___392 = tmp___397;
      }
    }
    if (tmp___392 == 0) {
      {
      tmp___127 = __dyc_funcallvar_62;
      }
      if (tmp___127) {
        {
        value = __dyc_funcallvar_63;
        }
      } else {
        {
        tmp___128 = __dyc_funcallvar_64;
        }
        if (tmp___128) {
          {
          value = __dyc_funcallvar_65;
          }
        } else {
          {
          value = __dyc_funcallvar_66;
          }
        }
      }
    } else {
      if (0) {
        {
        tmp___380 = __dyc_funcallvar_67;
        __s1_len___18 = (unsigned long )tmp___380;
        tmp___381 = __dyc_funcallvar_68;
        __s2_len___18 = (unsigned long )tmp___381;
        }
        if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
          goto _L___38;
        } else {
          if (__s1_len___18 >= 4UL) {
            _L___38:  
            if (! ((unsigned long )((void const   *)("&&" + 1)) - (unsigned long )((void const   *)"&&") == 1UL)) {
              tmp___382 = 1;
            } else {
              if (__s2_len___18 >= 4UL) {
                tmp___382 = 1;
              } else {
                tmp___382 = 0;
              }
            }
          } else {
            tmp___382 = 0;
          }
        }
        if (tmp___382) {
          {
          tmp___374 = __dyc_funcallvar_69;
          }
        } else {
          {
          tmp___379 = __dyc_funcallvar_70;
          tmp___374 = tmp___379;
          }
        }
      } else {
        {
        tmp___379 = __dyc_funcallvar_71;
        tmp___374 = tmp___379;
        }
      }
      if (tmp___374 == 0) {
        {
        tmp___129 = __dyc_funcallvar_72;
        }
        if (tmp___129) {
          {
          tmp___130 = __dyc_funcallvar_73;
          }
          if (tmp___130) {
            {
            value = __dyc_funcallvar_74;
            }
          } else {
            {
            value = __dyc_funcallvar_75;
            }
          }
        } else {
          {
          value = __dyc_funcallvar_76;
          }
        }
      } else {
        if (0) {
          {
          tmp___362 = __dyc_funcallvar_77;
          __s1_len___17 = (unsigned long )tmp___362;
          tmp___363 = __dyc_funcallvar_78;
          __s2_len___17 = (unsigned long )tmp___363;
          }
          if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
            goto _L___36;
          } else {
            if (__s1_len___17 >= 4UL) {
              _L___36:  
              if (! ((unsigned long )((void const   *)("==" + 1)) - (unsigned long )((void const   *)"==") == 1UL)) {
                tmp___364 = 1;
              } else {
                if (__s2_len___17 >= 4UL) {
                  tmp___364 = 1;
                } else {
                  tmp___364 = 0;
                }
              }
            } else {
              tmp___364 = 0;
            }
          }
          if (tmp___364) {
            {
            tmp___356 = __dyc_funcallvar_79;
            }
          } else {
            {
            tmp___361 = __dyc_funcallvar_80;
            tmp___356 = tmp___361;
            }
          }
        } else {
          {
          tmp___361 = __dyc_funcallvar_81;
          tmp___356 = tmp___361;
          }
        }
        if (tmp___356 == 0) {
          if (0) {
            {
            tmp___146 = __dyc_funcallvar_82;
            __s1_len___5 = (unsigned long )tmp___146;
            tmp___147 = __dyc_funcallvar_83;
            __s2_len___5 = (unsigned long )tmp___147;
            }
            if (! ((unsigned long )((void const   *)(left + 1)) - (unsigned long )((void const   *)left) == 1UL)) {
              goto _L___12;
            } else {
              if (__s1_len___5 >= 4UL) {
                _L___12:  
                if (! ((unsigned long )((void const   *)(right + 1)) - (unsigned long )((void const   *)right) == 1UL)) {
                  tmp___148 = 1;
                } else {
                  if (__s2_len___5 >= 4UL) {
                    tmp___148 = 1;
                  } else {
                    tmp___148 = 0;
                  }
                }
              } else {
                tmp___148 = 0;
              }
            }
            if (tmp___148) {
              {
              tmp___140 = __dyc_funcallvar_84;
              }
            } else {
              {
              tmp___145 = __dyc_funcallvar_85;
              tmp___140 = tmp___145;
              }
            }
          } else {
            {
            tmp___145 = __dyc_funcallvar_86;
            tmp___140 = tmp___145;
            }
          }
          if (tmp___140 == 0) {
            {
            value = __dyc_funcallvar_87;
            }
          } else {
            {
            value = __dyc_funcallvar_88;
            }
          }
        } else {
          if (0) {
            {
            tmp___344 = __dyc_funcallvar_89;
            __s1_len___16 = (unsigned long )tmp___344;
            tmp___345 = __dyc_funcallvar_90;
            __s2_len___16 = (unsigned long )tmp___345;
            }
            if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
              goto _L___34;
            } else {
              if (__s1_len___16 >= 4UL) {
                _L___34:  
                if (! ((unsigned long )((void const   *)("!=" + 1)) - (unsigned long )((void const   *)"!=") == 1UL)) {
                  tmp___346 = 1;
                } else {
                  if (__s2_len___16 >= 4UL) {
                    tmp___346 = 1;
                  } else {
                    tmp___346 = 0;
                  }
                }
              } else {
                tmp___346 = 0;
              }
            }
            if (tmp___346) {
              {
              tmp___338 = __dyc_funcallvar_91;
              }
            } else {
              {
              tmp___343 = __dyc_funcallvar_92;
              tmp___338 = tmp___343;
              }
            }
          } else {
            {
            tmp___343 = __dyc_funcallvar_93;
            tmp___338 = tmp___343;
            }
          }
          if (tmp___338 == 0) {
            if (0) {
              {
              tmp___164 = __dyc_funcallvar_94;
              __s1_len___6 = (unsigned long )tmp___164;
              tmp___165 = __dyc_funcallvar_95;
              __s2_len___6 = (unsigned long )tmp___165;
              }
              if (! ((unsigned long )((void const   *)(left + 1)) - (unsigned long )((void const   *)left) == 1UL)) {
                goto _L___14;
              } else {
                if (__s1_len___6 >= 4UL) {
                  _L___14:  
                  if (! ((unsigned long )((void const   *)(right + 1)) - (unsigned long )((void const   *)right) == 1UL)) {
                    tmp___166 = 1;
                  } else {
                    if (__s2_len___6 >= 4UL) {
                      tmp___166 = 1;
                    } else {
                      tmp___166 = 0;
                    }
                  }
                } else {
                  tmp___166 = 0;
                }
              }
              if (tmp___166) {
                {
                tmp___158 = __dyc_funcallvar_96;
                }
              } else {
                {
                tmp___163 = __dyc_funcallvar_97;
                tmp___158 = tmp___163;
                }
              }
            } else {
              {
              tmp___163 = __dyc_funcallvar_98;
              tmp___158 = tmp___163;
              }
            }
            if (tmp___158 != 0) {
              {
              value = __dyc_funcallvar_99;
              }
            } else {
              {
              value = __dyc_funcallvar_100;
              }
            }
          } else {
            if (0) {
              {
              tmp___326 = __dyc_funcallvar_101;
              __s1_len___15 = (unsigned long )tmp___326;
              tmp___327 = __dyc_funcallvar_102;
              __s2_len___15 = (unsigned long )tmp___327;
              }
              if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
                goto _L___32;
              } else {
                if (__s1_len___15 >= 4UL) {
                  _L___32:  
                  if (! ((unsigned long )((void const   *)("<" + 1)) - (unsigned long )((void const   *)"<") == 1UL)) {
                    tmp___328 = 1;
                  } else {
                    if (__s2_len___15 >= 4UL) {
                      tmp___328 = 1;
                    } else {
                      tmp___328 = 0;
                    }
                  }
                } else {
                  tmp___328 = 0;
                }
              }
              if (tmp___328) {
                {
                tmp___320 = __dyc_funcallvar_103;
                }
              } else {
                {
                tmp___325 = __dyc_funcallvar_104;
                tmp___320 = tmp___325;
                }
              }
            } else {
              {
              tmp___325 = __dyc_funcallvar_105;
              tmp___320 = tmp___325;
              }
            }
            if (tmp___320 == 0) {
              if (0) {
                {
                tmp___182 = __dyc_funcallvar_106;
                __s1_len___7 = (unsigned long )tmp___182;
                tmp___183 = __dyc_funcallvar_107;
                __s2_len___7 = (unsigned long )tmp___183;
                }
                if (! ((unsigned long )((void const   *)(left + 1)) - (unsigned long )((void const   *)left) == 1UL)) {
                  goto _L___16;
                } else {
                  if (__s1_len___7 >= 4UL) {
                    _L___16:  
                    if (! ((unsigned long )((void const   *)(right + 1)) - (unsigned long )((void const   *)right) == 1UL)) {
                      tmp___184 = 1;
                    } else {
                      if (__s2_len___7 >= 4UL) {
                        tmp___184 = 1;
                      } else {
                        tmp___184 = 0;
                      }
                    }
                  } else {
                    tmp___184 = 0;
                  }
                }
                if (tmp___184) {
                  {
                  tmp___176 = __dyc_funcallvar_108;
                  }
                } else {
                  {
                  tmp___181 = __dyc_funcallvar_109;
                  tmp___176 = tmp___181;
                  }
                }
              } else {
                {
                tmp___181 = __dyc_funcallvar_110;
                tmp___176 = tmp___181;
                }
              }
              if (tmp___176 < 0) {
                {
                value = __dyc_funcallvar_111;
                }
              } else {
                {
                value = __dyc_funcallvar_112;
                }
              }
            } else {
              if (0) {
                {
                tmp___308 = __dyc_funcallvar_113;
                __s1_len___14 = (unsigned long )tmp___308;
                tmp___309 = __dyc_funcallvar_114;
                __s2_len___14 = (unsigned long )tmp___309;
                }
                if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
                  goto _L___30;
                } else {
                  if (__s1_len___14 >= 4UL) {
                    _L___30:  
                    if (! ((unsigned long )((void const   *)(">" + 1)) - (unsigned long )((void const   *)">") == 1UL)) {
                      tmp___310 = 1;
                    } else {
                      if (__s2_len___14 >= 4UL) {
                        tmp___310 = 1;
                      } else {
                        tmp___310 = 0;
                      }
                    }
                  } else {
                    tmp___310 = 0;
                  }
                }
                if (tmp___310) {
                  {
                  tmp___302 = __dyc_funcallvar_115;
                  }
                } else {
                  {
                  tmp___307 = __dyc_funcallvar_116;
                  tmp___302 = tmp___307;
                  }
                }
              } else {
                {
                tmp___307 = __dyc_funcallvar_117;
                tmp___302 = tmp___307;
                }
              }
              if (tmp___302 == 0) {
                if (0) {
                  {
                  tmp___200 = __dyc_funcallvar_118;
                  __s1_len___8 = (unsigned long )tmp___200;
                  tmp___201 = __dyc_funcallvar_119;
                  __s2_len___8 = (unsigned long )tmp___201;
                  }
                  if (! ((unsigned long )((void const   *)(left + 1)) - (unsigned long )((void const   *)left) == 1UL)) {
                    goto _L___18;
                  } else {
                    if (__s1_len___8 >= 4UL) {
                      _L___18:  
                      if (! ((unsigned long )((void const   *)(right + 1)) - (unsigned long )((void const   *)right) == 1UL)) {
                        tmp___202 = 1;
                      } else {
                        if (__s2_len___8 >= 4UL) {
                          tmp___202 = 1;
                        } else {
                          tmp___202 = 0;
                        }
                      }
                    } else {
                      tmp___202 = 0;
                    }
                  }
                  if (tmp___202) {
                    {
                    tmp___194 = __dyc_funcallvar_120;
                    }
                  } else {
                    {
                    tmp___199 = __dyc_funcallvar_121;
                    tmp___194 = tmp___199;
                    }
                  }
                } else {
                  {
                  tmp___199 = __dyc_funcallvar_122;
                  tmp___194 = tmp___199;
                  }
                }
                if (tmp___194 > 0) {
                  {
                  value = __dyc_funcallvar_123;
                  }
                } else {
                  {
                  value = __dyc_funcallvar_124;
                  }
                }
              } else {
                if (0) {
                  {
                  tmp___290 = __dyc_funcallvar_125;
                  __s1_len___13 = (unsigned long )tmp___290;
                  tmp___291 = __dyc_funcallvar_126;
                  __s2_len___13 = (unsigned long )tmp___291;
                  }
                  if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
                    goto _L___28;
                  } else {
                    if (__s1_len___13 >= 4UL) {
                      _L___28:  
                      if (! ((unsigned long )((void const   *)("<=" + 1)) - (unsigned long )((void const   *)"<=") == 1UL)) {
                        tmp___292 = 1;
                      } else {
                        if (__s2_len___13 >= 4UL) {
                          tmp___292 = 1;
                        } else {
                          tmp___292 = 0;
                        }
                      }
                    } else {
                      tmp___292 = 0;
                    }
                  }
                  if (tmp___292) {
                    {
                    tmp___284 = __dyc_funcallvar_127;
                    }
                  } else {
                    {
                    tmp___289 = __dyc_funcallvar_128;
                    tmp___284 = tmp___289;
                    }
                  }
                } else {
                  {
                  tmp___289 = __dyc_funcallvar_129;
                  tmp___284 = tmp___289;
                  }
                }
                if (tmp___284 == 0) {
                  if (0) {
                    {
                    tmp___218 = __dyc_funcallvar_130;
                    __s1_len___9 = (unsigned long )tmp___218;
                    tmp___219 = __dyc_funcallvar_131;
                    __s2_len___9 = (unsigned long )tmp___219;
                    }
                    if (! ((unsigned long )((void const   *)(left + 1)) - (unsigned long )((void const   *)left) == 1UL)) {
                      goto _L___20;
                    } else {
                      if (__s1_len___9 >= 4UL) {
                        _L___20:  
                        if (! ((unsigned long )((void const   *)(right + 1)) - (unsigned long )((void const   *)right) == 1UL)) {
                          tmp___220 = 1;
                        } else {
                          if (__s2_len___9 >= 4UL) {
                            tmp___220 = 1;
                          } else {
                            tmp___220 = 0;
                          }
                        }
                      } else {
                        tmp___220 = 0;
                      }
                    }
                    if (tmp___220) {
                      {
                      tmp___212 = __dyc_funcallvar_132;
                      }
                    } else {
                      {
                      tmp___217 = __dyc_funcallvar_133;
                      tmp___212 = tmp___217;
                      }
                    }
                  } else {
                    {
                    tmp___217 = __dyc_funcallvar_134;
                    tmp___212 = tmp___217;
                    }
                  }
                  if (tmp___212 <= 0) {
                    {
                    value = __dyc_funcallvar_135;
                    }
                  } else {
                    {
                    value = __dyc_funcallvar_136;
                    }
                  }
                } else {
                  if (0) {
                    {
                    tmp___272 = __dyc_funcallvar_137;
                    __s1_len___12 = (unsigned long )tmp___272;
                    tmp___273 = __dyc_funcallvar_138;
                    __s2_len___12 = (unsigned long )tmp___273;
                    }
                    if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
                      goto _L___26;
                    } else {
                      if (__s1_len___12 >= 4UL) {
                        _L___26:  
                        if (! ((unsigned long )((void const   *)(">=" + 1)) - (unsigned long )((void const   *)">=") == 1UL)) {
                          tmp___274 = 1;
                        } else {
                          if (__s2_len___12 >= 4UL) {
                            tmp___274 = 1;
                          } else {
                            tmp___274 = 0;
                          }
                        }
                      } else {
                        tmp___274 = 0;
                      }
                    }
                    if (tmp___274) {
                      {
                      tmp___266 = __dyc_funcallvar_139;
                      }
                    } else {
                      {
                      tmp___271 = __dyc_funcallvar_140;
                      tmp___266 = tmp___271;
                      }
                    }
                  } else {
                    {
                    tmp___271 = __dyc_funcallvar_141;
                    tmp___266 = tmp___271;
                    }
                  }
                  if (tmp___266 == 0) {
                    if (0) {
                      {
                      tmp___236 = __dyc_funcallvar_142;
                      __s1_len___10 = (unsigned long )tmp___236;
                      tmp___237 = __dyc_funcallvar_143;
                      __s2_len___10 = (unsigned long )tmp___237;
                      }
                      if (! ((unsigned long )((void const   *)(left + 1)) - (unsigned long )((void const   *)left) == 1UL)) {
                        goto _L___22;
                      } else {
                        if (__s1_len___10 >= 4UL) {
                          _L___22:  
                          if (! ((unsigned long )((void const   *)(right + 1)) - (unsigned long )((void const   *)right) == 1UL)) {
                            tmp___238 = 1;
                          } else {
                            if (__s2_len___10 >= 4UL) {
                              tmp___238 = 1;
                            } else {
                              tmp___238 = 0;
                            }
                          }
                        } else {
                          tmp___238 = 0;
                        }
                      }
                      if (tmp___238) {
                        {
                        tmp___230 = __dyc_funcallvar_144;
                        }
                      } else {
                        {
                        tmp___235 = __dyc_funcallvar_145;
                        tmp___230 = tmp___235;
                        }
                      }
                    } else {
                      {
                      tmp___235 = __dyc_funcallvar_146;
                      tmp___230 = tmp___235;
                      }
                    }
                    if (tmp___230 >= 0) {
                      {
                      value = __dyc_funcallvar_147;
                      }
                    } else {
                      {
                      value = __dyc_funcallvar_148;
                      }
                    }
                  } else {
                    if (0) {
                      {
                      tmp___254 = __dyc_funcallvar_149;
                      __s1_len___11 = (unsigned long )tmp___254;
                      tmp___255 = __dyc_funcallvar_150;
                      __s2_len___11 = (unsigned long )tmp___255;
                      }
                      if (! ((unsigned long )((void const   *)(cmp->modifier + 1)) - (unsigned long )((void const   *)(cmp->modifier)) == 1UL)) {
                        goto _L___24;
                      } else {
                        if (__s1_len___11 >= 4UL) {
                          _L___24:  
                          if (! ((unsigned long )((void const   *)("m" + 1)) - (unsigned long )((void const   *)"m") == 1UL)) {
                            tmp___256 = 1;
                          } else {
                            if (__s2_len___11 >= 4UL) {
                              tmp___256 = 1;
                            } else {
                              tmp___256 = 0;
                            }
                          }
                        } else {
                          tmp___256 = 0;
                        }
                      }
                      if (tmp___256) {
                        {
                        tmp___248 = __dyc_funcallvar_151;
                        }
                      } else {
                        {
                        tmp___253 = __dyc_funcallvar_152;
                        tmp___248 = tmp___253;
                        }
                      }
                    } else {
                      {
                      tmp___253 = __dyc_funcallvar_153;
                      tmp___248 = tmp___253;
                      }
                    }
                    if (tmp___248 == 0) {
                      {
                      value = __dyc_funcallvar_154;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    {


    }
  } else {
    if ((int const   )*copy == 63) {
      {
      cp = __dyc_funcallvar_155;
      }
      if ((unsigned long )cp == (unsigned long )((void *)0)) {
        {

        }
        goto __dyc_dummy_label;
      }
      {
      condition = __dyc_funcallvar_156;

      found = __dyc_funcallvar_157;
      }
      if ((unsigned long )found == (unsigned long )((void *)0)) {
        {
        found = __dyc_funcallvar_158;
        }
        if (0) {
          {
          tmp___416 = __dyc_funcallvar_159;
          __s1_len___20 = (unsigned long )tmp___416;
          tmp___417 = __dyc_funcallvar_160;
          __s2_len___20 = (unsigned long )tmp___417;
          }
          if (! ((unsigned long )((void const   *)(found + 1)) - (unsigned long )((void const   *)found) == 1UL)) {
            goto _L___42;
          } else {
            if (__s1_len___20 >= 4UL) {
              _L___42:  
              if (! ((unsigned long )((void const   *)(condition + 1)) - (unsigned long )((void const   *)condition) == 1UL)) {
                tmp___418 = 1;
              } else {
                if (__s2_len___20 >= 4UL) {
                  tmp___418 = 1;
                } else {
                  tmp___418 = 0;
                }
              }
            } else {
              tmp___418 = 0;
            }
          }
          if (tmp___418) {
            {
            tmp___410 = __dyc_funcallvar_161;
            }
          } else {
            {
            tmp___415 = __dyc_funcallvar_162;
            tmp___410 = tmp___415;
            }
          }
        } else {
          {
          tmp___415 = __dyc_funcallvar_163;
          tmp___410 = tmp___415;
          }
        }
        if (tmp___410 == 0) {
          {

          found = __dyc_funcallvar_164;

          }
        } else {
          {

          }
        }
      } else {
        {

        }
      }
      {
      tmp___419 = __dyc_funcallvar_165;
      }
      if (tmp___419 != 0) {
        {


        }
        goto __dyc_dummy_label;
      }
      {
      tmp___420 = __dyc_funcallvar_166;
      }
      if (tmp___420) {
        {

        value = __dyc_funcallvar_167;
        }
      } else {
        {

        value = __dyc_funcallvar_168;
        }
      }
      {




      }
    } else {
      if ((unsigned long )mexp != (unsigned long )((void *)0)) {
        {
        value = __dyc_funcallvar_169;
        }
        if ((unsigned long )value == (unsigned long )((void *)0)) {
          {
          value = __dyc_funcallvar_170;
          }
        }
      } else {
        {
        tmp___421 = __dyc_funcallvar_171;
        }
        if ((unsigned long )tmp___421 != (unsigned long )((char *)0)) {
          {

          value = __dyc_funcallvar_172;
          }
        } else {
          {
          value = __dyc_funcallvar_173;
          }
          if ((unsigned long )value == (unsigned long )((void *)0)) {
            {

            value = __dyc_funcallvar_174;
            }
          } else {
            {

            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(condition);
  __dyc_print_ptr__char(found);
  __dyc_print_ptr__char(new);
  __dyc_print_ptr__char(value);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(__s1_len___9);
  __dyc_printpre_byte(__s2_len___9);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___11);
  __dyc_printpre_byte(__s2_len___11);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
  __dyc_printpre_byte(__s1_len___13);
  __dyc_printpre_byte(__s2_len___13);
  __dyc_printpre_byte(__s1_len___14);
  __dyc_printpre_byte(__s2_len___14);
  __dyc_printpre_byte(__s1_len___15);
  __dyc_printpre_byte(__s2_len___15);
  __dyc_printpre_byte(__s1_len___16);
  __dyc_printpre_byte(__s2_len___16);
  __dyc_printpre_byte(__s1_len___17);
  __dyc_printpre_byte(__s2_len___17);
  __dyc_printpre_byte(__s1_len___18);
  __dyc_printpre_byte(__s2_len___18);
  __dyc_printpre_byte(__s1_len___19);
  __dyc_printpre_byte(__s2_len___19);
  __dyc_printpre_byte(__s1_len___20);
  __dyc_printpre_byte(__s2_len___20);
}
}
