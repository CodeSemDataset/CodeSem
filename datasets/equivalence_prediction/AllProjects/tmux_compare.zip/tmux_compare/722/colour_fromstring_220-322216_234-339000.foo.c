#include "../include/dycfoo.h"
#include "../include/colour.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp___122 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___132 ;
  int tmp___137 ;
  int tmp___138 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___151 ;
  int tmp___156 ;
  int tmp___157 ;
  int tmp___158 ;
  int tmp___159 ;
  int tmp___160 ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___170 ;
  int tmp___175 ;
  int tmp___176 ;
  int tmp___177 ;
  int tmp___178 ;
  int tmp___179 ;
  size_t __s1_len___8 ;
  size_t __s2_len___8 ;
  int tmp___189 ;
  int tmp___194 ;
  int tmp___195 ;
  int tmp___196 ;
  int tmp___197 ;
  int tmp___198 ;
  size_t __s1_len___9 ;
  size_t __s2_len___9 ;
  int tmp___208 ;
  int tmp___213 ;
  int tmp___214 ;
  int tmp___215 ;
  int tmp___216 ;
  int tmp___217 ;
  size_t __s1_len___10 ;
  size_t __s2_len___10 ;
  int tmp___227 ;
  int tmp___232 ;
  int tmp___233 ;
  int tmp___234 ;
  int tmp___235 ;
  int tmp___236 ;
  size_t __s1_len___11 ;
  size_t __s2_len___11 ;
  int tmp___246 ;
  int tmp___251 ;
  int tmp___252 ;
  int tmp___253 ;
  int tmp___254 ;
  int tmp___255 ;
  size_t __s1_len___12 ;
  size_t __s2_len___12 ;
  int tmp___265 ;
  int tmp___270 ;
  int tmp___271 ;
  int tmp___272 ;
  int tmp___273 ;
  char const   *s___0 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;
  int __dyc_funcallvar_66 ;
  int __dyc_funcallvar_67 ;
  int __dyc_funcallvar_68 ;
  int __dyc_funcallvar_69 ;
  int __dyc_funcallvar_70 ;
  int __dyc_funcallvar_71 ;
  int __dyc_funcallvar_72 ;
  int __dyc_funcallvar_73 ;
  int __dyc_funcallvar_74 ;
  int __dyc_funcallvar_75 ;
  int __dyc_funcallvar_76 ;
  int __dyc_funcallvar_77 ;
  int __dyc_funcallvar_78 ;
  int __dyc_funcallvar_79 ;
  int __dyc_funcallvar_80 ;
  int __dyc_funcallvar_81 ;
  int __dyc_funcallvar_82 ;
  int __dyc_funcallvar_83 ;
  int __dyc_funcallvar_84 ;
  int __dyc_funcallvar_85 ;
  int __dyc_funcallvar_86 ;
  int __dyc_funcallvar_87 ;
  int __dyc_funcallvar_88 ;
  int __dyc_funcallvar_89 ;
  int __dyc_funcallvar_90 ;
  int __dyc_funcallvar_91 ;
  int __dyc_funcallvar_92 ;
  int __dyc_funcallvar_93 ;
  int __dyc_funcallvar_94 ;

  {
  s___0 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  __dyc_funcallvar_66 = __dyc_readpre_byte();
  __dyc_funcallvar_67 = __dyc_readpre_byte();
  __dyc_funcallvar_68 = __dyc_readpre_byte();
  __dyc_funcallvar_69 = __dyc_readpre_byte();
  __dyc_funcallvar_70 = __dyc_readpre_byte();
  __dyc_funcallvar_71 = __dyc_readpre_byte();
  __dyc_funcallvar_72 = __dyc_readpre_byte();
  __dyc_funcallvar_73 = __dyc_readpre_byte();
  __dyc_funcallvar_74 = __dyc_readpre_byte();
  __dyc_funcallvar_75 = __dyc_readpre_byte();
  __dyc_funcallvar_76 = __dyc_readpre_byte();
  __dyc_funcallvar_77 = __dyc_readpre_byte();
  __dyc_funcallvar_78 = __dyc_readpre_byte();
  __dyc_funcallvar_79 = __dyc_readpre_byte();
  __dyc_funcallvar_80 = __dyc_readpre_byte();
  __dyc_funcallvar_81 = __dyc_readpre_byte();
  __dyc_funcallvar_82 = __dyc_readpre_byte();
  __dyc_funcallvar_83 = __dyc_readpre_byte();
  __dyc_funcallvar_84 = __dyc_readpre_byte();
  __dyc_funcallvar_85 = __dyc_readpre_byte();
  __dyc_funcallvar_86 = __dyc_readpre_byte();
  __dyc_funcallvar_87 = __dyc_readpre_byte();
  __dyc_funcallvar_88 = __dyc_readpre_byte();
  __dyc_funcallvar_89 = __dyc_readpre_byte();
  __dyc_funcallvar_90 = __dyc_readpre_byte();
  __dyc_funcallvar_91 = __dyc_readpre_byte();
  __dyc_funcallvar_92 = __dyc_readpre_byte();
  __dyc_funcallvar_93 = __dyc_readpre_byte();
  __dyc_funcallvar_94 = __dyc_readpre_byte();
  tmp___122 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___132 = 0;
  tmp___137 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___151 = 0;
  tmp___156 = 0;
  tmp___157 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___170 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  tmp___178 = 0;
  tmp___179 = 0;
  __s1_len___8 = 0;
  __s2_len___8 = 0;
  tmp___189 = 0;
  tmp___194 = 0;
  tmp___195 = 0;
  tmp___196 = 0;
  tmp___197 = 0;
  tmp___198 = 0;
  __s1_len___9 = 0;
  __s2_len___9 = 0;
  tmp___208 = 0;
  tmp___213 = 0;
  tmp___214 = 0;
  tmp___215 = 0;
  tmp___216 = 0;
  tmp___217 = 0;
  __s1_len___10 = 0;
  __s2_len___10 = 0;
  tmp___227 = 0;
  tmp___232 = 0;
  tmp___233 = 0;
  tmp___234 = 0;
  tmp___235 = 0;
  tmp___236 = 0;
  __s1_len___11 = 0;
  __s2_len___11 = 0;
  tmp___246 = 0;
  tmp___251 = 0;
  tmp___252 = 0;
  tmp___253 = 0;
  tmp___254 = 0;
  tmp___255 = 0;
  __s1_len___12 = 0;
  __s2_len___12 = 0;
  tmp___265 = 0;
  tmp___270 = 0;
  tmp___271 = 0;
  tmp___272 = 0;
  tmp___273 = 0;
  tmp___122 = __dyc_funcallvar_47;
  if (tmp___122 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___138 = __dyc_funcallvar_48;
      __s1_len___5 = (unsigned long )tmp___138;
      tmp___139 = __dyc_funcallvar_49;
      __s2_len___5 = (unsigned long )tmp___139;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___12;
      } else {
        if (__s1_len___5 >= 4UL) {
          _L___12:  
          if (! ((unsigned long )((void const   *)("6" + 1)) - (unsigned long )((void const   *)"6") == 1UL)) {
            tmp___140 = 1;
          } else {
            if (__s2_len___5 >= 4UL) {
              tmp___140 = 1;
            } else {
              tmp___140 = 0;
            }
          }
        } else {
          tmp___140 = 0;
        }
      }
      if (tmp___140) {
        {
        tmp___132 = __dyc_funcallvar_50;
        }
      } else {
        {
        tmp___137 = __dyc_funcallvar_51;
        tmp___132 = tmp___137;
        }
      }
    } else {
      {
      tmp___137 = __dyc_funcallvar_52;
      tmp___132 = tmp___137;
      }
    }
    if (tmp___132 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___141 = __dyc_funcallvar_53;
  if (tmp___141 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___157 = __dyc_funcallvar_54;
      __s1_len___6 = (unsigned long )tmp___157;
      tmp___158 = __dyc_funcallvar_55;
      __s2_len___6 = (unsigned long )tmp___158;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___14;
      } else {
        if (__s1_len___6 >= 4UL) {
          _L___14:  
          if (! ((unsigned long )((void const   *)("7" + 1)) - (unsigned long )((void const   *)"7") == 1UL)) {
            tmp___159 = 1;
          } else {
            if (__s2_len___6 >= 4UL) {
              tmp___159 = 1;
            } else {
              tmp___159 = 0;
            }
          }
        } else {
          tmp___159 = 0;
        }
      }
      if (tmp___159) {
        {
        tmp___151 = __dyc_funcallvar_56;
        }
      } else {
        {
        tmp___156 = __dyc_funcallvar_57;
        tmp___151 = tmp___156;
        }
      }
    } else {
      {
      tmp___156 = __dyc_funcallvar_58;
      tmp___151 = tmp___156;
      }
    }
    if (tmp___151 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___160 = __dyc_funcallvar_59;
  if (tmp___160 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___176 = __dyc_funcallvar_60;
      __s1_len___7 = (unsigned long )tmp___176;
      tmp___177 = __dyc_funcallvar_61;
      __s2_len___7 = (unsigned long )tmp___177;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___16;
      } else {
        if (__s1_len___7 >= 4UL) {
          _L___16:  
          if (! ((unsigned long )((void const   *)("90" + 1)) - (unsigned long )((void const   *)"90") == 1UL)) {
            tmp___178 = 1;
          } else {
            if (__s2_len___7 >= 4UL) {
              tmp___178 = 1;
            } else {
              tmp___178 = 0;
            }
          }
        } else {
          tmp___178 = 0;
        }
      }
      if (tmp___178) {
        {
        tmp___170 = __dyc_funcallvar_62;
        }
      } else {
        {
        tmp___175 = __dyc_funcallvar_63;
        tmp___170 = tmp___175;
        }
      }
    } else {
      {
      tmp___175 = __dyc_funcallvar_64;
      tmp___170 = tmp___175;
      }
    }
    if (tmp___170 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___179 = __dyc_funcallvar_65;
  if (tmp___179 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___195 = __dyc_funcallvar_66;
      __s1_len___8 = (unsigned long )tmp___195;
      tmp___196 = __dyc_funcallvar_67;
      __s2_len___8 = (unsigned long )tmp___196;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___18;
      } else {
        if (__s1_len___8 >= 4UL) {
          _L___18:  
          if (! ((unsigned long )((void const   *)("91" + 1)) - (unsigned long )((void const   *)"91") == 1UL)) {
            tmp___197 = 1;
          } else {
            if (__s2_len___8 >= 4UL) {
              tmp___197 = 1;
            } else {
              tmp___197 = 0;
            }
          }
        } else {
          tmp___197 = 0;
        }
      }
      if (tmp___197) {
        {
        tmp___189 = __dyc_funcallvar_68;
        }
      } else {
        {
        tmp___194 = __dyc_funcallvar_69;
        tmp___189 = tmp___194;
        }
      }
    } else {
      {
      tmp___194 = __dyc_funcallvar_70;
      tmp___189 = tmp___194;
      }
    }
    if (tmp___189 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___198 = __dyc_funcallvar_71;
  if (tmp___198 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___214 = __dyc_funcallvar_72;
      __s1_len___9 = (unsigned long )tmp___214;
      tmp___215 = __dyc_funcallvar_73;
      __s2_len___9 = (unsigned long )tmp___215;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___20;
      } else {
        if (__s1_len___9 >= 4UL) {
          _L___20:  
          if (! ((unsigned long )((void const   *)("92" + 1)) - (unsigned long )((void const   *)"92") == 1UL)) {
            tmp___216 = 1;
          } else {
            if (__s2_len___9 >= 4UL) {
              tmp___216 = 1;
            } else {
              tmp___216 = 0;
            }
          }
        } else {
          tmp___216 = 0;
        }
      }
      if (tmp___216) {
        {
        tmp___208 = __dyc_funcallvar_74;
        }
      } else {
        {
        tmp___213 = __dyc_funcallvar_75;
        tmp___208 = tmp___213;
        }
      }
    } else {
      {
      tmp___213 = __dyc_funcallvar_76;
      tmp___208 = tmp___213;
      }
    }
    if (tmp___208 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___217 = __dyc_funcallvar_77;
  if (tmp___217 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___233 = __dyc_funcallvar_78;
      __s1_len___10 = (unsigned long )tmp___233;
      tmp___234 = __dyc_funcallvar_79;
      __s2_len___10 = (unsigned long )tmp___234;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___22;
      } else {
        if (__s1_len___10 >= 4UL) {
          _L___22:  
          if (! ((unsigned long )((void const   *)("93" + 1)) - (unsigned long )((void const   *)"93") == 1UL)) {
            tmp___235 = 1;
          } else {
            if (__s2_len___10 >= 4UL) {
              tmp___235 = 1;
            } else {
              tmp___235 = 0;
            }
          }
        } else {
          tmp___235 = 0;
        }
      }
      if (tmp___235) {
        {
        tmp___227 = __dyc_funcallvar_80;
        }
      } else {
        {
        tmp___232 = __dyc_funcallvar_81;
        tmp___227 = tmp___232;
        }
      }
    } else {
      {
      tmp___232 = __dyc_funcallvar_82;
      tmp___227 = tmp___232;
      }
    }
    if (tmp___227 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___236 = __dyc_funcallvar_83;
  if (tmp___236 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___252 = __dyc_funcallvar_84;
      __s1_len___11 = (unsigned long )tmp___252;
      tmp___253 = __dyc_funcallvar_85;
      __s2_len___11 = (unsigned long )tmp___253;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___24;
      } else {
        if (__s1_len___11 >= 4UL) {
          _L___24:  
          if (! ((unsigned long )((void const   *)("94" + 1)) - (unsigned long )((void const   *)"94") == 1UL)) {
            tmp___254 = 1;
          } else {
            if (__s2_len___11 >= 4UL) {
              tmp___254 = 1;
            } else {
              tmp___254 = 0;
            }
          }
        } else {
          tmp___254 = 0;
        }
      }
      if (tmp___254) {
        {
        tmp___246 = __dyc_funcallvar_86;
        }
      } else {
        {
        tmp___251 = __dyc_funcallvar_87;
        tmp___246 = tmp___251;
        }
      }
    } else {
      {
      tmp___251 = __dyc_funcallvar_88;
      tmp___246 = tmp___251;
      }
    }
    if (tmp___246 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___255 = __dyc_funcallvar_89;
  if (! (tmp___255 == 0)) {
    if (0) {
      {
      tmp___271 = __dyc_funcallvar_90;
      __s1_len___12 = (unsigned long )tmp___271;
      tmp___272 = __dyc_funcallvar_91;
      __s2_len___12 = (unsigned long )tmp___272;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___26;
      } else {
        if (__s1_len___12 >= 4UL) {
          _L___26:  
          if (! ((unsigned long )((void const   *)("95" + 1)) - (unsigned long )((void const   *)"95") == 1UL)) {
            tmp___273 = 1;
          } else {
            if (__s2_len___12 >= 4UL) {
              tmp___273 = 1;
            } else {
              tmp___273 = 0;
            }
          }
        } else {
          tmp___273 = 0;
        }
      }
      if (tmp___273) {
        {
        tmp___265 = __dyc_funcallvar_92;
        }
      } else {
        {
        tmp___270 = __dyc_funcallvar_93;
        tmp___265 = tmp___270;
        }
      }
    } else {
      {
      tmp___270 = __dyc_funcallvar_94;
      tmp___265 = tmp___270;
      }
    }
    if (tmp___265 == 0) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(__s1_len___8);
  __dyc_printpre_byte(__s2_len___8);
  __dyc_printpre_byte(__s1_len___9);
  __dyc_printpre_byte(__s2_len___9);
  __dyc_printpre_byte(__s1_len___10);
  __dyc_printpre_byte(__s2_len___10);
  __dyc_printpre_byte(__s1_len___11);
  __dyc_printpre_byte(__s2_len___11);
  __dyc_printpre_byte(__s1_len___12);
  __dyc_printpre_byte(__s2_len___12);
}
}
