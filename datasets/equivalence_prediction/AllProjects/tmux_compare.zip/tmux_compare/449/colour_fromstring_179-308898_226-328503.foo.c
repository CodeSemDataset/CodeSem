#include "../include/dycfoo.h"
#include "../include/colour.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *errstr ;
  char const   *cp ;
  int n ;
  unsigned short const   **tmp ;
  int tmp___0 ;
  size_t tmp___1 ;
  long long tmp___2 ;
  int tmp___3 ;
  long long tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___18 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___37 ;
  int tmp___42 ;
  int tmp___43 ;
  int tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___56 ;
  int tmp___61 ;
  int tmp___62 ;
  int tmp___63 ;
  int tmp___64 ;
  int tmp___65 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___75 ;
  int tmp___80 ;
  int tmp___81 ;
  int tmp___82 ;
  int tmp___83 ;
  int tmp___84 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___94 ;
  int tmp___99 ;
  int tmp___100 ;
  int tmp___101 ;
  int tmp___102 ;
  int tmp___103 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___113 ;
  int tmp___118 ;
  int tmp___119 ;
  int tmp___120 ;
  int tmp___121 ;
  int tmp___122 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___132 ;
  int tmp___137 ;
  int tmp___138 ;
  int tmp___139 ;
  int tmp___140 ;
  int tmp___141 ;
  size_t __s1_len___6 ;
  size_t __s2_len___6 ;
  int tmp___151 ;
  int tmp___156 ;
  int tmp___157 ;
  int tmp___158 ;
  int tmp___159 ;
  int tmp___160 ;
  size_t __s1_len___7 ;
  size_t __s2_len___7 ;
  int tmp___170 ;
  int tmp___175 ;
  int tmp___176 ;
  int tmp___177 ;
  int tmp___178 ;
  int tmp___179 ;
  char const   *s___0 ;
  size_t __dyc_funcallvar_1 ;
  unsigned short const   **__dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  long long __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  long long __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  int __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;
  int __dyc_funcallvar_21 ;
  int __dyc_funcallvar_22 ;
  int __dyc_funcallvar_23 ;
  int __dyc_funcallvar_24 ;
  int __dyc_funcallvar_25 ;
  int __dyc_funcallvar_26 ;
  int __dyc_funcallvar_27 ;
  int __dyc_funcallvar_28 ;
  int __dyc_funcallvar_29 ;
  int __dyc_funcallvar_30 ;
  int __dyc_funcallvar_31 ;
  int __dyc_funcallvar_32 ;
  int __dyc_funcallvar_33 ;
  int __dyc_funcallvar_34 ;
  int __dyc_funcallvar_35 ;
  int __dyc_funcallvar_36 ;
  int __dyc_funcallvar_37 ;
  int __dyc_funcallvar_38 ;
  int __dyc_funcallvar_39 ;
  int __dyc_funcallvar_40 ;
  int __dyc_funcallvar_41 ;
  int __dyc_funcallvar_42 ;
  int __dyc_funcallvar_43 ;
  int __dyc_funcallvar_44 ;
  int __dyc_funcallvar_45 ;
  int __dyc_funcallvar_46 ;
  int __dyc_funcallvar_47 ;
  int __dyc_funcallvar_48 ;
  int __dyc_funcallvar_49 ;
  int __dyc_funcallvar_50 ;
  int __dyc_funcallvar_51 ;
  int __dyc_funcallvar_52 ;
  int __dyc_funcallvar_53 ;
  int __dyc_funcallvar_54 ;
  int __dyc_funcallvar_55 ;
  int __dyc_funcallvar_56 ;
  int __dyc_funcallvar_57 ;
  int __dyc_funcallvar_58 ;
  int __dyc_funcallvar_59 ;
  int __dyc_funcallvar_60 ;
  int __dyc_funcallvar_61 ;
  int __dyc_funcallvar_62 ;
  int __dyc_funcallvar_63 ;
  int __dyc_funcallvar_64 ;
  int __dyc_funcallvar_65 ;

  {
  errstr = (char const   *)__dyc_read_ptr__char();
  s___0 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_1 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = (long long )__dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = (long long )__dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = __dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  __dyc_funcallvar_21 = __dyc_readpre_byte();
  __dyc_funcallvar_22 = __dyc_readpre_byte();
  __dyc_funcallvar_23 = __dyc_readpre_byte();
  __dyc_funcallvar_24 = __dyc_readpre_byte();
  __dyc_funcallvar_25 = __dyc_readpre_byte();
  __dyc_funcallvar_26 = __dyc_readpre_byte();
  __dyc_funcallvar_27 = __dyc_readpre_byte();
  __dyc_funcallvar_28 = __dyc_readpre_byte();
  __dyc_funcallvar_29 = __dyc_readpre_byte();
  __dyc_funcallvar_30 = __dyc_readpre_byte();
  __dyc_funcallvar_31 = __dyc_readpre_byte();
  __dyc_funcallvar_32 = __dyc_readpre_byte();
  __dyc_funcallvar_33 = __dyc_readpre_byte();
  __dyc_funcallvar_34 = __dyc_readpre_byte();
  __dyc_funcallvar_35 = __dyc_readpre_byte();
  __dyc_funcallvar_36 = __dyc_readpre_byte();
  __dyc_funcallvar_37 = __dyc_readpre_byte();
  __dyc_funcallvar_38 = __dyc_readpre_byte();
  __dyc_funcallvar_39 = __dyc_readpre_byte();
  __dyc_funcallvar_40 = __dyc_readpre_byte();
  __dyc_funcallvar_41 = __dyc_readpre_byte();
  __dyc_funcallvar_42 = __dyc_readpre_byte();
  __dyc_funcallvar_43 = __dyc_readpre_byte();
  __dyc_funcallvar_44 = __dyc_readpre_byte();
  __dyc_funcallvar_45 = __dyc_readpre_byte();
  __dyc_funcallvar_46 = __dyc_readpre_byte();
  __dyc_funcallvar_47 = __dyc_readpre_byte();
  __dyc_funcallvar_48 = __dyc_readpre_byte();
  __dyc_funcallvar_49 = __dyc_readpre_byte();
  __dyc_funcallvar_50 = __dyc_readpre_byte();
  __dyc_funcallvar_51 = __dyc_readpre_byte();
  __dyc_funcallvar_52 = __dyc_readpre_byte();
  __dyc_funcallvar_53 = __dyc_readpre_byte();
  __dyc_funcallvar_54 = __dyc_readpre_byte();
  __dyc_funcallvar_55 = __dyc_readpre_byte();
  __dyc_funcallvar_56 = __dyc_readpre_byte();
  __dyc_funcallvar_57 = __dyc_readpre_byte();
  __dyc_funcallvar_58 = __dyc_readpre_byte();
  __dyc_funcallvar_59 = __dyc_readpre_byte();
  __dyc_funcallvar_60 = __dyc_readpre_byte();
  __dyc_funcallvar_61 = __dyc_readpre_byte();
  __dyc_funcallvar_62 = __dyc_readpre_byte();
  __dyc_funcallvar_63 = __dyc_readpre_byte();
  __dyc_funcallvar_64 = __dyc_readpre_byte();
  __dyc_funcallvar_65 = __dyc_readpre_byte();
  cp = 0;
  n = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  __s1_len = 0;
  __s2_len = 0;
  tmp___18 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___37 = 0;
  tmp___42 = 0;
  tmp___43 = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  tmp___46 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___56 = 0;
  tmp___61 = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  __s1_len___2 = 0;
  __s2_len___2 = 0;
  tmp___75 = 0;
  tmp___80 = 0;
  tmp___81 = 0;
  tmp___82 = 0;
  tmp___83 = 0;
  tmp___84 = 0;
  __s1_len___3 = 0;
  __s2_len___3 = 0;
  tmp___94 = 0;
  tmp___99 = 0;
  tmp___100 = 0;
  tmp___101 = 0;
  tmp___102 = 0;
  tmp___103 = 0;
  __s1_len___4 = 0;
  __s2_len___4 = 0;
  tmp___113 = 0;
  tmp___118 = 0;
  tmp___119 = 0;
  tmp___120 = 0;
  tmp___121 = 0;
  tmp___122 = 0;
  __s1_len___5 = 0;
  __s2_len___5 = 0;
  tmp___132 = 0;
  tmp___137 = 0;
  tmp___138 = 0;
  tmp___139 = 0;
  tmp___140 = 0;
  tmp___141 = 0;
  __s1_len___6 = 0;
  __s2_len___6 = 0;
  tmp___151 = 0;
  tmp___156 = 0;
  tmp___157 = 0;
  tmp___158 = 0;
  tmp___159 = 0;
  tmp___160 = 0;
  __s1_len___7 = 0;
  __s2_len___7 = 0;
  tmp___170 = 0;
  tmp___175 = 0;
  tmp___176 = 0;
  tmp___177 = 0;
  tmp___178 = 0;
  tmp___179 = 0;
  if ((int const   )*s___0 == 35) {
    {
    tmp___1 = __dyc_funcallvar_1;
    }
    if (tmp___1 == 7UL) {
      cp = s___0 + 1;
      {
      while (1) {
        while_1_continue:  ;
        {
        tmp = __dyc_funcallvar_2;
        }
        if (! ((int const   )*(*tmp + (int )((unsigned char )*cp)) & 4096)) {
          goto while_1_break;
        }
        cp ++;
      }
      while_1_break:  ;
      }
      if ((int const   )*cp != 0) {
        goto __dyc_dummy_label;
      }
      {
      n = __dyc_funcallvar_3;
      }
      if (n != 3) {
        goto __dyc_dummy_label;
      }
      {
      tmp___0 = __dyc_funcallvar_4;
      }
      goto __dyc_dummy_label;
    }
  }
  tmp___3 = __dyc_funcallvar_5;
  if (tmp___3 == 0) {
    {
    tmp___2 = __dyc_funcallvar_6;
    n = (int )tmp___2;
    }
    if ((unsigned long )errstr != (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
    goto __dyc_dummy_label;
  }
  tmp___5 = __dyc_funcallvar_7;
  if (tmp___5 == 0) {
    {
    tmp___4 = __dyc_funcallvar_8;
    n = (int )tmp___4;
    }
    if ((unsigned long )errstr != (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
    goto __dyc_dummy_label;
  }
  tmp___6 = __dyc_funcallvar_9;
  if (tmp___6 == 0) {
    goto __dyc_dummy_label;
  }
  tmp___7 = __dyc_funcallvar_10;
  if (tmp___7 == 0) {
    goto __dyc_dummy_label;
  }
  tmp___8 = __dyc_funcallvar_11;
  if (tmp___8 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___24 = __dyc_funcallvar_12;
      __s1_len = (unsigned long )tmp___24;
      tmp___25 = __dyc_funcallvar_13;
      __s2_len = (unsigned long )tmp___25;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___0;
      } else {
        if (__s1_len >= 4UL) {
          _L___0:  
          if (! ((unsigned long )((void const   *)("0" + 1)) - (unsigned long )((void const   *)"0") == 1UL)) {
            tmp___26 = 1;
          } else {
            if (__s2_len >= 4UL) {
              tmp___26 = 1;
            } else {
              tmp___26 = 0;
            }
          }
        } else {
          tmp___26 = 0;
        }
      }
      if (tmp___26) {
        {
        tmp___18 = __dyc_funcallvar_14;
        }
      } else {
        {
        tmp___23 = __dyc_funcallvar_15;
        tmp___18 = tmp___23;
        }
      }
    } else {
      {
      tmp___23 = __dyc_funcallvar_16;
      tmp___18 = tmp___23;
      }
    }
    if (tmp___18 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___27 = __dyc_funcallvar_17;
  if (tmp___27 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___43 = __dyc_funcallvar_18;
      __s1_len___0 = (unsigned long )tmp___43;
      tmp___44 = __dyc_funcallvar_19;
      __s2_len___0 = (unsigned long )tmp___44;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___2;
      } else {
        if (__s1_len___0 >= 4UL) {
          _L___2:  
          if (! ((unsigned long )((void const   *)("1" + 1)) - (unsigned long )((void const   *)"1") == 1UL)) {
            tmp___45 = 1;
          } else {
            if (__s2_len___0 >= 4UL) {
              tmp___45 = 1;
            } else {
              tmp___45 = 0;
            }
          }
        } else {
          tmp___45 = 0;
        }
      }
      if (tmp___45) {
        {
        tmp___37 = __dyc_funcallvar_20;
        }
      } else {
        {
        tmp___42 = __dyc_funcallvar_21;
        tmp___37 = tmp___42;
        }
      }
    } else {
      {
      tmp___42 = __dyc_funcallvar_22;
      tmp___37 = tmp___42;
      }
    }
    if (tmp___37 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___46 = __dyc_funcallvar_23;
  if (tmp___46 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___62 = __dyc_funcallvar_24;
      __s1_len___1 = (unsigned long )tmp___62;
      tmp___63 = __dyc_funcallvar_25;
      __s2_len___1 = (unsigned long )tmp___63;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___4;
      } else {
        if (__s1_len___1 >= 4UL) {
          _L___4:  
          if (! ((unsigned long )((void const   *)("2" + 1)) - (unsigned long )((void const   *)"2") == 1UL)) {
            tmp___64 = 1;
          } else {
            if (__s2_len___1 >= 4UL) {
              tmp___64 = 1;
            } else {
              tmp___64 = 0;
            }
          }
        } else {
          tmp___64 = 0;
        }
      }
      if (tmp___64) {
        {
        tmp___56 = __dyc_funcallvar_26;
        }
      } else {
        {
        tmp___61 = __dyc_funcallvar_27;
        tmp___56 = tmp___61;
        }
      }
    } else {
      {
      tmp___61 = __dyc_funcallvar_28;
      tmp___56 = tmp___61;
      }
    }
    if (tmp___56 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___65 = __dyc_funcallvar_29;
  if (tmp___65 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___81 = __dyc_funcallvar_30;
      __s1_len___2 = (unsigned long )tmp___81;
      tmp___82 = __dyc_funcallvar_31;
      __s2_len___2 = (unsigned long )tmp___82;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___6;
      } else {
        if (__s1_len___2 >= 4UL) {
          _L___6:  
          if (! ((unsigned long )((void const   *)("3" + 1)) - (unsigned long )((void const   *)"3") == 1UL)) {
            tmp___83 = 1;
          } else {
            if (__s2_len___2 >= 4UL) {
              tmp___83 = 1;
            } else {
              tmp___83 = 0;
            }
          }
        } else {
          tmp___83 = 0;
        }
      }
      if (tmp___83) {
        {
        tmp___75 = __dyc_funcallvar_32;
        }
      } else {
        {
        tmp___80 = __dyc_funcallvar_33;
        tmp___75 = tmp___80;
        }
      }
    } else {
      {
      tmp___80 = __dyc_funcallvar_34;
      tmp___75 = tmp___80;
      }
    }
    if (tmp___75 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___84 = __dyc_funcallvar_35;
  if (tmp___84 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___100 = __dyc_funcallvar_36;
      __s1_len___3 = (unsigned long )tmp___100;
      tmp___101 = __dyc_funcallvar_37;
      __s2_len___3 = (unsigned long )tmp___101;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___8;
      } else {
        if (__s1_len___3 >= 4UL) {
          _L___8:  
          if (! ((unsigned long )((void const   *)("4" + 1)) - (unsigned long )((void const   *)"4") == 1UL)) {
            tmp___102 = 1;
          } else {
            if (__s2_len___3 >= 4UL) {
              tmp___102 = 1;
            } else {
              tmp___102 = 0;
            }
          }
        } else {
          tmp___102 = 0;
        }
      }
      if (tmp___102) {
        {
        tmp___94 = __dyc_funcallvar_38;
        }
      } else {
        {
        tmp___99 = __dyc_funcallvar_39;
        tmp___94 = tmp___99;
        }
      }
    } else {
      {
      tmp___99 = __dyc_funcallvar_40;
      tmp___94 = tmp___99;
      }
    }
    if (tmp___94 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___103 = __dyc_funcallvar_41;
  if (tmp___103 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___119 = __dyc_funcallvar_42;
      __s1_len___4 = (unsigned long )tmp___119;
      tmp___120 = __dyc_funcallvar_43;
      __s2_len___4 = (unsigned long )tmp___120;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___10;
      } else {
        if (__s1_len___4 >= 4UL) {
          _L___10:  
          if (! ((unsigned long )((void const   *)("5" + 1)) - (unsigned long )((void const   *)"5") == 1UL)) {
            tmp___121 = 1;
          } else {
            if (__s2_len___4 >= 4UL) {
              tmp___121 = 1;
            } else {
              tmp___121 = 0;
            }
          }
        } else {
          tmp___121 = 0;
        }
      }
      if (tmp___121) {
        {
        tmp___113 = __dyc_funcallvar_44;
        }
      } else {
        {
        tmp___118 = __dyc_funcallvar_45;
        tmp___113 = tmp___118;
        }
      }
    } else {
      {
      tmp___118 = __dyc_funcallvar_46;
      tmp___113 = tmp___118;
      }
    }
    if (tmp___113 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___122 = __dyc_funcallvar_47;
  if (tmp___122 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___138 = __dyc_funcallvar_48;
      __s1_len___5 = (unsigned long )tmp___138;
      tmp___139 = __dyc_funcallvar_49;
      __s2_len___5 = (unsigned long )tmp___139;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___12;
      } else {
        if (__s1_len___5 >= 4UL) {
          _L___12:  
          if (! ((unsigned long )((void const   *)("6" + 1)) - (unsigned long )((void const   *)"6") == 1UL)) {
            tmp___140 = 1;
          } else {
            if (__s2_len___5 >= 4UL) {
              tmp___140 = 1;
            } else {
              tmp___140 = 0;
            }
          }
        } else {
          tmp___140 = 0;
        }
      }
      if (tmp___140) {
        {
        tmp___132 = __dyc_funcallvar_50;
        }
      } else {
        {
        tmp___137 = __dyc_funcallvar_51;
        tmp___132 = tmp___137;
        }
      }
    } else {
      {
      tmp___137 = __dyc_funcallvar_52;
      tmp___132 = tmp___137;
      }
    }
    if (tmp___132 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___141 = __dyc_funcallvar_53;
  if (tmp___141 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___157 = __dyc_funcallvar_54;
      __s1_len___6 = (unsigned long )tmp___157;
      tmp___158 = __dyc_funcallvar_55;
      __s2_len___6 = (unsigned long )tmp___158;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___14;
      } else {
        if (__s1_len___6 >= 4UL) {
          _L___14:  
          if (! ((unsigned long )((void const   *)("7" + 1)) - (unsigned long )((void const   *)"7") == 1UL)) {
            tmp___159 = 1;
          } else {
            if (__s2_len___6 >= 4UL) {
              tmp___159 = 1;
            } else {
              tmp___159 = 0;
            }
          }
        } else {
          tmp___159 = 0;
        }
      }
      if (tmp___159) {
        {
        tmp___151 = __dyc_funcallvar_56;
        }
      } else {
        {
        tmp___156 = __dyc_funcallvar_57;
        tmp___151 = tmp___156;
        }
      }
    } else {
      {
      tmp___156 = __dyc_funcallvar_58;
      tmp___151 = tmp___156;
      }
    }
    if (tmp___151 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___160 = __dyc_funcallvar_59;
  if (tmp___160 == 0) {
    goto __dyc_dummy_label;
  } else {
    if (0) {
      {
      tmp___176 = __dyc_funcallvar_60;
      __s1_len___7 = (unsigned long )tmp___176;
      tmp___177 = __dyc_funcallvar_61;
      __s2_len___7 = (unsigned long )tmp___177;
      }
      if (! ((unsigned long )((void const   *)(s___0 + 1)) - (unsigned long )((void const   *)s___0) == 1UL)) {
        goto _L___16;
      } else {
        if (__s1_len___7 >= 4UL) {
          _L___16:  
          if (! ((unsigned long )((void const   *)("90" + 1)) - (unsigned long )((void const   *)"90") == 1UL)) {
            tmp___178 = 1;
          } else {
            if (__s2_len___7 >= 4UL) {
              tmp___178 = 1;
            } else {
              tmp___178 = 0;
            }
          }
        } else {
          tmp___178 = 0;
        }
      }
      if (tmp___178) {
        {
        tmp___170 = __dyc_funcallvar_62;
        }
      } else {
        {
        tmp___175 = __dyc_funcallvar_63;
        tmp___170 = tmp___175;
        }
      }
    } else {
      {
      tmp___175 = __dyc_funcallvar_64;
      tmp___170 = tmp___175;
      }
    }
    if (tmp___170 == 0) {
      goto __dyc_dummy_label;
    }
  }
  tmp___179 = __dyc_funcallvar_65;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(n);
  __dyc_printpre_byte(tmp___0);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_printpre_byte(__s1_len___2);
  __dyc_printpre_byte(__s2_len___2);
  __dyc_printpre_byte(__s1_len___3);
  __dyc_printpre_byte(__s2_len___3);
  __dyc_printpre_byte(__s1_len___4);
  __dyc_printpre_byte(__s2_len___4);
  __dyc_printpre_byte(__s1_len___5);
  __dyc_printpre_byte(__s2_len___5);
  __dyc_printpre_byte(__s1_len___6);
  __dyc_printpre_byte(__s2_len___6);
  __dyc_printpre_byte(__s1_len___7);
  __dyc_printpre_byte(__s2_len___7);
  __dyc_printpre_byte(tmp___179);
}
}
