#line 137 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned long __ino_t;
#line 141 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __off_t;
#line 143 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef int __pid_t;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 23 "/usr/include/x86_64-linux-gnu/bits/dirent.h"
struct dirent {
   __ino_t d_ino ;
   __off_t d_off ;
   unsigned short d_reclen ;
   unsigned char d_type ;
   char d_name[256] ;
};
#line 129 "/usr/include/dirent.h"
struct __dirstream;
#line 129 "/usr/include/dirent.h"
typedef struct __dirstream DIR;
extern struct dirent __dyc_random_comp_48dirent(unsigned int __dyc_exp ) ;
extern struct dirent __dyc_read_comp_48dirent(void) ;
extern void __dyc_print_comp_48dirent(struct dirent __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern void *__dyc_random_ptr__typdef_DIR(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__typdef_DIR(void) ;
extern void __dyc_print_ptr__typdef_DIR(void const   * const  __dyc_thistype ) ;
extern __off_t __dyc_random_typdef___off_t(unsigned int __dyc_exp ) ;
extern __off_t __dyc_read_typdef___off_t(void) ;
extern void __dyc_print_typdef___off_t(__off_t __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   * __restrict  __dyc_thistype ) ;
extern __pid_t __dyc_random_typdef___pid_t(unsigned int __dyc_exp ) ;
extern __pid_t __dyc_read_typdef___pid_t(void) ;
extern void __dyc_print_typdef___pid_t(__pid_t __dyc_thistype ) ;
extern __ino_t __dyc_random_typdef___ino_t(unsigned int __dyc_exp ) ;
extern __ino_t __dyc_read_typdef___ino_t(void) ;
extern void __dyc_print_typdef___ino_t(__ino_t __dyc_thistype ) ;
extern struct dirent *__dyc_random_ptr__comp_48dirent(unsigned int __dyc_exp ) ;
extern struct dirent *__dyc_read_ptr__comp_48dirent(void) ;
extern void __dyc_print_ptr__comp_48dirent(struct dirent  const  *__dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  * __restrict  __dyc_thistype ) ;
