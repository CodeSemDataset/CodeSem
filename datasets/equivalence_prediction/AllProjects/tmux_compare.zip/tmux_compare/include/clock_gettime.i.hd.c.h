#line 149 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __time_t;
#line 151 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __suseconds_t;
#line 120 "/usr/include/time.h"
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
#line 31 "/usr/include/x86_64-linux-gnu/bits/time.h"
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
#line 57 "/usr/include/x86_64-linux-gnu/sys/time.h"
struct timezone {
   int tz_minuteswest ;
   int tz_dsttime ;
};
#line 63 "/usr/include/x86_64-linux-gnu/sys/time.h"
typedef struct timezone *__timezone_ptr_t;
extern struct timespec *__dyc_random_ptr__comp_3timespec(unsigned int __dyc_exp ) ;
extern struct timespec *__dyc_read_ptr__comp_3timespec(void) ;
extern void __dyc_print_ptr__comp_3timespec(struct timespec  const  *__dyc_thistype ) ;
extern struct timeval __dyc_random_comp_4timeval(unsigned int __dyc_exp ) ;
extern struct timeval __dyc_read_comp_4timeval(void) ;
extern void __dyc_print_comp_4timeval(struct timeval __dyc_thistype ) ;
extern struct timespec __dyc_random_comp_3timespec(unsigned int __dyc_exp ) ;
extern struct timespec __dyc_read_comp_3timespec(void) ;
extern void __dyc_print_comp_3timespec(struct timespec __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern __suseconds_t __dyc_random_typdef___suseconds_t(unsigned int __dyc_exp ) ;
extern __suseconds_t __dyc_read_typdef___suseconds_t(void) ;
extern void __dyc_print_typdef___suseconds_t(__suseconds_t __dyc_thistype ) ;
extern __time_t __dyc_random_typdef___time_t(unsigned int __dyc_exp ) ;
extern __time_t __dyc_read_typdef___time_t(void) ;
extern void __dyc_print_typdef___time_t(__time_t __dyc_thistype ) ;
extern __timezone_ptr_t __dyc_random_typdef___timezone_ptr_t(unsigned int __dyc_exp ) ;
extern __timezone_ptr_t __dyc_read_typdef___timezone_ptr_t(void) ;
extern void __dyc_print_typdef___timezone_ptr_t(__timezone_ptr_t __dyc_thistype ) ;
extern struct timeval *__dyc_random_ptr__comp_4timeval(unsigned int __dyc_exp ) ;
extern struct timeval *__dyc_read_ptr__comp_4timeval(void) ;
extern void __dyc_print_ptr__comp_4timeval(struct timeval  const  * __restrict  __dyc_thistype ) ;
extern struct timezone __dyc_random_comp_19timezone(unsigned int __dyc_exp ) ;
extern struct timezone __dyc_read_comp_19timezone(void) ;
extern void __dyc_print_comp_19timezone(struct timezone __dyc_thistype ) ;
extern struct timezone *__dyc_random_ptr__comp_19timezone(unsigned int __dyc_exp ) ;
extern struct timezone *__dyc_read_ptr__comp_19timezone(void) ;
extern void __dyc_print_ptr__comp_19timezone(struct timezone  const  *__dyc_thistype ) ;
