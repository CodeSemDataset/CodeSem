#line 31 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned char __u_char;
#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 34 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_char u_char;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 39 "tmux.h"
struct args;
#line 39
struct args;
#line 42
struct cmd;
#line 42
struct cmd;
#line 44
struct cmdq_item;
#line 44
struct cmdq_item;
#line 47
struct cmds;
#line 47
struct cmds;
#line 177 "tmux.h"
typedef unsigned long long key_code;
#line 1433
struct args_entry;
#line 1433
struct args_entry;
#line 1434 "tmux.h"
struct args_tree {
   struct args_entry *rbh_root ;
};
#line 1435 "tmux.h"
struct args {
   struct args_tree tree ;
   int argc ;
   char **argv ;
};
#line 1442
enum cmd_find_type {
    CMD_FIND_PANE = 0,
    CMD_FIND_WINDOW = 1,
    CMD_FIND_SESSION = 2
} ;
#line 1468 "tmux.h"
struct cmd_list {
   int references ;
   u_int group ;
   struct cmds *list ;
};
#line 1475
enum cmd_retval {
    CMD_RETURN_ERROR = -1,
    CMD_RETURN_NORMAL = 0,
    CMD_RETURN_WAIT = 1,
    CMD_RETURN_STOP = 2
} ;
#line 1518 "tmux.h"
struct cmd_entry_flag {
   char flag ;
   enum cmd_find_type type ;
   int flags ;
};
#line 1525 "tmux.h"
struct __anonstruct_args_75 {
   char *template ;
   int lower ;
   int upper ;
};
#line 1525 "tmux.h"
struct cmd_entry {
   char *name ;
   char *alias ;
   struct __anonstruct_args_75 args ;
   char *usage ;
   struct cmd_entry_flag source ;
   struct cmd_entry_flag target ;
   int flags ;
   enum cmd_retval (*exec)(struct cmd * , struct cmdq_item * ) ;
};
#line 1608
struct key_table;
#line 1776 "tmux.h"
struct __anonstruct_entry_81 {
   struct key_binding *rbe_left ;
   struct key_binding *rbe_right ;
   struct key_binding *rbe_parent ;
   int rbe_color ;
};
#line 1776 "tmux.h"
struct key_binding {
   key_code key ;
   struct cmd_list *cmdlist ;
   char *note ;
   int flags ;
   struct __anonstruct_entry_81 entry ;
};
#line 1786 "tmux.h"
struct key_bindings {
   struct key_binding *rbh_root ;
};
#line 1788 "tmux.h"
struct __anonstruct_entry_82 {
   struct key_table *rbe_left ;
   struct key_table *rbe_right ;
   struct key_table *rbe_parent ;
   int rbe_color ;
};
#line 1788 "tmux.h"
struct key_table {
   char *name ;
   struct key_bindings key_bindings ;
   struct key_bindings default_key_bindings ;
   u_int references ;
   struct __anonstruct_entry_82 entry ;
};
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern u_char __dyc_random_typdef_u_char(unsigned int __dyc_exp ) ;
extern u_char __dyc_read_typdef_u_char(void) ;
extern void __dyc_print_typdef_u_char(u_char __dyc_thistype ) ;
extern struct args __dyc_random_comp_141args(unsigned int __dyc_exp ) ;
extern struct args __dyc_read_comp_141args(void) ;
extern void __dyc_print_comp_141args(struct args __dyc_thistype ) ;
extern struct __anonstruct_args_75 __dyc_random_comp_248__anonstruct_args_75(unsigned int __dyc_exp ) ;
extern struct __anonstruct_args_75 __dyc_read_comp_248__anonstruct_args_75(void) ;
extern void __dyc_print_comp_248__anonstruct_args_75(struct __anonstruct_args_75 __dyc_thistype ) ;
extern struct __anonstruct_entry_81 __dyc_random_comp_261__anonstruct_entry_81(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_81 __dyc_read_comp_261__anonstruct_entry_81(void) ;
extern void __dyc_print_comp_261__anonstruct_entry_81(struct __anonstruct_entry_81 __dyc_thistype ) ;
extern struct __anonstruct_entry_82 __dyc_random_comp_263__anonstruct_entry_82(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_82 __dyc_read_comp_263__anonstruct_entry_82(void) ;
extern void __dyc_print_comp_263__anonstruct_entry_82(struct __anonstruct_entry_82 __dyc_thistype ) ;
extern struct key_table __dyc_random_comp_257key_table(unsigned int __dyc_exp ) ;
extern struct key_table __dyc_read_comp_257key_table(void) ;
extern void __dyc_print_comp_257key_table(struct key_table __dyc_thistype ) ;
extern struct args *__dyc_random_ptr__comp_141args(unsigned int __dyc_exp ) ;
extern struct args *__dyc_read_ptr__comp_141args(void) ;
extern void __dyc_print_ptr__comp_141args(struct args  const  *__dyc_thistype ) ;
extern void *__dyc_random_ptr__fun_name_is_not_here(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__fun_name_is_not_here(void) ;
extern void __dyc_print_ptr__fun_name_is_not_here(void const   * const  __dyc_thistype ) ;
extern struct cmd_entry __dyc_random_comp_247cmd_entry(unsigned int __dyc_exp ) ;
extern struct cmd_entry __dyc_read_comp_247cmd_entry(void) ;
extern void __dyc_print_comp_247cmd_entry(struct cmd_entry __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_146cmdq_item(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_146cmdq_item(void) ;
extern void __dyc_print_ptr__comp_146cmdq_item(void const   * const  __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_144cmd(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_144cmd(void) ;
extern void __dyc_print_ptr__comp_144cmd(void const   * const  __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern struct key_bindings __dyc_random_comp_262key_bindings(unsigned int __dyc_exp ) ;
extern struct key_bindings __dyc_read_comp_262key_bindings(void) ;
extern void __dyc_print_comp_262key_bindings(struct key_bindings __dyc_thistype ) ;
extern struct args_tree __dyc_random_comp_242args_tree(unsigned int __dyc_exp ) ;
extern struct args_tree __dyc_read_comp_242args_tree(void) ;
extern void __dyc_print_comp_242args_tree(struct args_tree __dyc_thistype ) ;
extern struct cmd_entry_flag __dyc_random_comp_246cmd_entry_flag(unsigned int __dyc_exp ) ;
extern struct cmd_entry_flag __dyc_read_comp_246cmd_entry_flag(void) ;
extern void __dyc_print_comp_246cmd_entry_flag(struct cmd_entry_flag __dyc_thistype ) ;
extern __u_char __dyc_random_typdef___u_char(unsigned int __dyc_exp ) ;
extern __u_char __dyc_read_typdef___u_char(void) ;
extern void __dyc_print_typdef___u_char(__u_char __dyc_thistype ) ;
extern struct key_binding __dyc_random_comp_260key_binding(unsigned int __dyc_exp ) ;
extern struct key_binding __dyc_read_comp_260key_binding(void) ;
extern void __dyc_print_comp_260key_binding(struct key_binding __dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct key_binding *__dyc_random_ptr__comp_260key_binding(unsigned int __dyc_exp ) ;
extern struct key_binding *__dyc_read_ptr__comp_260key_binding(void) ;
extern void __dyc_print_ptr__comp_260key_binding(struct key_binding  const  *__dyc_thistype ) ;
extern struct key_table *__dyc_random_ptr__comp_257key_table(unsigned int __dyc_exp ) ;
extern struct key_table *__dyc_read_ptr__comp_257key_table(void) ;
extern void __dyc_print_ptr__comp_257key_table(struct key_table  const  *__dyc_thistype ) ;
extern struct cmd_list __dyc_random_comp_243cmd_list(unsigned int __dyc_exp ) ;
extern struct cmd_list __dyc_read_comp_243cmd_list(void) ;
extern void __dyc_print_comp_243cmd_list(struct cmd_list __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_241args_entry(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_241args_entry(void) ;
extern void __dyc_print_ptr__comp_241args_entry(void const   * const  __dyc_thistype ) ;
extern key_code __dyc_random_typdef_key_code(unsigned int __dyc_exp ) ;
extern key_code __dyc_read_typdef_key_code(void) ;
extern void __dyc_print_typdef_key_code(key_code __dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_149cmds(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_149cmds(void) ;
extern void __dyc_print_ptr__comp_149cmds(void const   * const  __dyc_thistype ) ;
extern struct cmd_list *__dyc_random_ptr__comp_243cmd_list(unsigned int __dyc_exp ) ;
extern struct cmd_list *__dyc_read_ptr__comp_243cmd_list(void) ;
extern void __dyc_print_ptr__comp_243cmd_list(struct cmd_list  const  *__dyc_thistype ) ;
