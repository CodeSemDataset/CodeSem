#line 31 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned char __u_char;
#line 32 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned short __u_short;
#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 34 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_char u_char;
#line 35 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_short u_short;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 620 "tmux.h"
typedef u_int utf8_char;
#line 628 "tmux.h"
struct utf8_data {
   u_char data[21] ;
   u_char have ;
   u_char size ;
   u_char width ;
};
#line 636
enum utf8_state {
    UTF8_MORE = 0,
    UTF8_DONE = 1,
    UTF8_ERROR = 2
} ;
#line 688 "tmux.h"
struct grid_cell {
   struct utf8_data data ;
   u_short attr ;
   u_char flags ;
   int fg ;
   int bg ;
   int us ;
};
#line 698 "tmux.h"
struct grid_extd_entry {
   utf8_char data ;
   u_short attr ;
   u_char flags ;
   int fg ;
   int bg ;
   int us ;
};
#line 708 "tmux.h"
struct __anonstruct_data_54 {
   u_char attr ;
   u_char fg ;
   u_char bg ;
   u_char data ;
};
#line 708 "tmux.h"
union __anonunion____missing_field_name_53 {
   u_int offset ;
   struct __anonstruct_data_54 data ;
};
#line 708 "tmux.h"
struct grid_cell_entry {
   u_char flags ;
   union __anonunion____missing_field_name_53 __annonCompField1 ;
};
#line 722 "tmux.h"
struct grid_line {
   u_int cellused ;
   u_int cellsize ;
   struct grid_cell_entry *celldata ;
   u_int extdsize ;
   struct grid_extd_entry *extddata ;
   int flags ;
};
#line 734 "tmux.h"
struct grid {
   int flags ;
   u_int sx ;
   u_int sy ;
   u_int hscrolled ;
   u_int hsize ;
   u_int hlimit ;
   struct grid_line *linedata ;
};
#line 842 "grid.c"
struct __anonstruct_attrs_83 {
   u_int mask ;
   u_int code ;
};
extern struct __anonstruct_attrs_83 __dyc_random_comp_274__anonstruct_attrs_83(unsigned int __dyc_exp ) ;
extern struct __anonstruct_attrs_83 __dyc_read_comp_274__anonstruct_attrs_83(void) ;
extern void __dyc_print_comp_274__anonstruct_attrs_83(struct __anonstruct_attrs_83 __dyc_thistype ) ;
extern u_short __dyc_random_typdef_u_short(unsigned int __dyc_exp ) ;
extern u_short __dyc_read_typdef_u_short(void) ;
extern void __dyc_print_typdef_u_short(u_short __dyc_thistype ) ;
extern struct grid_cell **__dyc_random_ptr__ptr__comp_178grid_cell(unsigned int __dyc_exp ) ;
extern struct grid_cell **__dyc_read_ptr__ptr__comp_178grid_cell(void) ;
extern void __dyc_print_ptr__ptr__comp_178grid_cell(struct grid_cell * const  *__dyc_thistype ) ;
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern struct grid_cell_entry __dyc_random_comp_180grid_cell_entry(unsigned int __dyc_exp ) ;
extern struct grid_cell_entry __dyc_read_comp_180grid_cell_entry(void) ;
extern void __dyc_print_comp_180grid_cell_entry(struct grid_cell_entry __dyc_thistype ) ;
extern u_char __dyc_random_typdef_u_char(unsigned int __dyc_exp ) ;
extern u_char __dyc_read_typdef_u_char(void) ;
extern void __dyc_print_typdef_u_char(u_char __dyc_thistype ) ;
extern int *__dyc_random_ptr__int(unsigned int __dyc_exp ) ;
extern int *__dyc_read_ptr__int(void) ;
extern void __dyc_print_ptr__int(int const   *__dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern struct grid_line __dyc_random_comp_183grid_line(unsigned int __dyc_exp ) ;
extern struct grid_line __dyc_read_comp_183grid_line(void) ;
extern void __dyc_print_comp_183grid_line(struct grid_line __dyc_thistype ) ;
extern struct grid_cell_entry *__dyc_random_ptr__comp_180grid_cell_entry(unsigned int __dyc_exp ) ;
extern struct grid_cell_entry *__dyc_read_ptr__comp_180grid_cell_entry(void) ;
extern void __dyc_print_ptr__comp_180grid_cell_entry(struct grid_cell_entry  const  *__dyc_thistype ) ;
extern u_int *__dyc_random_ptr__typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int *__dyc_read_ptr__typdef_u_int(void) ;
extern void __dyc_print_ptr__typdef_u_int(u_int const   *__dyc_thistype ) ;
extern struct grid __dyc_random_comp_184grid(unsigned int __dyc_exp ) ;
extern struct grid __dyc_read_comp_184grid(void) ;
extern void __dyc_print_comp_184grid(struct grid __dyc_thistype ) ;
extern utf8_char __dyc_random_typdef_utf8_char(unsigned int __dyc_exp ) ;
extern utf8_char __dyc_read_typdef_utf8_char(void) ;
extern void __dyc_print_typdef_utf8_char(utf8_char __dyc_thistype ) ;
extern struct grid_cell *__dyc_random_ptr__comp_178grid_cell(unsigned int __dyc_exp ) ;
extern struct grid_cell *__dyc_read_ptr__comp_178grid_cell(void) ;
extern void __dyc_print_ptr__comp_178grid_cell(struct grid_cell  const  *__dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern union __anonunion____missing_field_name_53 __dyc_random_comp_181__anonunion____missing_field_name_53(unsigned int __dyc_exp ) ;
extern union __anonunion____missing_field_name_53 __dyc_read_comp_181__anonunion____missing_field_name_53(void) ;
extern void __dyc_print_comp_181__anonunion____missing_field_name_53(union __anonunion____missing_field_name_53 __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern utf8_char *__dyc_random_ptr__typdef_utf8_char(unsigned int __dyc_exp ) ;
extern utf8_char *__dyc_read_ptr__typdef_utf8_char(void) ;
extern void __dyc_print_ptr__typdef_utf8_char(utf8_char const   *__dyc_thistype ) ;
extern struct grid *__dyc_random_ptr__comp_184grid(unsigned int __dyc_exp ) ;
extern struct grid *__dyc_read_ptr__comp_184grid(void) ;
extern void __dyc_print_ptr__comp_184grid(struct grid  const  *__dyc_thistype ) ;
extern struct utf8_data *__dyc_random_ptr__comp_177utf8_data(unsigned int __dyc_exp ) ;
extern struct utf8_data *__dyc_read_ptr__comp_177utf8_data(void) ;
extern void __dyc_print_ptr__comp_177utf8_data(struct utf8_data  const  *__dyc_thistype ) ;
extern __u_char __dyc_random_typdef___u_char(unsigned int __dyc_exp ) ;
extern __u_char __dyc_read_typdef___u_char(void) ;
extern void __dyc_print_typdef___u_char(__u_char __dyc_thistype ) ;
extern u_char *__dyc_random_ptr__typdef_u_char(unsigned int __dyc_exp ) ;
extern u_char *__dyc_read_ptr__typdef_u_char(void) ;
extern void __dyc_print_ptr__typdef_u_char(u_char const   *__dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct grid_line *__dyc_random_ptr__comp_183grid_line(unsigned int __dyc_exp ) ;
extern struct grid_line *__dyc_read_ptr__comp_183grid_line(void) ;
extern void __dyc_print_ptr__comp_183grid_line(struct grid_line  const  *__dyc_thistype ) ;
extern struct grid_cell __dyc_random_comp_178grid_cell(unsigned int __dyc_exp ) ;
extern struct grid_cell __dyc_read_comp_178grid_cell(void) ;
extern void __dyc_print_comp_178grid_cell(struct grid_cell __dyc_thistype ) ;
extern struct grid_extd_entry __dyc_random_comp_179grid_extd_entry(unsigned int __dyc_exp ) ;
extern struct grid_extd_entry __dyc_read_comp_179grid_extd_entry(void) ;
extern void __dyc_print_comp_179grid_extd_entry(struct grid_extd_entry __dyc_thistype ) ;
extern struct __anonstruct_data_54 __dyc_random_comp_182__anonstruct_data_54(unsigned int __dyc_exp ) ;
extern struct __anonstruct_data_54 __dyc_read_comp_182__anonstruct_data_54(void) ;
extern void __dyc_print_comp_182__anonstruct_data_54(struct __anonstruct_data_54 __dyc_thistype ) ;
extern struct grid_extd_entry *__dyc_random_ptr__comp_179grid_extd_entry(unsigned int __dyc_exp ) ;
extern struct grid_extd_entry *__dyc_read_ptr__comp_179grid_extd_entry(void) ;
extern void __dyc_print_ptr__comp_179grid_extd_entry(struct grid_extd_entry  const  *__dyc_thistype ) ;
extern __u_short __dyc_random_typdef___u_short(unsigned int __dyc_exp ) ;
extern __u_short __dyc_read_typdef___u_short(void) ;
extern void __dyc_print_typdef___u_short(__u_short __dyc_thistype ) ;
extern struct utf8_data __dyc_random_comp_177utf8_data(unsigned int __dyc_exp ) ;
extern struct utf8_data __dyc_read_comp_177utf8_data(void) ;
extern void __dyc_print_comp_177utf8_data(struct utf8_data __dyc_thistype ) ;
