#line 143 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef int __pid_t;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 82 "/usr/include/glob.h"
struct stat;
#line 82
struct stat;
#line 84
struct dirent;
#line 84 "/usr/include/glob.h"
struct __anonstruct_glob_t_15 {
   size_t gl_pathc ;
   char **gl_pathv ;
   size_t gl_offs ;
   int gl_flags ;
   void (*gl_closedir)(void * ) ;
   struct dirent *(*gl_readdir)(void * ) ;
   void *(*gl_opendir)(char const   * ) ;
   int (*gl_lstat)(char const   * __restrict   , struct stat * __restrict   ) ;
   int (*gl_stat)(char const   * __restrict   , struct stat * __restrict   ) ;
};
#line 84 "/usr/include/glob.h"
typedef struct __anonstruct_glob_t_15 glob_t;
extern void *__dyc_random_ptr__comp_21dirent(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_21dirent(void) ;
extern void __dyc_print_ptr__comp_21dirent(void const   * const  __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_19stat(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_19stat(void) ;
extern void __dyc_print_ptr__comp_19stat(void const   * const  __dyc_thistype ) ;
extern glob_t __dyc_random_typdef_glob_t(unsigned int __dyc_exp ) ;
extern glob_t __dyc_read_typdef_glob_t(void) ;
extern void __dyc_print_typdef_glob_t(glob_t __dyc_thistype ) ;
extern void *__dyc_random_ptr__fun_name_is_not_here(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__fun_name_is_not_here(void) ;
extern void __dyc_print_ptr__fun_name_is_not_here(void const   * const  __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern struct __anonstruct_glob_t_15 __dyc_random_comp_20__anonstruct_glob_t_15(unsigned int __dyc_exp ) ;
extern struct __anonstruct_glob_t_15 __dyc_read_comp_20__anonstruct_glob_t_15(void) ;
extern void __dyc_print_comp_20__anonstruct_glob_t_15(struct __anonstruct_glob_t_15 __dyc_thistype ) ;
extern __pid_t __dyc_random_typdef___pid_t(unsigned int __dyc_exp ) ;
extern __pid_t __dyc_read_typdef___pid_t(void) ;
extern void __dyc_print_typdef___pid_t(__pid_t __dyc_thistype ) ;
extern glob_t *__dyc_random_ptr__typdef_glob_t(unsigned int __dyc_exp ) ;
extern glob_t *__dyc_read_ptr__typdef_glob_t(void) ;
extern void __dyc_print_ptr__typdef_glob_t(glob_t const   * __restrict  __dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
