#line 31 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned char __u_char;
#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 180 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __ssize_t;
#line 34 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_char u_char;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 110 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __ssize_t ssize_t;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 324 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef int wchar_t;
#line 620 "tmux.h"
typedef u_int utf8_char;
#line 628 "tmux.h"
struct utf8_data {
   u_char data[21] ;
   u_char have ;
   u_char size ;
   u_char width ;
};
#line 636
enum utf8_state {
    UTF8_MORE = 0,
    UTF8_DONE = 1,
    UTF8_ERROR = 2
} ;
#line 29 "utf8.c"
struct __anonstruct_index_entry_84 {
   struct utf8_item *rbe_left ;
   struct utf8_item *rbe_right ;
   struct utf8_item *rbe_parent ;
   int rbe_color ;
};
#line 29 "utf8.c"
struct __anonstruct_data_entry_85 {
   struct utf8_item *rbe_left ;
   struct utf8_item *rbe_right ;
   struct utf8_item *rbe_parent ;
   int rbe_color ;
};
#line 29 "utf8.c"
struct utf8_item {
   struct __anonstruct_index_entry_84 index_entry ;
   u_int index ;
   struct __anonstruct_data_entry_85 data_entry ;
   char data[21] ;
   u_char size ;
};
#line 47 "utf8.c"
struct utf8_data_tree {
   struct utf8_item *rbh_root ;
};
#line 60 "utf8.c"
struct utf8_index_tree {
   struct utf8_item *rbh_root ;
};
extern struct __anonstruct_data_entry_85 __dyc_random_comp_276__anonstruct_data_entry_85(unsigned int __dyc_exp ) ;
extern struct __anonstruct_data_entry_85 __dyc_read_comp_276__anonstruct_data_entry_85(void) ;
extern void __dyc_print_comp_276__anonstruct_data_entry_85(struct __anonstruct_data_entry_85 __dyc_thistype ) ;
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern wchar_t __dyc_random_typdef_wchar_t(unsigned int __dyc_exp ) ;
extern wchar_t __dyc_read_typdef_wchar_t(void) ;
extern void __dyc_print_typdef_wchar_t(wchar_t __dyc_thistype ) ;
extern unsigned short **__dyc_random_ptr__ptr__short(unsigned int __dyc_exp ) ;
extern unsigned short **__dyc_read_ptr__ptr__short(void) ;
extern void __dyc_print_ptr__ptr__short(unsigned short const   * const  *__dyc_thistype ) ;
extern u_char __dyc_random_typdef_u_char(unsigned int __dyc_exp ) ;
extern u_char __dyc_read_typdef_u_char(void) ;
extern void __dyc_print_typdef_u_char(u_char __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern int *__dyc_random_ptr__int(unsigned int __dyc_exp ) ;
extern int *__dyc_read_ptr__int(void) ;
extern void __dyc_print_ptr__int(int const   *__dyc_thistype ) ;
extern struct utf8_data_tree __dyc_random_comp_277utf8_data_tree(unsigned int __dyc_exp ) ;
extern struct utf8_data_tree __dyc_read_comp_277utf8_data_tree(void) ;
extern void __dyc_print_comp_277utf8_data_tree(struct utf8_data_tree __dyc_thistype ) ;
extern u_int *__dyc_random_ptr__typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int *__dyc_read_ptr__typdef_u_int(void) ;
extern void __dyc_print_ptr__typdef_u_int(u_int const   *__dyc_thistype ) ;
extern utf8_char __dyc_random_typdef_utf8_char(unsigned int __dyc_exp ) ;
extern utf8_char __dyc_read_typdef_utf8_char(void) ;
extern void __dyc_print_typdef_utf8_char(utf8_char __dyc_thistype ) ;
extern struct __anonstruct_index_entry_84 __dyc_random_comp_275__anonstruct_index_entry_84(unsigned int __dyc_exp ) ;
extern struct __anonstruct_index_entry_84 __dyc_read_comp_275__anonstruct_index_entry_84(void) ;
extern void __dyc_print_comp_275__anonstruct_index_entry_84(struct __anonstruct_index_entry_84 __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern unsigned short *__dyc_random_ptr__short(unsigned int __dyc_exp ) ;
extern unsigned short *__dyc_read_ptr__short(void) ;
extern void __dyc_print_ptr__short(unsigned short const   *__dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   * __restrict  __dyc_thistype ) ;
extern utf8_char *__dyc_random_ptr__typdef_utf8_char(unsigned int __dyc_exp ) ;
extern utf8_char *__dyc_read_ptr__typdef_utf8_char(void) ;
extern void __dyc_print_ptr__typdef_utf8_char(utf8_char const   *__dyc_thistype ) ;
extern struct utf8_data *__dyc_random_ptr__comp_177utf8_data(unsigned int __dyc_exp ) ;
extern struct utf8_data *__dyc_read_ptr__comp_177utf8_data(void) ;
extern void __dyc_print_ptr__comp_177utf8_data(struct utf8_data  const  *__dyc_thistype ) ;
extern struct utf8_item *__dyc_random_ptr__comp_274utf8_item(unsigned int __dyc_exp ) ;
extern struct utf8_item *__dyc_read_ptr__comp_274utf8_item(void) ;
extern void __dyc_print_ptr__comp_274utf8_item(struct utf8_item  const  *__dyc_thistype ) ;
extern __u_char __dyc_random_typdef___u_char(unsigned int __dyc_exp ) ;
extern __u_char __dyc_read_typdef___u_char(void) ;
extern void __dyc_print_typdef___u_char(__u_char __dyc_thistype ) ;
extern __ssize_t __dyc_random_typdef___ssize_t(unsigned int __dyc_exp ) ;
extern __ssize_t __dyc_read_typdef___ssize_t(void) ;
extern void __dyc_print_typdef___ssize_t(__ssize_t __dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct utf8_index_tree __dyc_random_comp_278utf8_index_tree(unsigned int __dyc_exp ) ;
extern struct utf8_index_tree __dyc_read_comp_278utf8_index_tree(void) ;
extern void __dyc_print_comp_278utf8_index_tree(struct utf8_index_tree __dyc_thistype ) ;
extern wchar_t *__dyc_random_ptr__typdef_wchar_t(unsigned int __dyc_exp ) ;
extern wchar_t *__dyc_read_ptr__typdef_wchar_t(void) ;
extern void __dyc_print_ptr__typdef_wchar_t(wchar_t const   * __restrict  __dyc_thistype ) ;
extern ssize_t __dyc_random_typdef_ssize_t(unsigned int __dyc_exp ) ;
extern ssize_t __dyc_read_typdef_ssize_t(void) ;
extern void __dyc_print_typdef_ssize_t(ssize_t __dyc_thistype ) ;
extern struct utf8_index_tree *__dyc_random_ptr__comp_278utf8_index_tree(unsigned int __dyc_exp ) ;
extern struct utf8_index_tree *__dyc_read_ptr__comp_278utf8_index_tree(void) ;
extern void __dyc_print_ptr__comp_278utf8_index_tree(struct utf8_index_tree  const  *__dyc_thistype ) ;
extern struct utf8_data_tree *__dyc_random_ptr__comp_277utf8_data_tree(unsigned int __dyc_exp ) ;
extern struct utf8_data_tree *__dyc_read_ptr__comp_277utf8_data_tree(void) ;
extern void __dyc_print_ptr__comp_277utf8_data_tree(struct utf8_data_tree  const  *__dyc_thistype ) ;
extern struct utf8_data __dyc_random_comp_177utf8_data(unsigned int __dyc_exp ) ;
extern struct utf8_data __dyc_read_comp_177utf8_data(void) ;
extern void __dyc_print_comp_177utf8_data(struct utf8_data __dyc_thistype ) ;
extern struct utf8_item __dyc_random_comp_274utf8_item(unsigned int __dyc_exp ) ;
extern struct utf8_item __dyc_read_comp_274utf8_item(void) ;
extern void __dyc_print_comp_274utf8_item(struct utf8_item __dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
