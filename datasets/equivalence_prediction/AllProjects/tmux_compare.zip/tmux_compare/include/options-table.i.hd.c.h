#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 1810 "tmux.h"
enum options_table_type {
    OPTIONS_TABLE_STRING = 0,
    OPTIONS_TABLE_NUMBER = 1,
    OPTIONS_TABLE_KEY = 2,
    OPTIONS_TABLE_COLOUR = 3,
    OPTIONS_TABLE_FLAG = 4,
    OPTIONS_TABLE_CHOICE = 5,
    OPTIONS_TABLE_COMMAND = 6
} ;
#line 1830 "tmux.h"
struct options_table_entry {
   char *name ;
   char *alternative_name ;
   enum options_table_type type ;
   int scope ;
   int flags ;
   u_int minimum ;
   u_int maximum ;
   char **choices ;
   char *default_str ;
   long long default_num ;
   char **default_arr ;
   char *separator ;
   char *pattern ;
   char *text ;
   char *unit ;
};
#line 1852 "tmux.h"
struct options_name_map {
   char *from ;
   char *to ;
};
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern struct options_table_entry __dyc_random_comp_258options_table_entry(unsigned int __dyc_exp ) ;
extern struct options_table_entry __dyc_read_comp_258options_table_entry(void) ;
extern void __dyc_print_comp_258options_table_entry(struct options_table_entry __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct options_name_map __dyc_random_comp_259options_name_map(unsigned int __dyc_exp ) ;
extern struct options_name_map __dyc_read_comp_259options_name_map(void) ;
extern void __dyc_print_comp_259options_name_map(struct options_name_map __dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
