#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 180 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __ssize_t;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 110 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __ssize_t ssize_t;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 45 "/usr/include/regex.h"
typedef unsigned long reg_syntax_t;
#line 370 "/usr/include/regex.h"
struct re_pattern_buffer {
   unsigned char *buffer ;
   unsigned long allocated ;
   unsigned long used ;
   reg_syntax_t syntax ;
   char *fastmap ;
   unsigned char *translate ;
   size_t re_nsub ;
   unsigned int can_be_null : 1 ;
   unsigned int regs_allocated : 2 ;
   unsigned int fastmap_accurate : 1 ;
   unsigned int no_sub : 1 ;
   unsigned int not_bol : 1 ;
   unsigned int not_eol : 1 ;
   unsigned int newline_anchor : 1 ;
};
#line 436 "/usr/include/regex.h"
typedef struct re_pattern_buffer regex_t;
#line 439 "/usr/include/regex.h"
typedef int regoff_t;
#line 465 "/usr/include/regex.h"
struct __anonstruct_regmatch_t_16 {
   regoff_t rm_so ;
   regoff_t rm_eo ;
};
#line 465 "/usr/include/regex.h"
typedef struct __anonstruct_regmatch_t_16 regmatch_t;
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern regoff_t __dyc_random_typdef_regoff_t(unsigned int __dyc_exp ) ;
extern regoff_t __dyc_read_typdef_regoff_t(void) ;
extern void __dyc_print_typdef_regoff_t(regoff_t __dyc_thistype ) ;
extern regex_t *__dyc_random_ptr__typdef_regex_t(unsigned int __dyc_exp ) ;
extern regex_t *__dyc_read_ptr__typdef_regex_t(void) ;
extern void __dyc_print_ptr__typdef_regex_t(regex_t const   * __restrict  __dyc_thistype ) ;
extern struct re_pattern_buffer __dyc_random_comp_19re_pattern_buffer(unsigned int __dyc_exp ) ;
extern struct re_pattern_buffer __dyc_read_comp_19re_pattern_buffer(void) ;
extern void __dyc_print_comp_19re_pattern_buffer(struct re_pattern_buffer __dyc_thistype ) ;
extern reg_syntax_t __dyc_random_typdef_reg_syntax_t(unsigned int __dyc_exp ) ;
extern reg_syntax_t __dyc_read_typdef_reg_syntax_t(void) ;
extern void __dyc_print_typdef_reg_syntax_t(reg_syntax_t __dyc_thistype ) ;
extern regmatch_t __dyc_random_typdef_regmatch_t(unsigned int __dyc_exp ) ;
extern regmatch_t __dyc_read_typdef_regmatch_t(void) ;
extern void __dyc_print_typdef_regmatch_t(regmatch_t __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern unsigned char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern unsigned char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(unsigned char const   *__dyc_thistype ) ;
extern regex_t __dyc_random_typdef_regex_t(unsigned int __dyc_exp ) ;
extern regex_t __dyc_read_typdef_regex_t(void) ;
extern void __dyc_print_typdef_regex_t(regex_t __dyc_thistype ) ;
extern size_t *__dyc_random_ptr__typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t *__dyc_read_ptr__typdef_size_t(void) ;
extern void __dyc_print_ptr__typdef_size_t(size_t const   *__dyc_thistype ) ;
extern __ssize_t __dyc_random_typdef___ssize_t(unsigned int __dyc_exp ) ;
extern __ssize_t __dyc_read_typdef___ssize_t(void) ;
extern void __dyc_print_typdef___ssize_t(__ssize_t __dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern ssize_t __dyc_random_typdef_ssize_t(unsigned int __dyc_exp ) ;
extern ssize_t __dyc_read_typdef_ssize_t(void) ;
extern void __dyc_print_typdef_ssize_t(ssize_t __dyc_thistype ) ;
extern regmatch_t *__dyc_random_ptr__typdef_regmatch_t(unsigned int __dyc_exp ) ;
extern regmatch_t *__dyc_read_ptr__typdef_regmatch_t(void) ;
extern void __dyc_print_ptr__typdef_regmatch_t(regmatch_t const   * __restrict  __dyc_thistype ) ;
extern struct __anonstruct_regmatch_t_16 __dyc_random_comp_21__anonstruct_regmatch_t_16(unsigned int __dyc_exp ) ;
extern struct __anonstruct_regmatch_t_16 __dyc_read_comp_21__anonstruct_regmatch_t_16(void) ;
extern void __dyc_print_comp_21__anonstruct_regmatch_t_16(struct __anonstruct_regmatch_t_16 __dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
