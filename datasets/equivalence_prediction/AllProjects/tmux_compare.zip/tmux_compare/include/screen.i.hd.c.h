#line 31 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned char __u_char;
#line 32 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned short __u_short;
#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 34 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_char u_char;
#line 35 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_short u_short;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 48 "compat/bitstring.h"
typedef unsigned char bitstr_t;
#line 56 "tmux.h"
struct options;
#line 56
struct options;
#line 60
struct screen_write_cline;
#line 60
struct screen_write_cline;
#line 620 "tmux.h"
typedef u_int utf8_char;
#line 628 "tmux.h"
struct utf8_data {
   u_char data[21] ;
   u_char have ;
   u_char size ;
   u_char width ;
};
#line 688 "tmux.h"
struct grid_cell {
   struct utf8_data data ;
   u_short attr ;
   u_char flags ;
   int fg ;
   int bg ;
   int us ;
};
#line 698 "tmux.h"
struct grid_extd_entry {
   utf8_char data ;
   u_short attr ;
   u_char flags ;
   int fg ;
   int bg ;
   int us ;
};
#line 708 "tmux.h"
struct __anonstruct_data_57 {
   u_char attr ;
   u_char fg ;
   u_char bg ;
   u_char data ;
};
#line 708 "tmux.h"
union __anonunion____missing_field_name_56 {
   u_int offset ;
   struct __anonstruct_data_57 data ;
};
#line 708 "tmux.h"
struct grid_cell_entry {
   u_char flags ;
   union __anonunion____missing_field_name_56 __annonCompField1 ;
};
#line 722 "tmux.h"
struct grid_line {
   u_int cellused ;
   u_int cellsize ;
   struct grid_cell_entry *celldata ;
   u_int extdsize ;
   struct grid_extd_entry *extddata ;
   int flags ;
};
#line 734 "tmux.h"
struct grid {
   int flags ;
   u_int sx ;
   u_int sy ;
   u_int hscrolled ;
   u_int hsize ;
   u_int hlimit ;
   struct grid_line *linedata ;
};
#line 814
struct screen_sel;
#line 814
struct screen_sel;
#line 815
struct screen_titles;
#line 815
struct screen_titles;
#line 816 "tmux.h"
struct screen {
   char *title ;
   char *path ;
   struct screen_titles *titles ;
   struct grid *grid ;
   u_int cx ;
   u_int cy ;
   u_int cstyle ;
   char *ccolour ;
   u_int rupper ;
   u_int rlower ;
   int mode ;
   u_int saved_cx ;
   u_int saved_cy ;
   struct grid *saved_grid ;
   struct grid_cell saved_cell ;
   int saved_flags ;
   bitstr_t *tabs ;
   struct screen_sel *sel ;
   struct screen_write_cline *write_list ;
};
#line 28 "screen.c"
struct screen_sel {
   int hidden ;
   int rectangle ;
   int modekeys ;
   u_int sx ;
   u_int sy ;
   u_int ex ;
   u_int ey ;
   struct grid_cell cell ;
};
#line 43 "screen.c"
struct __anonstruct_entry_86 {
   struct screen_title_entry *tqe_next ;
   struct screen_title_entry **tqe_prev ;
};
#line 43 "screen.c"
struct screen_title_entry {
   char *text ;
   struct __anonstruct_entry_86 entry ;
};
#line 48 "screen.c"
struct screen_titles {
   struct screen_title_entry *tqh_first ;
   struct screen_title_entry **tqh_last ;
};
extern u_short __dyc_random_typdef_u_short(unsigned int __dyc_exp ) ;
extern u_short __dyc_read_typdef_u_short(void) ;
extern void __dyc_print_typdef_u_short(u_short __dyc_thistype ) ;
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern struct grid_cell_entry __dyc_random_comp_180grid_cell_entry(unsigned int __dyc_exp ) ;
extern struct grid_cell_entry __dyc_read_comp_180grid_cell_entry(void) ;
extern void __dyc_print_comp_180grid_cell_entry(struct grid_cell_entry __dyc_thistype ) ;
extern u_char __dyc_random_typdef_u_char(unsigned int __dyc_exp ) ;
extern u_char __dyc_read_typdef_u_char(void) ;
extern void __dyc_print_typdef_u_char(u_char __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern struct grid_line __dyc_random_comp_183grid_line(unsigned int __dyc_exp ) ;
extern struct grid_line __dyc_read_comp_183grid_line(void) ;
extern void __dyc_print_comp_183grid_line(struct grid_line __dyc_thistype ) ;
extern struct grid_cell_entry *__dyc_random_ptr__comp_180grid_cell_entry(unsigned int __dyc_exp ) ;
extern struct grid_cell_entry *__dyc_read_ptr__comp_180grid_cell_entry(void) ;
extern void __dyc_print_ptr__comp_180grid_cell_entry(struct grid_cell_entry  const  *__dyc_thistype ) ;
extern struct screen *__dyc_random_ptr__comp_192screen(unsigned int __dyc_exp ) ;
extern struct screen *__dyc_read_ptr__comp_192screen(void) ;
extern void __dyc_print_ptr__comp_192screen(struct screen  const  *__dyc_thistype ) ;
extern u_int *__dyc_random_ptr__typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int *__dyc_read_ptr__typdef_u_int(void) ;
extern void __dyc_print_ptr__typdef_u_int(u_int const   *__dyc_thistype ) ;
extern struct screen_titles __dyc_random_comp_191screen_titles(unsigned int __dyc_exp ) ;
extern struct screen_titles __dyc_read_comp_191screen_titles(void) ;
extern void __dyc_print_comp_191screen_titles(struct screen_titles __dyc_thistype ) ;
extern struct grid __dyc_random_comp_184grid(unsigned int __dyc_exp ) ;
extern struct grid __dyc_read_comp_184grid(void) ;
extern void __dyc_print_comp_184grid(struct grid __dyc_thistype ) ;
extern utf8_char __dyc_random_typdef_utf8_char(unsigned int __dyc_exp ) ;
extern utf8_char __dyc_read_typdef_utf8_char(void) ;
extern void __dyc_print_typdef_utf8_char(utf8_char __dyc_thistype ) ;
extern struct grid_cell *__dyc_random_ptr__comp_178grid_cell(unsigned int __dyc_exp ) ;
extern struct grid_cell *__dyc_read_ptr__comp_178grid_cell(void) ;
extern void __dyc_print_ptr__comp_178grid_cell(struct grid_cell  const  *__dyc_thistype ) ;
extern struct screen_title_entry *__dyc_random_ptr__comp_274screen_title_entry(unsigned int __dyc_exp ) ;
extern struct screen_title_entry *__dyc_read_ptr__comp_274screen_title_entry(void) ;
extern void __dyc_print_ptr__comp_274screen_title_entry(struct screen_title_entry  const  *__dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern struct screen_title_entry **__dyc_random_ptr__ptr__comp_274screen_title_entry(unsigned int __dyc_exp ) ;
extern struct screen_title_entry **__dyc_read_ptr__ptr__comp_274screen_title_entry(void) ;
extern void __dyc_print_ptr__ptr__comp_274screen_title_entry(struct screen_title_entry * const  *__dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern union __anonunion____missing_field_name_56 __dyc_random_comp_181__anonunion____missing_field_name_56(unsigned int __dyc_exp ) ;
extern union __anonunion____missing_field_name_56 __dyc_read_comp_181__anonunion____missing_field_name_56(void) ;
extern void __dyc_print_comp_181__anonunion____missing_field_name_56(union __anonunion____missing_field_name_56 __dyc_thistype ) ;
extern struct screen __dyc_random_comp_192screen(unsigned int __dyc_exp ) ;
extern struct screen __dyc_read_comp_192screen(void) ;
extern void __dyc_print_comp_192screen(struct screen __dyc_thistype ) ;
extern struct screen_sel *__dyc_random_ptr__comp_190screen_sel(unsigned int __dyc_exp ) ;
extern struct screen_sel *__dyc_read_ptr__comp_190screen_sel(void) ;
extern void __dyc_print_ptr__comp_190screen_sel(struct screen_sel  const  *__dyc_thistype ) ;
extern struct grid *__dyc_random_ptr__comp_184grid(unsigned int __dyc_exp ) ;
extern struct grid *__dyc_read_ptr__comp_184grid(void) ;
extern void __dyc_print_ptr__comp_184grid(struct grid  const  *__dyc_thistype ) ;
extern struct utf8_data *__dyc_random_ptr__comp_177utf8_data(unsigned int __dyc_exp ) ;
extern struct utf8_data *__dyc_read_ptr__comp_177utf8_data(void) ;
extern void __dyc_print_ptr__comp_177utf8_data(struct utf8_data  const  *__dyc_thistype ) ;
extern __u_char __dyc_random_typdef___u_char(unsigned int __dyc_exp ) ;
extern __u_char __dyc_read_typdef___u_char(void) ;
extern void __dyc_print_typdef___u_char(__u_char __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_158options(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_158options(void) ;
extern void __dyc_print_ptr__comp_158options(void const   * const  __dyc_thistype ) ;
extern struct screen_title_entry __dyc_random_comp_274screen_title_entry(unsigned int __dyc_exp ) ;
extern struct screen_title_entry __dyc_read_comp_274screen_title_entry(void) ;
extern void __dyc_print_comp_274screen_title_entry(struct screen_title_entry __dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct grid_line *__dyc_random_ptr__comp_183grid_line(unsigned int __dyc_exp ) ;
extern struct grid_line *__dyc_read_ptr__comp_183grid_line(void) ;
extern void __dyc_print_ptr__comp_183grid_line(struct grid_line  const  *__dyc_thistype ) ;
extern struct __anonstruct_entry_86 __dyc_random_comp_275__anonstruct_entry_86(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_86 __dyc_read_comp_275__anonstruct_entry_86(void) ;
extern void __dyc_print_comp_275__anonstruct_entry_86(struct __anonstruct_entry_86 __dyc_thistype ) ;
extern struct grid_cell __dyc_random_comp_178grid_cell(unsigned int __dyc_exp ) ;
extern struct grid_cell __dyc_read_comp_178grid_cell(void) ;
extern void __dyc_print_comp_178grid_cell(struct grid_cell __dyc_thistype ) ;
extern struct grid_extd_entry __dyc_random_comp_179grid_extd_entry(unsigned int __dyc_exp ) ;
extern struct grid_extd_entry __dyc_read_comp_179grid_extd_entry(void) ;
extern void __dyc_print_comp_179grid_extd_entry(struct grid_extd_entry __dyc_thistype ) ;
extern struct screen_sel __dyc_random_comp_190screen_sel(unsigned int __dyc_exp ) ;
extern struct screen_sel __dyc_read_comp_190screen_sel(void) ;
extern void __dyc_print_comp_190screen_sel(struct screen_sel __dyc_thistype ) ;
extern struct screen_titles *__dyc_random_ptr__comp_191screen_titles(unsigned int __dyc_exp ) ;
extern struct screen_titles *__dyc_read_ptr__comp_191screen_titles(void) ;
extern void __dyc_print_ptr__comp_191screen_titles(struct screen_titles  const  *__dyc_thistype ) ;
extern struct __anonstruct_data_57 __dyc_random_comp_182__anonstruct_data_57(unsigned int __dyc_exp ) ;
extern struct __anonstruct_data_57 __dyc_read_comp_182__anonstruct_data_57(void) ;
extern void __dyc_print_comp_182__anonstruct_data_57(struct __anonstruct_data_57 __dyc_thistype ) ;
extern struct grid_extd_entry *__dyc_random_ptr__comp_179grid_extd_entry(unsigned int __dyc_exp ) ;
extern struct grid_extd_entry *__dyc_read_ptr__comp_179grid_extd_entry(void) ;
extern void __dyc_print_ptr__comp_179grid_extd_entry(struct grid_extd_entry  const  *__dyc_thistype ) ;
extern bitstr_t __dyc_random_typdef_bitstr_t(unsigned int __dyc_exp ) ;
extern bitstr_t __dyc_read_typdef_bitstr_t(void) ;
extern void __dyc_print_typdef_bitstr_t(bitstr_t __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_162screen_write_cline(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_162screen_write_cline(void) ;
extern void __dyc_print_ptr__comp_162screen_write_cline(void const   * const  __dyc_thistype ) ;
extern __u_short __dyc_random_typdef___u_short(unsigned int __dyc_exp ) ;
extern __u_short __dyc_read_typdef___u_short(void) ;
extern void __dyc_print_typdef___u_short(__u_short __dyc_thistype ) ;
extern struct utf8_data __dyc_random_comp_177utf8_data(unsigned int __dyc_exp ) ;
extern struct utf8_data __dyc_read_comp_177utf8_data(void) ;
extern void __dyc_print_comp_177utf8_data(struct utf8_data __dyc_thistype ) ;
extern bitstr_t *__dyc_random_ptr__typdef_bitstr_t(unsigned int __dyc_exp ) ;
extern bitstr_t *__dyc_read_ptr__typdef_bitstr_t(void) ;
extern void __dyc_print_ptr__typdef_bitstr_t(bitstr_t const   *__dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
