#line 143 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef int __pid_t;
#line 42 "tmux.h"
struct cmd;
#line 42
struct cmd;
#line 44
struct cmdq_item;
#line 44
struct cmdq_item;
#line 1442
enum cmd_find_type {
    CMD_FIND_PANE = 0,
    CMD_FIND_WINDOW = 1,
    CMD_FIND_SESSION = 2
} ;
#line 1475
enum cmd_retval {
    CMD_RETURN_ERROR = -1,
    CMD_RETURN_NORMAL = 0,
    CMD_RETURN_WAIT = 1,
    CMD_RETURN_STOP = 2
} ;
#line 1518 "tmux.h"
struct cmd_entry_flag {
   char flag ;
   enum cmd_find_type type ;
   int flags ;
};
#line 1525 "tmux.h"
struct __anonstruct_args_91 {
   char *template ;
   int lower ;
   int upper ;
};
#line 1525 "tmux.h"
struct cmd_entry {
   char *name ;
   char *alias ;
   struct __anonstruct_args_91 args ;
   char *usage ;
   struct cmd_entry_flag source ;
   struct cmd_entry_flag target ;
   int flags ;
   enum cmd_retval (*exec)(struct cmd * , struct cmdq_item * ) ;
};
extern struct cmd_entry __dyc_random_comp_261cmd_entry(unsigned int __dyc_exp ) ;
extern struct cmd_entry __dyc_read_comp_261cmd_entry(void) ;
extern void __dyc_print_comp_261cmd_entry(struct cmd_entry __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_160cmdq_item(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_160cmdq_item(void) ;
extern void __dyc_print_ptr__comp_160cmdq_item(void const   * const  __dyc_thistype ) ;
extern void *__dyc_random_ptr__fun_name_is_not_here(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__fun_name_is_not_here(void) ;
extern void __dyc_print_ptr__fun_name_is_not_here(void const   * const  __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern __pid_t __dyc_random_typdef___pid_t(unsigned int __dyc_exp ) ;
extern __pid_t __dyc_read_typdef___pid_t(void) ;
extern void __dyc_print_typdef___pid_t(__pid_t __dyc_thistype ) ;
extern struct cmd_entry *__dyc_random_ptr__comp_261cmd_entry(unsigned int __dyc_exp ) ;
extern struct cmd_entry *__dyc_read_ptr__comp_261cmd_entry(void) ;
extern void __dyc_print_ptr__comp_261cmd_entry(struct cmd_entry  const  *__dyc_thistype ) ;
extern struct __anonstruct_args_91 __dyc_random_comp_262__anonstruct_args_91(unsigned int __dyc_exp ) ;
extern struct __anonstruct_args_91 __dyc_read_comp_262__anonstruct_args_91(void) ;
extern void __dyc_print_comp_262__anonstruct_args_91(struct __anonstruct_args_91 __dyc_thistype ) ;
extern struct cmd_entry_flag __dyc_random_comp_260cmd_entry_flag(unsigned int __dyc_exp ) ;
extern struct cmd_entry_flag __dyc_read_comp_260cmd_entry_flag(void) ;
extern void __dyc_print_comp_260cmd_entry_flag(struct cmd_entry_flag __dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_158cmd(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_158cmd(void) ;
extern void __dyc_print_ptr__comp_158cmd(void const   * const  __dyc_thistype ) ;
