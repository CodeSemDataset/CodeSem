#line 143 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef int __pid_t;
#line 180 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __ssize_t;
#line 192 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __socklen_t;
#line 99 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __pid_t pid_t;
#line 110 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __ssize_t ssize_t;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 44 "/usr/include/x86_64-linux-gnu/bits/uio.h"
struct iovec {
   void *iov_base ;
   size_t iov_len ;
};
#line 35 "/usr/include/x86_64-linux-gnu/bits/socket.h"
typedef __socklen_t socklen_t;
#line 253 "/usr/include/x86_64-linux-gnu/bits/socket.h"
struct msghdr {
   void *msg_name ;
   socklen_t msg_namelen ;
   struct iovec *msg_iov ;
   size_t msg_iovlen ;
   void *msg_control ;
   size_t msg_controllen ;
   int msg_flags ;
};
#line 280 "/usr/include/x86_64-linux-gnu/bits/socket.h"
struct cmsghdr {
   size_t cmsg_len ;
   int cmsg_level ;
   int cmsg_type ;
   unsigned char __cmsg_data[] ;
};
#line 50 "/usr/include/stdint.h"
typedef unsigned short uint16_t;
#line 52 "/usr/include/stdint.h"
typedef unsigned int uint32_t;
#line 30 "./compat/imsg.h"
struct __anonstruct_entry_51 {
   struct ibuf *tqe_next ;
   struct ibuf **tqe_prev ;
};
#line 30 "./compat/imsg.h"
struct ibuf {
   struct __anonstruct_entry_51 entry ;
   unsigned char *buf ;
   size_t size ;
   size_t max ;
   size_t wpos ;
   size_t rpos ;
   int fd ;
};
#line 40 "./compat/imsg.h"
struct __anonstruct_bufs_52 {
   struct ibuf *tqh_first ;
   struct ibuf **tqh_last ;
};
#line 40 "./compat/imsg.h"
struct msgbuf {
   struct __anonstruct_bufs_52 bufs ;
   uint32_t queued ;
   int fd ;
};
#line 46 "./compat/imsg.h"
struct ibuf_read {
   unsigned char buf[65535] ;
   unsigned char *rptr ;
   size_t wpos ;
};
#line 52 "./compat/imsg.h"
struct __anonstruct_entry_53 {
   struct imsg_fd *tqe_next ;
   struct imsg_fd **tqe_prev ;
};
#line 52 "./compat/imsg.h"
struct imsg_fd {
   struct __anonstruct_entry_53 entry ;
   int fd ;
};
#line 57 "./compat/imsg.h"
struct __anonstruct_fds_54 {
   struct imsg_fd *tqh_first ;
   struct imsg_fd **tqh_last ;
};
#line 57 "./compat/imsg.h"
struct imsgbuf {
   struct __anonstruct_fds_54 fds ;
   struct ibuf_read r ;
   struct msgbuf w ;
   int fd ;
   pid_t pid ;
};
#line 67 "./compat/imsg.h"
struct imsg_hdr {
   uint32_t type ;
   uint16_t len ;
   uint16_t flags ;
   uint32_t peerid ;
   uint32_t pid ;
};
#line 75 "./compat/imsg.h"
struct imsg {
   struct imsg_hdr hdr ;
   int fd ;
   void *data ;
};
#line 51 "compat/imsg.c"
union __anonunion_cmsgbuf_55 {
   struct cmsghdr hdr ;
   char buf[(((sizeof(int ) + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL)) + (((sizeof(struct cmsghdr ) + sizeof(size_t )) - 1UL) & ~ (sizeof(size_t ) - 1UL))] ;
};
extern struct __anonstruct_entry_53 __dyc_random_comp_136__anonstruct_entry_53(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_53 __dyc_read_comp_136__anonstruct_entry_53(void) ;
extern void __dyc_print_comp_136__anonstruct_entry_53(struct __anonstruct_entry_53 __dyc_thistype ) ;
extern int *__dyc_random_ptr__int(unsigned int __dyc_exp ) ;
extern int *__dyc_read_ptr__int(void) ;
extern void __dyc_print_ptr__int(int const   *__dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern struct msgbuf __dyc_random_comp_132msgbuf(unsigned int __dyc_exp ) ;
extern struct msgbuf __dyc_read_comp_132msgbuf(void) ;
extern void __dyc_print_comp_132msgbuf(struct msgbuf __dyc_thistype ) ;
extern struct cmsghdr __dyc_random_comp_24cmsghdr(unsigned int __dyc_exp ) ;
extern struct cmsghdr __dyc_read_comp_24cmsghdr(void) ;
extern void __dyc_print_comp_24cmsghdr(struct cmsghdr __dyc_thistype ) ;
extern struct imsg_fd __dyc_random_comp_135imsg_fd(unsigned int __dyc_exp ) ;
extern struct imsg_fd __dyc_read_comp_135imsg_fd(void) ;
extern void __dyc_print_comp_135imsg_fd(struct imsg_fd __dyc_thistype ) ;
extern struct ibuf *__dyc_random_ptr__comp_130ibuf(unsigned int __dyc_exp ) ;
extern struct ibuf *__dyc_read_ptr__comp_130ibuf(void) ;
extern void __dyc_print_ptr__comp_130ibuf(struct ibuf  const  *__dyc_thistype ) ;
extern struct imsg_fd *__dyc_random_ptr__comp_135imsg_fd(unsigned int __dyc_exp ) ;
extern struct imsg_fd *__dyc_read_ptr__comp_135imsg_fd(void) ;
extern void __dyc_print_ptr__comp_135imsg_fd(struct imsg_fd  const  *__dyc_thistype ) ;
extern struct iovec __dyc_random_comp_19iovec(unsigned int __dyc_exp ) ;
extern struct iovec __dyc_read_comp_19iovec(void) ;
extern void __dyc_print_comp_19iovec(struct iovec __dyc_thistype ) ;
extern struct imsg __dyc_random_comp_140imsg(unsigned int __dyc_exp ) ;
extern struct imsg __dyc_read_comp_140imsg(void) ;
extern void __dyc_print_comp_140imsg(struct imsg __dyc_thistype ) ;
extern struct __anonstruct_fds_54 __dyc_random_comp_138__anonstruct_fds_54(unsigned int __dyc_exp ) ;
extern struct __anonstruct_fds_54 __dyc_read_comp_138__anonstruct_fds_54(void) ;
extern void __dyc_print_comp_138__anonstruct_fds_54(struct __anonstruct_fds_54 __dyc_thistype ) ;
extern union __anonunion_cmsgbuf_55 __dyc_random_comp_141__anonunion_cmsgbuf_55(unsigned int __dyc_exp ) ;
extern union __anonunion_cmsgbuf_55 __dyc_read_comp_141__anonunion_cmsgbuf_55(void) ;
extern void __dyc_print_comp_141__anonunion_cmsgbuf_55(union __anonunion_cmsgbuf_55 __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern socklen_t __dyc_random_typdef_socklen_t(unsigned int __dyc_exp ) ;
extern socklen_t __dyc_read_typdef_socklen_t(void) ;
extern void __dyc_print_typdef_socklen_t(socklen_t __dyc_thistype ) ;
extern struct imsg_hdr __dyc_random_comp_139imsg_hdr(unsigned int __dyc_exp ) ;
extern struct imsg_hdr __dyc_read_comp_139imsg_hdr(void) ;
extern void __dyc_print_comp_139imsg_hdr(struct imsg_hdr __dyc_thistype ) ;
extern struct imsg_fd **__dyc_random_ptr__ptr__comp_135imsg_fd(unsigned int __dyc_exp ) ;
extern struct imsg_fd **__dyc_read_ptr__ptr__comp_135imsg_fd(void) ;
extern void __dyc_print_ptr__ptr__comp_135imsg_fd(struct imsg_fd * const  *__dyc_thistype ) ;
extern unsigned char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern unsigned char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(unsigned char const   *__dyc_thistype ) ;
extern struct iovec *__dyc_random_ptr__comp_19iovec(unsigned int __dyc_exp ) ;
extern struct iovec *__dyc_read_ptr__comp_19iovec(void) ;
extern void __dyc_print_ptr__comp_19iovec(struct iovec  const  *__dyc_thistype ) ;
extern struct imsg *__dyc_random_ptr__comp_140imsg(unsigned int __dyc_exp ) ;
extern struct imsg *__dyc_read_ptr__comp_140imsg(void) ;
extern void __dyc_print_ptr__comp_140imsg(struct imsg  const  *__dyc_thistype ) ;
extern struct ibuf_read __dyc_random_comp_134ibuf_read(unsigned int __dyc_exp ) ;
extern struct ibuf_read __dyc_read_comp_134ibuf_read(void) ;
extern void __dyc_print_comp_134ibuf_read(struct ibuf_read __dyc_thistype ) ;
extern __socklen_t __dyc_random_typdef___socklen_t(unsigned int __dyc_exp ) ;
extern __socklen_t __dyc_read_typdef___socklen_t(void) ;
extern void __dyc_print_typdef___socklen_t(__socklen_t __dyc_thistype ) ;
extern struct msghdr *__dyc_random_ptr__comp_22msghdr(unsigned int __dyc_exp ) ;
extern struct msghdr *__dyc_read_ptr__comp_22msghdr(void) ;
extern void __dyc_print_ptr__comp_22msghdr(struct msghdr  const  *__dyc_thistype ) ;
extern __pid_t __dyc_random_typdef___pid_t(unsigned int __dyc_exp ) ;
extern __pid_t __dyc_read_typdef___pid_t(void) ;
extern void __dyc_print_typdef___pid_t(__pid_t __dyc_thistype ) ;
extern uint32_t __dyc_random_typdef_uint32_t(unsigned int __dyc_exp ) ;
extern uint32_t __dyc_read_typdef_uint32_t(void) ;
extern void __dyc_print_typdef_uint32_t(uint32_t __dyc_thistype ) ;
extern struct imsg_hdr *__dyc_random_ptr__comp_139imsg_hdr(unsigned int __dyc_exp ) ;
extern struct imsg_hdr *__dyc_read_ptr__comp_139imsg_hdr(void) ;
extern void __dyc_print_ptr__comp_139imsg_hdr(struct imsg_hdr  const  *__dyc_thistype ) ;
extern struct __anonstruct_bufs_52 __dyc_random_comp_133__anonstruct_bufs_52(unsigned int __dyc_exp ) ;
extern struct __anonstruct_bufs_52 __dyc_read_comp_133__anonstruct_bufs_52(void) ;
extern void __dyc_print_comp_133__anonstruct_bufs_52(struct __anonstruct_bufs_52 __dyc_thistype ) ;
extern uint16_t __dyc_random_typdef_uint16_t(unsigned int __dyc_exp ) ;
extern uint16_t __dyc_read_typdef_uint16_t(void) ;
extern void __dyc_print_typdef_uint16_t(uint16_t __dyc_thistype ) ;
extern __ssize_t __dyc_random_typdef___ssize_t(unsigned int __dyc_exp ) ;
extern __ssize_t __dyc_read_typdef___ssize_t(void) ;
extern void __dyc_print_typdef___ssize_t(__ssize_t __dyc_thistype ) ;
extern struct ibuf **__dyc_random_ptr__ptr__comp_130ibuf(unsigned int __dyc_exp ) ;
extern struct ibuf **__dyc_read_ptr__ptr__comp_130ibuf(void) ;
extern void __dyc_print_ptr__ptr__comp_130ibuf(struct ibuf * const  *__dyc_thistype ) ;
extern struct imsgbuf __dyc_random_comp_137imsgbuf(unsigned int __dyc_exp ) ;
extern struct imsgbuf __dyc_read_comp_137imsgbuf(void) ;
extern void __dyc_print_comp_137imsgbuf(struct imsgbuf __dyc_thistype ) ;
extern ssize_t __dyc_random_typdef_ssize_t(unsigned int __dyc_exp ) ;
extern ssize_t __dyc_read_typdef_ssize_t(void) ;
extern void __dyc_print_typdef_ssize_t(ssize_t __dyc_thistype ) ;
extern struct msgbuf *__dyc_random_ptr__comp_132msgbuf(unsigned int __dyc_exp ) ;
extern struct msgbuf *__dyc_read_ptr__comp_132msgbuf(void) ;
extern void __dyc_print_ptr__comp_132msgbuf(struct msgbuf  const  *__dyc_thistype ) ;
extern struct cmsghdr *__dyc_random_ptr__comp_24cmsghdr(unsigned int __dyc_exp ) ;
extern struct cmsghdr *__dyc_read_ptr__comp_24cmsghdr(void) ;
extern void __dyc_print_ptr__comp_24cmsghdr(struct cmsghdr  const __attribute__((__gnu_inline__)) * __attribute__((__leaf__)) __dyc_thistype ) ;
extern struct imsgbuf *__dyc_random_ptr__comp_137imsgbuf(unsigned int __dyc_exp ) ;
extern struct imsgbuf *__dyc_read_ptr__comp_137imsgbuf(void) ;
extern void __dyc_print_ptr__comp_137imsgbuf(struct imsgbuf  const  *__dyc_thistype ) ;
extern pid_t __dyc_random_typdef_pid_t(unsigned int __dyc_exp ) ;
extern pid_t __dyc_read_typdef_pid_t(void) ;
extern void __dyc_print_typdef_pid_t(pid_t __dyc_thistype ) ;
extern struct __anonstruct_entry_51 __dyc_random_comp_131__anonstruct_entry_51(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_51 __dyc_read_comp_131__anonstruct_entry_51(void) ;
extern void __dyc_print_comp_131__anonstruct_entry_51(struct __anonstruct_entry_51 __dyc_thistype ) ;
extern struct msghdr __dyc_random_comp_22msghdr(unsigned int __dyc_exp ) ;
extern struct msghdr __dyc_read_comp_22msghdr(void) ;
extern void __dyc_print_comp_22msghdr(struct msghdr __dyc_thistype ) ;
extern struct ibuf __dyc_random_comp_130ibuf(unsigned int __dyc_exp ) ;
extern struct ibuf __dyc_read_comp_130ibuf(void) ;
extern void __dyc_print_comp_130ibuf(struct ibuf __dyc_thistype ) ;
