#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 149 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef long __time_t;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 76 "/usr/include/time.h"
typedef __time_t time_t;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 56 "tmux.h"
struct options;
#line 56
struct options;
#line 1953
struct paste_buffer;
#line 1953
struct paste_buffer;
#line 32 "paste.c"
struct __anonstruct_name_entry_83 {
   struct paste_buffer *rbe_left ;
   struct paste_buffer *rbe_right ;
   struct paste_buffer *rbe_parent ;
   int rbe_color ;
};
#line 32 "paste.c"
struct __anonstruct_time_entry_84 {
   struct paste_buffer *rbe_left ;
   struct paste_buffer *rbe_right ;
   struct paste_buffer *rbe_parent ;
   int rbe_color ;
};
#line 32 "paste.c"
struct paste_buffer {
   char *data ;
   size_t size ;
   char *name ;
   time_t created ;
   int automatic ;
   u_int order ;
   struct __anonstruct_name_entry_83 name_entry ;
   struct __anonstruct_time_entry_84 time_entry ;
};
#line 48 "paste.c"
struct paste_name_tree {
   struct paste_buffer *rbh_root ;
};
#line 49 "paste.c"
struct paste_time_tree {
   struct paste_buffer *rbh_root ;
};
extern time_t __dyc_random_typdef_time_t(unsigned int __dyc_exp ) ;
extern time_t __dyc_read_typdef_time_t(void) ;
extern void __dyc_print_typdef_time_t(time_t __dyc_thistype ) ;
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern struct __anonstruct_time_entry_84 __dyc_random_comp_275__anonstruct_time_entry_84(unsigned int __dyc_exp ) ;
extern struct __anonstruct_time_entry_84 __dyc_read_comp_275__anonstruct_time_entry_84(void) ;
extern void __dyc_print_comp_275__anonstruct_time_entry_84(struct __anonstruct_time_entry_84 __dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern struct paste_time_tree __dyc_random_comp_277paste_time_tree(unsigned int __dyc_exp ) ;
extern struct paste_time_tree __dyc_read_comp_277paste_time_tree(void) ;
extern void __dyc_print_comp_277paste_time_tree(struct paste_time_tree __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern struct paste_name_tree __dyc_random_comp_276paste_name_tree(unsigned int __dyc_exp ) ;
extern struct paste_name_tree __dyc_read_comp_276paste_name_tree(void) ;
extern void __dyc_print_comp_276paste_name_tree(struct paste_name_tree __dyc_thistype ) ;
extern struct paste_time_tree *__dyc_random_ptr__comp_277paste_time_tree(unsigned int __dyc_exp ) ;
extern struct paste_time_tree *__dyc_read_ptr__comp_277paste_time_tree(void) ;
extern void __dyc_print_ptr__comp_277paste_time_tree(struct paste_time_tree  const  *__dyc_thistype ) ;
extern __time_t __dyc_random_typdef___time_t(unsigned int __dyc_exp ) ;
extern __time_t __dyc_read_typdef___time_t(void) ;
extern void __dyc_print_typdef___time_t(__time_t __dyc_thistype ) ;
extern struct paste_name_tree *__dyc_random_ptr__comp_276paste_name_tree(unsigned int __dyc_exp ) ;
extern struct paste_name_tree *__dyc_read_ptr__comp_276paste_name_tree(void) ;
extern void __dyc_print_ptr__comp_276paste_name_tree(struct paste_name_tree  const  *__dyc_thistype ) ;
extern struct paste_buffer __dyc_random_comp_271paste_buffer(unsigned int __dyc_exp ) ;
extern struct paste_buffer __dyc_read_comp_271paste_buffer(void) ;
extern void __dyc_print_comp_271paste_buffer(struct paste_buffer __dyc_thistype ) ;
extern time_t *__dyc_random_ptr__typdef_time_t(unsigned int __dyc_exp ) ;
extern time_t *__dyc_read_ptr__typdef_time_t(void) ;
extern void __dyc_print_ptr__typdef_time_t(time_t const   *__dyc_thistype ) ;
extern void *__dyc_random_ptr__comp_158options(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__comp_158options(void) ;
extern void __dyc_print_ptr__comp_158options(void const   * const  __dyc_thistype ) ;
extern size_t *__dyc_random_ptr__typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t *__dyc_read_ptr__typdef_size_t(void) ;
extern void __dyc_print_ptr__typdef_size_t(size_t const   *__dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct paste_buffer *__dyc_random_ptr__comp_271paste_buffer(unsigned int __dyc_exp ) ;
extern struct paste_buffer *__dyc_read_ptr__comp_271paste_buffer(void) ;
extern void __dyc_print_ptr__comp_271paste_buffer(struct paste_buffer  const  *__dyc_thistype ) ;
extern struct __anonstruct_name_entry_83 __dyc_random_comp_274__anonstruct_name_entry_83(unsigned int __dyc_exp ) ;
extern struct __anonstruct_name_entry_83 __dyc_read_comp_274__anonstruct_name_entry_83(void) ;
extern void __dyc_print_comp_274__anonstruct_name_entry_83(struct __anonstruct_name_entry_83 __dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
