#line 31 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned char __u_char;
#line 33 "/usr/include/x86_64-linux-gnu/bits/types.h"
typedef unsigned int __u_int;
#line 34 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_char u_char;
#line 36 "/usr/include/x86_64-linux-gnu/sys/types.h"
typedef __u_int u_int;
#line 212 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stddef.h"
typedef unsigned long size_t;
#line 40 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stdarg.h"
typedef __builtin_va_list __gnuc_va_list;
#line 98 "/usr/local/lib/gcc/x86_64-unknown-linux-gnu/4.8.2/include/stdarg.h"
typedef __gnuc_va_list va_list;
#line 39 "tmux.h"
struct args;
#line 39
struct args;
#line 40
struct args_value;
#line 40
struct args_value;
#line 1433
struct args_entry;
#line 1433
struct args_entry;
#line 1434 "tmux.h"
struct args_tree {
   struct args_entry *rbh_root ;
};
#line 1435 "tmux.h"
struct args {
   struct args_tree tree ;
   int argc ;
   char **argv ;
};
#line 31 "arguments.c"
struct __anonstruct_entry_86 {
   struct args_value *tqe_next ;
   struct args_value **tqe_prev ;
};
#line 31 "arguments.c"
struct args_value {
   char *value ;
   struct __anonstruct_entry_86 entry ;
};
#line 35 "arguments.c"
struct args_values {
   struct args_value *tqh_first ;
   struct args_value **tqh_last ;
};
#line 37 "arguments.c"
struct __anonstruct_entry_87 {
   struct args_entry *rbe_left ;
   struct args_entry *rbe_right ;
   struct args_entry *rbe_parent ;
   int rbe_color ;
};
#line 37 "arguments.c"
struct args_entry {
   u_char flag ;
   struct args_values values ;
   u_int count ;
   struct __anonstruct_entry_87 entry ;
};
extern struct args_tree *__dyc_random_ptr__comp_242args_tree(unsigned int __dyc_exp ) ;
extern struct args_tree *__dyc_read_ptr__comp_242args_tree(void) ;
extern void __dyc_print_ptr__comp_242args_tree(struct args_tree  const  *__dyc_thistype ) ;
extern u_int __dyc_random_typdef_u_int(unsigned int __dyc_exp ) ;
extern u_int __dyc_read_typdef_u_int(void) ;
extern void __dyc_print_typdef_u_int(u_int __dyc_thistype ) ;
extern struct args_value **__dyc_random_ptr__ptr__comp_142args_value(unsigned int __dyc_exp ) ;
extern struct args_value **__dyc_read_ptr__ptr__comp_142args_value(void) ;
extern void __dyc_print_ptr__ptr__comp_142args_value(struct args_value * const  *__dyc_thistype ) ;
extern u_char __dyc_random_typdef_u_char(unsigned int __dyc_exp ) ;
extern u_char __dyc_read_typdef_u_char(void) ;
extern void __dyc_print_typdef_u_char(u_char __dyc_thistype ) ;
extern size_t __dyc_random_typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t __dyc_read_typdef_size_t(void) ;
extern void __dyc_print_typdef_size_t(size_t __dyc_thistype ) ;
extern struct args __dyc_random_comp_141args(unsigned int __dyc_exp ) ;
extern struct args __dyc_read_comp_141args(void) ;
extern void __dyc_print_comp_141args(struct args __dyc_thistype ) ;
extern struct args_entry __dyc_random_comp_241args_entry(unsigned int __dyc_exp ) ;
extern struct args_entry __dyc_read_comp_241args_entry(void) ;
extern void __dyc_print_comp_241args_entry(struct args_entry __dyc_thistype ) ;
extern struct args_value __dyc_random_comp_142args_value(unsigned int __dyc_exp ) ;
extern struct args_value __dyc_read_comp_142args_value(void) ;
extern void __dyc_print_comp_142args_value(struct args_value __dyc_thistype ) ;
extern struct args *__dyc_random_ptr__comp_141args(unsigned int __dyc_exp ) ;
extern struct args *__dyc_read_ptr__comp_141args(void) ;
extern void __dyc_print_ptr__comp_141args(struct args  const  *__dyc_thistype ) ;
extern void *__dyc_random_ptr__void(unsigned int __dyc_exp ) ;
extern void *__dyc_read_ptr__void(void) ;
extern void __dyc_print_ptr__void(void const   * const  __dyc_thistype ) ;
extern char *__dyc_random_ptr__char(unsigned int __dyc_exp ) ;
extern char *__dyc_read_ptr__char(void) ;
extern void __dyc_print_ptr__char(char const   *__dyc_thistype ) ;
extern struct args_tree __dyc_random_comp_242args_tree(unsigned int __dyc_exp ) ;
extern struct args_tree __dyc_read_comp_242args_tree(void) ;
extern void __dyc_print_comp_242args_tree(struct args_tree __dyc_thistype ) ;
extern __u_char __dyc_random_typdef___u_char(unsigned int __dyc_exp ) ;
extern __u_char __dyc_read_typdef___u_char(void) ;
extern void __dyc_print_typdef___u_char(__u_char __dyc_thistype ) ;
extern size_t *__dyc_random_ptr__typdef_size_t(unsigned int __dyc_exp ) ;
extern size_t *__dyc_read_ptr__typdef_size_t(void) ;
extern void __dyc_print_ptr__typdef_size_t(size_t const   *__dyc_thistype ) ;
extern __u_int __dyc_random_typdef___u_int(unsigned int __dyc_exp ) ;
extern __u_int __dyc_read_typdef___u_int(void) ;
extern void __dyc_print_typdef___u_int(__u_int __dyc_thistype ) ;
extern struct __anonstruct_entry_86 __dyc_random_comp_274__anonstruct_entry_86(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_86 __dyc_read_comp_274__anonstruct_entry_86(void) ;
extern void __dyc_print_comp_274__anonstruct_entry_86(struct __anonstruct_entry_86 __dyc_thistype ) ;
extern struct __anonstruct_entry_87 __dyc_random_comp_276__anonstruct_entry_87(unsigned int __dyc_exp ) ;
extern struct __anonstruct_entry_87 __dyc_read_comp_276__anonstruct_entry_87(void) ;
extern void __dyc_print_comp_276__anonstruct_entry_87(struct __anonstruct_entry_87 __dyc_thistype ) ;
extern struct args_values __dyc_random_comp_275args_values(unsigned int __dyc_exp ) ;
extern struct args_values __dyc_read_comp_275args_values(void) ;
extern void __dyc_print_comp_275args_values(struct args_values __dyc_thistype ) ;
extern struct args_values *__dyc_random_ptr__comp_275args_values(unsigned int __dyc_exp ) ;
extern struct args_values *__dyc_read_ptr__comp_275args_values(void) ;
extern void __dyc_print_ptr__comp_275args_values(struct args_values  const  *__dyc_thistype ) ;
extern struct args_entry *__dyc_random_ptr__comp_241args_entry(unsigned int __dyc_exp ) ;
extern struct args_entry *__dyc_read_ptr__comp_241args_entry(void) ;
extern void __dyc_print_ptr__comp_241args_entry(struct args_entry  const  *__dyc_thistype ) ;
extern struct args_value *__dyc_random_ptr__comp_142args_value(unsigned int __dyc_exp ) ;
extern struct args_value *__dyc_read_ptr__comp_142args_value(void) ;
extern void __dyc_print_ptr__comp_142args_value(struct args_value  const  *__dyc_thistype ) ;
extern char **__dyc_random_ptr__ptr__char(unsigned int __dyc_exp ) ;
extern char **__dyc_read_ptr__ptr__char(void) ;
extern void __dyc_print_ptr__ptr__char(char * const  *__dyc_thistype ) ;
extern struct args_entry **__dyc_random_ptr__ptr__comp_241args_entry(unsigned int __dyc_exp ) ;
extern struct args_entry **__dyc_read_ptr__ptr__comp_241args_entry(void) ;
extern void __dyc_print_ptr__ptr__comp_241args_entry(struct args_entry * const  *__dyc_thistype ) ;
