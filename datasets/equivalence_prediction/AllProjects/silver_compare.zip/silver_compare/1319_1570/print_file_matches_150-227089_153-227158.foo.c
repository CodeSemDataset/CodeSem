#include "../include/dycfoo.h"
#include "../include/print.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  size_t cur_match ;
  ssize_t lines_to_print ;
  char sep ;
  int blanks_between_matches ;
  int tmp ;

  {
  opts = __dyc_read_comp_72__anonstruct_cli_options_40();
  cur_match = 0;
  lines_to_print = 0;
  sep = 0;
  blanks_between_matches = 0;
  tmp = 0;
  cur_match = (size_t )0;
  lines_to_print = (ssize_t )0;
  sep = (char )'-';
  if (opts.context) {
    tmp = 1;
  } else {
    if (opts.after) {
      tmp = 1;
    } else {
      if (opts.before) {
        tmp = 1;
      } else {
        tmp = 0;
      }
    }
  }
  blanks_between_matches = tmp;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(cur_match);
  __dyc_printpre_byte(lines_to_print);
  __dyc_printpre_byte(sep);
  __dyc_printpre_byte(blanks_between_matches);
}
}
