#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  char const   *evil_hardcoded_ignore_files[3] ;
  char const   *filename ;
  size_t i ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___8 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  scandir_baton_t *scandir_baton ;
  char const   *path_start ;
  char const   *extension ;
  char *tmp___20 ;
  void *baton ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  char *__dyc_funcallvar_8 ;

  {
  opts = __dyc_read_comp_72__anonstruct_cli_options_41();
  filename = (char const   *)__dyc_read_ptr__char();
  i = (size_t )__dyc_readpre_byte();
  baton = __dyc_read_ptr__void();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_read_ptr__char();
  __s1_len = 0;
  __s2_len = 0;
  tmp___8 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  scandir_baton = 0;
  path_start = 0;
  extension = 0;
  tmp___20 = 0;
  while (1) {
    while_7_continue:  ;
    if (! ((unsigned long )evil_hardcoded_ignore_files[i] != (unsigned long )((void *)0))) {
      goto while_7_break;
    }
    if (0) {
      {
      tmp___14 = __dyc_funcallvar_1;
      __s1_len = (unsigned long )tmp___14;
      tmp___15 = __dyc_funcallvar_2;
      __s2_len = (unsigned long )tmp___15;
      }
      if (! ((unsigned long )((void const   *)(filename + 1)) - (unsigned long )((void const   *)filename) == 1UL)) {
        goto _L___0;
      } else {
        if (__s1_len >= 4UL) {
          _L___0:  
          if (! ((unsigned long )((void const   *)(evil_hardcoded_ignore_files[i] + 1)) - (unsigned long )((void const   *)evil_hardcoded_ignore_files[i]) == 1UL)) {
            tmp___16 = 1;
          } else {
            if (__s2_len >= 4UL) {
              tmp___16 = 1;
            } else {
              tmp___16 = 0;
            }
          }
        } else {
          tmp___16 = 0;
        }
      }
      if (tmp___16) {
        {
        tmp___8 = __dyc_funcallvar_3;
        }
      } else {
        {
        tmp___13 = __dyc_funcallvar_4;
        tmp___8 = tmp___13;
        }
      }
    } else {
      {
      tmp___13 = __dyc_funcallvar_5;
      tmp___8 = tmp___13;
      }
    }
    if (tmp___8 == 0) {
      goto __dyc_dummy_label;
    }
    i ++;
  }
  while_7_break:  ;
  if (! opts.follow_symlinks) {
    {
    tmp___17 = __dyc_funcallvar_6;
    }
    if (tmp___17) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___18 = __dyc_funcallvar_7;
  if (tmp___18) {
    {

    }
    goto __dyc_dummy_label;
  }
  if (opts.search_all_files) {
    if (! opts.path_to_ignore) {
      goto __dyc_dummy_label;
    }
  }
  scandir_baton = (scandir_baton_t *)baton;
  path_start = scandir_baton->path_start;
  tmp___20 = __dyc_funcallvar_8;
  extension = (char const   *)tmp___20;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
  __dyc_print_ptr__char(path_start);
  __dyc_print_ptr__char(extension);
}
}
