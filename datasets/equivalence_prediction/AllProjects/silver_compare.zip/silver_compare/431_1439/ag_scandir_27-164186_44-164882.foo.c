#include "../include/dycfoo.h"
#include "../include/scandir.i.hd.c.h"
void __dyc_foo(void) 
{ struct dirent **names ;
  struct dirent *entry ;
  struct dirent *d ;
  int names_len ;
  int results_len ;
  int tmp___0 ;
  struct dirent **tmp_names ;
  void *tmp___1 ;
  void *tmp___2 ;
  int __dyc_funcallvar_4 ;
  void *__dyc_funcallvar_5 ;
  void *__dyc_funcallvar_6 ;

  {
  names = __dyc_read_ptr__ptr__comp_2dirent();
  entry = __dyc_read_ptr__comp_2dirent();
  names_len = __dyc_readpre_byte();
  results_len = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = __dyc_read_ptr__void();
  d = 0;
  tmp___0 = 0;
  tmp_names = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  if (! ((unsigned long )entry != (unsigned long )((void *)0))) {
    goto __dyc_dummy_label;
  }
  tmp___0 = __dyc_funcallvar_4;
  if (tmp___0 == 0) {
    goto __dyc_dummy_label;
  }
  if (results_len >= names_len) {
    {
    tmp_names = names;
    names_len *= 2;
    tmp___1 = __dyc_funcallvar_5;
    names = (struct dirent **)tmp___1;
    }
    if ((unsigned long )names == (unsigned long )((void *)0)) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___2 = __dyc_funcallvar_6;
  d = (struct dirent *)tmp___2;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__comp_2dirent(d);
  __dyc_printpre_byte(names_len);
  __dyc_print_ptr__ptr__comp_2dirent(tmp_names);
}
}
