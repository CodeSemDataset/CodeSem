#include "../include/dycfoo.h"
#include "../include/main.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  int i ;
  worker_t *workers ;
  int workers_len ;
  int num_cores ;
  int rv ;
  int tmp___13 ;
  char *tmp___14 ;
  cpu_set_t cpu_set ;
  size_t __cpu ;
  char *tmp___15 ;
  int __dyc_funcallvar_15 ;
  char *__dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  char *__dyc_funcallvar_18 ;

  {
  opts = __dyc_read_comp_70__anonstruct_cli_options_43();
  i = __dyc_readpre_byte();
  workers = __dyc_read_ptr__typdef_worker_t();
  workers_len = __dyc_readpre_byte();
  num_cores = __dyc_readpre_byte();
  cpu_set = __dyc_read_comp_57__anonstruct_cpu_set_t_30();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = (char *)__dyc_read_ptr__char();
  rv = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  __cpu = 0;
  tmp___15 = 0;
  if (! (i < workers_len)) {
    goto __dyc_dummy_label;
  }
  (workers + i)->id = i;
  tmp___13 = __dyc_funcallvar_15;
  rv = tmp___13;
  if (rv != 0) {
    {
    tmp___14 = __dyc_funcallvar_16;

    }
  }
  if (opts.use_thread_affinity) {
    {
    while (1) {
      while_2_continue:  ;
      {

      }
      goto while_2_break;
    }
    while_2_break:  ;
    }
    __cpu = (size_t )(i % num_cores);
    if (__cpu / 8UL < sizeof(cpu_set_t )) {
      cpu_set.__bits[__cpu / (8UL * sizeof(__cpu_mask ))] |= 1UL << __cpu % (8UL * sizeof(__cpu_mask ));
    }
    {
    rv = __dyc_funcallvar_17;
    }
    if (rv) {
      {
      tmp___15 = __dyc_funcallvar_18;


      }
    } else {
      {

      }
    }
  } else {
    {

    }
  }
  i ++;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(i);
  __dyc_print_ptr__char(tmp___14);
  __dyc_print_comp_57__anonstruct_cpu_set_t_30(cpu_set);
  __dyc_print_ptr__char(tmp___15);
}
}
