#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *new_item ;
  unsigned int _he_bkt ;
  unsigned int _he_bkt_i ;
  struct UT_hash_handle *_he_thh ;
  struct UT_hash_handle *_he_hh_nxt ;
  UT_hash_bucket *_he_new_buckets ;
  UT_hash_bucket *_he_newbkt ;
  int tmp___5 ;

  {
  new_item = __dyc_read_ptr__typdef_symdir_t();
  _he_bkt_i = (unsigned int )__dyc_readpre_byte();
  _he_new_buckets = __dyc_read_ptr__typdef_UT_hash_bucket();
  _he_bkt = 0;
  _he_thh = 0;
  _he_hh_nxt = 0;
  _he_newbkt = 0;
  tmp___5 = 0;
  tmp___5 = 0;
  while_27_continue:  ;
  if (! (_he_bkt_i < (new_item->hh.tbl)->num_buckets)) {
    goto __dyc_dummy_label;
  }
  _he_thh = ((new_item->hh.tbl)->buckets + _he_bkt_i)->hh_head;
  while (1) {
    while_28_continue:  ;
    if (! _he_thh) {
      goto __dyc_dummy_label;
    }
    _he_hh_nxt = _he_thh->hh_next;
    {
    while (1) {
      while_29_continue:  ;
      _he_bkt = _he_thh->hashv & ((new_item->hh.tbl)->num_buckets * 2U - 1U);
      goto while_29_break;
    }
    while_29_break:  ;
    }
    _he_newbkt = _he_new_buckets + _he_bkt;
    (_he_newbkt->count) ++;
    if (_he_newbkt->count > (new_item->hh.tbl)->ideal_chain_maxlen) {
      ((new_item->hh.tbl)->nonideal_items) ++;
      _he_newbkt->expand_mult = _he_newbkt->count / (new_item->hh.tbl)->ideal_chain_maxlen;
    }
    _he_thh->hh_prev = (struct UT_hash_handle *)((void *)0);
    _he_thh->hh_next = _he_newbkt->hh_head;
    if (_he_newbkt->hh_head) {
      (_he_newbkt->hh_head)->hh_prev = _he_thh;
    }
    _he_newbkt->hh_head = _he_thh;
    _he_thh = _he_hh_nxt;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___5);
}
}
