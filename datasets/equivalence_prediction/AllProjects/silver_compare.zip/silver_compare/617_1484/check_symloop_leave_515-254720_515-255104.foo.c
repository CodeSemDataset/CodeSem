#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  symdir_t *item_found ;
  unsigned int _hf_bkt ;
  unsigned int _hf_hashv ;
  int tmp ;
  int __dyc_funcallvar_1 ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  _hf_bkt = (unsigned int )__dyc_readpre_byte();
  _hf_hashv = (unsigned int )__dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  item_found = 0;
  tmp = 0;
  _hf_bkt = _hf_hashv & ((symhash->hh.tbl)->num_buckets - 1U);
  goto __dyc_dummy_label;
  while_36_continue:  ;
  if (((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head) {
    {
    while (1) {
      while_37_continue:  ;
      item_found = (symdir_t *)((void *)((char *)((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head - (symhash->hh.tbl)->hho));
      goto while_37_break;
    }
    while_37_break:  ;
    }
  } else {
    item_found = (symdir_t *)((void *)0);
  }
  while (1) {
    while_38_continue:  ;
    if (! item_found) {
      goto __dyc_dummy_label;
    }
    if ((unsigned long )item_found->hh.keylen == sizeof(dirkey_t )) {
      {
      tmp = __dyc_funcallvar_1;
      }
      if (tmp == 0) {
        goto __dyc_dummy_label;
      }
    }
    if (item_found->hh.hh_next) {
      {
      while (1) {
        while_39_continue:  ;
        item_found = (symdir_t *)((void *)((char *)item_found->hh.hh_next - (symhash->hh.tbl)->hho));
        goto while_39_break;
      }
      while_39_break:  ;
      }
    } else {
      item_found = (symdir_t *)((void *)0);
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(_hf_bkt);
}
}
