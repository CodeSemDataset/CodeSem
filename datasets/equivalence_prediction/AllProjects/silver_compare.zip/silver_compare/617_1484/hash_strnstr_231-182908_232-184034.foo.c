#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ size_t i___0 ;
  char const   *R___0 ;
  char s_c ;
  int tmp___12 ;
  int __res___2 ;
  int __attribute__((__leaf__))  tmp___15 ;
  __int32_t const   **tmp___16 ;
  size_t f_len ;
  int case_sensitive ;
  int __attribute__((__leaf__))  __dyc_funcallvar_3 ;
  __int32_t const   **__dyc_funcallvar_4 ;

  {
  i___0 = (size_t )__dyc_readpre_byte();
  R___0 = (char const   *)__dyc_read_ptr__char();
  f_len = (size_t )__dyc_readpre_byte();
  case_sensitive = __dyc_readpre_byte();
  __dyc_funcallvar_3 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  s_c = 0;
  tmp___12 = 0;
  __res___2 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  if (! (i___0 < f_len)) {
    goto __dyc_dummy_label;
  }
  if (case_sensitive) {
    tmp___12 = (int const   )*(R___0 + i___0);
  } else {
    if (sizeof(char const   ) > 1UL) {
      {
      tmp___15 = __dyc_funcallvar_3;
      __res___2 = (int )tmp___15;
      }
    } else {
      {
      tmp___16 = __dyc_funcallvar_4;
      __res___2 = (int )*(*tmp___16 + (int )*(R___0 + i___0));
      }
    }
    tmp___12 = (int const   )__res___2;
  }
  s_c = (char )tmp___12;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(s_c);
}
}
