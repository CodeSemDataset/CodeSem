#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  unsigned int _hf_bkt ;
  unsigned int _hf_hashv ;
  unsigned int _hj_i ;
  unsigned int _hj_j ;
  unsigned int _hj_k ;
  unsigned char *_hj_key ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  _hf_hashv = (unsigned int )__dyc_readpre_byte();
  _hj_i = (unsigned int )__dyc_readpre_byte();
  _hj_j = (unsigned int )__dyc_readpre_byte();
  _hj_k = (unsigned int )__dyc_readpre_byte();
  _hj_key = __dyc_read_ptr__char();
  _hf_bkt = 0;
  _hf_hashv = (unsigned int )((unsigned long )_hf_hashv + sizeof(dirkey_t ));
  if ((int )_hj_k == 11) {
    goto switch_34_11;
  } else {
    if ((int )_hj_k == 10) {
      goto switch_34_10;
    } else {
      if ((int )_hj_k == 9) {
        goto switch_34_9;
      } else {
        if ((int )_hj_k == 8) {
          goto switch_34_8;
        } else {
          if ((int )_hj_k == 7) {
            goto switch_34_7;
          } else {
            if ((int )_hj_k == 6) {
              goto switch_34_6;
            } else {
              if ((int )_hj_k == 5) {
                goto switch_34_5;
              } else {
                if ((int )_hj_k == 4) {
                  goto switch_34_4;
                } else {
                  if ((int )_hj_k == 3) {
                    goto switch_34_3;
                  } else {
                    if ((int )_hj_k == 2) {
                      goto switch_34_2;
                    } else {
                      if ((int )_hj_k == 1) {
                        goto switch_34_1;
                      } else {
                        if (0) {
                          switch_34_11:  
                          _hf_hashv += (unsigned int )*(_hj_key + 10) << 24;
                          switch_34_10:  
                          _hf_hashv += (unsigned int )*(_hj_key + 9) << 16;
                          switch_34_9:  
                          _hf_hashv += (unsigned int )*(_hj_key + 8) << 8;
                          switch_34_8:  
                          _hj_j += (unsigned int )*(_hj_key + 7) << 24;
                          switch_34_7:  
                          _hj_j += (unsigned int )*(_hj_key + 6) << 16;
                          switch_34_6:  
                          _hj_j += (unsigned int )*(_hj_key + 5) << 8;
                          switch_34_5:  
                          _hj_j += (unsigned int )*(_hj_key + 4);
                          switch_34_4:  
                          _hj_i += (unsigned int )*(_hj_key + 3) << 24;
                          switch_34_3:  
                          _hj_i += (unsigned int )*(_hj_key + 2) << 16;
                          switch_34_2:  
                          _hj_i += (unsigned int )*(_hj_key + 1) << 8;
                          switch_34_1:  
                          _hj_i += (unsigned int )*(_hj_key + 0);
                        } else {
                          switch_34_break:  ;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  while (1) {
    while_35_continue:  ;
    _hj_i -= _hj_j;
    _hj_i -= _hf_hashv;
    _hj_i ^= _hf_hashv >> 13;
    _hj_j -= _hf_hashv;
    _hj_j -= _hj_i;
    _hj_j ^= _hj_i << 8;
    _hf_hashv -= _hj_i;
    _hf_hashv -= _hj_j;
    _hf_hashv ^= _hj_j >> 13;
    _hj_i -= _hj_j;
    _hj_i -= _hf_hashv;
    _hj_i ^= _hf_hashv >> 12;
    _hj_j -= _hf_hashv;
    _hj_j -= _hj_i;
    _hj_j ^= _hj_i << 16;
    _hf_hashv -= _hj_i;
    _hf_hashv -= _hj_j;
    _hf_hashv ^= _hj_j >> 5;
    _hj_i -= _hj_j;
    _hj_i -= _hf_hashv;
    _hj_i ^= _hf_hashv >> 3;
    _hj_j -= _hf_hashv;
    _hj_j -= _hj_i;
    _hj_j ^= _hj_i << 10;
    _hf_hashv -= _hj_i;
    _hf_hashv -= _hj_j;
    _hf_hashv ^= _hj_j >> 15;
    goto while_35_break;
  }
  while_35_break:  ;
  _hf_bkt = _hf_hashv & ((symhash->hh.tbl)->num_buckets - 1U);
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(_hf_bkt);
}
}
