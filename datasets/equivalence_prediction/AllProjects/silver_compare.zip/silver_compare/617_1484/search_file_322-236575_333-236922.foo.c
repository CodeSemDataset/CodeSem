#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  off_t f_len ;
  struct stat statbuf ;
  int matches_count ;
  ssize_t tmp___5 ;
  ssize_t __dyc_funcallvar_8 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  statbuf = __dyc_read_comp_27stat();
  __dyc_funcallvar_8 = (ssize_t )__dyc_readpre_byte();
  f_len = 0;
  matches_count = 0;
  tmp___5 = 0;
  f_len = statbuf.st_size;
  if (f_len == 0L) {
    if ((int )*(opts.query + 0) == 46) {
      if (opts.query_len == 1) {
        if (! opts.literal) {
          if (opts.search_all_files) {
            {
            tmp___5 = __dyc_funcallvar_8;
            matches_count = (int )tmp___5;
            }
          } else {
            {

            }
          }
        } else {
          {

          }
        }
      } else {
        {

        }
      }
    } else {
      {

      }
    }
    goto __dyc_dummy_label;
  }
  if (! opts.literal) {
    if (f_len > 2147483647L) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(matches_count);
}
}
