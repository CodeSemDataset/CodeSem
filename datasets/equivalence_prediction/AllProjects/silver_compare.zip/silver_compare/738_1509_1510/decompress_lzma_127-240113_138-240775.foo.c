#include "../include/dycfoo.h"
#include "../include/decompress.i.hd.c.h"
void __dyc_foo(void) 
{ lzma_stream stream ;
  lzma_ret lzrt ;
  unsigned char *result ;
  size_t result_size ;
  size_t pagesize ;
  void const   *buf ;
  int buf_len ;
  lzma_ret __dyc_funcallvar_1 ;

  {
  buf = (void const   *)__dyc_read_ptr__void();
  buf_len = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (lzma_ret )__dyc_readpre_byte();
  memset(& stream, 0, sizeof(lzma_stream ));
  lzrt = 0;
  result = 0;
  result_size = 0;
  pagesize = 0;
  stream.reserved_int4 = (size_t )0;
  stream.reserved_enum1 = 0;
  stream.reserved_enum2 = 0;
  result = (unsigned char *)((void *)0);
  result_size = (size_t )0;
  pagesize = (size_t )0;
  stream.avail_in = (unsigned long )buf_len;
  stream.next_in = (uint8_t const   *)buf;
  lzrt = __dyc_funcallvar_1;
  if ((int )lzrt != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_72__anonstruct_lzma_stream_49(stream);
  __dyc_print_ptr__char(result);
  __dyc_printpre_byte(result_size);
  __dyc_printpre_byte(pagesize);
}
}
