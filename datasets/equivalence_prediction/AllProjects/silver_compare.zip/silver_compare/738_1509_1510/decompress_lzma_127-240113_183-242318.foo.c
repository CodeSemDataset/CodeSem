#include "../include/dycfoo.h"
#include "../include/decompress.i.hd.c.h"
void __dyc_foo(void) 
{ lzma_stream stream ;
  lzma_ret lzrt ;
  unsigned char *result ;
  size_t result_size ;
  size_t pagesize ;
  int tmp ;
  unsigned char *tmp_result ;
  void *tmp___0 ;
  void const   *buf ;
  int buf_len ;
  int *new_buf_len ;
  lzma_ret __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;
  lzma_ret __dyc_funcallvar_4 ;

  {
  buf = (void const   *)__dyc_read_ptr__void();
  buf_len = __dyc_readpre_byte();
  new_buf_len = __dyc_read_ptr__int();
  __dyc_funcallvar_1 = (lzma_ret )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = (lzma_ret )__dyc_readpre_byte();
  memset(& stream, 0, sizeof(lzma_stream ));
  lzrt = 0;
  result = 0;
  result_size = 0;
  pagesize = 0;
  tmp = 0;
  tmp_result = 0;
  tmp___0 = 0;
  stream.reserved_enum2 = 0;
  result = (unsigned char *)((void *)0);
  result_size = (size_t )0;
  pagesize = (size_t )0;
  stream.avail_in = (unsigned long )buf_len;
  stream.next_in = (uint8_t const   *)buf;
  lzrt = __dyc_funcallvar_1;
  if ((int )lzrt != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  tmp = __dyc_funcallvar_2;
  pagesize = (unsigned long )tmp;
  result_size = (((size_t )buf_len + pagesize) - 1UL) & ~ (pagesize - 1UL);
  while (1) {
    while_3_continue:  ;
    {
    while (1) {
      while_4_continue:  ;
      {
      tmp_result = result;
      result_size *= 2UL;
      tmp___0 = __dyc_funcallvar_3;
      result = (unsigned char *)tmp___0;
      }
      if ((unsigned long )result == (unsigned long )((void *)0)) {
        {


        }
        goto __dyc_dummy_label;
      }
      {
      stream.avail_out = result_size / 2UL;
      stream.next_out = result + stream.total_out;
      lzrt = __dyc_funcallvar_4;

      }
      if ((int )lzrt == 0) {
        goto switch_5_0;
      } else {
        if ((int )lzrt == 1) {
          goto switch_5_0;
        } else {
          {
          goto switch_5_default;
          if (0) {
            switch_5_0:  
            switch_5_1:  
            goto switch_5_break;
            switch_5_default:  
            {

            }
            goto __dyc_dummy_label;
          } else {
            switch_5_break:  ;
          }
          }
        }
      }
      if (! (stream.avail_out == 0UL)) {
        goto while_4_break;
      }
    }
    while_4_break:  ;
    }
    if (! ((int )lzrt == 0)) {
      goto while_3_break;
    }
  }
  while_3_break:  ;
  *new_buf_len = (int )stream.total_out;
  if ((int )lzrt == 1) {
    {

    }
    goto __dyc_dummy_label;
  }

  *new_buf_len = 0;
  if (result) {
    {

    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_72__anonstruct_lzma_stream_49(stream);
  __dyc_printpre_byte(result_size);
  __dyc_printpre_byte(pagesize);
  __dyc_print_ptr__char(tmp_result);
}
}
