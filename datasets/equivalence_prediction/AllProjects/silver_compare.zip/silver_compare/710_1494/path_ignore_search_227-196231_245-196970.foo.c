#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ char *temp ;
  int temp_start_pos ;
  size_t i ;
  int match_pos ;
  char *slash_filename ;
  char *pos ;
  char *tmp___0 ;
  size_t tmp___1 ;
  ignores const   *ig ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  char *__dyc_funcallvar_10 ;
  size_t __dyc_funcallvar_11 ;

  {
  temp = __dyc_read_ptr__char();
  temp_start_pos = __dyc_readpre_byte();
  ig = (ignores const   *)__dyc_read_ptr__typdef_ignores();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = (size_t )__dyc_readpre_byte();
  i = 0;
  match_pos = 0;
  slash_filename = 0;
  pos = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  slash_filename = (temp + temp_start_pos) + ig->abs_path_len;
  if ((int )*(slash_filename + 0) == 47) {
    slash_filename ++;
  }
  match_pos = __dyc_funcallvar_8;
  if (match_pos >= 0) {
    {


    }
    goto __dyc_dummy_label;
  }
  match_pos = __dyc_funcallvar_9;
  if (match_pos >= 0) {
    {


    }
    goto __dyc_dummy_label;
  }
  i = 0UL;
  while (1) {
    while_3_continue:  ;
    if (! (i < (size_t )ig->names_len)) {
      goto __dyc_dummy_label;
    }
    {
    tmp___0 = __dyc_funcallvar_10;
    pos = tmp___0;
    }
    if ((unsigned long )pos == (unsigned long )slash_filename) {
      goto _L;
    } else {
      if (pos) {
        if ((int )*(pos - 1) == 47) {
          _L:  
          {
          tmp___1 = __dyc_funcallvar_11;
          pos += tmp___1;
          }
          if ((int )*pos == 0) {
            {


            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*pos == 47) {
              {


              }
              goto __dyc_dummy_label;
            }
          }
        }
      }
    }
    {

    i ++;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(slash_filename);
}
}
