#include "../include/dycfoo.h"
#include "../include/scandir.i.hd.c.h"
void __dyc_foo(void) 
{ DIR *dirp ;
  struct dirent **names ;
  struct dirent *entry ;
  struct dirent *d ;
  int names_len ;
  int results_len ;
  void *tmp ;
  int tmp___0 ;
  struct dirent **tmp_names ;
  void *tmp___1 ;
  void *tmp___2 ;
  int i ;
  struct dirent ***namelist ;
  DIR *__dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;
  struct dirent *__dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  void *__dyc_funcallvar_5 ;
  void *__dyc_funcallvar_6 ;

  {
  names = __dyc_read_ptr__ptr__comp_2dirent();
  namelist = __dyc_read_ptr__ptr__ptr__comp_2dirent();
  __dyc_funcallvar_1 = (DIR *)__dyc_read_ptr__typdef_DIR();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  __dyc_funcallvar_3 = __dyc_read_ptr__comp_2dirent();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = __dyc_read_ptr__void();
  dirp = 0;
  entry = 0;
  d = 0;
  names_len = 0;
  results_len = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp_names = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  i = 0;
  names_len = 32;
  results_len = 0;
  dirp = __dyc_funcallvar_1;
  if ((unsigned long )dirp == (unsigned long )((void *)0)) {
    goto fail;
  }
  tmp = __dyc_funcallvar_2;
  names = (struct dirent **)tmp;
  if ((unsigned long )names == (unsigned long )((void *)0)) {
    goto fail;
  }
  while (1) {
    while_0_continue:  ;
    {
    entry = __dyc_funcallvar_3;
    }
    if (! ((unsigned long )entry != (unsigned long )((void *)0))) {
      goto while_0_break;
    }
    {
    tmp___0 = __dyc_funcallvar_4;
    }
    if (tmp___0 == 0) {
      goto while_0_continue;
    }
    if (results_len >= names_len) {
      {
      tmp_names = names;
      names_len *= 2;
      tmp___1 = __dyc_funcallvar_5;
      names = (struct dirent **)tmp___1;
      }
      if ((unsigned long )names == (unsigned long )((void *)0)) {
        {

        }
        goto fail;
      }
    }
    {
    tmp___2 = __dyc_funcallvar_6;
    d = (struct dirent *)tmp___2;
    }
    if ((unsigned long )d == (unsigned long )((void *)0)) {
      goto fail;
    }
    {

    *(names + results_len) = d;
    results_len ++;
    }
  }
  while_0_break:  ;

  *namelist = names;
  goto __dyc_dummy_label;
  fail: 
  if (dirp) {
    {

    }
  }
  if ((unsigned long )names != (unsigned long )((void *)0)) {
    i = 0;
    {
    while (1) {
      while_1_continue:  ;
      if (! (i < results_len)) {
        goto while_1_break;
      }
      {

      i ++;
      }
    }
    while_1_break:  ;
    }
    {

    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(names_len);
  __dyc_printpre_byte(results_len);
  __dyc_print_ptr__ptr__comp_2dirent(tmp_names);
}
}
