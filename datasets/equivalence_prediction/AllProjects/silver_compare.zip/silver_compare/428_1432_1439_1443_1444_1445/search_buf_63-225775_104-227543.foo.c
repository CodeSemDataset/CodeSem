#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  size_t *find_skip_lookup ;
  size_t buf_offset ;
  size_t matches_len ;
  match_t *matches ;
  char const   *match_ptr ;
  char const   *start ;
  char const   *end ;
  int tmp___2 ;
  int tmp___3 ;
  char const   *buf ;
  size_t buf_len ;
  char const   *__dyc_funcallvar_4 ;
  char const   *__dyc_funcallvar_5 ;
  char const   *__dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  find_skip_lookup = __dyc_read_ptr__typdef_size_t();
  buf_offset = (size_t )__dyc_readpre_byte();
  matches_len = (size_t )__dyc_readpre_byte();
  matches = __dyc_read_ptr__typdef_match_t();
  buf = (char const   *)__dyc_read_ptr__char();
  buf_len = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_5 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_6 = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  match_ptr = 0;
  start = 0;
  end = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  if (! (buf_offset < buf_len)) {
    goto __dyc_dummy_label;
  }
  if ((unsigned long )opts.query_len < 2UL * sizeof(uint16_t ) - 1UL) {
    {
    match_ptr = __dyc_funcallvar_4;
    }
  } else {
    if (opts.query_len >= 255) {
      {
      match_ptr = __dyc_funcallvar_5;
      }
    } else {
      {
      match_ptr = __dyc_funcallvar_6;
      }
    }
  }
  if ((unsigned long )match_ptr == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  if (opts.word_regexp) {
    start = match_ptr;
    end = match_ptr + opts.query_len;
    if ((unsigned long )start == (unsigned long )buf) {
      goto _L;
    } else {
      {
      tmp___2 = __dyc_funcallvar_7;
      }
      if (tmp___2 != opts.literal_starts_wordchar) {
        _L:  
        if (! ((unsigned long )end == (unsigned long )(buf + buf_len))) {
          {
          tmp___3 = __dyc_funcallvar_8;
          }
          if (! (tmp___3 != opts.literal_ends_wordchar)) {
            match_ptr += (*(find_skip_lookup + 0) - (size_t )opts.query_len) + 1UL;
            buf_offset = (unsigned long )(match_ptr - buf);
            goto __dyc_dummy_label;
          }
        }
      } else {
        match_ptr += (*(find_skip_lookup + 0) - (size_t )opts.query_len) + 1UL;
        buf_offset = (unsigned long )(match_ptr - buf);
        goto __dyc_dummy_label;
      }
    }
  }

  (matches + matches_len)->start = (unsigned long )(match_ptr - buf);
  (matches + matches_len)->end = (matches + matches_len)->start + (size_t )opts.query_len;
  buf_offset = (matches + matches_len)->end;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(buf_offset);
  __dyc_print_ptr__char(end);
}
}
