#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ scandir_baton_t scandir_baton ;
  size_t base_path_len ;
  char const   *path_start ;
  int i ;
  ignores *ig ;
  char const   *base_path ;
  char const   *path ;
  size_t __dyc_funcallvar_2 ;

  {
  path_start = (char const   *)__dyc_read_ptr__char();
  ig = __dyc_read_ptr__typdef_ignores();
  base_path = (char const   *)__dyc_read_ptr__char();
  path = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_2 = (size_t )__dyc_readpre_byte();
  memset(& scandir_baton, 0, sizeof(scandir_baton_t ));
  base_path_len = 0;
  i = 0;
  if (base_path) {
    {
    base_path_len = __dyc_funcallvar_2;
    }
  } else {
    base_path_len = 0UL;
  }
  i = 0;
  while (1) {
    while_44_continue:  ;
    if ((unsigned long )i < base_path_len) {
      if (*(path + i)) {
        if (! ((int const   )*(base_path + i) == (int const   )*(path + i))) {
          goto while_44_break;
        }
      } else {
        goto while_44_break;
      }
    } else {
      goto while_44_break;
    }
    path_start = (path + i) + 1;
    i ++;
  }
  while_44_break:  ;

  scandir_baton.ig = (ignores const   *)ig;
  scandir_baton.base_path = base_path;
  scandir_baton.base_path_len = base_path_len;
  scandir_baton.path_start = path_start;
  __dyc_dummy_label:  ;
  __dyc_print_comp_89__anonstruct_scandir_baton_t_50(scandir_baton);
}
}
