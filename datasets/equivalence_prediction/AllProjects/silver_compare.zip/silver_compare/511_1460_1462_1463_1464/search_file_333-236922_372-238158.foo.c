#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ off_t f_len ;
  char *buf ;
  void *tmp___6 ;
  int *tmp___7 ;
  char *tmp___8 ;
  void *tmp___9 ;
  ssize_t bytes_read ;
  void *__dyc_funcallvar_9 ;
  int *__dyc_funcallvar_10 ;
  char *__dyc_funcallvar_11 ;
  void *__dyc_funcallvar_12 ;

  {
  f_len = (off_t )__dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_read_ptr__void();
  __dyc_funcallvar_10 = __dyc_read_ptr__int();
  __dyc_funcallvar_11 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_12 = __dyc_read_ptr__void();
  buf = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  bytes_read = 0;
  if (f_len > 2147483647L) {
    {

    }
    goto __dyc_dummy_label;
  }
  tmp___6 = __dyc_funcallvar_9;
  buf = (char *)tmp___6;
  if ((unsigned long )buf == (unsigned long )((void *)-1)) {
    {
    tmp___7 = __dyc_funcallvar_10;
    tmp___8 = __dyc_funcallvar_11;

    }
    goto __dyc_dummy_label;
  }

  tmp___9 = __dyc_funcallvar_12;
  buf = (char *)tmp___9;
  bytes_read = (ssize_t )0;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(buf);
  __dyc_print_ptr__int(tmp___7);
  __dyc_print_ptr__char(tmp___8);
  __dyc_printpre_byte(bytes_read);
}
}
