#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  int tmp___17 ;
  int tmp___18 ;
  scandir_baton_t *scandir_baton ;
  char const   *path_start ;
  char const   *extension ;
  char *tmp___20 ;
  void *baton ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  char *__dyc_funcallvar_8 ;

  {
  opts = __dyc_read_comp_72__anonstruct_cli_options_41();
  baton = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_read_ptr__char();
  tmp___17 = 0;
  tmp___18 = 0;
  scandir_baton = 0;
  path_start = 0;
  extension = 0;
  tmp___20 = 0;
  if (! opts.follow_symlinks) {
    {
    tmp___17 = __dyc_funcallvar_6;
    }
    if (tmp___17) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___18 = __dyc_funcallvar_7;
  if (tmp___18) {
    {

    }
    goto __dyc_dummy_label;
  }
  if (opts.search_all_files) {
    if (! opts.path_to_ignore) {
      goto __dyc_dummy_label;
    }
  }
  scandir_baton = (scandir_baton_t *)baton;
  path_start = scandir_baton->path_start;
  tmp___20 = __dyc_funcallvar_8;
  extension = (char const   *)tmp___20;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(path_start);
  __dyc_print_ptr__char(extension);
}
}
