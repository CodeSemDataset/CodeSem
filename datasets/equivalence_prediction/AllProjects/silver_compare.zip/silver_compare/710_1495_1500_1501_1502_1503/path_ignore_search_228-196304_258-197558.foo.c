#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ size_t i ;
  int match_pos ;
  char *slash_filename ;
  char *pos ;
  char *tmp___0 ;
  size_t tmp___1 ;
  int tmp___2 ;
  ignores const   *ig ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  char *__dyc_funcallvar_10 ;
  size_t __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;

  {
  slash_filename = __dyc_read_ptr__char();
  ig = (ignores const   *)__dyc_read_ptr__typdef_ignores();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  i = 0;
  match_pos = 0;
  pos = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  if ((int )*(slash_filename + 0) == 47) {
    slash_filename ++;
  }
  match_pos = __dyc_funcallvar_8;
  if (match_pos >= 0) {
    {


    }
    goto __dyc_dummy_label;
  }
  match_pos = __dyc_funcallvar_9;
  if (match_pos >= 0) {
    {


    }
    goto __dyc_dummy_label;
  }
  i = 0UL;
  while (1) {
    while_3_continue:  ;
    if (! (i < (size_t )ig->names_len)) {
      goto while_3_break;
    }
    {
    tmp___0 = __dyc_funcallvar_10;
    pos = tmp___0;
    }
    if ((unsigned long )pos == (unsigned long )slash_filename) {
      goto _L;
    } else {
      if (pos) {
        if ((int )*(pos - 1) == 47) {
          _L:  
          {
          tmp___1 = __dyc_funcallvar_11;
          pos += tmp___1;
          }
          if ((int )*pos == 0) {
            {


            }
            goto __dyc_dummy_label;
          } else {
            if ((int )*pos == 47) {
              {


              }
              goto __dyc_dummy_label;
            }
          }
        }
      }
    }
    {

    i ++;
    }
  }
  while_3_break:  ;
  i = 0UL;
  while (1) {
    while_4_continue:  ;
    if (! (i < (size_t )ig->slash_regexes_len)) {
      goto __dyc_dummy_label;
    }
    {
    tmp___2 = __dyc_funcallvar_12;
    }
    if (tmp___2 == 0) {
      {


      }
      goto __dyc_dummy_label;
    }
    {

    i ++;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(slash_filename);
}
}
