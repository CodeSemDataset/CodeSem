#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  symdir_t *item_found ;
  unsigned int _hf_bkt ;
  unsigned int _hf_hashv ;
  unsigned int _hj_i ;
  unsigned int _hj_j ;
  unsigned int _hj_k ;
  unsigned char *_hj_key ;
  int tmp ;
  unsigned int _hd_bkt ;
  struct UT_hash_handle *_hd_hh_del ;
  dirkey_t *dirkey ;
  int __dyc_funcallvar_1 ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  dirkey = __dyc_read_ptr__typdef_dirkey_t();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  item_found = 0;
  _hf_bkt = 0;
  _hf_hashv = 0;
  _hj_i = 0;
  _hj_j = 0;
  _hj_k = 0;
  _hj_key = 0;
  tmp = 0;
  _hd_bkt = 0;
  _hd_hh_del = 0;
  item_found = (symdir_t *)((void *)0);
  if (dirkey->dev == 0UL) {
    if (dirkey->ino == 0UL) {
      goto __dyc_dummy_label;
    }
  }
  while (1) {
    while_30_continue:  ;
    item_found = (symdir_t *)((void *)0);
    if (symhash) {
      {
      while (1) {
        while_31_continue:  ;
        _hj_key = (unsigned char *)dirkey;
        _hf_hashv = 4276993775U;
        _hj_j = 2654435769U;
        _hj_i = _hj_j;
        _hj_k = (unsigned int )sizeof(dirkey_t );
        {
        while (1) {
          while_32_continue:  ;
          if (! (_hj_k >= 12U)) {
            goto while_32_break;
          }
          _hj_i += (((unsigned int )*(_hj_key + 0) + ((unsigned int )*(_hj_key + 1) << 8)) + ((unsigned int )*(_hj_key + 2) << 16)) + ((unsigned int )*(_hj_key + 3) << 24);
          _hj_j += (((unsigned int )*(_hj_key + 4) + ((unsigned int )*(_hj_key + 5) << 8)) + ((unsigned int )*(_hj_key + 6) << 16)) + ((unsigned int )*(_hj_key + 7) << 24);
          _hf_hashv += (((unsigned int )*(_hj_key + 8) + ((unsigned int )*(_hj_key + 9) << 8)) + ((unsigned int )*(_hj_key + 10) << 16)) + ((unsigned int )*(_hj_key + 11) << 24);
          {
          while (1) {
            while_33_continue:  ;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 13;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 8;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 13;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 12;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 16;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 5;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 3;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 10;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 15;
            goto while_33_break;
          }
          while_33_break:  ;
          }
          _hj_key += 12;
          _hj_k -= 12U;
        }
        while_32_break:  ;
        }
        _hf_hashv = (unsigned int )((unsigned long )_hf_hashv + sizeof(dirkey_t ));
        if ((int )_hj_k == 11) {
          goto switch_34_11;
        } else {
          if ((int )_hj_k == 10) {
            goto switch_34_10;
          } else {
            if ((int )_hj_k == 9) {
              goto switch_34_9;
            } else {
              if ((int )_hj_k == 8) {
                goto switch_34_8;
              } else {
                if ((int )_hj_k == 7) {
                  goto switch_34_7;
                } else {
                  if ((int )_hj_k == 6) {
                    goto switch_34_6;
                  } else {
                    if ((int )_hj_k == 5) {
                      goto switch_34_5;
                    } else {
                      if ((int )_hj_k == 4) {
                        goto switch_34_4;
                      } else {
                        if ((int )_hj_k == 3) {
                          goto switch_34_3;
                        } else {
                          if ((int )_hj_k == 2) {
                            goto switch_34_2;
                          } else {
                            if ((int )_hj_k == 1) {
                              goto switch_34_1;
                            } else {
                              if (0) {
                                switch_34_11:  
                                _hf_hashv += (unsigned int )*(_hj_key + 10) << 24;
                                switch_34_10:  
                                _hf_hashv += (unsigned int )*(_hj_key + 9) << 16;
                                switch_34_9:  
                                _hf_hashv += (unsigned int )*(_hj_key + 8) << 8;
                                switch_34_8:  
                                _hj_j += (unsigned int )*(_hj_key + 7) << 24;
                                switch_34_7:  
                                _hj_j += (unsigned int )*(_hj_key + 6) << 16;
                                switch_34_6:  
                                _hj_j += (unsigned int )*(_hj_key + 5) << 8;
                                switch_34_5:  
                                _hj_j += (unsigned int )*(_hj_key + 4);
                                switch_34_4:  
                                _hj_i += (unsigned int )*(_hj_key + 3) << 24;
                                switch_34_3:  
                                _hj_i += (unsigned int )*(_hj_key + 2) << 16;
                                switch_34_2:  
                                _hj_i += (unsigned int )*(_hj_key + 1) << 8;
                                switch_34_1:  
                                _hj_i += (unsigned int )*(_hj_key + 0);
                              } else {
                                switch_34_break:  ;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        {
        while (1) {
          while_35_continue:  ;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 13;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 8;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 13;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 12;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 16;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 5;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 3;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 10;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 15;
          goto while_35_break;
        }
        while_35_break:  ;
        }
        _hf_bkt = _hf_hashv & ((symhash->hh.tbl)->num_buckets - 1U);
        goto while_31_break;
      }
      while_31_break:  ;
      }
      {
      while (1) {
        while_36_continue:  ;
        if (((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head) {
          {
          while (1) {
            while_37_continue:  ;
            item_found = (symdir_t *)((void *)((char *)((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head - (symhash->hh.tbl)->hho));
            goto while_37_break;
          }
          while_37_break:  ;
          }
        } else {
          item_found = (symdir_t *)((void *)0);
        }
        {
        while (1) {
          while_38_continue:  ;
          if (! item_found) {
            goto while_38_break;
          }
          if ((unsigned long )item_found->hh.keylen == sizeof(dirkey_t )) {
            {
            tmp = __dyc_funcallvar_1;
            }
            if (tmp == 0) {
              goto while_38_break;
            }
          }
          if (item_found->hh.hh_next) {
            {
            while (1) {
              while_39_continue:  ;
              item_found = (symdir_t *)((void *)((char *)item_found->hh.hh_next - (symhash->hh.tbl)->hho));
              goto while_39_break;
            }
            while_39_break:  ;
            }
          } else {
            item_found = (symdir_t *)((void *)0);
          }
        }
        while_38_break:  ;
        }
        goto while_36_break;
      }
      while_36_break:  ;
      }
    }
    goto while_30_break;
  }
  while_30_break:  ;
  if (! item_found) {
    {

    }
    goto __dyc_dummy_label;
  }
  while (1) {
    while_40_continue:  ;
    if ((unsigned long )item_found->hh.prev == (unsigned long )((void *)0)) {
      if ((unsigned long )item_found->hh.next == (unsigned long )((void *)0)) {
        {


        symhash = (symdir_t *)((void *)0);
        }
      } else {
        goto _L;
      }
    } else {
      _L:  
      _hd_hh_del = & item_found->hh;
      if ((unsigned long )item_found == (unsigned long )((void *)((char *)(symhash->hh.tbl)->tail - (symhash->hh.tbl)->hho))) {
        (symhash->hh.tbl)->tail = (UT_hash_handle *)((long )item_found->hh.prev + (symhash->hh.tbl)->hho);
      }
      if (item_found->hh.prev) {
        ((UT_hash_handle *)((long )item_found->hh.prev + (symhash->hh.tbl)->hho))->next = item_found->hh.next;
      } else {
        {
        while (1) {
          while_41_continue:  ;
          symhash = (symdir_t *)item_found->hh.next;
          goto while_41_break;
        }
        while_41_break:  ;
        }
      }
      if (_hd_hh_del->next) {
        ((UT_hash_handle *)((long )_hd_hh_del->next + (symhash->hh.tbl)->hho))->prev = _hd_hh_del->prev;
      }
      {
      while (1) {
        while_42_continue:  ;
        _hd_bkt = _hd_hh_del->hashv & ((symhash->hh.tbl)->num_buckets - 1U);
        goto while_42_break;
      }
      while_42_break:  ;
      }
      (((symhash->hh.tbl)->buckets + _hd_bkt)->count) --;
      if ((unsigned long )((symhash->hh.tbl)->buckets + _hd_bkt)->hh_head == (unsigned long )_hd_hh_del) {
        ((symhash->hh.tbl)->buckets + _hd_bkt)->hh_head = _hd_hh_del->hh_next;
      }
      if (_hd_hh_del->hh_prev) {
        (_hd_hh_del->hh_prev)->hh_next = _hd_hh_del->hh_next;
      }
      if (_hd_hh_del->hh_next) {
        (_hd_hh_del->hh_next)->hh_prev = _hd_hh_del->hh_prev;
      }
      ((symhash->hh.tbl)->num_items) --;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_symdir_t(symhash);
  __dyc_print_ptr__typdef_symdir_t(item_found);
  __dyc_print_ptr__char(_hj_key);
}
}
