#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  struct stat buf ;
  symdir_t *item_found ;
  symdir_t *new_item ;
  int res ;
  int __attribute__((__leaf__))  tmp ;
  unsigned int _hf_bkt ;
  unsigned int _hf_hashv ;
  unsigned int _hj_i ;
  unsigned int _hj_j ;
  unsigned int _hj_k ;
  unsigned char *_hj_key ;
  int tmp___0 ;
  void *tmp___1 ;
  dirkey_t *outkey ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  buf = __dyc_read_comp_27stat();
  outkey = __dyc_read_ptr__typdef_dirkey_t();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  item_found = 0;
  new_item = 0;
  res = 0;
  tmp = 0;
  _hf_bkt = 0;
  _hf_hashv = 0;
  _hj_i = 0;
  _hj_j = 0;
  _hj_k = 0;
  _hj_key = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  item_found = (symdir_t *)((void *)0);
  new_item = (symdir_t *)((void *)0);

  outkey->dev = 0UL;
  outkey->ino = 0UL;
  tmp = __dyc_funcallvar_1;
  res = (int )tmp;
  if (res != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  outkey->dev = buf.st_dev;
  outkey->ino = buf.st_ino;
  while (1) {
    while_8_continue:  ;
    item_found = (symdir_t *)((void *)0);
    if (symhash) {
      {
      while (1) {
        while_9_continue:  ;
        _hj_key = (unsigned char *)outkey;
        _hf_hashv = 4276993775U;
        _hj_j = 2654435769U;
        _hj_i = _hj_j;
        _hj_k = (unsigned int )sizeof(dirkey_t );
        {
        while (1) {
          while_10_continue:  ;
          if (! (_hj_k >= 12U)) {
            goto while_10_break;
          }
          _hj_i += (((unsigned int )*(_hj_key + 0) + ((unsigned int )*(_hj_key + 1) << 8)) + ((unsigned int )*(_hj_key + 2) << 16)) + ((unsigned int )*(_hj_key + 3) << 24);
          _hj_j += (((unsigned int )*(_hj_key + 4) + ((unsigned int )*(_hj_key + 5) << 8)) + ((unsigned int )*(_hj_key + 6) << 16)) + ((unsigned int )*(_hj_key + 7) << 24);
          _hf_hashv += (((unsigned int )*(_hj_key + 8) + ((unsigned int )*(_hj_key + 9) << 8)) + ((unsigned int )*(_hj_key + 10) << 16)) + ((unsigned int )*(_hj_key + 11) << 24);
          {
          while (1) {
            while_11_continue:  ;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 13;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 8;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 13;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 12;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 16;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 5;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 3;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 10;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 15;
            goto while_11_break;
          }
          while_11_break:  ;
          }
          _hj_key += 12;
          _hj_k -= 12U;
        }
        while_10_break:  ;
        }
        _hf_hashv = (unsigned int )((unsigned long )_hf_hashv + sizeof(dirkey_t ));
        if ((int )_hj_k == 11) {
          goto switch_12_11;
        } else {
          if ((int )_hj_k == 10) {
            goto switch_12_10;
          } else {
            if ((int )_hj_k == 9) {
              goto switch_12_9;
            } else {
              if ((int )_hj_k == 8) {
                goto switch_12_8;
              } else {
                if ((int )_hj_k == 7) {
                  goto switch_12_7;
                } else {
                  if ((int )_hj_k == 6) {
                    goto switch_12_6;
                  } else {
                    if ((int )_hj_k == 5) {
                      goto switch_12_5;
                    } else {
                      if ((int )_hj_k == 4) {
                        goto switch_12_4;
                      } else {
                        if ((int )_hj_k == 3) {
                          goto switch_12_3;
                        } else {
                          if ((int )_hj_k == 2) {
                            goto switch_12_2;
                          } else {
                            if ((int )_hj_k == 1) {
                              goto switch_12_1;
                            } else {
                              if (0) {
                                switch_12_11:  
                                _hf_hashv += (unsigned int )*(_hj_key + 10) << 24;
                                switch_12_10:  
                                _hf_hashv += (unsigned int )*(_hj_key + 9) << 16;
                                switch_12_9:  
                                _hf_hashv += (unsigned int )*(_hj_key + 8) << 8;
                                switch_12_8:  
                                _hj_j += (unsigned int )*(_hj_key + 7) << 24;
                                switch_12_7:  
                                _hj_j += (unsigned int )*(_hj_key + 6) << 16;
                                switch_12_6:  
                                _hj_j += (unsigned int )*(_hj_key + 5) << 8;
                                switch_12_5:  
                                _hj_j += (unsigned int )*(_hj_key + 4);
                                switch_12_4:  
                                _hj_i += (unsigned int )*(_hj_key + 3) << 24;
                                switch_12_3:  
                                _hj_i += (unsigned int )*(_hj_key + 2) << 16;
                                switch_12_2:  
                                _hj_i += (unsigned int )*(_hj_key + 1) << 8;
                                switch_12_1:  
                                _hj_i += (unsigned int )*(_hj_key + 0);
                              } else {
                                switch_12_break:  ;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        {
        while (1) {
          while_13_continue:  ;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 13;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 8;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 13;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 12;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 16;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 5;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 3;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 10;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 15;
          goto while_13_break;
        }
        while_13_break:  ;
        }
        _hf_bkt = _hf_hashv & ((symhash->hh.tbl)->num_buckets - 1U);
        goto while_9_break;
      }
      while_9_break:  ;
      }
      {
      while (1) {
        while_14_continue:  ;
        if (((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head) {
          {
          while (1) {
            while_15_continue:  ;
            item_found = (symdir_t *)((void *)((char *)((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head - (symhash->hh.tbl)->hho));
            goto while_15_break;
          }
          while_15_break:  ;
          }
        } else {
          item_found = (symdir_t *)((void *)0);
        }
        {
        while (1) {
          while_16_continue:  ;
          if (! item_found) {
            goto while_16_break;
          }
          if ((unsigned long )item_found->hh.keylen == sizeof(dirkey_t )) {
            {
            tmp___0 = __dyc_funcallvar_2;
            }
            if (tmp___0 == 0) {
              goto while_16_break;
            }
          }
          if (item_found->hh.hh_next) {
            {
            while (1) {
              while_17_continue:  ;
              item_found = (symdir_t *)((void *)((char *)item_found->hh.hh_next - (symhash->hh.tbl)->hho));
              goto while_17_break;
            }
            while_17_break:  ;
            }
          } else {
            item_found = (symdir_t *)((void *)0);
          }
        }
        while_16_break:  ;
        }
        goto while_14_break;
      }
      while_14_break:  ;
      }
    }
    goto while_8_break;
  }
  while_8_break:  ;
  if (item_found) {
    goto __dyc_dummy_label;
  }
  tmp___1 = __dyc_funcallvar_3;
  new_item = (symdir_t *)tmp___1;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_symdir_t(item_found);
  __dyc_print_ptr__typdef_symdir_t(new_item);
  __dyc_print_ptr__char(_hj_key);
}
}
