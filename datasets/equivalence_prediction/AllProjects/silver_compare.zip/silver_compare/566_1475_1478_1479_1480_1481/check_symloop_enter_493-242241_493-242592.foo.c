#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned int _hf_hashv ;
  unsigned int _hj_i ;
  unsigned int _hj_j ;
  unsigned char *_hj_key ;

  {
  _hf_hashv = (unsigned int )__dyc_readpre_byte();
  _hj_i = (unsigned int )__dyc_readpre_byte();
  _hj_j = (unsigned int )__dyc_readpre_byte();
  _hj_key = __dyc_read_ptr__char();

  _hj_i += (((unsigned int )*(_hj_key + 0) + ((unsigned int )*(_hj_key + 1) << 8)) + ((unsigned int )*(_hj_key + 2) << 16)) + ((unsigned int )*(_hj_key + 3) << 24);
  _hj_j += (((unsigned int )*(_hj_key + 4) + ((unsigned int )*(_hj_key + 5) << 8)) + ((unsigned int )*(_hj_key + 6) << 16)) + ((unsigned int )*(_hj_key + 7) << 24);
  _hf_hashv += (((unsigned int )*(_hj_key + 8) + ((unsigned int )*(_hj_key + 9) << 8)) + ((unsigned int )*(_hj_key + 10) << 16)) + ((unsigned int )*(_hj_key + 11) << 24);
  while (1) {
    while_11_continue:  ;
    _hj_i -= _hj_j;
    _hj_i -= _hf_hashv;
    _hj_i ^= _hf_hashv >> 13;
    _hj_j -= _hf_hashv;
    _hj_j -= _hj_i;
    _hj_j ^= _hj_i << 8;
    _hf_hashv -= _hj_i;
    _hf_hashv -= _hj_j;
    _hf_hashv ^= _hj_j >> 13;
    _hj_i -= _hj_j;
    _hj_i -= _hf_hashv;
    _hj_i ^= _hf_hashv >> 12;
    _hj_j -= _hf_hashv;
    _hj_j -= _hj_i;
    _hj_j ^= _hj_i << 16;
    _hf_hashv -= _hj_i;
    _hf_hashv -= _hj_j;
    _hf_hashv ^= _hj_j >> 5;
    _hj_i -= _hj_j;
    _hj_i -= _hf_hashv;
    _hj_i ^= _hf_hashv >> 3;
    _hj_j -= _hf_hashv;
    _hj_j -= _hj_i;
    _hj_j ^= _hj_i << 10;
    _hf_hashv -= _hj_i;
    _hf_hashv -= _hj_j;
    _hf_hashv ^= _hj_j >> 15;
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(_hf_hashv);
}
}
