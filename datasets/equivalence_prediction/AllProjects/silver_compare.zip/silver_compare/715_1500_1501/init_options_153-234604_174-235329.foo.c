#include "../include/dycfoo.h"
#include "../include/options.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  char *term ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___9 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  char *__dyc_funcallvar_7 ;
  char *__dyc_funcallvar_8 ;

  {
  term = __dyc_read_ptr__char();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_read_ptr__char();
  __dyc_funcallvar_8 = __dyc_read_ptr__char();
  memset(& opts, 0, sizeof(cli_options ));
  __s1_len = 0;
  __s2_len = 0;
  tmp___9 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  if (term) {
    if (0) {
      {
      tmp___15 = __dyc_funcallvar_2;
      __s1_len = (unsigned long )tmp___15;
      tmp___16 = __dyc_funcallvar_3;
      __s2_len = (unsigned long )tmp___16;
      }
      if (! ((unsigned long )((void const   *)(term + 1)) - (unsigned long )((void const   *)term) == 1UL)) {
        goto _L___0;
      } else {
        if (__s1_len >= 4UL) {
          _L___0:  
          if (! ((unsigned long )((void const   *)("dumb" + 1)) - (unsigned long )((void const   *)"dumb") == 1UL)) {
            tmp___17 = 1;
          } else {
            if (__s2_len >= 4UL) {
              tmp___17 = 1;
            } else {
              tmp___17 = 0;
            }
          }
        } else {
          tmp___17 = 0;
        }
      }
      if (tmp___17) {
        {
        tmp___9 = __dyc_funcallvar_4;
        }
      } else {
        {
        tmp___14 = __dyc_funcallvar_5;
        tmp___9 = tmp___14;
        }
      }
    } else {
      {
      tmp___14 = __dyc_funcallvar_6;
      tmp___9 = tmp___14;
      }
    }
    if (! tmp___9) {
      opts.color = 0;
    }
  }
  opts.color_win_ansi = 0;
  opts.max_matches_per_file = 0UL;
  opts.max_search_depth = 25;
  opts.mmap = 1;
  opts.multiline = 1;
  opts.width = 0UL;
  opts.path_sep = (char )'\n';
  opts.print_break = 1;
  opts.print_path = 0;
  opts.print_all_paths = 0;
  opts.print_line_numbers = 1;
  opts.recurse_dirs = 1;
  opts.color_path = __dyc_funcallvar_7;
  opts.color_match = __dyc_funcallvar_8;
  __dyc_dummy_label:  ;
  __dyc_print_comp_105__anonstruct_cli_options_70(opts);
  __dyc_printpre_byte(__s1_len);
  __dyc_printpre_byte(__s2_len);
}
}
