#include "../include/dycfoo.h"
#include "../include/decompress.i.hd.c.h"
void __dyc_foo(void) 
{ lzma_stream stream ;

  {

  memset(& stream, 0, sizeof(lzma_stream ));
  stream.reserved_ptr1 = (void *)0;
  stream.reserved_ptr2 = (void *)0;
  stream.reserved_ptr3 = (void *)0;
  stream.reserved_ptr4 = (void *)0;
  stream.reserved_int1 = (uint64_t )0;
  stream.reserved_int2 = (uint64_t )0;
  stream.reserved_int3 = (size_t )0;
  stream.reserved_int4 = (size_t )0;
  stream.reserved_enum1 = 0;
  stream.reserved_enum2 = 0;
  __dyc_dummy_label:  ;
  __dyc_print_comp_72__anonstruct_lzma_stream_49(stream);
}
}
