#include "../include/dycfoo.h"
#include "../include/options.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;

  {

  memset(& opts, 0, sizeof(cli_options ));
  opts.color_win_ansi = 0;
  opts.max_matches_per_file = 0UL;
  opts.max_search_depth = 25;
  opts.mmap = 1;
  opts.multiline = 1;
  opts.width = 0UL;
  opts.path_sep = (char )'\n';
  opts.print_break = 1;
  opts.print_path = 0;
  opts.print_all_paths = 0;
  opts.print_line_numbers = 1;
  opts.recurse_dirs = 1;
  __dyc_dummy_label:  ;
  __dyc_print_comp_105__anonstruct_cli_options_70(opts);
}
}
