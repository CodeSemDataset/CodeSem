#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  char *buf ;
  void *tmp___6 ;
  int *tmp___7 ;
  char *tmp___8 ;
  void *tmp___9 ;
  ssize_t bytes_read ;
  size_t tmp___10 ;
  ssize_t __attribute__((__artificial__))  tmp___11 ;
  int tmp___12 ;
  int *__dyc_funcallvar_10 ;
  char *__dyc_funcallvar_11 ;
  void *__dyc_funcallvar_12 ;
  size_t __dyc_funcallvar_13 ;
  ssize_t __attribute__((__warn_unused_result__,
  __artificial__))  __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  tmp___6 = __dyc_read_ptr__void();
  __dyc_funcallvar_10 = __dyc_read_ptr__int();
  __dyc_funcallvar_11 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_12 = __dyc_read_ptr__void();
  __dyc_funcallvar_13 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_14 = (ssize_t __attribute__((__warn_unused_result__,
  __artificial__))  )__dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  buf = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  bytes_read = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  buf = (char *)tmp___6;
  if ((unsigned long )buf == (unsigned long )((void *)-1)) {
    {
    tmp___7 = __dyc_funcallvar_10;
    tmp___8 = __dyc_funcallvar_11;

    }
    goto __dyc_dummy_label;
  }

  tmp___9 = __dyc_funcallvar_12;
  buf = (char *)tmp___9;
  bytes_read = (ssize_t )0;
  if (! opts.search_binary_files) {
    {
    tmp___10 = __dyc_funcallvar_13;
    tmp___11 = __dyc_funcallvar_14;
    bytes_read += (ssize_t )tmp___11;
    tmp___12 = __dyc_funcallvar_15;
    }
    if (tmp___12) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(buf);
  __dyc_print_ptr__int(tmp___7);
  __dyc_print_ptr__char(tmp___8);
  __dyc_printpre_byte(bytes_read);
  __dyc_printpre_byte(tmp___10);
}
}
