#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ size_t h ;
  char const   *R ;
  size_t i ;
  int tmp___3 ;
  int __res___0 ;
  int __attribute__((__leaf__))  tmp___6 ;
  __int32_t const   **tmp___7 ;
  char const   *find ;
  size_t f_len ;
  int case_sensitive ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  __int32_t const   **__dyc_funcallvar_2 ;

  {
  h = (size_t )__dyc_readpre_byte();
  R = (char const   *)__dyc_read_ptr__char();
  i = (size_t )__dyc_readpre_byte();
  find = (char const   *)__dyc_read_ptr__char();
  f_len = (size_t )__dyc_readpre_byte();
  case_sensitive = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  tmp___3 = 0;
  __res___0 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  while (1) {
    while_15_continue:  ;
    if (! (i < f_len)) {
      goto while_15_break;
    }
    if (case_sensitive) {
      tmp___3 = (int const   )*(R + i);
    } else {
      if (sizeof(char const   ) > 1UL) {
        {
        tmp___6 = __dyc_funcallvar_1;
        __res___0 = (int )tmp___6;
        }
      } else {
        {
        tmp___7 = __dyc_funcallvar_2;
        __res___0 = (int )*(*tmp___7 + (int )*(R + i));
        }
      }
      tmp___3 = (int const   )__res___0;
    }
    if (tmp___3 != (int const   )*(find + i)) {
      goto next_hash_cell;
    }
    i ++;
  }
  while_15_break:  ;
  goto __dyc_dummy_label;
  next_hash_cell: 
  h = (h + 1UL) % 65536UL;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(h);
}
}
