#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  char **patterns ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___57 ;
  int tmp___62 ;
  int tmp___65 ;
  char const   *pattern ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;

  {
  i = __dyc_readpre_byte();
  patterns = __dyc_read_ptr__ptr__char();
  __s1_len___1 = (size_t )__dyc_readpre_byte();
  __s2_len___1 = (size_t )__dyc_readpre_byte();
  pattern = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  tmp___57 = 0;
  tmp___62 = 0;
  tmp___65 = 0;
  if (! ((unsigned long )((void const   *)(pattern + 1)) - (unsigned long )((void const   *)pattern) == 1UL)) {
    goto _L___7;
  } else {
    if (__s1_len___1 >= 4UL) {
      _L___7:  
      if (! ((unsigned long )((void const   *)(*(patterns + (i - 1)) + 1)) - (unsigned long )((void const   *)*(patterns + (i - 1))) == 1UL)) {
        tmp___65 = 1;
      } else {
        if (__s2_len___1 >= 4UL) {
          tmp___65 = 1;
        } else {
          tmp___65 = 0;
        }
      }
    } else {
      tmp___65 = 0;
    }
  }
  if (tmp___65) {
    {
    tmp___57 = __dyc_funcallvar_15;
    }
  } else {
    {
    tmp___62 = __dyc_funcallvar_16;
    tmp___57 = tmp___62;
    }
  }
  tmp___62 = __dyc_funcallvar_17;
  tmp___57 = tmp___62;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___57);
}
}
