#include "../include/dycfoo.h"
#include "../include/options.i.hd.c.h"
void __dyc_foo(void) 
{ char *term ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___9 ;
  int tmp___14 ;
  int tmp___17 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;

  {
  term = __dyc_read_ptr__char();
  __s1_len = (size_t )__dyc_readpre_byte();
  __s2_len = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  tmp___9 = 0;
  tmp___14 = 0;
  tmp___17 = 0;
  if (! ((unsigned long )((void const   *)(term + 1)) - (unsigned long )((void const   *)term) == 1UL)) {
    goto _L___0;
  } else {
    if (__s1_len >= 4UL) {
      _L___0:  
      if (! ((unsigned long )((void const   *)("dumb" + 1)) - (unsigned long )((void const   *)"dumb") == 1UL)) {
        tmp___17 = 1;
      } else {
        if (__s2_len >= 4UL) {
          tmp___17 = 1;
        } else {
          tmp___17 = 0;
        }
      }
    } else {
      tmp___17 = 0;
    }
  }
  if (tmp___17) {
    {
    tmp___9 = __dyc_funcallvar_4;
    }
  } else {
    {
    tmp___14 = __dyc_funcallvar_5;
    tmp___9 = tmp___14;
    }
  }
  tmp___14 = __dyc_funcallvar_6;
  tmp___9 = tmp___14;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___9);
}
}
