#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___30 ;
  int tmp___35 ;
  int tmp___38 ;
  char const   *pattern ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;

  {
  __s1_len___0 = (size_t )__dyc_readpre_byte();
  __s2_len___0 = (size_t )__dyc_readpre_byte();
  pattern = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  tmp___30 = 0;
  tmp___35 = 0;
  tmp___38 = 0;
  if (! ((unsigned long )((void const   *)(pattern + 1)) - (unsigned long )((void const   *)pattern) == 1UL)) {
    goto _L___2;
  } else {
    if (__s1_len___0 >= 4UL) {
      _L___2:  
      if (! ((unsigned long )((void const   *)("./" + 1)) - (unsigned long )((void const   *)"./") == 1UL)) {
        tmp___38 = 1;
      } else {
        if (__s2_len___0 >= 4UL) {
          tmp___38 = 1;
        } else {
          tmp___38 = 0;
        }
      }
    } else {
      tmp___38 = 0;
    }
  }
  if (tmp___38) {
    {
    tmp___30 = __dyc_funcallvar_3;
    }
  } else {
    {
    tmp___35 = __dyc_funcallvar_4;
    tmp___30 = tmp___35;
    }
  }
  tmp___35 = __dyc_funcallvar_5;
  tmp___30 = tmp___35;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___30);
}
}
