#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  int fd ;
  off_t f_len ;
  char *buf ;
  struct stat statbuf ;
  int rv ;
  int matches_count ;
  FILE *fp ;
  int __attribute__((__artificial__))  tmp___0 ;
  int *tmp___1 ;
  char *tmp___2 ;
  int __attribute__((__leaf__))  tmp___3 ;
  ssize_t tmp___4 ;
  ssize_t tmp___5 ;
  void *tmp___6 ;
  int *tmp___7 ;
  char *tmp___8 ;
  void *tmp___9 ;
  ssize_t bytes_read ;
  size_t tmp___10 ;
  ssize_t __attribute__((__artificial__))  tmp___11 ;
  int tmp___12 ;
  ssize_t __attribute__((__artificial__))  tmp___13 ;
  ag_compression_type zip_type ;
  ag_compression_type tmp___14 ;
  ssize_t tmp___15 ;
  int __attribute__((__artificial__))  __dyc_funcallvar_2 ;
  int *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  int __attribute__((__leaf__))  __dyc_funcallvar_5 ;
  FILE *__dyc_funcallvar_6 ;
  ssize_t __dyc_funcallvar_7 ;
  ssize_t __dyc_funcallvar_8 ;
  void *__dyc_funcallvar_9 ;
  int *__dyc_funcallvar_10 ;
  char *__dyc_funcallvar_11 ;
  void *__dyc_funcallvar_12 ;
  size_t __dyc_funcallvar_13 ;
  ssize_t __attribute__((__warn_unused_result__,
  __artificial__))  __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  ssize_t __attribute__((__warn_unused_result__,
  __artificial__))  __dyc_funcallvar_16 ;
  ag_compression_type __dyc_funcallvar_17 ;
  FILE *__dyc_funcallvar_18 ;
  ssize_t __dyc_funcallvar_19 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  statbuf = __dyc_read_comp_27stat();
  __dyc_funcallvar_2 = (int __attribute__((__artificial__))  )__dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__int();
  __dyc_funcallvar_4 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_5 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_read_ptr__typdef_FILE();
  __dyc_funcallvar_7 = (ssize_t )__dyc_readpre_byte();
  __dyc_funcallvar_8 = (ssize_t )__dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_read_ptr__void();
  __dyc_funcallvar_10 = __dyc_read_ptr__int();
  __dyc_funcallvar_11 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_12 = __dyc_read_ptr__void();
  __dyc_funcallvar_13 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_14 = (ssize_t __attribute__((__warn_unused_result__,
  __artificial__))  )__dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = (ssize_t __attribute__((__warn_unused_result__,
  __artificial__))  )__dyc_readpre_byte();
  __dyc_funcallvar_17 = (ag_compression_type )__dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_read_ptr__typdef_FILE();
  __dyc_funcallvar_19 = (ssize_t )__dyc_readpre_byte();
  fd = 0;
  f_len = 0;
  buf = 0;
  rv = 0;
  matches_count = 0;
  fp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  bytes_read = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  zip_type = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  if (opts.stdout_inode != 0UL) {
    if (opts.stdout_inode == statbuf.st_ino) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  if (! ((statbuf.st_mode & 61440U) == 32768U)) {
    if (! ((statbuf.st_mode & 61440U) == 4096U)) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___0 = __dyc_funcallvar_2;
  fd = (int )tmp___0;
  if (fd < 0) {
    {
    tmp___1 = __dyc_funcallvar_3;
    tmp___2 = __dyc_funcallvar_4;

    }
    goto __dyc_dummy_label;
  }
  tmp___3 = __dyc_funcallvar_5;
  rv = (int )tmp___3;
  if (rv != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  if (opts.stdout_inode != 0UL) {
    if (opts.stdout_inode == statbuf.st_ino) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  if (! ((statbuf.st_mode & 61440U) == 32768U)) {
    if (! ((statbuf.st_mode & 61440U) == 4096U)) {
      {

      }
      goto __dyc_dummy_label;
    }
  }

  if (statbuf.st_mode & 4096U) {
    {

    fp = __dyc_funcallvar_6;
    tmp___4 = __dyc_funcallvar_7;
    matches_count = (int )tmp___4;

    }
    goto __dyc_dummy_label;
  }
  f_len = statbuf.st_size;
  if (f_len == 0L) {
    if ((int )*(opts.query + 0) == 46) {
      if (opts.query_len == 1) {
        if (! opts.literal) {
          if (opts.search_all_files) {
            {
            tmp___5 = __dyc_funcallvar_8;
            matches_count = (int )tmp___5;
            }
          } else {
            {

            }
          }
        } else {
          {

          }
        }
      } else {
        {

        }
      }
    } else {
      {

      }
    }
    goto __dyc_dummy_label;
  }
  if (! opts.literal) {
    if (f_len > 2147483647L) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  if (opts.mmap) {
    {
    tmp___6 = __dyc_funcallvar_9;
    buf = (char *)tmp___6;
    }
    if ((unsigned long )buf == (unsigned long )((void *)-1)) {
      {
      tmp___7 = __dyc_funcallvar_10;
      tmp___8 = __dyc_funcallvar_11;

      }
      goto __dyc_dummy_label;
    }
    {

    }
  } else {
    {
    tmp___9 = __dyc_funcallvar_12;
    buf = (char *)tmp___9;
    bytes_read = (ssize_t )0;
    }
    if (! opts.search_binary_files) {
      {
      tmp___10 = __dyc_funcallvar_13;
      tmp___11 = __dyc_funcallvar_14;
      bytes_read += (ssize_t )tmp___11;
      tmp___12 = __dyc_funcallvar_15;
      }
      if (tmp___12) {
        {

        }
        goto __dyc_dummy_label;
      }
    }
    {
    while (1) {
      while_5_continue:  ;
      if (! (bytes_read < f_len)) {
        goto while_5_break;
      }
      {
      tmp___13 = __dyc_funcallvar_16;
      bytes_read += (ssize_t )tmp___13;
      }
    }
    while_5_break:  ;
    }
    if (bytes_read != f_len) {
      {

      }
    }
  }
  if (opts.search_zip_files) {
    {
    tmp___14 = __dyc_funcallvar_17;
    zip_type = tmp___14;
    }
    if ((int )zip_type != 0) {
      {

      fp = __dyc_funcallvar_18;
      tmp___15 = __dyc_funcallvar_19;
      matches_count = (int )tmp___15;

      }
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(buf);
  __dyc_printpre_byte(matches_count);
  __dyc_print_ptr__typdef_FILE(fp);
  __dyc_print_ptr__int(tmp___1);
  __dyc_print_ptr__char(tmp___2);
  __dyc_print_ptr__int(tmp___7);
  __dyc_print_ptr__char(tmp___8);
  __dyc_printpre_byte(bytes_read);
  __dyc_printpre_byte(tmp___10);
}
}
