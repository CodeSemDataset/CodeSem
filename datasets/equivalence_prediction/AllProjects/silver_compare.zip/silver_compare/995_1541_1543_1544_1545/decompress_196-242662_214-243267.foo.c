#include "../include/dycfoo.h"
#include "../include/decompress.i.hd.c.h"
void __dyc_foo(void) 
{ void *tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  void *tmp___2 ;
  ag_compression_type zip_type ;
  int *new_buf_len ;
  void *__dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;
  void *__dyc_funcallvar_4 ;

  {
  zip_type = (ag_compression_type )__dyc_readpre_byte();
  new_buf_len = __dyc_read_ptr__int();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = __dyc_read_ptr__void();
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  if ((int )zip_type == 1) {
    goto switch_6_1;
  } else {
    if ((int )zip_type == 2) {
      goto switch_6_2;
    } else {
      if ((int )zip_type == 3) {
        goto switch_6_3;
      } else {
        if ((int )zip_type == 4) {
          goto switch_6_4;
        } else {
          if ((int )zip_type == 0) {
            goto switch_6_0;
          } else {
            {
            goto switch_6_default;
            if (0) {
              switch_6_1:  
              {
              tmp = __dyc_funcallvar_1;
              }
              goto __dyc_dummy_label;
              switch_6_2:  
              {
              tmp___0 = __dyc_funcallvar_2;
              }
              goto __dyc_dummy_label;
              switch_6_3:  
              {
              tmp___1 = __dyc_funcallvar_3;
              }
              goto __dyc_dummy_label;
              switch_6_4:  
              {
              tmp___2 = __dyc_funcallvar_4;
              }
              goto __dyc_dummy_label;
              switch_6_0:  
              {

              }
              goto switch_6_break;
              switch_6_default:  
              {

              }
            } else {
              switch_6_break:  ;
            }
            }
          }
        }
      }
    }
  }
  *new_buf_len = 0;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__void(tmp);
  __dyc_print_ptr__void(tmp___0);
  __dyc_print_ptr__void(tmp___1);
  __dyc_print_ptr__void(tmp___2);
}
}
