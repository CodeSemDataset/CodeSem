#include "../include/dycfoo.h"
#include "../include/decompress.i.hd.c.h"
void __dyc_foo(void) 
{ size_t pagesize ;
  z_stream stream ;
  int tmp ;
  void const   *buf ;
  int buf_len ;
  int __dyc_funcallvar_1 ;

  {
  buf = (void const   *)__dyc_read_ptr__void();
  buf_len = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  pagesize = 0;
  memset(& stream, 0, sizeof(z_stream ));
  tmp = 0;
  pagesize = (size_t )0;

  stream.zalloc = (voidpf (*)(voidpf opaque , uInt items , uInt size ))0;
  stream.zfree = (void (*)(voidpf opaque , voidpf address ))0;
  stream.opaque = (void *)0;
  stream.avail_in = 0U;
  stream.next_in = (Bytef const   *)0;
  tmp = __dyc_funcallvar_1;
  if (tmp != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  stream.avail_in = (unsigned int )buf_len;
  stream.next_in = (Bytef const   *)((Bytef *)buf);
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(pagesize);
  __dyc_print_comp_86z_stream_s(stream);
}
}
