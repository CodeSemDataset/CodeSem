#include "../include/dycfoo.h"
#include "../include/decompress.i.hd.c.h"
void __dyc_foo(void) 
{ int ret ;
  unsigned char *result ;
  size_t result_size ;
  size_t pagesize ;
  z_stream stream ;
  int tmp ;
  int tmp___0 ;
  unsigned char *tmp_result ;
  void *tmp___1 ;
  void const   *buf ;
  int buf_len ;
  int *new_buf_len ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;

  {
  buf = (void const   *)__dyc_read_ptr__void();
  buf_len = __dyc_readpre_byte();
  new_buf_len = __dyc_read_ptr__int();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  ret = 0;
  result = 0;
  result_size = 0;
  pagesize = 0;
  memset(& stream, 0, sizeof(z_stream ));
  tmp = 0;
  tmp___0 = 0;
  tmp_result = 0;
  tmp___1 = 0;
  result = (unsigned char *)((void *)0);
  result_size = (size_t )0;
  pagesize = (size_t )0;

  stream.zalloc = (voidpf (*)(voidpf opaque , uInt items , uInt size ))0;
  stream.zfree = (void (*)(voidpf opaque , voidpf address ))0;
  stream.opaque = (void *)0;
  stream.avail_in = 0U;
  stream.next_in = (Bytef const   *)0;
  tmp = __dyc_funcallvar_1;
  if (tmp != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  stream.avail_in = (unsigned int )buf_len;
  stream.next_in = (Bytef const   *)((Bytef *)buf);
  tmp___0 = __dyc_funcallvar_2;
  pagesize = (unsigned long )tmp___0;
  result_size = (((size_t )buf_len + pagesize) - 1UL) & ~ (pagesize - 1UL);
  while (1) {
    while_0_continue:  ;
    {
    while (1) {
      while_1_continue:  ;
      {
      tmp_result = result;
      result_size *= 2UL;
      tmp___1 = __dyc_funcallvar_3;
      result = (unsigned char *)tmp___1;
      }
      if ((unsigned long )result == (unsigned long )((void *)0)) {
        {



        }
        goto __dyc_dummy_label;
      }
      {
      stream.avail_out = (unsigned int )(result_size / 2UL);
      stream.next_out = result + stream.total_out;
      ret = __dyc_funcallvar_4;

      }
      if (ret == -2) {
        goto switch_2_neg_2;
      } else {
        if (ret == 2) {
          goto switch_2_2;
        } else {
          if (ret == -3) {
            goto switch_2_2;
          } else {
            if (ret == -4) {
              goto switch_2_2;
            } else {
              if (0) {
                switch_2_neg_2:  
                {


                }
                goto __dyc_dummy_label;
                switch_2_2:  
                switch_2_neg_3:  
                switch_2_neg_4:  
                {


                }
                goto __dyc_dummy_label;
              } else {
                switch_2_break:  ;
              }
            }
          }
        }
      }
      if (! (stream.avail_out == 0U)) {
        goto while_1_break;
      }
    }
    while_1_break:  ;
    }
    if (! (ret == 0)) {
      goto while_0_break;
    }
  }
  while_0_break:  ;
  *new_buf_len = (int )stream.total_out;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(result);
  __dyc_printpre_byte(result_size);
  __dyc_printpre_byte(pagesize);
  __dyc_print_comp_86z_stream_s(stream);
  __dyc_print_ptr__char(tmp_result);
}
}
