#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *new_item ;
  unsigned int _hj_i___0 ;
  unsigned int _hj_j___0 ;
  unsigned int _hj_k___0 ;
  unsigned char *_hj_key___0 ;

  {
  new_item = __dyc_read_ptr__typdef_symdir_t();
  _hj_i___0 = 0;
  _hj_j___0 = 0;
  _hj_k___0 = 0;
  _hj_key___0 = 0;
  _hj_key___0 = (unsigned char *)(& new_item->key);
  new_item->hh.hashv = 4276993775U;
  _hj_j___0 = 2654435769U;
  _hj_i___0 = _hj_j___0;
  _hj_k___0 = (unsigned int )sizeof(dirkey_t );
  while (1) {
    while_21_continue:  ;
    if (! (_hj_k___0 >= 12U)) {
      goto while_21_break;
    }
    _hj_i___0 += (((unsigned int )*(_hj_key___0 + 0) + ((unsigned int )*(_hj_key___0 + 1) << 8)) + ((unsigned int )*(_hj_key___0 + 2) << 16)) + ((unsigned int )*(_hj_key___0 + 3) << 24);
    _hj_j___0 += (((unsigned int )*(_hj_key___0 + 4) + ((unsigned int )*(_hj_key___0 + 5) << 8)) + ((unsigned int )*(_hj_key___0 + 6) << 16)) + ((unsigned int )*(_hj_key___0 + 7) << 24);
    new_item->hh.hashv += (((unsigned int )*(_hj_key___0 + 8) + ((unsigned int )*(_hj_key___0 + 9) << 8)) + ((unsigned int )*(_hj_key___0 + 10) << 16)) + ((unsigned int )*(_hj_key___0 + 11) << 24);
    {
    while (1) {
      while_22_continue:  ;
      _hj_i___0 -= _hj_j___0;
      _hj_i___0 -= new_item->hh.hashv;
      _hj_i___0 ^= new_item->hh.hashv >> 13;
      _hj_j___0 -= new_item->hh.hashv;
      _hj_j___0 -= _hj_i___0;
      _hj_j___0 ^= _hj_i___0 << 8;
      new_item->hh.hashv -= _hj_i___0;
      new_item->hh.hashv -= _hj_j___0;
      new_item->hh.hashv ^= _hj_j___0 >> 13;
      _hj_i___0 -= _hj_j___0;
      _hj_i___0 -= new_item->hh.hashv;
      _hj_i___0 ^= new_item->hh.hashv >> 12;
      _hj_j___0 -= new_item->hh.hashv;
      _hj_j___0 -= _hj_i___0;
      _hj_j___0 ^= _hj_i___0 << 16;
      new_item->hh.hashv -= _hj_i___0;
      new_item->hh.hashv -= _hj_j___0;
      new_item->hh.hashv ^= _hj_j___0 >> 5;
      _hj_i___0 -= _hj_j___0;
      _hj_i___0 -= new_item->hh.hashv;
      _hj_i___0 ^= new_item->hh.hashv >> 3;
      _hj_j___0 -= new_item->hh.hashv;
      _hj_j___0 -= _hj_i___0;
      _hj_j___0 ^= _hj_i___0 << 10;
      new_item->hh.hashv -= _hj_i___0;
      new_item->hh.hashv -= _hj_j___0;
      new_item->hh.hashv ^= _hj_j___0 >> 15;
      goto while_22_break;
    }
    while_22_break:  ;
    }
    _hj_key___0 += 12;
    _hj_k___0 -= 12U;
  }
  while_21_break:  ;
  new_item->hh.hashv = (unsigned int )((unsigned long )new_item->hh.hashv + sizeof(dirkey_t ));
  if ((int )_hj_k___0 == 11) {
    goto switch_23_11;
  } else {
    if ((int )_hj_k___0 == 10) {
      goto switch_23_10;
    } else {
      if ((int )_hj_k___0 == 9) {
        goto switch_23_9;
      } else {
        if ((int )_hj_k___0 == 8) {
          goto switch_23_8;
        } else {
          if ((int )_hj_k___0 == 7) {
            goto switch_23_7;
          } else {
            if ((int )_hj_k___0 == 6) {
              goto switch_23_6;
            } else {
              if ((int )_hj_k___0 == 5) {
                goto switch_23_5;
              } else {
                if ((int )_hj_k___0 == 4) {
                  goto switch_23_4;
                } else {
                  if ((int )_hj_k___0 == 3) {
                    goto switch_23_3;
                  } else {
                    if ((int )_hj_k___0 == 2) {
                      goto switch_23_2;
                    } else {
                      if ((int )_hj_k___0 == 1) {
                        goto switch_23_1;
                      } else {
                        if (0) {
                          switch_23_11:  
                          new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 10) << 24;
                          switch_23_10:  
                          new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 9) << 16;
                          switch_23_9:  
                          new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 8) << 8;
                          switch_23_8:  
                          _hj_j___0 += (unsigned int )*(_hj_key___0 + 7) << 24;
                          switch_23_7:  
                          _hj_j___0 += (unsigned int )*(_hj_key___0 + 6) << 16;
                          switch_23_6:  
                          _hj_j___0 += (unsigned int )*(_hj_key___0 + 5) << 8;
                          switch_23_5:  
                          _hj_j___0 += (unsigned int )*(_hj_key___0 + 4);
                          switch_23_4:  
                          _hj_i___0 += (unsigned int )*(_hj_key___0 + 3) << 24;
                          switch_23_3:  
                          _hj_i___0 += (unsigned int )*(_hj_key___0 + 2) << 16;
                          switch_23_2:  
                          _hj_i___0 += (unsigned int )*(_hj_key___0 + 1) << 8;
                          switch_23_1:  
                          _hj_i___0 += (unsigned int )*(_hj_key___0 + 0);
                        } else {
                          switch_23_break:  ;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(_hj_i___0);
  __dyc_printpre_byte(_hj_j___0);
  __dyc_print_ptr__char(_hj_key___0);
}
}
