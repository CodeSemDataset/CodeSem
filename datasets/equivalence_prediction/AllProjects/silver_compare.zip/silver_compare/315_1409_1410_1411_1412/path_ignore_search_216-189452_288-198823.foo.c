#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ char *temp ;
  int temp_start_pos ;
  size_t i ;
  int match_pos ;
  char const   *tmp ;
  char *slash_filename ;
  char *pos ;
  char *tmp___0 ;
  size_t tmp___1 ;
  int tmp___2 ;
  int tmp___24 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___34 ;
  int tmp___39 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  int tmp___45 ;
  int tmp___46 ;
  int rv ;
  int tmp___47 ;
  ignores const   *ig ;
  char const   *path ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  char *__dyc_funcallvar_10 ;
  size_t __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;

  {
  temp = __dyc_read_ptr__char();
  match_pos = __dyc_readpre_byte();
  ig = (ignores const   *)__dyc_read_ptr__typdef_ignores();
  path = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  temp_start_pos = 0;
  i = 0;
  tmp = 0;
  slash_filename = 0;
  pos = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___24 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___34 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  tmp___42 = 0;
  tmp___45 = 0;
  tmp___46 = 0;
  rv = 0;
  tmp___47 = 0;
  if (match_pos >= 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  if ((int const   )*(path + 0) == 46) {
    tmp = path + 1;
  } else {
    tmp = path;
  }

  if ((int )*(temp + 0) == 47) {
    temp_start_pos = 1;
  } else {
    temp_start_pos = 0;
  }
  if (0) {
    if (0) {
      {
      tmp___40 = __dyc_funcallvar_2;
      __s1_len___0 = (unsigned long )tmp___40;
      tmp___41 = __dyc_funcallvar_3;
      __s2_len___0 = (unsigned long )tmp___41;
      }
      if (! ((unsigned long )((void const   *)((temp + temp_start_pos) + 1)) - (unsigned long )((void const   *)(temp + temp_start_pos)) == 1UL)) {
        goto _L___3;
      } else {
        if (__s1_len___0 >= 4UL) {
          _L___3:  
          if (! ((unsigned long )((void const   *)(ig->abs_path + 1)) - (unsigned long )((void const   *)ig->abs_path) == 1UL)) {
            tmp___42 = 1;
          } else {
            if (__s2_len___0 >= 4UL) {
              tmp___42 = 1;
            } else {
              tmp___42 = 0;
            }
          }
        } else {
          tmp___42 = 0;
        }
      }
      if (tmp___42) {
        {
        tmp___34 = __dyc_funcallvar_4;
        }
      } else {
        {
        tmp___39 = __dyc_funcallvar_5;
        tmp___34 = tmp___39;
        }
      }
    } else {
      {
      tmp___39 = __dyc_funcallvar_6;
      tmp___34 = tmp___39;
      }
    }
    tmp___24 = tmp___34;
  } else {
    {
    tmp___24 = __dyc_funcallvar_7;
    }
  }
  if (tmp___24 == 0) {
    slash_filename = (temp + temp_start_pos) + ig->abs_path_len;
    if ((int )*(slash_filename + 0) == 47) {
      slash_filename ++;
    }
    {
    match_pos = __dyc_funcallvar_8;
    }
    if (match_pos >= 0) {
      {


      }
      goto __dyc_dummy_label;
    }
    {
    match_pos = __dyc_funcallvar_9;
    }
    if (match_pos >= 0) {
      {


      }
      goto __dyc_dummy_label;
    }
    i = 0UL;
    {
    while (1) {
      while_3_continue:  ;
      if (! (i < (size_t )ig->names_len)) {
        goto while_3_break;
      }
      {
      tmp___0 = __dyc_funcallvar_10;
      pos = tmp___0;
      }
      if ((unsigned long )pos == (unsigned long )slash_filename) {
        goto _L;
      } else {
        if (pos) {
          if ((int )*(pos - 1) == 47) {
            _L:  
            {
            tmp___1 = __dyc_funcallvar_11;
            pos += tmp___1;
            }
            if ((int )*pos == 0) {
              {


              }
              goto __dyc_dummy_label;
            } else {
              if ((int )*pos == 47) {
                {


                }
                goto __dyc_dummy_label;
              }
            }
          }
        }
      }
      {

      i ++;
      }
    }
    while_3_break:  ;
    }
    i = 0UL;
    {
    while (1) {
      while_4_continue:  ;
      if (! (i < (size_t )ig->slash_regexes_len)) {
        goto while_4_break;
      }
      {
      tmp___2 = __dyc_funcallvar_12;
      }
      if (tmp___2 == 0) {
        {


        }
        goto __dyc_dummy_label;
      }
      {

      i ++;
      }
    }
    while_4_break:  ;
    }
  }
  i = 0UL;
  while (1) {
    while_5_continue:  ;
    if (! (i < (size_t )ig->invert_regexes_len)) {
      goto while_5_break;
    }
    {
    tmp___45 = __dyc_funcallvar_13;
    }
    if (tmp___45 == 0) {
      {


      }
      goto __dyc_dummy_label;
    }
    {

    i ++;
    }
  }
  while_5_break:  ;
  i = 0UL;
  while (1) {
    while_6_continue:  ;
    if (! (i < (size_t )ig->regexes_len)) {
      goto while_6_break;
    }
    {
    tmp___46 = __dyc_funcallvar_14;
    }
    if (tmp___46 == 0) {
      {


      }
      goto __dyc_dummy_label;
    }
    {

    i ++;
    }
  }
  while_6_break:  ;
  tmp___47 = __dyc_funcallvar_15;
  rv = tmp___47;

  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(temp_start_pos);
  __dyc_print_ptr__char(tmp);
  __dyc_print_ptr__char(slash_filename);
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
  __dyc_printpre_byte(rv);
}
}
