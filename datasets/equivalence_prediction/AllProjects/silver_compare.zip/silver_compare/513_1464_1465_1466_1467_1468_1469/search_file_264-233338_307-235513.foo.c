#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  int fd ;
  char *buf ;
  struct stat statbuf ;
  int rv ;
  int matches_count ;
  FILE *fp ;
  int __attribute__((__leaf__))  tmp ;
  int __attribute__((__artificial__))  tmp___0 ;
  int *tmp___1 ;
  char *tmp___2 ;
  int __attribute__((__leaf__))  tmp___3 ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  int __attribute__((__artificial__))  __dyc_funcallvar_2 ;
  int *__dyc_funcallvar_3 ;
  char *__dyc_funcallvar_4 ;
  int __attribute__((__leaf__))  __dyc_funcallvar_5 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  statbuf = __dyc_read_comp_27stat();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (int __attribute__((__artificial__))  )__dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__int();
  __dyc_funcallvar_4 = (char *)__dyc_read_ptr__char();
  __dyc_funcallvar_5 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  fd = 0;
  buf = 0;
  rv = 0;
  matches_count = 0;
  fp = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  buf = (char *)((void *)0);
  rv = 0;
  matches_count = -1;
  fp = (FILE *)((void *)0);
  tmp = __dyc_funcallvar_1;
  rv = (int )tmp;
  if (rv != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  if (opts.stdout_inode != 0UL) {
    if (opts.stdout_inode == statbuf.st_ino) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  if (! ((statbuf.st_mode & 61440U) == 32768U)) {
    if (! ((statbuf.st_mode & 61440U) == 4096U)) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  tmp___0 = __dyc_funcallvar_2;
  fd = (int )tmp___0;
  if (fd < 0) {
    {
    tmp___1 = __dyc_funcallvar_3;
    tmp___2 = __dyc_funcallvar_4;

    }
    goto __dyc_dummy_label;
  }
  tmp___3 = __dyc_funcallvar_5;
  rv = (int )tmp___3;
  if (rv != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  if (opts.stdout_inode != 0UL) {
    if (opts.stdout_inode == statbuf.st_ino) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  if (! ((statbuf.st_mode & 61440U) == 32768U)) {
    if (! ((statbuf.st_mode & 61440U) == 4096U)) {
      {

      }
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(buf);
  __dyc_printpre_byte(matches_count);
  __dyc_print_ptr__typdef_FILE(fp);
  __dyc_print_ptr__int(tmp___1);
  __dyc_print_ptr__char(tmp___2);
}
}
