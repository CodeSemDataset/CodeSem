#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  int binary ;
  size_t buf_offset ;
  size_t matches_len ;
  match_t *matches ;
  size_t matches_size ;
  size_t matches_spare ;
  void *tmp ;
  int __dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  binary = 0;
  buf_offset = 0;
  matches_len = 0;
  matches = 0;
  matches_size = 0;
  matches_spare = 0;
  tmp = 0;
  binary = -1;
  buf_offset = (size_t )0;
  if (opts.search_stream) {
    binary = 0;
  } else {
    if (! opts.search_binary_files) {
      if (opts.mmap) {
        {
        binary = __dyc_funcallvar_1;
        }
        if (binary) {
          {

          }
          goto __dyc_dummy_label;
        }
      }
    }
  }
  matches_len = (size_t )0;
  if (opts.invert_match) {
    {
    matches_size = 100UL;
    tmp = __dyc_funcallvar_2;
    matches = (match_t *)tmp;
    matches_spare = 1UL;
    }
  } else {
    matches_size = 0UL;
    matches = (match_t *)((void *)0);
    matches_spare = 0UL;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(binary);
  __dyc_printpre_byte(buf_offset);
  __dyc_printpre_byte(matches_len);
  __dyc_print_ptr__typdef_match_t(matches);
  __dyc_printpre_byte(matches_size);
  __dyc_printpre_byte(matches_spare);
}
}
