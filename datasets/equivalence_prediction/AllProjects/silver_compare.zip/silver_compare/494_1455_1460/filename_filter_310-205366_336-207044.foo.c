#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  int tmp___18 ;
  scandir_baton_t *scandir_baton ;
  char const   *path_start ;
  char const   *extension ;
  char *tmp___20 ;
  size_t filename_len ;
  void *baton ;
  char *__dyc_funcallvar_8 ;

  {
  opts = __dyc_read_comp_72__anonstruct_cli_options_41();
  tmp___18 = __dyc_readpre_byte();
  baton = __dyc_read_ptr__void();
  __dyc_funcallvar_8 = __dyc_read_ptr__char();
  scandir_baton = 0;
  path_start = 0;
  extension = 0;
  tmp___20 = 0;
  filename_len = 0;
  if (tmp___18) {
    {

    }
    goto __dyc_dummy_label;
  }
  if (opts.search_all_files) {
    if (! opts.path_to_ignore) {
      goto __dyc_dummy_label;
    }
  }
  scandir_baton = (scandir_baton_t *)baton;
  path_start = scandir_baton->path_start;
  tmp___20 = __dyc_funcallvar_8;
  extension = (char const   *)tmp___20;
  if (extension) {
    if (*(extension + 1)) {
      extension ++;
    } else {
      extension = (char const   *)((void *)0);
    }
  }
  filename_len = (size_t )0;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(path_start);
  __dyc_print_ptr__char(extension);
  __dyc_printpre_byte(filename_len);
}
}
