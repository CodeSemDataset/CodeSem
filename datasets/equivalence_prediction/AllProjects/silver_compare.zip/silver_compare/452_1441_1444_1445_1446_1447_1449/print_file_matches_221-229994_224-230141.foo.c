#include "../include/dycfoo.h"
#include "../include/print.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  struct print_context print_context ;
  size_t cur_match ;
  size_t i ;
  size_t j ;
  size_t start ;
  int printed_match ;
  size_t buf_len ;
  match_t const   *matches ;
  size_t matches_len ;

  {
  opts = __dyc_read_comp_72__anonstruct_cli_options_40();
  print_context = __dyc_read_comp_89print_context();
  cur_match = (size_t )__dyc_readpre_byte();
  i = (size_t )__dyc_readpre_byte();
  buf_len = (size_t )__dyc_readpre_byte();
  matches = (match_t const   *)__dyc_read_ptr__typdef_match_t();
  matches_len = (size_t )__dyc_readpre_byte();
  j = 0;
  start = 0;
  printed_match = 0;
  if (opts.print_path == 3) {
    if (! opts.search_stream) {
      {

      }
    }
  }
  if (opts.ackmate) {
    {

    }
    {
    while (1) {
      while_3_continue:  ;
      if (! (print_context.last_printed_match < cur_match)) {
        goto while_3_break;
      }
      {
      start = (size_t )((matches + print_context.last_printed_match)->start - (size_t const   )print_context.line_preceding_current_match_offset);

      }
      if (print_context.last_printed_match == cur_match - 1UL) {
        {

        }
      } else {
        {

        }
      }
      (print_context.last_printed_match) ++;
    }
    while_3_break:  ;
    }
    {

    }
  } else {
    if (opts.vimgrep) {
      {
      while (1) {
        while_4_continue:  ;
        if (! (print_context.last_printed_match < cur_match)) {
          goto while_4_break;
        }
        {




        (print_context.last_printed_match) ++;
        }
      }
      while_4_break:  ;
      }
    } else {
      {

      printed_match = 0;
      }
      if (opts.column) {
        {

        }
      }
      if (print_context.printing_a_match) {
        if (opts.color) {
          {

          }
        }
      }
      j = print_context.prev_line_offset;
      {
      while (1) {
        while_5_continue:  ;
        if (! (j <= i)) {
          goto while_5_break;
        }
        if (print_context.last_printed_match < matches_len) {
          if (j == (size_t )(matches + print_context.last_printed_match)->end) {
            if (opts.color) {
              {

              }
            }
            print_context.printing_a_match = 0;
            (print_context.last_printed_match) ++;
            printed_match = 1;
            if (opts.only_matching) {
              {

              }
            }
          }
        }
        if (j < buf_len) {
          if (opts.width > 0UL) {
            if (j - print_context.prev_line_offset >= opts.width) {
              if (j < i) {
                {

                }
              }
              {

              j = i;
              print_context.last_printed_match = matches_len;
              }
            }
          }
        }
        if (print_context.last_printed_match < matches_len) {
          if (j == (size_t )(matches + print_context.last_printed_match)->start) {
            if (opts.only_matching) {
              if (printed_match) {
                if (opts.print_path == 3) {
                  {

                  }
                }
                {

                }
                if (opts.column) {
                  {

                  }
                }
              }
            }
            if (opts.color) {
              {

              }
            }
            print_context.printing_a_match = 1;
          }
        }
        if (j < buf_len) {
          if (! opts.only_matching) {
            goto _L___0;
          } else {
            if (print_context.printing_a_match) {
              _L___0:  
              if (opts.width == 0UL) {
                {

                }
              } else {
                if (j - print_context.prev_line_offset < opts.width) {
                  {

                  }
                }
              }
            }
          }
        }
        j ++;
      }
      while_5_break:  ;
      }
      if (print_context.printing_a_match) {
        if (opts.color) {
          {

          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(start);
  __dyc_printpre_byte(printed_match);
}
}
