#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  char ***patterns_p ;
  size_t *patterns_len ;
  char **patterns ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___57 ;
  int tmp___62 ;
  int tmp___63 ;
  int tmp___64 ;
  int tmp___65 ;
  char const   *pattern ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;

  {
  patterns_p = __dyc_read_ptr__ptr__ptr__char();
  patterns_len = __dyc_read_ptr__typdef_size_t();
  patterns = __dyc_read_ptr__ptr__char();
  pattern = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  i = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___57 = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  *patterns_p = patterns;
  i = (int )(*patterns_len - 1UL);
  while (1) {
    while_1_continue:  ;
    if (! (i > 0)) {
      goto __dyc_dummy_label;
    }
    if (0) {
      {
      tmp___63 = __dyc_funcallvar_13;
      __s1_len___1 = (unsigned long )tmp___63;
      tmp___64 = __dyc_funcallvar_14;
      __s2_len___1 = (unsigned long )tmp___64;
      }
      if (! ((unsigned long )((void const   *)(pattern + 1)) - (unsigned long )((void const   *)pattern) == 1UL)) {
        goto _L___7;
      } else {
        if (__s1_len___1 >= 4UL) {
          _L___7:  
          if (! ((unsigned long )((void const   *)(*(patterns + (i - 1)) + 1)) - (unsigned long )((void const   *)*(patterns + (i - 1))) == 1UL)) {
            tmp___65 = 1;
          } else {
            if (__s2_len___1 >= 4UL) {
              tmp___65 = 1;
            } else {
              tmp___65 = 0;
            }
          }
        } else {
          tmp___65 = 0;
        }
      }
      if (tmp___65) {
        {
        tmp___57 = __dyc_funcallvar_15;
        }
      } else {
        {
        tmp___62 = __dyc_funcallvar_16;
        tmp___57 = tmp___62;
        }
      }
    } else {
      {
      tmp___62 = __dyc_funcallvar_17;
      tmp___57 = tmp___62;
      }
    }
    if (tmp___57 > 0) {
      goto __dyc_dummy_label;
    }
    *(patterns + i) = *(patterns + (i - 1));
    i --;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
}
}
