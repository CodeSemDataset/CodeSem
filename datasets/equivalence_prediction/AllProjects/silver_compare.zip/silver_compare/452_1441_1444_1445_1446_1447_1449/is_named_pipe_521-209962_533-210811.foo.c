#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ int tmp ;
  struct stat s ;
  int __attribute__((__leaf__))  tmp___0 ;
  int tmp___1 ;
  struct dirent  const  *d ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;

  {
  s = __dyc_read_comp_41stat();
  d = (struct dirent  const  *)__dyc_read_ptr__comp_43dirent();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  if ((int const   )d->d_type != 0) {
    if ((int const   )d->d_type != 10) {
      if ((int const   )d->d_type == 1) {
        tmp = 1;
      } else {
        if ((int const   )d->d_type == 12) {
          tmp = 1;
        } else {
          tmp = 0;
        }
      }
      goto __dyc_dummy_label;
    }
  }

  tmp___0 = __dyc_funcallvar_1;
  if (tmp___0 != (int __attribute__((__leaf__))  )0) {
    {

    }
    goto __dyc_dummy_label;
  }

  if ((s.st_mode & 61440U) == 4096U) {
    tmp___1 = 1;
  } else {
    if ((s.st_mode & 61440U) == 49152U) {
      tmp___1 = 1;
    } else {
      tmp___1 = 0;
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp);
  __dyc_printpre_byte(tmp___1);
}
}
