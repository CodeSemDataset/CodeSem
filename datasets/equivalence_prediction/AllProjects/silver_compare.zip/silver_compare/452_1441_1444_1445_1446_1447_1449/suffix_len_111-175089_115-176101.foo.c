#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ size_t i ;
  int __res ;
  int __attribute__((__leaf__))  tmp___1 ;
  __int32_t const   **tmp___2 ;
  int __res___0 ;
  int __attribute__((__leaf__))  tmp___5 ;
  __int32_t const   **tmp___6 ;
  char const   *s ;
  size_t s_len ;
  size_t pos ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  __int32_t const   **__dyc_funcallvar_2 ;
  int __attribute__((__leaf__))  __dyc_funcallvar_3 ;
  __int32_t const   **__dyc_funcallvar_4 ;

  {
  i = (size_t )__dyc_readpre_byte();
  s = (char const   *)__dyc_read_ptr__char();
  s_len = (size_t )__dyc_readpre_byte();
  pos = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_3 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __res = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  __res___0 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  if ((int const   )*(s + (pos - i)) != (int const   )*(s + ((s_len - i) - 1UL))) {
    goto __dyc_dummy_label;
  }
  if (sizeof(char const   ) > 1UL) {
    {
    tmp___1 = __dyc_funcallvar_1;
    __res = (int )tmp___1;
    }
  } else {
    {
    tmp___2 = __dyc_funcallvar_2;
    __res = (int )*(*tmp___2 + (int )*(s + (pos - i)));
    }
  }
  if (sizeof(char const   ) > 1UL) {
    {
    tmp___5 = __dyc_funcallvar_3;
    __res___0 = (int )tmp___5;
    }
  } else {
    {
    tmp___6 = __dyc_funcallvar_4;
    __res___0 = (int )*(*tmp___6 + (int )*(s + ((s_len - i) - 1UL)));
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__res);
  __dyc_printpre_byte(__res___0);
}
}
