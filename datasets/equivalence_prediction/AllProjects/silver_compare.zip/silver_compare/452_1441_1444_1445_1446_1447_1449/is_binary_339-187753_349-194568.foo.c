#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned char const   *buf_c ;
  int tmp___21 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___31 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  void const   *buf ;
  size_t buf_len ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;
  int __dyc_funcallvar_6 ;

  {
  buf_c = (unsigned char const   *)__dyc_read_ptr__char();
  buf = (void const   *)__dyc_read_ptr__void();
  buf_len = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  tmp___21 = 0;
  __s1_len___0 = 0;
  __s2_len___0 = 0;
  tmp___31 = 0;
  tmp___36 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  if (buf_len == 0UL) {
    goto __dyc_dummy_label;
  }
  if (buf_len >= 3UL) {
    if ((int const   )*(buf_c + 0) == 239) {
      if ((int const   )*(buf_c + 1) == 187) {
        if ((int const   )*(buf_c + 2) == 191) {
          goto __dyc_dummy_label;
        }
      }
    }
  }
  if (buf_len >= 5UL) {
    if (0) {
      if (0) {
        {
        tmp___37 = __dyc_funcallvar_1;
        __s1_len___0 = (unsigned long )tmp___37;
        tmp___38 = __dyc_funcallvar_2;
        __s2_len___0 = (unsigned long )tmp___38;
        }
        if (! ((unsigned long )(buf + 1) - (unsigned long )buf == 1UL)) {
          goto _L___2;
        } else {
          if (__s1_len___0 >= 4UL) {
            _L___2:  
            if (! ((unsigned long )((void const   *)("%PDF-" + 1)) - (unsigned long )((void const   *)"%PDF-") == 1UL)) {
              tmp___39 = 1;
            } else {
              if (__s2_len___0 >= 4UL) {
                tmp___39 = 1;
              } else {
                tmp___39 = 0;
              }
            }
          } else {
            tmp___39 = 0;
          }
        }
        if (tmp___39) {
          {
          tmp___31 = __dyc_funcallvar_3;
          }
        } else {
          {
          tmp___36 = __dyc_funcallvar_4;
          tmp___31 = tmp___36;
          }
        }
      } else {
        {
        tmp___36 = __dyc_funcallvar_5;
        tmp___31 = tmp___36;
        }
      }
      tmp___21 = tmp___31;
    } else {
      {
      tmp___21 = __dyc_funcallvar_6;
      }
    }
    if (tmp___21 == 0) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__s1_len___0);
  __dyc_printpre_byte(__s2_len___0);
}
}
