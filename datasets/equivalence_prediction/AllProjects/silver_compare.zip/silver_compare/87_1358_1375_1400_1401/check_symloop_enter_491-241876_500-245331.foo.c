#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  struct stat buf ;
  symdir_t *item_found ;
  symdir_t *new_item ;
  unsigned int _hf_bkt ;
  unsigned int _hf_hashv ;
  unsigned int _hj_i ;
  unsigned int _hj_j ;
  unsigned int _hj_k ;
  unsigned char *_hj_key ;
  int tmp___0 ;
  void *tmp___1 ;
  unsigned int _ha_bkt ;
  void *tmp___2 ;
  void *tmp___3 ;
  unsigned int _hj_i___0 ;
  unsigned int _hj_j___0 ;
  unsigned int _hj_k___0 ;
  unsigned char *_hj_key___0 ;
  unsigned int _he_bkt ;
  unsigned int _he_bkt_i ;
  struct UT_hash_handle *_he_thh ;
  struct UT_hash_handle *_he_hh_nxt ;
  UT_hash_bucket *_he_new_buckets ;
  UT_hash_bucket *_he_newbkt ;
  void *tmp___4 ;
  int tmp___5 ;
  dirkey_t *outkey ;
  int __dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;
  void *__dyc_funcallvar_4 ;
  void *__dyc_funcallvar_5 ;
  void *__dyc_funcallvar_6 ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  buf = __dyc_read_comp_27stat();
  outkey = __dyc_read_ptr__typdef_dirkey_t();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  __dyc_funcallvar_4 = __dyc_read_ptr__void();
  __dyc_funcallvar_5 = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = __dyc_read_ptr__void();
  item_found = 0;
  new_item = 0;
  _hf_bkt = 0;
  _hf_hashv = 0;
  _hj_i = 0;
  _hj_j = 0;
  _hj_k = 0;
  _hj_key = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  _ha_bkt = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  _hj_i___0 = 0;
  _hj_j___0 = 0;
  _hj_k___0 = 0;
  _hj_key___0 = 0;
  _he_bkt = 0;
  _he_bkt_i = 0;
  _he_thh = 0;
  _he_hh_nxt = 0;
  _he_new_buckets = 0;
  _he_newbkt = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  outkey->dev = buf.st_dev;
  outkey->ino = buf.st_ino;
  while (1) {
    while_8_continue:  ;
    item_found = (symdir_t *)((void *)0);
    if (symhash) {
      {
      while (1) {
        while_9_continue:  ;
        _hj_key = (unsigned char *)outkey;
        _hf_hashv = 4276993775U;
        _hj_j = 2654435769U;
        _hj_i = _hj_j;
        _hj_k = (unsigned int )sizeof(dirkey_t );
        {
        while (1) {
          while_10_continue:  ;
          if (! (_hj_k >= 12U)) {
            goto while_10_break;
          }
          _hj_i += (((unsigned int )*(_hj_key + 0) + ((unsigned int )*(_hj_key + 1) << 8)) + ((unsigned int )*(_hj_key + 2) << 16)) + ((unsigned int )*(_hj_key + 3) << 24);
          _hj_j += (((unsigned int )*(_hj_key + 4) + ((unsigned int )*(_hj_key + 5) << 8)) + ((unsigned int )*(_hj_key + 6) << 16)) + ((unsigned int )*(_hj_key + 7) << 24);
          _hf_hashv += (((unsigned int )*(_hj_key + 8) + ((unsigned int )*(_hj_key + 9) << 8)) + ((unsigned int )*(_hj_key + 10) << 16)) + ((unsigned int )*(_hj_key + 11) << 24);
          {
          while (1) {
            while_11_continue:  ;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 13;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 8;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 13;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 12;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 16;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 5;
            _hj_i -= _hj_j;
            _hj_i -= _hf_hashv;
            _hj_i ^= _hf_hashv >> 3;
            _hj_j -= _hf_hashv;
            _hj_j -= _hj_i;
            _hj_j ^= _hj_i << 10;
            _hf_hashv -= _hj_i;
            _hf_hashv -= _hj_j;
            _hf_hashv ^= _hj_j >> 15;
            goto while_11_break;
          }
          while_11_break:  ;
          }
          _hj_key += 12;
          _hj_k -= 12U;
        }
        while_10_break:  ;
        }
        _hf_hashv = (unsigned int )((unsigned long )_hf_hashv + sizeof(dirkey_t ));
        if ((int )_hj_k == 11) {
          goto switch_12_11;
        } else {
          if ((int )_hj_k == 10) {
            goto switch_12_10;
          } else {
            if ((int )_hj_k == 9) {
              goto switch_12_9;
            } else {
              if ((int )_hj_k == 8) {
                goto switch_12_8;
              } else {
                if ((int )_hj_k == 7) {
                  goto switch_12_7;
                } else {
                  if ((int )_hj_k == 6) {
                    goto switch_12_6;
                  } else {
                    if ((int )_hj_k == 5) {
                      goto switch_12_5;
                    } else {
                      if ((int )_hj_k == 4) {
                        goto switch_12_4;
                      } else {
                        if ((int )_hj_k == 3) {
                          goto switch_12_3;
                        } else {
                          if ((int )_hj_k == 2) {
                            goto switch_12_2;
                          } else {
                            if ((int )_hj_k == 1) {
                              goto switch_12_1;
                            } else {
                              if (0) {
                                switch_12_11:  
                                _hf_hashv += (unsigned int )*(_hj_key + 10) << 24;
                                switch_12_10:  
                                _hf_hashv += (unsigned int )*(_hj_key + 9) << 16;
                                switch_12_9:  
                                _hf_hashv += (unsigned int )*(_hj_key + 8) << 8;
                                switch_12_8:  
                                _hj_j += (unsigned int )*(_hj_key + 7) << 24;
                                switch_12_7:  
                                _hj_j += (unsigned int )*(_hj_key + 6) << 16;
                                switch_12_6:  
                                _hj_j += (unsigned int )*(_hj_key + 5) << 8;
                                switch_12_5:  
                                _hj_j += (unsigned int )*(_hj_key + 4);
                                switch_12_4:  
                                _hj_i += (unsigned int )*(_hj_key + 3) << 24;
                                switch_12_3:  
                                _hj_i += (unsigned int )*(_hj_key + 2) << 16;
                                switch_12_2:  
                                _hj_i += (unsigned int )*(_hj_key + 1) << 8;
                                switch_12_1:  
                                _hj_i += (unsigned int )*(_hj_key + 0);
                              } else {
                                switch_12_break:  ;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        {
        while (1) {
          while_13_continue:  ;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 13;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 8;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 13;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 12;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 16;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 5;
          _hj_i -= _hj_j;
          _hj_i -= _hf_hashv;
          _hj_i ^= _hf_hashv >> 3;
          _hj_j -= _hf_hashv;
          _hj_j -= _hj_i;
          _hj_j ^= _hj_i << 10;
          _hf_hashv -= _hj_i;
          _hf_hashv -= _hj_j;
          _hf_hashv ^= _hj_j >> 15;
          goto while_13_break;
        }
        while_13_break:  ;
        }
        _hf_bkt = _hf_hashv & ((symhash->hh.tbl)->num_buckets - 1U);
        goto while_9_break;
      }
      while_9_break:  ;
      }
      {
      while (1) {
        while_14_continue:  ;
        if (((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head) {
          {
          while (1) {
            while_15_continue:  ;
            item_found = (symdir_t *)((void *)((char *)((symhash->hh.tbl)->buckets + _hf_bkt)->hh_head - (symhash->hh.tbl)->hho));
            goto while_15_break;
          }
          while_15_break:  ;
          }
        } else {
          item_found = (symdir_t *)((void *)0);
        }
        {
        while (1) {
          while_16_continue:  ;
          if (! item_found) {
            goto while_16_break;
          }
          if ((unsigned long )item_found->hh.keylen == sizeof(dirkey_t )) {
            {
            tmp___0 = __dyc_funcallvar_2;
            }
            if (tmp___0 == 0) {
              goto while_16_break;
            }
          }
          if (item_found->hh.hh_next) {
            {
            while (1) {
              while_17_continue:  ;
              item_found = (symdir_t *)((void *)((char *)item_found->hh.hh_next - (symhash->hh.tbl)->hho));
              goto while_17_break;
            }
            while_17_break:  ;
            }
          } else {
            item_found = (symdir_t *)((void *)0);
          }
        }
        while_16_break:  ;
        }
        goto while_14_break;
      }
      while_14_break:  ;
      }
    }
    goto while_8_break;
  }
  while_8_break:  ;
  if (item_found) {
    goto __dyc_dummy_label;
  }
  tmp___1 = __dyc_funcallvar_3;
  new_item = (symdir_t *)tmp___1;

  while (1) {
    while_18_continue:  ;
    new_item->hh.next = (void *)0;
    new_item->hh.key = (void *)((char *)(& new_item->key));
    new_item->hh.keylen = (unsigned int )sizeof(dirkey_t );
    if (! symhash) {
      symhash = new_item;
      symhash->hh.prev = (void *)0;
      {
      while (1) {
        while_19_continue:  ;
        {
        tmp___2 = __dyc_funcallvar_4;
        symhash->hh.tbl = (UT_hash_table *)tmp___2;
        }
        if (! symhash->hh.tbl) {
          {

          }
        }
        {

        (symhash->hh.tbl)->tail = & symhash->hh;
        (symhash->hh.tbl)->num_buckets = 32U;
        (symhash->hh.tbl)->log2_num_buckets = 5U;
        (symhash->hh.tbl)->hho = (long )((char *)(& symhash->hh) - (char *)symhash);
        tmp___3 = __dyc_funcallvar_5;
        (symhash->hh.tbl)->buckets = (UT_hash_bucket *)tmp___3;
        }
        if (! (symhash->hh.tbl)->buckets) {
          {

          }
        }
        {

        (symhash->hh.tbl)->signature = 2685476833U;
        }
        goto while_19_break;
      }
      while_19_break:  ;
      }
    } else {
      ((symhash->hh.tbl)->tail)->next = (void *)new_item;
      new_item->hh.prev = (void *)((char *)(symhash->hh.tbl)->tail - (symhash->hh.tbl)->hho);
      (symhash->hh.tbl)->tail = & new_item->hh;
    }
    ((symhash->hh.tbl)->num_items) ++;
    new_item->hh.tbl = symhash->hh.tbl;
    {
    while (1) {
      while_20_continue:  ;
      _hj_key___0 = (unsigned char *)(& new_item->key);
      new_item->hh.hashv = 4276993775U;
      _hj_j___0 = 2654435769U;
      _hj_i___0 = _hj_j___0;
      _hj_k___0 = (unsigned int )sizeof(dirkey_t );
      {
      while (1) {
        while_21_continue:  ;
        if (! (_hj_k___0 >= 12U)) {
          goto while_21_break;
        }
        _hj_i___0 += (((unsigned int )*(_hj_key___0 + 0) + ((unsigned int )*(_hj_key___0 + 1) << 8)) + ((unsigned int )*(_hj_key___0 + 2) << 16)) + ((unsigned int )*(_hj_key___0 + 3) << 24);
        _hj_j___0 += (((unsigned int )*(_hj_key___0 + 4) + ((unsigned int )*(_hj_key___0 + 5) << 8)) + ((unsigned int )*(_hj_key___0 + 6) << 16)) + ((unsigned int )*(_hj_key___0 + 7) << 24);
        new_item->hh.hashv += (((unsigned int )*(_hj_key___0 + 8) + ((unsigned int )*(_hj_key___0 + 9) << 8)) + ((unsigned int )*(_hj_key___0 + 10) << 16)) + ((unsigned int )*(_hj_key___0 + 11) << 24);
        {
        while (1) {
          while_22_continue:  ;
          _hj_i___0 -= _hj_j___0;
          _hj_i___0 -= new_item->hh.hashv;
          _hj_i___0 ^= new_item->hh.hashv >> 13;
          _hj_j___0 -= new_item->hh.hashv;
          _hj_j___0 -= _hj_i___0;
          _hj_j___0 ^= _hj_i___0 << 8;
          new_item->hh.hashv -= _hj_i___0;
          new_item->hh.hashv -= _hj_j___0;
          new_item->hh.hashv ^= _hj_j___0 >> 13;
          _hj_i___0 -= _hj_j___0;
          _hj_i___0 -= new_item->hh.hashv;
          _hj_i___0 ^= new_item->hh.hashv >> 12;
          _hj_j___0 -= new_item->hh.hashv;
          _hj_j___0 -= _hj_i___0;
          _hj_j___0 ^= _hj_i___0 << 16;
          new_item->hh.hashv -= _hj_i___0;
          new_item->hh.hashv -= _hj_j___0;
          new_item->hh.hashv ^= _hj_j___0 >> 5;
          _hj_i___0 -= _hj_j___0;
          _hj_i___0 -= new_item->hh.hashv;
          _hj_i___0 ^= new_item->hh.hashv >> 3;
          _hj_j___0 -= new_item->hh.hashv;
          _hj_j___0 -= _hj_i___0;
          _hj_j___0 ^= _hj_i___0 << 10;
          new_item->hh.hashv -= _hj_i___0;
          new_item->hh.hashv -= _hj_j___0;
          new_item->hh.hashv ^= _hj_j___0 >> 15;
          goto while_22_break;
        }
        while_22_break:  ;
        }
        _hj_key___0 += 12;
        _hj_k___0 -= 12U;
      }
      while_21_break:  ;
      }
      new_item->hh.hashv = (unsigned int )((unsigned long )new_item->hh.hashv + sizeof(dirkey_t ));
      if ((int )_hj_k___0 == 11) {
        goto switch_23_11;
      } else {
        if ((int )_hj_k___0 == 10) {
          goto switch_23_10;
        } else {
          if ((int )_hj_k___0 == 9) {
            goto switch_23_9;
          } else {
            if ((int )_hj_k___0 == 8) {
              goto switch_23_8;
            } else {
              if ((int )_hj_k___0 == 7) {
                goto switch_23_7;
              } else {
                if ((int )_hj_k___0 == 6) {
                  goto switch_23_6;
                } else {
                  if ((int )_hj_k___0 == 5) {
                    goto switch_23_5;
                  } else {
                    if ((int )_hj_k___0 == 4) {
                      goto switch_23_4;
                    } else {
                      if ((int )_hj_k___0 == 3) {
                        goto switch_23_3;
                      } else {
                        if ((int )_hj_k___0 == 2) {
                          goto switch_23_2;
                        } else {
                          if ((int )_hj_k___0 == 1) {
                            goto switch_23_1;
                          } else {
                            if (0) {
                              switch_23_11:  
                              new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 10) << 24;
                              switch_23_10:  
                              new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 9) << 16;
                              switch_23_9:  
                              new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 8) << 8;
                              switch_23_8:  
                              _hj_j___0 += (unsigned int )*(_hj_key___0 + 7) << 24;
                              switch_23_7:  
                              _hj_j___0 += (unsigned int )*(_hj_key___0 + 6) << 16;
                              switch_23_6:  
                              _hj_j___0 += (unsigned int )*(_hj_key___0 + 5) << 8;
                              switch_23_5:  
                              _hj_j___0 += (unsigned int )*(_hj_key___0 + 4);
                              switch_23_4:  
                              _hj_i___0 += (unsigned int )*(_hj_key___0 + 3) << 24;
                              switch_23_3:  
                              _hj_i___0 += (unsigned int )*(_hj_key___0 + 2) << 16;
                              switch_23_2:  
                              _hj_i___0 += (unsigned int )*(_hj_key___0 + 1) << 8;
                              switch_23_1:  
                              _hj_i___0 += (unsigned int )*(_hj_key___0 + 0);
                            } else {
                              switch_23_break:  ;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      {
      while (1) {
        while_24_continue:  ;
        _hj_i___0 -= _hj_j___0;
        _hj_i___0 -= new_item->hh.hashv;
        _hj_i___0 ^= new_item->hh.hashv >> 13;
        _hj_j___0 -= new_item->hh.hashv;
        _hj_j___0 -= _hj_i___0;
        _hj_j___0 ^= _hj_i___0 << 8;
        new_item->hh.hashv -= _hj_i___0;
        new_item->hh.hashv -= _hj_j___0;
        new_item->hh.hashv ^= _hj_j___0 >> 13;
        _hj_i___0 -= _hj_j___0;
        _hj_i___0 -= new_item->hh.hashv;
        _hj_i___0 ^= new_item->hh.hashv >> 12;
        _hj_j___0 -= new_item->hh.hashv;
        _hj_j___0 -= _hj_i___0;
        _hj_j___0 ^= _hj_i___0 << 16;
        new_item->hh.hashv -= _hj_i___0;
        new_item->hh.hashv -= _hj_j___0;
        new_item->hh.hashv ^= _hj_j___0 >> 5;
        _hj_i___0 -= _hj_j___0;
        _hj_i___0 -= new_item->hh.hashv;
        _hj_i___0 ^= new_item->hh.hashv >> 3;
        _hj_j___0 -= new_item->hh.hashv;
        _hj_j___0 -= _hj_i___0;
        _hj_j___0 ^= _hj_i___0 << 10;
        new_item->hh.hashv -= _hj_i___0;
        new_item->hh.hashv -= _hj_j___0;
        new_item->hh.hashv ^= _hj_j___0 >> 15;
        goto while_24_break;
      }
      while_24_break:  ;
      }
      _ha_bkt = new_item->hh.hashv & ((symhash->hh.tbl)->num_buckets - 1U);
      goto while_20_break;
    }
    while_20_break:  ;
    }
    {
    while (1) {
      while_25_continue:  ;
      (((symhash->hh.tbl)->buckets + _ha_bkt)->count) ++;
      new_item->hh.hh_next = ((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head;
      new_item->hh.hh_prev = (struct UT_hash_handle *)((void *)0);
      if (((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head) {
        (((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head)->hh_prev = & new_item->hh;
      }
      ((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head = & new_item->hh;
      if (((symhash->hh.tbl)->buckets + _ha_bkt)->count >= (((symhash->hh.tbl)->buckets + _ha_bkt)->expand_mult + 1U) * 10U) {
        if ((new_item->hh.tbl)->noexpand != 1U) {
          {
          while (1) {
            while_26_continue:  ;
            {
            tmp___4 = __dyc_funcallvar_6;
            _he_new_buckets = (UT_hash_bucket *)tmp___4;
            }
            if (! _he_new_buckets) {
              {

              }
            }
            {

            }
            if ((new_item->hh.tbl)->num_items & ((new_item->hh.tbl)->num_buckets * 2U - 1U)) {
              tmp___5 = 1;
            } else {
              tmp___5 = 0;
            }
            (new_item->hh.tbl)->ideal_chain_maxlen = ((new_item->hh.tbl)->num_items >> ((new_item->hh.tbl)->log2_num_buckets + 1U)) + (unsigned int )tmp___5;
            (new_item->hh.tbl)->nonideal_items = 0U;
            _he_bkt_i = 0U;
            {
            while (1) {
              while_27_continue:  ;
              if (! (_he_bkt_i < (new_item->hh.tbl)->num_buckets)) {
                goto while_27_break;
              }
              _he_thh = ((new_item->hh.tbl)->buckets + _he_bkt_i)->hh_head;
              {
              while (1) {
                while_28_continue:  ;
                if (! _he_thh) {
                  goto while_28_break;
                }
                _he_hh_nxt = _he_thh->hh_next;
                {
                while (1) {
                  while_29_continue:  ;
                  _he_bkt = _he_thh->hashv & ((new_item->hh.tbl)->num_buckets * 2U - 1U);
                  goto while_29_break;
                }
                while_29_break:  ;
                }
                _he_newbkt = _he_new_buckets + _he_bkt;
                (_he_newbkt->count) ++;
                if (_he_newbkt->count > (new_item->hh.tbl)->ideal_chain_maxlen) {
                  ((new_item->hh.tbl)->nonideal_items) ++;
                  _he_newbkt->expand_mult = _he_newbkt->count / (new_item->hh.tbl)->ideal_chain_maxlen;
                }
                _he_thh->hh_prev = (struct UT_hash_handle *)((void *)0);
                _he_thh->hh_next = _he_newbkt->hh_head;
                if (_he_newbkt->hh_head) {
                  (_he_newbkt->hh_head)->hh_prev = _he_thh;
                }
                _he_newbkt->hh_head = _he_thh;
                _he_thh = _he_hh_nxt;
              }
              while_28_break:  ;
              }
              _he_bkt_i ++;
            }
            while_27_break:  ;
            }
            {

            (new_item->hh.tbl)->num_buckets *= 2U;
            ((new_item->hh.tbl)->log2_num_buckets) ++;
            (new_item->hh.tbl)->buckets = _he_new_buckets;
            }
            if ((new_item->hh.tbl)->nonideal_items > (new_item->hh.tbl)->num_items >> 1) {
              ((new_item->hh.tbl)->ineff_expands) ++;
            } else {
              (new_item->hh.tbl)->ineff_expands = 0U;
            }
            if ((new_item->hh.tbl)->ineff_expands > 1U) {
              (new_item->hh.tbl)->noexpand = 1U;
            }
            goto while_26_break;
          }
          while_26_break:  ;
          }
        }
      }
      goto while_25_break;
    }
    while_25_break:  ;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(_hj_key);
  __dyc_print_ptr__char(_hj_key___0);
}
}
