#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  symdir_t *new_item ;
  unsigned int _ha_bkt ;
  void *tmp___2 ;
  void *tmp___3 ;
  unsigned int _hj_i___0 ;
  unsigned int _hj_j___0 ;
  unsigned int _hj_k___0 ;
  unsigned char *_hj_key___0 ;
  unsigned int _he_bkt ;
  unsigned int _he_bkt_i ;
  struct UT_hash_handle *_he_thh ;
  struct UT_hash_handle *_he_hh_nxt ;
  UT_hash_bucket *_he_new_buckets ;
  UT_hash_bucket *_he_newbkt ;
  void *tmp___4 ;
  int tmp___5 ;
  void *__dyc_funcallvar_4 ;
  void *__dyc_funcallvar_5 ;
  void *__dyc_funcallvar_6 ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  new_item = __dyc_read_ptr__typdef_symdir_t();
  __dyc_funcallvar_4 = __dyc_read_ptr__void();
  __dyc_funcallvar_5 = __dyc_read_ptr__void();
  __dyc_funcallvar_6 = __dyc_read_ptr__void();
  _ha_bkt = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  _hj_i___0 = 0;
  _hj_j___0 = 0;
  _hj_k___0 = 0;
  _hj_key___0 = 0;
  _he_bkt = 0;
  _he_bkt_i = 0;
  _he_thh = 0;
  _he_hh_nxt = 0;
  _he_new_buckets = 0;
  _he_newbkt = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  if (! symhash) {
    symhash = new_item;
    symhash->hh.prev = (void *)0;
    {
    while (1) {
      while_19_continue:  ;
      {
      tmp___2 = __dyc_funcallvar_4;
      symhash->hh.tbl = (UT_hash_table *)tmp___2;
      }
      if (! symhash->hh.tbl) {
        {

        }
      }
      {

      (symhash->hh.tbl)->tail = & symhash->hh;
      (symhash->hh.tbl)->num_buckets = 32U;
      (symhash->hh.tbl)->log2_num_buckets = 5U;
      (symhash->hh.tbl)->hho = (long )((char *)(& symhash->hh) - (char *)symhash);
      tmp___3 = __dyc_funcallvar_5;
      (symhash->hh.tbl)->buckets = (UT_hash_bucket *)tmp___3;
      }
      if (! (symhash->hh.tbl)->buckets) {
        {

        }
      }
      {

      (symhash->hh.tbl)->signature = 2685476833U;
      }
      goto while_19_break;
    }
    while_19_break:  ;
    }
  } else {
    ((symhash->hh.tbl)->tail)->next = (void *)new_item;
    new_item->hh.prev = (void *)((char *)(symhash->hh.tbl)->tail - (symhash->hh.tbl)->hho);
    (symhash->hh.tbl)->tail = & new_item->hh;
  }
  ((symhash->hh.tbl)->num_items) ++;
  new_item->hh.tbl = symhash->hh.tbl;
  while (1) {
    while_20_continue:  ;
    _hj_key___0 = (unsigned char *)(& new_item->key);
    new_item->hh.hashv = 4276993775U;
    _hj_j___0 = 2654435769U;
    _hj_i___0 = _hj_j___0;
    _hj_k___0 = (unsigned int )sizeof(dirkey_t );
    {
    while (1) {
      while_21_continue:  ;
      if (! (_hj_k___0 >= 12U)) {
        goto while_21_break;
      }
      _hj_i___0 += (((unsigned int )*(_hj_key___0 + 0) + ((unsigned int )*(_hj_key___0 + 1) << 8)) + ((unsigned int )*(_hj_key___0 + 2) << 16)) + ((unsigned int )*(_hj_key___0 + 3) << 24);
      _hj_j___0 += (((unsigned int )*(_hj_key___0 + 4) + ((unsigned int )*(_hj_key___0 + 5) << 8)) + ((unsigned int )*(_hj_key___0 + 6) << 16)) + ((unsigned int )*(_hj_key___0 + 7) << 24);
      new_item->hh.hashv += (((unsigned int )*(_hj_key___0 + 8) + ((unsigned int )*(_hj_key___0 + 9) << 8)) + ((unsigned int )*(_hj_key___0 + 10) << 16)) + ((unsigned int )*(_hj_key___0 + 11) << 24);
      {
      while (1) {
        while_22_continue:  ;
        _hj_i___0 -= _hj_j___0;
        _hj_i___0 -= new_item->hh.hashv;
        _hj_i___0 ^= new_item->hh.hashv >> 13;
        _hj_j___0 -= new_item->hh.hashv;
        _hj_j___0 -= _hj_i___0;
        _hj_j___0 ^= _hj_i___0 << 8;
        new_item->hh.hashv -= _hj_i___0;
        new_item->hh.hashv -= _hj_j___0;
        new_item->hh.hashv ^= _hj_j___0 >> 13;
        _hj_i___0 -= _hj_j___0;
        _hj_i___0 -= new_item->hh.hashv;
        _hj_i___0 ^= new_item->hh.hashv >> 12;
        _hj_j___0 -= new_item->hh.hashv;
        _hj_j___0 -= _hj_i___0;
        _hj_j___0 ^= _hj_i___0 << 16;
        new_item->hh.hashv -= _hj_i___0;
        new_item->hh.hashv -= _hj_j___0;
        new_item->hh.hashv ^= _hj_j___0 >> 5;
        _hj_i___0 -= _hj_j___0;
        _hj_i___0 -= new_item->hh.hashv;
        _hj_i___0 ^= new_item->hh.hashv >> 3;
        _hj_j___0 -= new_item->hh.hashv;
        _hj_j___0 -= _hj_i___0;
        _hj_j___0 ^= _hj_i___0 << 10;
        new_item->hh.hashv -= _hj_i___0;
        new_item->hh.hashv -= _hj_j___0;
        new_item->hh.hashv ^= _hj_j___0 >> 15;
        goto while_22_break;
      }
      while_22_break:  ;
      }
      _hj_key___0 += 12;
      _hj_k___0 -= 12U;
    }
    while_21_break:  ;
    }
    new_item->hh.hashv = (unsigned int )((unsigned long )new_item->hh.hashv + sizeof(dirkey_t ));
    if ((int )_hj_k___0 == 11) {
      goto switch_23_11;
    } else {
      if ((int )_hj_k___0 == 10) {
        goto switch_23_10;
      } else {
        if ((int )_hj_k___0 == 9) {
          goto switch_23_9;
        } else {
          if ((int )_hj_k___0 == 8) {
            goto switch_23_8;
          } else {
            if ((int )_hj_k___0 == 7) {
              goto switch_23_7;
            } else {
              if ((int )_hj_k___0 == 6) {
                goto switch_23_6;
              } else {
                if ((int )_hj_k___0 == 5) {
                  goto switch_23_5;
                } else {
                  if ((int )_hj_k___0 == 4) {
                    goto switch_23_4;
                  } else {
                    if ((int )_hj_k___0 == 3) {
                      goto switch_23_3;
                    } else {
                      if ((int )_hj_k___0 == 2) {
                        goto switch_23_2;
                      } else {
                        if ((int )_hj_k___0 == 1) {
                          goto switch_23_1;
                        } else {
                          if (0) {
                            switch_23_11:  
                            new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 10) << 24;
                            switch_23_10:  
                            new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 9) << 16;
                            switch_23_9:  
                            new_item->hh.hashv += (unsigned int )*(_hj_key___0 + 8) << 8;
                            switch_23_8:  
                            _hj_j___0 += (unsigned int )*(_hj_key___0 + 7) << 24;
                            switch_23_7:  
                            _hj_j___0 += (unsigned int )*(_hj_key___0 + 6) << 16;
                            switch_23_6:  
                            _hj_j___0 += (unsigned int )*(_hj_key___0 + 5) << 8;
                            switch_23_5:  
                            _hj_j___0 += (unsigned int )*(_hj_key___0 + 4);
                            switch_23_4:  
                            _hj_i___0 += (unsigned int )*(_hj_key___0 + 3) << 24;
                            switch_23_3:  
                            _hj_i___0 += (unsigned int )*(_hj_key___0 + 2) << 16;
                            switch_23_2:  
                            _hj_i___0 += (unsigned int )*(_hj_key___0 + 1) << 8;
                            switch_23_1:  
                            _hj_i___0 += (unsigned int )*(_hj_key___0 + 0);
                          } else {
                            switch_23_break:  ;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    {
    while (1) {
      while_24_continue:  ;
      _hj_i___0 -= _hj_j___0;
      _hj_i___0 -= new_item->hh.hashv;
      _hj_i___0 ^= new_item->hh.hashv >> 13;
      _hj_j___0 -= new_item->hh.hashv;
      _hj_j___0 -= _hj_i___0;
      _hj_j___0 ^= _hj_i___0 << 8;
      new_item->hh.hashv -= _hj_i___0;
      new_item->hh.hashv -= _hj_j___0;
      new_item->hh.hashv ^= _hj_j___0 >> 13;
      _hj_i___0 -= _hj_j___0;
      _hj_i___0 -= new_item->hh.hashv;
      _hj_i___0 ^= new_item->hh.hashv >> 12;
      _hj_j___0 -= new_item->hh.hashv;
      _hj_j___0 -= _hj_i___0;
      _hj_j___0 ^= _hj_i___0 << 16;
      new_item->hh.hashv -= _hj_i___0;
      new_item->hh.hashv -= _hj_j___0;
      new_item->hh.hashv ^= _hj_j___0 >> 5;
      _hj_i___0 -= _hj_j___0;
      _hj_i___0 -= new_item->hh.hashv;
      _hj_i___0 ^= new_item->hh.hashv >> 3;
      _hj_j___0 -= new_item->hh.hashv;
      _hj_j___0 -= _hj_i___0;
      _hj_j___0 ^= _hj_i___0 << 10;
      new_item->hh.hashv -= _hj_i___0;
      new_item->hh.hashv -= _hj_j___0;
      new_item->hh.hashv ^= _hj_j___0 >> 15;
      goto while_24_break;
    }
    while_24_break:  ;
    }
    _ha_bkt = new_item->hh.hashv & ((symhash->hh.tbl)->num_buckets - 1U);
    goto while_20_break;
  }
  while_20_break:  ;
  while (1) {
    while_25_continue:  ;
    (((symhash->hh.tbl)->buckets + _ha_bkt)->count) ++;
    new_item->hh.hh_next = ((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head;
    new_item->hh.hh_prev = (struct UT_hash_handle *)((void *)0);
    if (((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head) {
      (((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head)->hh_prev = & new_item->hh;
    }
    ((symhash->hh.tbl)->buckets + _ha_bkt)->hh_head = & new_item->hh;
    if (((symhash->hh.tbl)->buckets + _ha_bkt)->count >= (((symhash->hh.tbl)->buckets + _ha_bkt)->expand_mult + 1U) * 10U) {
      if ((new_item->hh.tbl)->noexpand != 1U) {
        {
        while (1) {
          while_26_continue:  ;
          {
          tmp___4 = __dyc_funcallvar_6;
          _he_new_buckets = (UT_hash_bucket *)tmp___4;
          }
          if (! _he_new_buckets) {
            {

            }
          }
          {

          }
          if ((new_item->hh.tbl)->num_items & ((new_item->hh.tbl)->num_buckets * 2U - 1U)) {
            tmp___5 = 1;
          } else {
            tmp___5 = 0;
          }
          (new_item->hh.tbl)->ideal_chain_maxlen = ((new_item->hh.tbl)->num_items >> ((new_item->hh.tbl)->log2_num_buckets + 1U)) + (unsigned int )tmp___5;
          (new_item->hh.tbl)->nonideal_items = 0U;
          _he_bkt_i = 0U;
          {
          while (1) {
            while_27_continue:  ;
            if (! (_he_bkt_i < (new_item->hh.tbl)->num_buckets)) {
              goto while_27_break;
            }
            _he_thh = ((new_item->hh.tbl)->buckets + _he_bkt_i)->hh_head;
            {
            while (1) {
              while_28_continue:  ;
              if (! _he_thh) {
                goto while_28_break;
              }
              _he_hh_nxt = _he_thh->hh_next;
              {
              while (1) {
                while_29_continue:  ;
                _he_bkt = _he_thh->hashv & ((new_item->hh.tbl)->num_buckets * 2U - 1U);
                goto while_29_break;
              }
              while_29_break:  ;
              }
              _he_newbkt = _he_new_buckets + _he_bkt;
              (_he_newbkt->count) ++;
              if (_he_newbkt->count > (new_item->hh.tbl)->ideal_chain_maxlen) {
                ((new_item->hh.tbl)->nonideal_items) ++;
                _he_newbkt->expand_mult = _he_newbkt->count / (new_item->hh.tbl)->ideal_chain_maxlen;
              }
              _he_thh->hh_prev = (struct UT_hash_handle *)((void *)0);
              _he_thh->hh_next = _he_newbkt->hh_head;
              if (_he_newbkt->hh_head) {
                (_he_newbkt->hh_head)->hh_prev = _he_thh;
              }
              _he_newbkt->hh_head = _he_thh;
              _he_thh = _he_hh_nxt;
            }
            while_28_break:  ;
            }
            _he_bkt_i ++;
          }
          while_27_break:  ;
          }
          {

          (new_item->hh.tbl)->num_buckets *= 2U;
          ((new_item->hh.tbl)->log2_num_buckets) ++;
          (new_item->hh.tbl)->buckets = _he_new_buckets;
          }
          if ((new_item->hh.tbl)->nonideal_items > (new_item->hh.tbl)->num_items >> 1) {
            ((new_item->hh.tbl)->ineff_expands) ++;
          } else {
            (new_item->hh.tbl)->ineff_expands = 0U;
          }
          if ((new_item->hh.tbl)->ineff_expands > 1U) {
            (new_item->hh.tbl)->noexpand = 1U;
          }
          goto while_26_break;
        }
        while_26_break:  ;
        }
      }
    }
    goto while_25_break;
  }
  while_25_break:  ;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(_hj_key___0);
}
}
