#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ ignores *root_ignores ;
  int i ;
  int pattern_len ;
  char ***patterns_p ;
  size_t *patterns_len ;
  char *tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  char **patterns ;
  void *tmp___47 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___57 ;
  int tmp___62 ;
  int tmp___63 ;
  int tmp___64 ;
  int tmp___65 ;
  char const   *tmp___66 ;
  ignores *ig ;
  char const   *pattern ;
  char *__dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  void *__dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  char *__dyc_funcallvar_18 ;

  {
  root_ignores = __dyc_read_ptr__typdef_ignores();
  pattern_len = __dyc_readpre_byte();
  tmp___46 = __dyc_readpre_byte();
  ig = __dyc_read_ptr__typdef_ignores();
  pattern = (char const   *)__dyc_read_ptr__char();
  __dyc_funcallvar_10 = __dyc_read_ptr__char();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_read_ptr__void();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_read_ptr__char();
  i = 0;
  patterns_p = 0;
  patterns_len = 0;
  tmp___44 = 0;
  tmp___45 = 0;
  patterns = 0;
  tmp___47 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___57 = 0;
  tmp___62 = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  tmp___65 = 0;
  tmp___66 = 0;
  if (tmp___46) {
    if ((int const   )*(pattern + 0) == 42) {
      if ((int const   )*(pattern + 1) == 46) {
        {
        tmp___44 = __dyc_funcallvar_10;
        }
        if (tmp___44) {
          {
          tmp___45 = __dyc_funcallvar_11;
          }
          if (tmp___45) {
            goto _L___5;
          } else {
            patterns_p = & ig->extensions;
            patterns_len = & ig->extensions_len;
            pattern += 2;
            pattern_len -= 2;
          }
        } else {
          goto _L___5;
        }
      } else {
        goto _L___5;
      }
    } else {
      _L___5:  
      if ((int const   )*(pattern + 0) == 47) {
        patterns_p = & ig->slash_regexes;
        patterns_len = & ig->slash_regexes_len;
        pattern ++;
        pattern_len --;
      } else {
        if ((int const   )*(pattern + 0) == 33) {
          patterns_p = & ig->invert_regexes;
          patterns_len = & ig->invert_regexes_len;
          pattern ++;
          pattern_len --;
        } else {
          patterns_p = & ig->regexes;
          patterns_len = & ig->regexes_len;
        }
      }
    }
  } else {
    if ((int const   )*(pattern + 0) == 47) {
      patterns_p = & ig->slash_names;
      patterns_len = & ig->slash_names_len;
      pattern ++;
      pattern_len --;
    } else {
      patterns_p = & ig->names;
      patterns_len = & ig->names_len;
    }
  }
  (*patterns_len) ++;
  tmp___47 = __dyc_funcallvar_12;
  patterns = (char **)tmp___47;
  *patterns_p = patterns;
  i = (int )(*patterns_len - 1UL);
  while (1) {
    while_1_continue:  ;
    if (! (i > 0)) {
      goto while_1_break;
    }
    if (0) {
      {
      tmp___63 = __dyc_funcallvar_13;
      __s1_len___1 = (unsigned long )tmp___63;
      tmp___64 = __dyc_funcallvar_14;
      __s2_len___1 = (unsigned long )tmp___64;
      }
      if (! ((unsigned long )((void const   *)(pattern + 1)) - (unsigned long )((void const   *)pattern) == 1UL)) {
        goto _L___7;
      } else {
        if (__s1_len___1 >= 4UL) {
          _L___7:  
          if (! ((unsigned long )((void const   *)(*(patterns + (i - 1)) + 1)) - (unsigned long )((void const   *)*(patterns + (i - 1))) == 1UL)) {
            tmp___65 = 1;
          } else {
            if (__s2_len___1 >= 4UL) {
              tmp___65 = 1;
            } else {
              tmp___65 = 0;
            }
          }
        } else {
          tmp___65 = 0;
        }
      }
      if (tmp___65) {
        {
        tmp___57 = __dyc_funcallvar_15;
        }
      } else {
        {
        tmp___62 = __dyc_funcallvar_16;
        tmp___57 = tmp___62;
        }
      }
    } else {
      {
      tmp___62 = __dyc_funcallvar_17;
      tmp___57 = tmp___62;
      }
    }
    if (tmp___57 > 0) {
      goto while_1_break;
    }
    *(patterns + i) = *(patterns + (i - 1));
    i --;
  }
  while_1_break:  ;
  *(patterns + i) = __dyc_funcallvar_18;
  if ((unsigned long )ig == (unsigned long )root_ignores) {
    tmp___66 = "root ignores";
  } else {
    tmp___66 = (char const   *)ig->abs_path;
  }

  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(pattern_len);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
  __dyc_print_ptr__char(tmp___66);
  __dyc_print_ptr__char(pattern);
}
}
