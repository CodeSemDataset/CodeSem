#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ ssize_t i ;
  size_t pos ;
  int tmp___3 ;
  int __res___0 ;
  int __attribute__((__leaf__))  tmp___6 ;
  __int32_t const   **tmp___7 ;
  char const   *s ;
  char const   *find ;
  int case_insensitive ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  __int32_t const   **__dyc_funcallvar_2 ;

  {
  i = (ssize_t )__dyc_readpre_byte();
  pos = (size_t )__dyc_readpre_byte();
  s = (char const   *)__dyc_read_ptr__char();
  find = (char const   *)__dyc_read_ptr__char();
  case_insensitive = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  tmp___3 = 0;
  __res___0 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  if (i >= 0L) {
    if (case_insensitive) {
      if (sizeof(char const   ) > 1UL) {
        {
        tmp___6 = __dyc_funcallvar_1;
        __res___0 = (int )tmp___6;
        }
      } else {
        {
        tmp___7 = __dyc_funcallvar_2;
        __res___0 = (int )*(*tmp___7 + (int )*(s + pos));
        }
      }
      tmp___3 = __res___0;
    } else {
      tmp___3 = (int )*(s + pos);
    }
    if (! (tmp___3 == (int )*(find + i))) {
      goto __dyc_dummy_label;
    }
  } else {
    goto __dyc_dummy_label;
  }
  pos --;
  i --;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(i);
  __dyc_printpre_byte(pos);
}
}
