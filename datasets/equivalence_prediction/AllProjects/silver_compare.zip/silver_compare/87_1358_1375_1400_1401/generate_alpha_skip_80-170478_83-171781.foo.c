#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ size_t i ;
  int __res ;
  int __attribute__((__leaf__))  tmp___1 ;
  __int32_t const   **tmp___2 ;
  int __res___0 ;
  int __attribute__((__leaf__))  tmp___5 ;
  __int32_t const   **tmp___6 ;
  char const   *find ;
  size_t f_len ;
  size_t *skip_lookup ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  __int32_t const   **__dyc_funcallvar_2 ;
  int __attribute__((__leaf__))  __dyc_funcallvar_3 ;
  __int32_t const   **__dyc_funcallvar_4 ;

  {
  i = (size_t )__dyc_readpre_byte();
  find = (char const   *)__dyc_read_ptr__char();
  f_len = (size_t )__dyc_readpre_byte();
  skip_lookup = __dyc_read_ptr__typdef_size_t();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_3 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __res = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  __res___0 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  *(skip_lookup + (unsigned char )*(find + i)) = f_len - i;
  if (sizeof(char const   ) > 1UL) {
    {
    tmp___1 = __dyc_funcallvar_1;
    __res = (int )tmp___1;
    }
  } else {
    {
    tmp___2 = __dyc_funcallvar_2;
    __res = (int )*(*tmp___2 + (int )*(find + i));
    }
  }
  *(skip_lookup + (unsigned char )__res) = f_len - i;
  if (sizeof(char const   ) > 1UL) {
    {
    tmp___5 = __dyc_funcallvar_3;
    __res___0 = (int )tmp___5;
    }
  } else {
    {
    tmp___6 = __dyc_funcallvar_4;
    __res___0 = (int )*(*tmp___6 + (int )*(find + i));
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__res___0);
}
}
