#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *filename ;
  scandir_baton_t *scandir_baton ;
  char const   *path_start ;
  char const   *extension ;
  char *tmp___20 ;
  size_t filename_len ;
  int tmp___42 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___52 ;
  int tmp___57 ;
  int tmp___58 ;
  int tmp___59 ;
  int tmp___60 ;
  void *baton ;
  char *__dyc_funcallvar_8 ;
  int __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  int __dyc_funcallvar_12 ;
  int __dyc_funcallvar_13 ;
  int __dyc_funcallvar_14 ;
  size_t __dyc_funcallvar_15 ;

  {
  filename = (char const   *)__dyc_read_ptr__char();
  baton = __dyc_read_ptr__void();
  __dyc_funcallvar_8 = __dyc_read_ptr__char();
  __dyc_funcallvar_9 = __dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_readpre_byte();
  __dyc_funcallvar_14 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = (size_t )__dyc_readpre_byte();
  scandir_baton = 0;
  path_start = 0;
  extension = 0;
  tmp___20 = 0;
  filename_len = 0;
  tmp___42 = 0;
  __s1_len___1 = 0;
  __s2_len___1 = 0;
  tmp___52 = 0;
  tmp___57 = 0;
  tmp___58 = 0;
  tmp___59 = 0;
  tmp___60 = 0;
  scandir_baton = (scandir_baton_t *)baton;
  path_start = scandir_baton->path_start;
  tmp___20 = __dyc_funcallvar_8;
  extension = (char const   *)tmp___20;
  if (extension) {
    if (*(extension + 1)) {
      extension ++;
    } else {
      extension = (char const   *)((void *)0);
    }
  }
  filename_len = (size_t )0;
  if (0) {
    if (0) {
      {
      tmp___58 = __dyc_funcallvar_9;
      __s1_len___1 = (unsigned long )tmp___58;
      tmp___59 = __dyc_funcallvar_10;
      __s2_len___1 = (unsigned long )tmp___59;
      }
      if (! ((unsigned long )((void const   *)(filename + 1)) - (unsigned long )((void const   *)filename) == 1UL)) {
        goto _L___4;
      } else {
        if (__s1_len___1 >= 4UL) {
          _L___4:  
          if (! ((unsigned long )((void const   *)("./" + 1)) - (unsigned long )((void const   *)"./") == 1UL)) {
            tmp___60 = 1;
          } else {
            if (__s2_len___1 >= 4UL) {
              tmp___60 = 1;
            } else {
              tmp___60 = 0;
            }
          }
        } else {
          tmp___60 = 0;
        }
      }
      if (tmp___60) {
        {
        tmp___52 = __dyc_funcallvar_11;
        }
      } else {
        {
        tmp___57 = __dyc_funcallvar_12;
        tmp___52 = tmp___57;
        }
      }
    } else {
      {
      tmp___57 = __dyc_funcallvar_13;
      tmp___52 = tmp___57;
      }
    }
    tmp___42 = tmp___52;
  } else {
    {
    tmp___42 = __dyc_funcallvar_14;
    }
  }
  if (tmp___42 == 0) {
    {
    filename_len = __dyc_funcallvar_15;
    filename ++;
    filename_len --;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(filename);
  __dyc_print_ptr__char(path_start);
  __dyc_print_ptr__char(extension);
  __dyc_printpre_byte(filename_len);
  __dyc_printpre_byte(__s1_len___1);
  __dyc_printpre_byte(__s2_len___1);
}
}
