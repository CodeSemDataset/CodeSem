#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ symdir_t *symhash ;
  symdir_t *item_found ;
  unsigned int _hd_bkt ;
  struct UT_hash_handle *_hd_hh_del ;

  {
  symhash = __dyc_read_ptr__typdef_symdir_t();
  item_found = __dyc_read_ptr__typdef_symdir_t();
  _hd_bkt = 0;
  _hd_hh_del = 0;
  if ((unsigned long )item_found->hh.next == (unsigned long )((void *)0)) {
    {


    symhash = (symdir_t *)((void *)0);
    }
  }
  _L:  
  _hd_hh_del = & item_found->hh;
  if ((unsigned long )item_found == (unsigned long )((void *)((char *)(symhash->hh.tbl)->tail - (symhash->hh.tbl)->hho))) {
    (symhash->hh.tbl)->tail = (UT_hash_handle *)((long )item_found->hh.prev + (symhash->hh.tbl)->hho);
  }
  if (item_found->hh.prev) {
    ((UT_hash_handle *)((long )item_found->hh.prev + (symhash->hh.tbl)->hho))->next = item_found->hh.next;
  } else {
    {
    while (1) {
      while_41_continue:  ;
      symhash = (symdir_t *)item_found->hh.next;
      goto while_41_break;
    }
    while_41_break:  ;
    }
  }
  if (_hd_hh_del->next) {
    ((UT_hash_handle *)((long )_hd_hh_del->next + (symhash->hh.tbl)->hho))->prev = _hd_hh_del->prev;
  }
  while (1) {
    while_42_continue:  ;
    _hd_bkt = _hd_hh_del->hashv & ((symhash->hh.tbl)->num_buckets - 1U);
    goto while_42_break;
  }
  while_42_break:  ;
  (((symhash->hh.tbl)->buckets + _hd_bkt)->count) --;
  if ((unsigned long )((symhash->hh.tbl)->buckets + _hd_bkt)->hh_head == (unsigned long )_hd_hh_del) {
    ((symhash->hh.tbl)->buckets + _hd_bkt)->hh_head = _hd_hh_del->hh_next;
  }
  if (_hd_hh_del->hh_prev) {
    (_hd_hh_del->hh_prev)->hh_next = _hd_hh_del->hh_next;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_symdir_t(symhash);
}
}
