#include "../include/dycfoo.h"
#include "../include/lang.i.hd.c.h"
void __dyc_foo(void) 
{ int regex_capacity ;
  char *regex ;
  void *tmp ;
  int regex_length ;
  int subsequent ;
  char *extension ;
  size_t i ;
  int extension_length ;
  size_t tmp___0 ;
  void *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  char *ext_array ;
  size_t num_exts ;
  void *__dyc_funcallvar_1 ;
  size_t __dyc_funcallvar_2 ;
  void *__dyc_funcallvar_3 ;

  {
  ext_array = __dyc_read_ptr__char();
  num_exts = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  __dyc_funcallvar_2 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  regex_capacity = 0;
  regex = 0;
  tmp = 0;
  regex_length = 0;
  subsequent = 0;
  extension = 0;
  i = 0;
  extension_length = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  regex_capacity = 100;
  tmp = __dyc_funcallvar_1;
  regex = (char *)tmp;
  regex_length = 3;
  subsequent = 0;

  i = 0UL;
  while (1) {
    while_0_continue:  ;
    if (! (i < num_exts)) {
      goto while_0_break;
    }
    {
    extension = ext_array + i * 20UL;
    tmp___0 = __dyc_funcallvar_2;
    extension_length = (int )tmp___0;
    }
    {
    while (1) {
      while_1_continue:  ;
      if (! (((regex_length + extension_length) + 3) + subsequent > regex_capacity)) {
        goto while_1_break;
      }
      {
      regex_capacity *= 2;
      tmp___1 = __dyc_funcallvar_3;
      regex = (char *)tmp___1;
      }
    }
    while_1_break:  ;
    }
    if (subsequent) {
      tmp___2 = regex_length;
      regex_length ++;
      *(regex + tmp___2) = (char )'|';
    } else {
      subsequent = 1;
    }
    {

    regex_length += extension_length;
    i ++;
    }
  }
  while_0_break:  ;
  tmp___3 = regex_length;
  regex_length ++;
  *(regex + tmp___3) = (char )')';
  tmp___4 = regex_length;
  regex_length ++;
  *(regex + tmp___4) = (char )'$';
  tmp___5 = regex_length;
  regex_length ++;
  *(regex + tmp___5) = (char)0;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(regex_capacity);
  __dyc_printpre_byte(regex_length);
  __dyc_printpre_byte(subsequent);
  __dyc_print_ptr__char(extension);
}
}
