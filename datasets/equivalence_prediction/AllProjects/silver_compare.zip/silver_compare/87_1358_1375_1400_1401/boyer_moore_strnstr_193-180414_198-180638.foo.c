#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ ssize_t i ;
  size_t pos ;
  int tmp___3 ;
  int __res___0 ;
  int __attribute__((__leaf__))  tmp___6 ;
  __int32_t const   **tmp___7 ;
  size_t tmp___8 ;
  char const   *s ;
  char const   *find ;
  int case_insensitive ;
  int __attribute__((__leaf__))  __dyc_funcallvar_1 ;
  __int32_t const   **__dyc_funcallvar_2 ;
  size_t __dyc_funcallvar_3 ;

  {
  i = (ssize_t )__dyc_readpre_byte();
  pos = (size_t )__dyc_readpre_byte();
  s = (char const   *)__dyc_read_ptr__char();
  find = (char const   *)__dyc_read_ptr__char();
  case_insensitive = __dyc_readpre_byte();
  __dyc_funcallvar_1 = (int __attribute__((__leaf__))  )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_3 = (size_t )__dyc_readpre_byte();
  tmp___3 = 0;
  __res___0 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  while (1) {
    while_12_continue:  ;
    if (i >= 0L) {
      if (case_insensitive) {
        if (sizeof(char const   ) > 1UL) {
          {
          tmp___6 = __dyc_funcallvar_1;
          __res___0 = (int )tmp___6;
          }
        } else {
          {
          tmp___7 = __dyc_funcallvar_2;
          __res___0 = (int )*(*tmp___7 + (int )*(s + pos));
          }
        }
        tmp___3 = __res___0;
      } else {
        tmp___3 = (int )*(s + pos);
      }
      if (! (tmp___3 == (int )*(find + i))) {
        goto while_12_break;
      }
    } else {
      goto while_12_break;
    }
    pos --;
    i --;
  }
  while_12_break:  ;
  if (i < 0L) {
    goto __dyc_dummy_label;
  }
  tmp___8 = __dyc_funcallvar_3;
  pos += tmp___8;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(pos);
}
}
