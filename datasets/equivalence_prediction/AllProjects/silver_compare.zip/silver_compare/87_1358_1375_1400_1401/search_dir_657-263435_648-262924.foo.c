#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  work_queue_t *work_queue ;
  work_queue_t *work_queue_tail ;
  char *dir_full_path ;
  int rc ;
  work_queue_t *queue_item ;
  size_t tmp___6 ;
  void *tmp___7 ;
  ignores *child_ig ;
  size_t tmp___8 ;
  int depth ;
  size_t __dyc_funcallvar_10 ;
  ignores *__dyc_funcallvar_11 ;
  size_t __dyc_funcallvar_12 ;
  ignores *__dyc_funcallvar_13 ;
  size_t __dyc_funcallvar_14 ;
  int __dyc_funcallvar_15 ;
  void *__dyc_funcallvar_16 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  work_queue_tail = __dyc_read_ptr__typdef_work_queue_t();
  dir_full_path = (char *)__dyc_read_ptr__char();
  depth = __dyc_readpre_byte();
  __dyc_funcallvar_10 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_read_ptr__typdef_ignores();
  __dyc_funcallvar_12 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_13 = __dyc_read_ptr__typdef_ignores();
  __dyc_funcallvar_14 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_15 = __dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_read_ptr__void();
  work_queue = 0;
  rc = 0;
  queue_item = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  child_ig = 0;
  tmp___8 = 0;
  if (opts.recurse_dirs) {
    if (depth < opts.max_search_depth) {
      {

      tmp___8 = __dyc_funcallvar_10;
      child_ig = __dyc_funcallvar_11;


      }
    } else {
      if (opts.max_search_depth == -1) {
        {

        tmp___8 = __dyc_funcallvar_12;
        child_ig = __dyc_funcallvar_13;


        }
      } else {
        if (opts.max_search_depth == 25) {
          {

          }
        } else {
          {

          }
        }
      }
    }
  }
  if (opts.file_search_regex) {
    {
    tmp___6 = __dyc_funcallvar_14;
    rc = __dyc_funcallvar_15;
    }
    if (rc < 0) {
      {

      }
      goto __dyc_dummy_label;
    } else {
      if (opts.match_files) {
        {




        opts.match_found = 1;
        }
        goto __dyc_dummy_label;
      }
    }
  }
  tmp___7 = __dyc_funcallvar_16;
  queue_item = (work_queue_t *)tmp___7;
  queue_item->path = dir_full_path;
  queue_item->next = (struct work_queue_t *)((void *)0);

  if ((unsigned long )work_queue_tail == (unsigned long )((void *)0)) {
    work_queue = queue_item;
  } else {
    work_queue_tail->next = queue_item;
  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_76__anonstruct_cli_options_43(opts);
  __dyc_print_ptr__typdef_work_queue_t(work_queue);
  __dyc_printpre_byte(tmp___6);
  __dyc_print_ptr__typdef_ignores(child_ig);
  __dyc_printpre_byte(tmp___8);
}
}
