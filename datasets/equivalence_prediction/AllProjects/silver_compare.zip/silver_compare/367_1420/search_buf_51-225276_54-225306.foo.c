#include "../include/dycfoo.h"
#include "../include/search.i.hd.c.h"
void __dyc_foo(void) 
{ cli_options opts ;
  size_t matches_len ;
  match_t *matches ;
  size_t matches_size ;
  size_t matches_spare ;
  void *tmp___1 ;
  size_t buf_len ;
  void *__dyc_funcallvar_3 ;

  {
  opts = __dyc_read_comp_76__anonstruct_cli_options_43();
  matches = __dyc_read_ptr__typdef_match_t();
  buf_len = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__void();
  matches_len = 0;
  matches_size = 0;
  matches_spare = 0;
  tmp___1 = 0;
  matches_size = 0UL;
  matches = (match_t *)((void *)0);
  matches_spare = 0UL;
  if (opts.query_len == 1) {
    if ((int )*(opts.query + 0) == 46) {
      matches_size = 1UL;
      if ((unsigned long )matches == (unsigned long )((void *)0)) {
        {
        tmp___1 = __dyc_funcallvar_3;
        matches = (match_t *)tmp___1;
        }
      } else {
        matches = matches;
      }
      (matches + 0)->start = 0UL;
      (matches + 0)->end = buf_len;
      matches_len = 1UL;
    } else {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(matches_len);
  __dyc_print_ptr__typdef_match_t(matches);
  __dyc_printpre_byte(matches_size);
  __dyc_printpre_byte(matches_spare);
}
}
