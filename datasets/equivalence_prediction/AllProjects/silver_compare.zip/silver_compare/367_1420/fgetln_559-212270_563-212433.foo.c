#include "../include/dycfoo.h"
#include "../include/util.i.hd.c.h"
void __dyc_foo(void) 
{ char *buf ;
  int c ;
  int used ;
  int len ;
  size_t nsize ;
  char *newbuf ;
  void *tmp ;
  int tmp___0 ;
  int __dyc_funcallvar_1 ;
  void *__dyc_funcallvar_2 ;

  {
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_read_ptr__void();
  buf = 0;
  c = 0;
  used = 0;
  len = 0;
  nsize = 0;
  newbuf = 0;
  tmp = 0;
  tmp___0 = 0;
  buf = (char *)((void *)0);
  used = 0;
  len = 0;

  while (1) {
    while_23_continue:  ;
    {
    c = __dyc_funcallvar_1;
    }
    if (! (c != -1)) {
      goto __dyc_dummy_label;
    }
    if (! buf) {
      goto _L;
    } else {
      if (len >= used) {
        _L:  
        {
        nsize = (unsigned long )(used + 8192);
        tmp = __dyc_funcallvar_2;
        newbuf = (char *)tmp;
        }
        if (! newbuf) {
          {

          }
          if (buf) {
            {

            }
          }
          goto __dyc_dummy_label;
        }
        buf = newbuf;
        used = (int )nsize;
      }
    }
    tmp___0 = len;
    len ++;
    *(buf + tmp___0) = (char )c;
    if (c == 10) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(buf);
  __dyc_printpre_byte(used);
  __dyc_printpre_byte(len);
  __dyc_printpre_byte(nsize);
}
}
