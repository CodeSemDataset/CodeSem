#include "../include/dycfoo.h"
#include "../include/ignore.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *filename ;
  scandir_baton_t *scandir_baton ;
  char const   *extension ;
  size_t filename_len ;
  int tmp___42 ;
  ignores const   *ig ;
  int match_pos ;
  int tmp___63 ;
  int tmp___64 ;
  int rv ;
  int tmp___65 ;
  int tmp___66 ;
  size_t __dyc_funcallvar_15 ;
  int __dyc_funcallvar_16 ;
  int __dyc_funcallvar_17 ;
  int __dyc_funcallvar_18 ;
  size_t __dyc_funcallvar_19 ;
  int __dyc_funcallvar_20 ;

  {
  filename = (char const   *)__dyc_read_ptr__char();
  scandir_baton = __dyc_read_ptr__typdef_scandir_baton_t();
  extension = (char const   *)__dyc_read_ptr__char();
  filename_len = (size_t )__dyc_readpre_byte();
  tmp___42 = __dyc_readpre_byte();
  __dyc_funcallvar_15 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_16 = __dyc_readpre_byte();
  __dyc_funcallvar_17 = __dyc_readpre_byte();
  __dyc_funcallvar_18 = __dyc_readpre_byte();
  __dyc_funcallvar_19 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_20 = __dyc_readpre_byte();
  ig = 0;
  match_pos = 0;
  tmp___63 = 0;
  tmp___64 = 0;
  rv = 0;
  tmp___65 = 0;
  tmp___66 = 0;
  if (tmp___42 == 0) {
    {
    filename_len = __dyc_funcallvar_15;
    filename ++;
    filename_len --;
    }
  }
  ig = scandir_baton->ig;
  while (1) {
    while_8_continue:  ;
    if (! ((unsigned long )ig != (unsigned long )((void *)0))) {
      goto __dyc_dummy_label;
    }
    if (extension) {
      {
      tmp___63 = __dyc_funcallvar_16;
      match_pos = tmp___63;
      }
      if (match_pos >= 0) {
        {

        }
        goto __dyc_dummy_label;
      }
    }
    {
    tmp___64 = __dyc_funcallvar_17;
    }
    if (tmp___64) {
      goto __dyc_dummy_label;
    }
    {
    tmp___66 = __dyc_funcallvar_18;
    }
    if (tmp___66) {
      if (! filename_len) {
        {
        filename_len = __dyc_funcallvar_19;
        }
      }
      if ((int const   )*(filename + (filename_len - 1UL)) != 47) {
        {

        tmp___65 = __dyc_funcallvar_20;
        rv = tmp___65;

        }
        if (rv) {
          goto __dyc_dummy_label;
        }
      }
    }
    ig = (ignores const   *)ig->parent;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(filename);
  __dyc_printpre_byte(filename_len);
}
}
