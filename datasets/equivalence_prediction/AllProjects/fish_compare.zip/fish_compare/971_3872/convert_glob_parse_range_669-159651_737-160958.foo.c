#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL is_negative ;
  BOOL separator_seen ;
  BOOL has_prev_c ;
  PCRE2_SPTR32 pattern ;
  PCRE2_SPTR32 char_start ;
  uint32_t c ;
  uint32_t prev_c ;
  int class_index ;
  BOOL tmp___0 ;
  PCRE2_SPTR32 tmp___1 ;
  PCRE2_SPTR32 tmp___2 ;
  PCRE2_SPTR32 tmp___3 ;
  PCRE2_SPTR32 *from ;
  PCRE2_SPTR32 pattern_end ;
  PCRE2_UCHAR32 separator ;
  PCRE2_UCHAR32 escape ;
  int __dyc_funcallvar_1 ;
  BOOL __dyc_funcallvar_2 ;

  {
  is_negative = __dyc_readpre_byte();
  has_prev_c = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  c = (uint32_t )__dyc_readpre_byte();
  prev_c = (uint32_t )__dyc_readpre_byte();
  from = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  separator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  escape = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  separator_seen = 0;
  char_start = 0;
  class_index = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  if (c == 91U) {
    if (*pattern == 58U) {
      {
      *from = pattern;
      class_index = __dyc_funcallvar_1;
      }
      if (class_index != 0) {
        pattern = *from;
        has_prev_c = 0;
        prev_c = 0U;
        if (! is_negative) {
          {
          tmp___0 = __dyc_funcallvar_2;
          }
          if (tmp___0) {
            separator_seen = 1;
          }
        }
        goto __dyc_dummy_label;
      }
    } else {
      goto _L___3;
    }
  } else {
    _L___3:  
    if (c == 45U) {
      if (has_prev_c) {
        if (*pattern != 93U) {
          {

          char_start = pattern;
          tmp___1 = pattern;
          pattern ++;
          c = (unsigned int )*tmp___1;
          }
          if ((unsigned long )pattern >= (unsigned long )pattern_end) {
            goto __dyc_dummy_label;
          }
          if (escape != 0U) {
            if (c == escape) {
              char_start = pattern;
              tmp___2 = pattern;
              pattern ++;
              c = (unsigned int )*tmp___2;
            } else {
              goto _L___0;
            }
          } else {
            _L___0:  
            if (c == 91U) {
              if (*pattern == 58U) {
                *from = pattern;
                goto __dyc_dummy_label;
              }
            }
          }
          if (prev_c > c) {
            *from = pattern;
            goto __dyc_dummy_label;
          }
          if (prev_c < separator) {
            if (separator < c) {
              separator_seen = 1;
            }
          }
          has_prev_c = 0;
          prev_c = 0U;
        } else {
          goto _L___2;
        }
      } else {
        goto _L___2;
      }
    } else {
      _L___2:  
      if (escape != 0U) {
        if (c == escape) {
          char_start = pattern;
          tmp___3 = pattern;
          pattern ++;
          c = (unsigned int )*tmp___3;
          if ((unsigned long )pattern >= (unsigned long )pattern_end) {
            goto __dyc_dummy_label;
          }
        }
      }
      has_prev_c = 1;
      prev_c = c;
    }
  }
  if (c == 91U) {
    {

    }
  } else {
    if (c == 93U) {
      {

      }
    } else {
      if (c == 92U) {
        {

        }
      } else {
        if (c == 45U) {
          {

          }
        }
      }
    }
  }
  if (c == separator) {
    separator_seen = 1;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(separator_seen);
  __dyc_printpre_byte(has_prev_c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(char_start);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(prev_c);
}
}
