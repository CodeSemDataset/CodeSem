#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL is_negative ;
  BOOL has_prev_c ;
  PCRE2_SPTR32 pattern ;
  uint32_t prev_c ;
  int len ;
  PCRE2_SPTR32 *from ;
  PCRE2_SPTR32 pattern_end ;
  pcre2_output_context *out ;
  PCRE2_UCHAR32 separator ;
  BOOL with_escape ;
  BOOL no_wildsep ;

  {
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  from = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  out = __dyc_read_ptr__typdef_pcre2_output_context();
  separator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  with_escape = __dyc_readpre_byte();
  no_wildsep = __dyc_readpre_byte();
  is_negative = 0;
  has_prev_c = 0;
  prev_c = 0;
  len = 0;
  if ((unsigned long )pattern >= (unsigned long )pattern_end) {
    *from = pattern;
    goto __dyc_dummy_label;
  }
  if (*pattern == 33U) {
    goto _L;
  } else {
    if (*pattern == 94U) {
      _L:  
      pattern ++;
      if ((unsigned long )pattern >= (unsigned long )pattern_end) {
        *from = pattern;
        goto __dyc_dummy_label;
      }
      is_negative = 1;
      out->out_str[0] = (unsigned char )'[';
      out->out_str[1] = (unsigned char )'^';
      len = 2;
      if (! no_wildsep) {
        if (with_escape) {
          out->out_str[len] = (unsigned char )'\\';
          len ++;
        }
        out->out_str[len] = (unsigned char )separator;
      }
      {

      }
    } else {
      {

      }
    }
  }
  has_prev_c = 0;
  prev_c = 0U;
  if (*pattern == 93U) {
    {
    out->out_str[0] = (unsigned char )'\\';
    out->out_str[1] = (unsigned char )']';

    has_prev_c = 1;
    prev_c = (unsigned int )']';
    pattern ++;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(is_negative);
  __dyc_printpre_byte(has_prev_c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern);
  __dyc_printpre_byte(prev_c);
  __dyc_printpre_byte(len);
}
}
