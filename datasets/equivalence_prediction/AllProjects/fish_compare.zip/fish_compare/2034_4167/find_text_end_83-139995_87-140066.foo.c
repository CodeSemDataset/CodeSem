#include "../include/dycfoo.h"
#include "../include/pcre2_substitute.i.hd.c.h"
void __dyc_foo(void) 
{ int rc ;
  uint32_t nestlevel ;
  BOOL literal ;
  PCRE2_SPTR32 ptr ;
  int erc ;
  int errorcode ;
  PCRE2_SPTR32 *ptrptr ;
  PCRE2_SPTR32 ptrend ;
  BOOL last ;
  int __dyc_funcallvar_1 ;

  {
  errorcode = __dyc_readpre_byte();
  ptrptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  last = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  rc = 0;
  nestlevel = 0;
  literal = 0;
  ptr = 0;
  erc = 0;
  rc = 0;
  nestlevel = (uint32_t )0;
  literal = 0;
  ptr = *ptrptr;
  while (1) {
    while_0_continue:  ;
    if (! ((unsigned long )ptr < (unsigned long )ptrend)) {
      goto __dyc_dummy_label;
    }
    if (literal) {
      if (*(ptr + 0) == 92U) {
        if ((unsigned long )ptr < (unsigned long )(ptrend - 1)) {
          if (*(ptr + 1) == 69U) {
            literal = 0;
            ptr ++;
          }
        }
      }
    } else {
      if (*ptr == 125U) {
        if (nestlevel == 0U) {
          goto __dyc_dummy_label;
        }
        nestlevel --;
      } else {
        if (*ptr == 58U) {
          if (! last) {
            if (nestlevel == 0U) {
              goto __dyc_dummy_label;
            } else {
              goto _L___0;
            }
          } else {
            goto _L___0;
          }
        } else {
          _L___0:  
          if (*ptr == 36U) {
            if ((unsigned long )ptr < (unsigned long )(ptrend - 1)) {
              if (*(ptr + 1) == 123U) {
                nestlevel ++;
                ptr ++;
              }
            }
          } else {
            if (*ptr == 92U) {
              if ((unsigned long )ptr < (unsigned long )(ptrend - 1)) {
                if ((int )*(ptr + 1) == 76) {
                  goto switch_1_76;
                } else {
                  if ((int )*(ptr + 1) == 108) {
                    goto switch_1_76;
                  } else {
                    if ((int )*(ptr + 1) == 85) {
                      goto switch_1_76;
                    } else {
                      if ((int )*(ptr + 1) == 117) {
                        goto switch_1_76;
                      } else {
                        if (0) {
                          switch_1_76:  
                          switch_1_108:  
                          switch_1_85:  
                          switch_1_117:  
                          ptr ++;
                          goto __Cont;
                        } else {
                          switch_1_break:  ;
                        }
                      }
                    }
                  }
                }
              }
              {
              ptr ++;
              erc = __dyc_funcallvar_1;
              ptr --;
              }
              if (errorcode != 0) {
                rc = errorcode;
                goto __dyc_dummy_label;
              }
              if (erc == 0) {
                goto switch_2_0;
              } else {
                if (erc == 25) {
                  goto switch_2_0;
                } else {
                  if (erc == 26) {
                    goto switch_2_26;
                  } else {
                    {
                    goto switch_2_default;
                    if (0) {
                      switch_2_0:  
                      switch_2_25:  
                      goto switch_2_break;
                      switch_2_26:  
                      literal = 1;
                      goto switch_2_break;
                      switch_2_default:  
                      rc = -57;
                      goto __dyc_dummy_label;
                    } else {
                      switch_2_break:  ;
                    }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    __Cont:  
    ptr ++;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(rc);
  __dyc_printpre_byte(nestlevel);
  __dyc_printpre_byte(literal);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(erc);
}
}
