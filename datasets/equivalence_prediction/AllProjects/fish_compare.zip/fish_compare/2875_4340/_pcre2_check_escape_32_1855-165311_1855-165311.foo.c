#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL utf ;
  PCRE2_SPTR32 ptr ;
  uint32_t c ;
  PCRE2_SPTR32 tmp___7 ;
  int *errorcodeptr ;
  uint32_t extra_options ;

  {
  utf = __dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  c = (uint32_t )__dyc_readpre_byte();
  errorcodeptr = __dyc_read_ptr__int();
  extra_options = (uint32_t )__dyc_readpre_byte();
  tmp___7 = 0;
  tmp___7 = ptr;
  ptr ++;
  if (*tmp___7 == 125U) {
    if (utf) {
      if (c >= 55296U) {
        if (c <= 57343U) {
          if ((extra_options & 1U) == 0U) {
            ptr --;
            *errorcodeptr = 173;
          }
        }
      }
    }
  } else {
    ptr --;
    *errorcodeptr = 164;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
}
}
