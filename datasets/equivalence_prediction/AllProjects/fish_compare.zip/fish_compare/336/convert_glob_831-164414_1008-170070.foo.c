#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ pcre2_output_context out ;
  PCRE2_SPTR32 pattern_start ;
  PCRE2_SPTR32 pattern_end ;
  PCRE2_UCHAR32 separator ;
  PCRE2_UCHAR32 escape ;
  PCRE2_UCHAR32 c ;
  BOOL no_wildsep ;
  BOOL no_starstar ;
  BOOL in_atomic ;
  BOOL after_starstar ;
  BOOL no_slash_z ;
  BOOL is_start ;
  BOOL after_separator ;
  int result ;
  PCRE2_SPTR32 tmp___1 ;
  int tmp___2 ;
  PCRE2_SPTR32 tmp___3 ;
  char *tmp___5 ;
  PCRE2_SPTR32 pattern ;
  PCRE2_UCHAR32 *use_buffer ;
  BOOL dummyrun ;
  int __dyc_funcallvar_2 ;
  char *__dyc_funcallvar_3 ;

  {
  out = __dyc_read_comp_85pcre2_output_context();
  pattern_start = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  separator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  escape = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  no_wildsep = __dyc_readpre_byte();
  no_starstar = __dyc_readpre_byte();
  in_atomic = __dyc_readpre_byte();
  after_starstar = __dyc_readpre_byte();
  no_slash_z = __dyc_readpre_byte();
  is_start = __dyc_readpre_byte();
  result = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  use_buffer = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  dummyrun = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__char();
  c = 0;
  after_separator = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___5 = 0;
  if ((unsigned long )pattern < (unsigned long )pattern_end) {
    if (*(pattern + 0) == 42U) {
      if (no_wildsep) {
        is_start = 0;
      } else {
        if (! no_starstar) {
          if ((unsigned long )(pattern + 1) < (unsigned long )pattern_end) {
            if (*(pattern + 1) == 42U) {
              is_start = 0;
            }
          }
        }
      }
    }
  }
  if (is_start) {
    {
    out.out_str[0] = (unsigned char )'\\';
    out.out_str[1] = (unsigned char )'A';

    }
  }
  while (1) {
    while_21_continue:  ;
    if (! ((unsigned long )pattern < (unsigned long )pattern_end)) {
      goto while_21_break;
    }
    tmp___1 = pattern;
    pattern ++;
    c = (unsigned int )*tmp___1;
    if (c == 42U) {
      is_start = (unsigned long )pattern == (unsigned long )(pattern_start + 1);
      if (in_atomic) {
        {

        in_atomic = 0;
        }
      }
      if (! no_starstar) {
        if ((unsigned long )pattern < (unsigned long )pattern_end) {
          if (*pattern == 42U) {
            if (is_start) {
              tmp___2 = 1;
            } else {
              if (*(pattern + -2) == (PCRE2_UCHAR32 const   )separator) {
                tmp___2 = 1;
              } else {
                tmp___2 = 0;
              }
            }
            after_separator = tmp___2;
            {
            while (1) {
              while_22_continue:  ;
              pattern ++;
              if ((unsigned long )pattern < (unsigned long )pattern_end) {
                if (! (*pattern == 42U)) {
                  goto while_22_break;
                }
              } else {
                goto while_22_break;
              }
            }
            while_22_break:  ;
            }
            if ((unsigned long )pattern >= (unsigned long )pattern_end) {
              no_slash_z = 1;
              goto while_21_break;
            }
            after_starstar = 1;
            if (after_separator) {
              if (escape != 0U) {
                if (*pattern == (PCRE2_UCHAR32 const   )escape) {
                  if ((unsigned long )(pattern + 1) < (unsigned long )pattern_end) {
                    if (*(pattern + 1) == (PCRE2_UCHAR32 const   )separator) {
                      pattern ++;
                    }
                  }
                }
              }
            }
            if (is_start) {
              if (*pattern != (PCRE2_UCHAR32 const   )separator) {
                goto while_21_continue;
              }
              {
              out.out_str[0] = (unsigned char )'(';
              out.out_str[1] = (unsigned char )'?';
              out.out_str[2] = (unsigned char )':';
              out.out_str[3] = (unsigned char )'\\';
              out.out_str[4] = (unsigned char )'A';
              out.out_str[5] = (unsigned char )'|';



              pattern ++;
              }
              goto while_21_continue;
            }
            {

            }
            if (! after_separator) {
              {
              out.out_str[0] = (unsigned char )'.';
              out.out_str[1] = (unsigned char )'*';
              out.out_str[2] = (unsigned char )'?';

              }
              goto while_21_continue;
            } else {
              if (*pattern != (PCRE2_UCHAR32 const   )separator) {
                {
                out.out_str[0] = (unsigned char )'.';
                out.out_str[1] = (unsigned char )'*';
                out.out_str[2] = (unsigned char )'?';

                }
                goto while_21_continue;
              }
            }
            {
            out.out_str[0] = (unsigned char )'(';
            out.out_str[1] = (unsigned char )'?';
            out.out_str[2] = (unsigned char )':';
            out.out_str[3] = (unsigned char )'.';
            out.out_str[4] = (unsigned char )'*';
            out.out_str[5] = (unsigned char )'?';


            out.out_str[0] = (unsigned char )')';
            out.out_str[1] = (unsigned char )'?';
            out.out_str[2] = (unsigned char )'?';

            pattern ++;
            }
            goto while_21_continue;
          }
        }
      }
      if ((unsigned long )pattern < (unsigned long )pattern_end) {
        if (*pattern == 42U) {
          {
          while (1) {
            while_23_continue:  ;
            pattern ++;
            if ((unsigned long )pattern < (unsigned long )pattern_end) {
              if (! (*pattern == 42U)) {
                goto while_23_break;
              }
            } else {
              goto while_23_break;
            }
          }
          while_23_break:  ;
          }
        }
      }
      if (no_wildsep) {
        if ((unsigned long )pattern >= (unsigned long )pattern_end) {
          no_slash_z = 1;
          goto while_21_break;
        }
        if (is_start) {
          goto while_21_continue;
        }
      }
      if (! is_start) {
        if (after_starstar) {
          {
          out.out_str[0] = (unsigned char )'(';
          out.out_str[1] = (unsigned char )'?';
          out.out_str[2] = (unsigned char )'>';

          in_atomic = 1;
          }
        } else {
          {

          }
        }
      }
      if (no_wildsep) {
        {

        }
      } else {
        {

        }
      }
      out.out_str[0] = (unsigned char )'*';
      out.out_str[1] = (unsigned char )'?';
      if ((unsigned long )pattern >= (unsigned long )pattern_end) {
        out.out_str[1] = (unsigned char )'+';
      }
      {

      }
      goto while_21_continue;
    }
    if (c == 63U) {
      if (no_wildsep) {
        {

        }
      } else {
        {

        }
      }
      goto while_21_continue;
    }
    if (c == 91U) {
      {
      result = __dyc_funcallvar_2;
      }
      if (result != 0) {
        goto while_21_break;
      }
      goto while_21_continue;
    }
    if (escape != 0U) {
      if (c == escape) {
        if ((unsigned long )pattern >= (unsigned long )pattern_end) {
          result = -64;
          goto while_21_break;
        }
        tmp___3 = pattern;
        pattern ++;
        c = (unsigned int )*tmp___3;
      }
    }
    if (c < 128U) {
      {
      tmp___5 = __dyc_funcallvar_3;
      }
      if ((unsigned long )tmp___5 != (unsigned long )((void *)0)) {
        {

        }
      }
    }
    {

    }
  }
  while_21_break:  ;
  if (result == 0) {
    if (! no_slash_z) {
      {
      out.out_str[0] = (unsigned char )'\\';
      out.out_str[1] = (unsigned char )'z';

      }
    }
    if (in_atomic) {
      {

      }
    }
    {

    }
    if (! dummyrun) {
      if (out.output_size != (unsigned long )(out.output - use_buffer)) {
        result = -48;
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(after_starstar);
  __dyc_printpre_byte(is_start);
  __dyc_printpre_byte(after_separator);
  __dyc_printpre_byte(result);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern);
}
}
