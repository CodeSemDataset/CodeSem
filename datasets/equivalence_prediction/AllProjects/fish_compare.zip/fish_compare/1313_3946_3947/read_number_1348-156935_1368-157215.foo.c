#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ int sign ;
  uint32_t n ;
  PCRE2_SPTR32 ptr ;
  BOOL yield ;
  PCRE2_SPTR32 *ptrptr ;
  int32_t allow_sign ;
  int *intptr ;
  int *errorcodeptr ;

  {
  sign = __dyc_readpre_byte();
  n = (uint32_t )__dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  ptrptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  allow_sign = __dyc_readpre_byte();
  intptr = __dyc_read_ptr__int();
  errorcodeptr = __dyc_read_ptr__int();
  yield = 0;
  if (allow_sign >= 0) {
    if (sign != 0) {
      if (n == 0U) {
        *errorcodeptr = 126;
        goto EXIT;
      }
      if (sign > 0) {
        n += (uint32_t )allow_sign;
      } else {
        if ((int )n > allow_sign) {
          *errorcodeptr = 115;
          goto EXIT;
        } else {
          n = (uint32_t )(allow_sign + 1) - n;
        }
      }
    }
  }
  yield = 1;
  EXIT: 
  *intptr = (int )n;
  *ptrptr = ptr;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(yield);
}
}
