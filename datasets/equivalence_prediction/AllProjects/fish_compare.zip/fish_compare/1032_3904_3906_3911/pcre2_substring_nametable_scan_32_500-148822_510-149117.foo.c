#include "../include/dycfoo.h"
#include "../include/pcre2_substring.i.hd.c.h"
void __dyc_foo(void) 
{ uint16_t entrysize ;
  PCRE2_SPTR32 nametable ;
  PCRE2_SPTR32 entry ;
  PCRE2_SPTR32 first ;
  PCRE2_SPTR32 last ;
  PCRE2_SPTR32 lastentry ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  PCRE2_SPTR32 *firstptr ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;

  {
  entrysize = (uint16_t )__dyc_readpre_byte();
  nametable = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  entry = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  first = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  last = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  lastentry = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  firstptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  while (1) {
    while_6_continue:  ;
    if (! ((unsigned long )first > (unsigned long )nametable)) {
      goto while_6_break;
    }
    {
    tmp___0 = __dyc_funcallvar_2;
    }
    if (tmp___0 != 0) {
      goto while_6_break;
    }
    first -= (int )entrysize;
  }
  while_6_break:  ;
  while (1) {
    while_7_continue:  ;
    if (! ((unsigned long )last < (unsigned long )lastentry)) {
      goto while_7_break;
    }
    {
    tmp___1 = __dyc_funcallvar_3;
    }
    if (tmp___1 != 0) {
      goto while_7_break;
    }
    last += (int )entrysize;
  }
  while_7_break:  ;
  if ((unsigned long )firstptr == (unsigned long )((void *)0)) {
    if ((unsigned long )first == (unsigned long )last) {
      tmp___2 = (int )*(entry + 0);
    } else {
      tmp___2 = -50;
    }
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___2);
}
}
