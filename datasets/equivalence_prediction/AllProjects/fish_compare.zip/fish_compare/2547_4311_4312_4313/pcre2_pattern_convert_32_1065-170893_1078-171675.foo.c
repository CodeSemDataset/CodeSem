#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 dummy_buffer[100] ;
  PCRE2_UCHAR32 *use_buffer ;
  size_t use_length ;
  BOOL utf ;
  uint32_t pattype ;
  PCRE2_SPTR32 pattern ;
  size_t plength ;
  uint32_t options ;
  size_t *bufflenptr ;
  size_t __dyc_funcallvar_1 ;

  {
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  plength = (size_t )__dyc_readpre_byte();
  options = (uint32_t )__dyc_readpre_byte();
  bufflenptr = __dyc_read_ptr__typdef_size_t();
  __dyc_funcallvar_1 = (size_t )__dyc_readpre_byte();
  use_buffer = 0;
  use_length = 0;
  utf = 0;
  pattype = 0;
  use_buffer = dummy_buffer;
  use_length = (size_t )100;
  utf = (options & 1U) != 0U;
  pattype = options & 28U;
  if ((unsigned long )pattern == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  } else {
    if ((unsigned long )bufflenptr == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
  }
  if ((options & 4294967168U) != 0U) {
    *bufflenptr = 0UL;
    goto __dyc_dummy_label;
  } else {
    if ((pattype & (~ pattype + 1U)) != pattype) {
      *bufflenptr = 0UL;
      goto __dyc_dummy_label;
    } else {
      if (pattype == 0U) {
        *bufflenptr = 0UL;
        goto __dyc_dummy_label;
      }
    }
  }
  if (plength == 0xffffffffUL) {
    {
    plength = __dyc_funcallvar_1;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(use_buffer);
  __dyc_printpre_byte(use_length);
  __dyc_printpre_byte(utf);
  __dyc_printpre_byte(pattype);
  __dyc_printpre_byte(plength);
}
}
