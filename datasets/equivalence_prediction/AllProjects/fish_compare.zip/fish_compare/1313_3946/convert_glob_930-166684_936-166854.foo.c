#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 pattern_end ;
  BOOL no_wildsep ;
  BOOL no_slash_z ;
  BOOL is_start ;
  PCRE2_SPTR32 pattern ;

  {
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  no_wildsep = __dyc_readpre_byte();
  is_start = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  no_slash_z = 0;
  if ((unsigned long )pattern < (unsigned long )pattern_end) {
    if (*pattern == 42U) {
      {
      while (1) {
        while_23_continue:  ;
        pattern ++;
        if ((unsigned long )pattern < (unsigned long )pattern_end) {
          if (! (*pattern == 42U)) {
            goto while_23_break;
          }
        } else {
          goto while_23_break;
        }
      }
      while_23_break:  ;
      }
    }
  }
  if (no_wildsep) {
    if ((unsigned long )pattern >= (unsigned long )pattern_end) {
      no_slash_z = 1;
      goto __dyc_dummy_label;
    }
    if (is_start) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(no_slash_z);
}
}
