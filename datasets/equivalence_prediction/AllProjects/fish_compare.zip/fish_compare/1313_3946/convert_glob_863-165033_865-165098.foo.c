#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 pattern_end ;
  PCRE2_UCHAR32 separator ;
  BOOL is_start ;
  BOOL after_separator ;
  int tmp___2 ;
  PCRE2_SPTR32 pattern ;

  {
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  separator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  is_start = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  after_separator = 0;
  tmp___2 = 0;
  if (is_start) {
    tmp___2 = 1;
  } else {
    if (*(pattern + -2) == (PCRE2_UCHAR32 const   )separator) {
      tmp___2 = 1;
    } else {
      tmp___2 = 0;
    }
  }
  after_separator = tmp___2;
  while (1) {
    while_22_continue:  ;
    pattern ++;
    if ((unsigned long )pattern < (unsigned long )pattern_end) {
      if (! (*pattern == 42U)) {
        goto __dyc_dummy_label;
      }
    } else {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(after_separator);
}
}
