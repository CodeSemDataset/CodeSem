#include "../include/dycfoo.h"
#include "../include/pcre2_serialize.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t *bytes ;
  int32_t i ;
  size_t total_size ;
  pcre2_real_code_32 const   *re ;
  uint8_t const   *tables ;
  pcre2_serialized_data *data ;
  pcre2_memctl const   *memctl ;
  pcre2_memctl const   *tmp ;
  void *tmp___0 ;
  pcre2_code_32 const   **codes ;
  int32_t number_of_codes ;
  uint8_t **serialized_bytes ;
  size_t *serialized_size ;
  void *__dyc_funcallvar_1 ;

  {
  tmp = (pcre2_memctl const   *)__dyc_read_ptr__typdef_pcre2_memctl();
  codes = (pcre2_code_32 const   **)__dyc_read_ptr__ptr__typdef_pcre2_code_32();
  number_of_codes = __dyc_readpre_byte();
  serialized_bytes = __dyc_read_ptr__ptr__typdef_uint8_t();
  serialized_size = __dyc_read_ptr__typdef_size_t();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  bytes = 0;
  i = 0;
  total_size = 0;
  re = 0;
  tables = 0;
  data = 0;
  memctl = 0;
  tmp___0 = 0;
  memctl = tmp;
  if ((unsigned long )codes == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  } else {
    if ((unsigned long )serialized_bytes == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    } else {
      if ((unsigned long )serialized_size == (unsigned long )((void *)0)) {
        goto __dyc_dummy_label;
      }
    }
  }
  if (number_of_codes <= 0) {
    goto __dyc_dummy_label;
  }
  total_size = sizeof(pcre2_serialized_data ) + 1088UL;
  tables = (uint8_t const   *)((void *)0);
  i = 0;
  while (1) {
    while_0_continue:  ;
    if (! (i < number_of_codes)) {
      goto while_0_break;
    }
    if ((unsigned long )*(codes + i) == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
    re = *(codes + i);
    if ((unsigned long )re->magic_number != 1346589253UL) {
      goto __dyc_dummy_label;
    }
    if ((unsigned long )tables == (unsigned long )((void *)0)) {
      tables = (uint8_t const   *)re->tables;
    } else {
      if ((unsigned long )tables != (unsigned long )re->tables) {
        goto __dyc_dummy_label;
      }
    }
    total_size += (size_t )re->blocksize;
    i ++;
  }
  while_0_break:  ;
  tmp___0 = __dyc_funcallvar_1;
  bytes = (uint8_t *)tmp___0;
  if ((unsigned long )bytes == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }

  bytes += sizeof(pcre2_memctl );
  data = (pcre2_serialized_data *)bytes;
  data->magic = 1347564115U;
  data->version = (unsigned int )(10 | (36 << 16));
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(total_size);
  __dyc_print_ptr__typdef_uint8_t(tables);
  __dyc_print_ptr__typdef_pcre2_memctl(memctl);
}
}
