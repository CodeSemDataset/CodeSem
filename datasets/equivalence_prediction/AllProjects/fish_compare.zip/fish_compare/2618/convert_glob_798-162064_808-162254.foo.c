#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 pattern_start ;
  PCRE2_SPTR32 pattern_end ;
  PCRE2_UCHAR32 separator ;
  PCRE2_UCHAR32 escape ;
  BOOL no_wildsep ;
  BOOL no_starstar ;
  BOOL in_atomic ;
  BOOL after_starstar ;
  BOOL no_slash_z ;
  int result ;
  uint32_t options ;
  PCRE2_SPTR32 pattern ;
  size_t plength ;
  BOOL utf ;
  size_t *bufflenptr ;
  pcre2_convert_context_32 *ccontext ;

  {
  options = (uint32_t )__dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  plength = (size_t )__dyc_readpre_byte();
  utf = __dyc_readpre_byte();
  bufflenptr = __dyc_read_ptr__typdef_size_t();
  ccontext = __dyc_read_ptr__typdef_pcre2_convert_context_32();
  pattern_start = 0;
  pattern_end = 0;
  separator = 0;
  escape = 0;
  no_wildsep = 0;
  no_starstar = 0;
  in_atomic = 0;
  after_starstar = 0;
  no_slash_z = 0;
  result = 0;
  pattern_start = pattern;
  pattern_end = pattern + plength;
  separator = ccontext->glob_separator;
  escape = ccontext->glob_escape;
  no_wildsep = (options & 48U) != 0U;
  no_starstar = (options & 80U) != 0U;
  in_atomic = 0;
  after_starstar = 0;
  no_slash_z = 0;
  result = 0;
  if (utf) {
    if (separator >= 128U) {
      *bufflenptr = 0UL;
      goto __dyc_dummy_label;
    } else {
      if (escape >= 128U) {
        *bufflenptr = 0UL;
        goto __dyc_dummy_label;
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern_start);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern_end);
  __dyc_printpre_byte(escape);
  __dyc_printpre_byte(no_wildsep);
  __dyc_printpre_byte(no_starstar);
  __dyc_printpre_byte(in_atomic);
  __dyc_printpre_byte(after_starstar);
  __dyc_printpre_byte(no_slash_z);
  __dyc_printpre_byte(result);
}
}
