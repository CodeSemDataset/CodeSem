#include "../include/dycfoo.h"
#include "../include/pcre2_substring.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  int count ;
  int count2 ;
  size_t size ;
  size_t *lensp ;
  pcre2_memctl *memp ;
  PCRE2_UCHAR32 **listp ;
  PCRE2_UCHAR32 *sp ;
  size_t *ovector ;
  PCRE2_UCHAR32 **tmp___0 ;
  size_t *tmp___1 ;
  PCRE2_UCHAR32 *tmp___2 ;
  PCRE2_UCHAR32 ***listptr ;
  size_t **lengthsptr ;

  {
  count = __dyc_readpre_byte();
  count2 = __dyc_readpre_byte();
  memp = __dyc_read_ptr__typdef_pcre2_memctl();
  ovector = __dyc_read_ptr__typdef_size_t();
  listptr = __dyc_read_ptr__ptr__ptr__typdef_PCRE2_UCHAR32();
  lengthsptr = __dyc_read_ptr__ptr__typdef_size_t();
  i = 0;
  size = 0;
  lensp = 0;
  listp = 0;
  sp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  if ((unsigned long )memp == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  listp = (PCRE2_UCHAR32 **)((char *)memp + sizeof(pcre2_memctl ));
  *listptr = listp;
  lensp = (size_t *)((char *)listp + sizeof(PCRE2_UCHAR32 *) * (unsigned long )(count + 1));
  if ((unsigned long )lengthsptr == (unsigned long )((void *)0)) {
    sp = (PCRE2_UCHAR32 *)lensp;
    lensp = (size_t *)((void *)0);
  } else {
    *lengthsptr = lensp;
    sp = (PCRE2_UCHAR32 *)((char *)lensp + sizeof(size_t ) * (unsigned long )count);
  }
  i = 0;
  while (1) {
    while_4_continue:  ;
    if (! (i < count2)) {
      goto __dyc_dummy_label;
    }
    if (*(ovector + (i + 1)) > *(ovector + i)) {
      size = *(ovector + (i + 1)) - *(ovector + i);
    } else {
      size = 0UL;
    }
    if (size != 0UL) {
      {

      }
    }
    tmp___0 = listp;
    listp ++;
    *tmp___0 = sp;
    if ((unsigned long )lensp != (unsigned long )((void *)0)) {
      tmp___1 = lensp;
      lensp ++;
      *tmp___1 = size;
    }
    sp += size;
    tmp___2 = sp;
    sp ++;
    *tmp___2 = 0U;
    i += 2;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_size_t(lensp);
  __dyc_print_ptr__ptr__typdef_PCRE2_UCHAR32(listp);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(sp);
}
}
