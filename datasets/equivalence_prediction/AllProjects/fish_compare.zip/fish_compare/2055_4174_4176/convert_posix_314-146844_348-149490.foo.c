#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ char *s ;
  PCRE2_UCHAR32 *p ;
  PCRE2_UCHAR32 *endp ;
  uint32_t posix_state ;
  uint32_t lastspecial ;
  BOOL extended ;
  uint32_t c ;
  int clength ;
  PCRE2_UCHAR32 *tmp___13 ;
  PCRE2_UCHAR32 *tmp___14 ;
  char *tmp___16 ;
  char *__dyc_funcallvar_4 ;

  {
  p = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  endp = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  posix_state = (uint32_t )__dyc_readpre_byte();
  lastspecial = (uint32_t )__dyc_readpre_byte();
  extended = __dyc_readpre_byte();
  c = (uint32_t )__dyc_readpre_byte();
  clength = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_read_ptr__char();
  s = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___16 = 0;
  COPY_SPECIAL: 
  lastspecial = c;
  if ((unsigned long )(p + 1) > (unsigned long )endp) {
    goto __dyc_dummy_label;
  }
  tmp___13 = p;
  p ++;
  *tmp___13 = c;
  goto __dyc_dummy_label;
  switch_6_42:  
  if (lastspecial != 42U) {
    if (! extended) {
      if (posix_state < 2U) {
        goto ESCAPE_LITERAL;
      } else {
        if (lastspecial == 40U) {
          goto ESCAPE_LITERAL;
        }
      }
    }
    goto COPY_SPECIAL;
  }
  goto __dyc_dummy_label;
  switch_6_94:  
  if (extended) {
    goto COPY_SPECIAL;
  }
  if (posix_state == 0U) {
    posix_state = 1U;
    goto COPY_SPECIAL;
  } else {
    if (lastspecial == 40U) {
      posix_state = 1U;
      goto COPY_SPECIAL;
    }
  }
  switch_6_default:  ;
  if (c < 128U) {
    {
    tmp___16 = __dyc_funcallvar_4;
    }
    if ((unsigned long )tmp___16 != (unsigned long )((void *)0)) {
      ESCAPE_LITERAL: 
      s = (char *)"\\";
      {
      while (1) {
        while_11_continue:  ;
        if (! ((int )*s != 0)) {
          goto while_11_break;
        }
        if ((unsigned long )p >= (unsigned long )endp) {
          goto __dyc_dummy_label;
        }
        tmp___14 = p;
        p ++;
        *tmp___14 = (unsigned int )*s;
        s ++;
      }
      while_11_break:  ;
      }
    }
  }
  lastspecial = 255U;
  if ((unsigned long )(p + clength) > (unsigned long )endp) {
    goto __dyc_dummy_label;
  }

  p += clength;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(posix_state);
  __dyc_printpre_byte(lastspecial);
}
}
