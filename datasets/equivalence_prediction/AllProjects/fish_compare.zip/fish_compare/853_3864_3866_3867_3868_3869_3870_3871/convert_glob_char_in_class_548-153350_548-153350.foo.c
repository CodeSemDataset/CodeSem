#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned short const   **tmp ;
  unsigned short const   **tmp___0 ;
  int tmp___1 ;
  unsigned short const   **tmp___2 ;
  unsigned short const   **tmp___3 ;
  unsigned short const   **tmp___4 ;
  unsigned short const   **tmp___5 ;
  unsigned short const   **tmp___6 ;
  unsigned short const   **tmp___7 ;
  unsigned short const   **tmp___8 ;
  unsigned short const   **tmp___9 ;
  unsigned short const   **tmp___10 ;
  int tmp___11 ;
  unsigned short const   **tmp___12 ;
  int class_index ;
  PCRE2_UCHAR32 c ;
  unsigned short const   **__dyc_funcallvar_1 ;
  unsigned short const   **__dyc_funcallvar_2 ;
  unsigned short const   **__dyc_funcallvar_3 ;
  unsigned short const   **__dyc_funcallvar_4 ;
  unsigned short const   **__dyc_funcallvar_5 ;
  unsigned short const   **__dyc_funcallvar_6 ;
  unsigned short const   **__dyc_funcallvar_7 ;
  unsigned short const   **__dyc_funcallvar_8 ;
  unsigned short const   **__dyc_funcallvar_9 ;
  unsigned short const   **__dyc_funcallvar_10 ;
  unsigned short const   **__dyc_funcallvar_11 ;
  unsigned short const   **__dyc_funcallvar_12 ;

  {
  class_index = __dyc_readpre_byte();
  c = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  __dyc_funcallvar_3 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_4 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_5 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_6 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_7 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_8 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_9 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_10 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_11 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_12 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  __dyc_funcallvar_1 = 0;
  __dyc_funcallvar_2 = 0;
  if (class_index == 3) {
    goto switch_18_3;
  } else {
    if (class_index == 4) {
      goto switch_18_4;
    } else {
      if (class_index == 5) {
        goto switch_18_5;
      } else {
        if (class_index == 6) {
          goto switch_18_6;
        } else {
          if (class_index == 7) {
            goto switch_18_7;
          } else {
            if (class_index == 8) {
              goto switch_18_8;
            } else {
              if (class_index == 9) {
                goto switch_18_9;
              } else {
                if (class_index == 10) {
                  goto switch_18_10;
                } else {
                  if (class_index == 11) {
                    goto switch_18_11;
                  } else {
                    if (class_index == 12) {
                      goto switch_18_12;
                    } else {
                      if (class_index == 13) {
                        goto switch_18_13;
                      } else {
                        {
                        goto switch_18_default;
                        if (0) {
                          switch_18_1:  
                          {
                          tmp = __dyc_funcallvar_1;
                          }
                          goto __dyc_dummy_label;
                          switch_18_2:  
                          {
                          tmp___0 = __dyc_funcallvar_2;
                          }
                          goto __dyc_dummy_label;
                          switch_18_3:  
                          goto __dyc_dummy_label;
                          switch_18_4:  
                          if (c == 9U) {
                            tmp___1 = 1;
                          } else {
                            if (c == 32U) {
                              tmp___1 = 1;
                            } else {
                              tmp___1 = 0;
                            }
                          }
                          goto __dyc_dummy_label;
                          switch_18_5:  
                          {
                          tmp___2 = __dyc_funcallvar_3;
                          }
                          goto __dyc_dummy_label;
                          switch_18_6:  
                          {
                          tmp___3 = __dyc_funcallvar_4;
                          }
                          goto __dyc_dummy_label;
                          switch_18_7:  
                          {
                          tmp___4 = __dyc_funcallvar_5;
                          }
                          goto __dyc_dummy_label;
                          switch_18_8:  
                          {
                          tmp___5 = __dyc_funcallvar_6;
                          }
                          goto __dyc_dummy_label;
                          switch_18_9:  
                          {
                          tmp___6 = __dyc_funcallvar_7;
                          }
                          goto __dyc_dummy_label;
                          switch_18_10:  
                          {
                          tmp___7 = __dyc_funcallvar_8;
                          }
                          goto __dyc_dummy_label;
                          switch_18_11:  
                          {
                          tmp___8 = __dyc_funcallvar_9;
                          }
                          goto __dyc_dummy_label;
                          switch_18_12:  
                          {
                          tmp___9 = __dyc_funcallvar_10;
                          }
                          goto __dyc_dummy_label;
                          switch_18_13:  
                          {
                          tmp___10 = __dyc_funcallvar_11;
                          }
                          if ((int const   )*(*tmp___10 + (int )c) & 8) {
                            tmp___11 = 1;
                          } else {
                            if (c == 95U) {
                              tmp___11 = 1;
                            } else {
                              tmp___11 = 0;
                            }
                          }
                          goto __dyc_dummy_label;
                          switch_18_default:  
                          {
                          tmp___12 = __dyc_funcallvar_12;
                          }
                          goto __dyc_dummy_label;
                        } else {
                          switch_18_break:  ;
                        }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(tmp___1);
  __dyc_print_ptr__ptr__short(tmp___2);
  __dyc_print_ptr__ptr__short(tmp___3);
  __dyc_print_ptr__ptr__short(tmp___4);
  __dyc_print_ptr__ptr__short(tmp___5);
  __dyc_print_ptr__ptr__short(tmp___6);
  __dyc_print_ptr__ptr__short(tmp___7);
  __dyc_print_ptr__ptr__short(tmp___8);
  __dyc_print_ptr__ptr__short(tmp___9);
  __dyc_printpre_byte(tmp___11);
  __dyc_print_ptr__ptr__short(tmp___12);
}
}
