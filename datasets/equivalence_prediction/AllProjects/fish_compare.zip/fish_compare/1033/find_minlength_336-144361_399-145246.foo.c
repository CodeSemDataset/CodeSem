#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ int branchlength ;
  PCRE2_UCHAR32 *cc ;
  int tmp___1 ;
  BOOL utf ;

  {
  branchlength = __dyc_readpre_byte();
  cc = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  utf = __dyc_readpre_byte();
  tmp___1 = 0;
  if (utf) {

  }
  goto __dyc_dummy_label;
  switch_1_93:  
  branchlength = (int )((PCRE2_UCHAR32 )branchlength + *(cc + 1));
  if (*(cc + 2) == 16U) {
    tmp___1 = 2;
  } else {
    if (*(cc + 2) == 15U) {
      tmp___1 = 2;
    } else {
      tmp___1 = 0;
    }
  }
  cc += 3 + tmp___1;
  goto __dyc_dummy_label;
  switch_1_16:  
  switch_1_15:  
  cc += 2;
  switch_1_6:  
  switch_1_7:  
  switch_1_8:  
  switch_1_9:  
  switch_1_10:  
  switch_1_11:  
  switch_1_12:  
  switch_1_13:  
  switch_1_22:  
  switch_1_19:  
  switch_1_18:  
  switch_1_21:  
  switch_1_20:  
  branchlength ++;
  cc ++;
  goto __dyc_dummy_label;
  switch_1_17:  
  branchlength ++;
  cc ++;
  goto __dyc_dummy_label;
  switch_1_14:  
  if (utf) {
    goto __dyc_dummy_label;
  }
  branchlength ++;
  cc ++;
  goto __dyc_dummy_label;
  switch_1_85:  
  switch_1_86:  
  switch_1_89:  
  switch_1_90:  
  switch_1_94:  
  switch_1_96:  
  if (*(cc + 1) == 16U) {
    cc += 2;
  } else {
    if (*(cc + 1) == 15U) {
      cc += 2;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(branchlength);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(cc);
}
}
