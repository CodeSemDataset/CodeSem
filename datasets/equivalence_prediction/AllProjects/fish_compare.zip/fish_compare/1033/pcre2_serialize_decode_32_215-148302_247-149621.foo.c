#include "../include/dycfoo.h"
#include "../include/pcre2_serialize.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   *src_bytes ;
  pcre2_real_code_32 *dst_re ;
  uint8_t *tables ;
  int32_t i ;
  int32_t j ;
  size_t blocksize ;
  void *tmp___1 ;
  pcre2_code_32 **codes ;

  {
  src_bytes = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  tables = __dyc_read_ptr__typdef_uint8_t();
  i = __dyc_readpre_byte();
  blocksize = (size_t )__dyc_readpre_byte();
  tmp___1 = __dyc_read_ptr__void();
  codes = __dyc_read_ptr__ptr__typdef_pcre2_code_32();
  dst_re = 0;
  j = 0;
  dst_re = (pcre2_real_code_32 *)tmp___1;
  if ((unsigned long )dst_re == (unsigned long )((void *)0)) {
    {

    j = 0;
    }
    {
    while (1) {
      while_3_continue:  ;
      if (! (j < i)) {
        goto while_3_break;
      }
      {

      *(codes + j) = (pcre2_code_32 *)((void *)0);
      j ++;
      }
    }
    while_3_break:  ;
    }
    goto __dyc_dummy_label;
  }

  if ((unsigned long )dst_re->magic_number != 1346589253UL) {
    {

    }
    goto __dyc_dummy_label;
  } else {
    if ((int )dst_re->name_entry_size > 34) {
      {

      }
      goto __dyc_dummy_label;
    } else {
      if ((int )dst_re->name_count > 10000) {
        {

        }
        goto __dyc_dummy_label;
      }
    }
  }
  dst_re->tables = (uint8_t const   *)tables;
  dst_re->executable_jit = (void *)0;
  dst_re->flags |= 262144U;
  *(codes + i) = dst_re;
  src_bytes += blocksize;
  i ++;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(src_bytes);
  __dyc_printpre_byte(i);
}
}
