#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 c ;
  PCRE2_UCHAR32 base ;
  PCRE2_SPTR32 code ;
  uint32_t *list ;

  {
  base = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  code = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  list = __dyc_read_ptr__typdef_uint32_t();
  c = 0;
  if ((int )base == 33) {
    goto switch_3_33;
  } else {
    if ((int )base == 46) {
      goto switch_3_46;
    } else {
      if ((int )base == 59) {
        goto switch_3_59;
      } else {
        if ((int )base == 72) {
          goto switch_3_72;
        } else {
          if ((int )base == 85) {
            goto switch_3_85;
          } else {
            if (0) {
              switch_3_33:  
              *(list + 0) = 29U;
              goto switch_3_break;
              switch_3_46:  
              *(list + 0) = 30U;
              goto switch_3_break;
              switch_3_59:  
              *(list + 0) = 31U;
              goto switch_3_break;
              switch_3_72:  
              *(list + 0) = 32U;
              goto switch_3_break;
              switch_3_85:  
              *(list + 0) = (unsigned int )*code;
              code ++;
              goto switch_3_break;
            } else {
              switch_3_break:  ;
            }
          }
        }
      }
    }
  }
  c = *(list + 0);
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(code);
}
}
