#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   xdigitab[256] ;
  BOOL utf ;
  PCRE2_SPTR32 ptr ;
  uint32_t c ;
  uint32_t cc ;
  BOOL overflow ;
  int tmp___9 ;
  PCRE2_SPTR32 tmp___10 ;
  PCRE2_SPTR32 ptrend ;
  int *errorcodeptr ;
  uint32_t extra_options ;

  {
  utf = __dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  c = (uint32_t )__dyc_readpre_byte();
  overflow = __dyc_readpre_byte();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  errorcodeptr = __dyc_read_ptr__int();
  extra_options = (uint32_t )__dyc_readpre_byte();
  cc = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  while (1) {
    while_6_continue:  ;
    if ((unsigned long )ptr < (unsigned long )ptrend) {
      if (*ptr <= 255U) {
        cc = (unsigned int )xdigitab[*ptr];
      } else {
        cc = 255U;
      }
      if (! (cc != 255U)) {
        goto while_6_break;
      }
    } else {
      goto while_6_break;
    }
    ptr ++;
    if (c == 0U) {
      if (cc == 0U) {
        goto while_6_continue;
      }
    }
    if ((long )c >= 268435456L) {
      overflow = 1;
      goto while_6_break;
    }
    c = (c << 4) | cc;
    if (utf) {
      if (c > 1114111U) {
        overflow = 1;
        goto while_6_break;
      } else {
        goto _L___3;
      }
    } else {
      _L___3:  
      if (! utf) {
        if (c > 4294967295U) {
          overflow = 1;
          goto while_6_break;
        }
      }
    }
  }
  while_6_break:  ;
  if (overflow) {
    {
    while (1) {
      while_7_continue:  ;
      if ((unsigned long )ptr < (unsigned long )ptrend) {
        if (*ptr <= 255U) {
          tmp___9 = (int const   )xdigitab[*ptr];
        } else {
          tmp___9 = (int const   )255;
        }
        if (! (tmp___9 != 255)) {
          goto while_7_break;
        }
      } else {
        goto while_7_break;
      }
      ptr ++;
    }
    while_7_break:  ;
    }
    *errorcodeptr = 134;
  } else {
    if ((unsigned long )ptr < (unsigned long )ptrend) {
      tmp___10 = ptr;
      ptr ++;
      if (*tmp___10 == 125U) {
        if (utf) {
          if (c >= 55296U) {
            if (c <= 57343U) {
              if ((extra_options & 1U) == 0U) {
                ptr --;
                *errorcodeptr = 173;
              }
            }
          }
        }
      } else {
        ptr --;
        *errorcodeptr = 167;
      }
    } else {
      ptr --;
      *errorcodeptr = 167;
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(c);
}
}
