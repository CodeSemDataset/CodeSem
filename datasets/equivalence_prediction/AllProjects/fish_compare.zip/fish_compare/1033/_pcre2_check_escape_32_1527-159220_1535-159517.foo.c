#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL utf ;
  PCRE2_SPTR32 ptr ;
  int escape ;
  PCRE2_SPTR32 p ;
  BOOL tmp___0 ;
  PCRE2_SPTR32 ptrend ;
  int *errorcodeptr ;
  compile_block_32 *cb ;
  BOOL __dyc_funcallvar_1 ;

  {
  utf = __dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  escape = __dyc_readpre_byte();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  errorcodeptr = __dyc_read_ptr__int();
  cb = __dyc_read_ptr__typdef_compile_block_32();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  p = 0;
  tmp___0 = 0;
  if ((unsigned long )cb != (unsigned long )((void *)0)) {
    if (escape == 15) {
      cb->external_flags |= 1048576U;
    } else {
      if (escape == 16) {
        cb->external_flags |= 1048576U;
      } else {
        if (escape == 22) {
          cb->external_flags |= 1048576U;
        }
      }
    }
  }
  if (escape == 12) {
    if ((unsigned long )ptr < (unsigned long )ptrend) {
      if (*ptr == 123U) {
        p = ptr + 1;
        if (ptrend - p > 1) {
          if (*p == 85U) {
            if (*(p + 1) == 43U) {
              if (utf) {
                ptr = p + 1;
                escape = 0;
                goto __dyc_dummy_label;
              } else {
                *errorcodeptr = 193;
              }
            } else {
              goto _L___0;
            }
          } else {
            goto _L___0;
          }
        } else {
          _L___0:  
          {
          tmp___0 = __dyc_funcallvar_1;
          }
          if (! tmp___0) {
            if (*errorcodeptr == 0) {
              *errorcodeptr = 137;
            }
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(escape);
}
}
