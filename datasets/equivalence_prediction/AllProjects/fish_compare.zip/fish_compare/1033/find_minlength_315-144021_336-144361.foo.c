#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ int branchlength ;
  PCRE2_UCHAR32 *cc ;
  int tmp___0 ;
  BOOL utf ;

  {
  branchlength = __dyc_readpre_byte();
  cc = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  utf = __dyc_readpre_byte();
  tmp___0 = 0;
  if (utf) {

  }
  goto __dyc_dummy_label;
  switch_1_87:  
  switch_1_88:  
  switch_1_95:  
  branchlength ++;
  if (*(cc + 1) == 16U) {
    tmp___0 = 4;
  } else {
    if (*(cc + 1) == 15U) {
      tmp___0 = 4;
    } else {
      tmp___0 = 2;
    }
  }
  cc += tmp___0;
  goto __dyc_dummy_label;
  switch_1_41:  
  switch_1_54:  
  switch_1_67:  
  switch_1_80:  
  branchlength = (int )((PCRE2_UCHAR32 )branchlength + *(cc + 1));
  cc += 3;
  if (utf) {

  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(branchlength);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(cc);
}
}
