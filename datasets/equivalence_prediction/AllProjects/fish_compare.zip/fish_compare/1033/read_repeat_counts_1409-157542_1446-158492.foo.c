#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 p ;
  BOOL yield ;
  int32_t min ;
  int32_t max ;
  BOOL tmp ;
  PCRE2_SPTR32 tmp___0 ;
  BOOL tmp___1 ;
  PCRE2_SPTR32 *ptrptr ;
  PCRE2_SPTR32 ptrend ;
  uint32_t *minp ;
  uint32_t *maxp ;
  int *errorcodeptr ;
  BOOL __dyc_funcallvar_2 ;

  {
  p = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  yield = __dyc_readpre_byte();
  min = __dyc_readpre_byte();
  max = __dyc_readpre_byte();
  tmp = __dyc_readpre_byte();
  ptrptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  minp = __dyc_read_ptr__typdef_uint32_t();
  maxp = __dyc_read_ptr__typdef_uint32_t();
  errorcodeptr = __dyc_read_ptr__int();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  tmp___0 = 0;
  tmp___1 = 0;
  if (! tmp) {
    goto EXIT;
  }
  if ((unsigned long )p >= (unsigned long )ptrend) {
    goto EXIT;
  }
  if (*p == 125U) {
    p ++;
    max = min;
  } else {
    tmp___0 = p;
    p ++;
    if (*tmp___0 != 44U) {
      goto EXIT;
    } else {
      if ((unsigned long )p >= (unsigned long )ptrend) {
        goto EXIT;
      }
    }
    if (*p != 125U) {
      {
      tmp___1 = __dyc_funcallvar_2;
      }
      if (tmp___1) {
        if ((unsigned long )p >= (unsigned long )ptrend) {
          goto EXIT;
        } else {
          if (*p != 125U) {
            goto EXIT;
          }
        }
      } else {
        goto EXIT;
      }
      if (max < min) {
        *errorcodeptr = 104;
        goto EXIT;
      }
    }
    p ++;
  }
  yield = 1;
  if ((unsigned long )minp != (unsigned long )((void *)0)) {
    *minp = (unsigned int )min;
  }
  if ((unsigned long )maxp != (unsigned long )((void *)0)) {
    *maxp = (unsigned int )max;
  }
  EXIT: 
  if (yield) {
    *ptrptr = p;
  } else {
    if (*errorcodeptr != 0) {
      *ptrptr = p;
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(max);
}
}
