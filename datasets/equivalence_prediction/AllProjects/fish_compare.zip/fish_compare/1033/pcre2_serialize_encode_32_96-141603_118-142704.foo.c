#include "../include/dycfoo.h"
#include "../include/pcre2_serialize.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t *bytes ;
  int32_t i ;
  size_t total_size ;
  pcre2_real_code_32 const   *re ;
  uint8_t const   *tables ;
  pcre2_serialized_data *data ;
  void *tmp___0 ;
  pcre2_code_32 const   **codes ;
  int32_t number_of_codes ;
  void *__dyc_funcallvar_1 ;

  {
  i = __dyc_readpre_byte();
  total_size = (size_t )__dyc_readpre_byte();
  tables = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  codes = (pcre2_code_32 const   **)__dyc_read_ptr__ptr__typdef_pcre2_code_32();
  number_of_codes = __dyc_readpre_byte();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  bytes = 0;
  re = 0;
  data = 0;
  tmp___0 = 0;
  while (1) {
    while_0_continue:  ;
    if (! (i < number_of_codes)) {
      goto while_0_break;
    }
    if ((unsigned long )*(codes + i) == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
    re = *(codes + i);
    if ((unsigned long )re->magic_number != 1346589253UL) {
      goto __dyc_dummy_label;
    }
    if ((unsigned long )tables == (unsigned long )((void *)0)) {
      tables = (uint8_t const   *)re->tables;
    } else {
      if ((unsigned long )tables != (unsigned long )re->tables) {
        goto __dyc_dummy_label;
      }
    }
    total_size += (size_t )re->blocksize;
    i ++;
  }
  while_0_break:  ;
  tmp___0 = __dyc_funcallvar_1;
  bytes = (uint8_t *)tmp___0;
  if ((unsigned long )bytes == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }

  bytes += sizeof(pcre2_memctl );
  data = (pcre2_serialized_data *)bytes;
  data->magic = 1347564115U;
  data->version = (unsigned int )(10 | (36 << 16));
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(total_size);
  __dyc_print_ptr__typdef_uint8_t(tables);
}
}
