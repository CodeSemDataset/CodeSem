#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 *p ;
  PCRE2_UCHAR32 *endp ;
  uint32_t posix_state ;
  uint32_t lastspecial ;
  BOOL extended ;
  uint32_t c ;
  PCRE2_UCHAR32 *tmp___13 ;

  {
  p = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  endp = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  posix_state = (uint32_t )__dyc_readpre_byte();
  lastspecial = (uint32_t )__dyc_readpre_byte();
  extended = __dyc_readpre_byte();
  c = (uint32_t )__dyc_readpre_byte();
  tmp___13 = 0;
  COPY_SPECIAL: 
  lastspecial = c;
  if ((unsigned long )(p + 1) > (unsigned long )endp) {
    goto __dyc_dummy_label;
  }
  tmp___13 = p;
  p ++;
  *tmp___13 = c;
  goto __dyc_dummy_label;
  switch_6_42:  
  if (lastspecial != 42U) {
    if (! extended) {
      if (posix_state < 2U) {
        goto __dyc_dummy_label;
      } else {
        if (lastspecial == 40U) {
          goto __dyc_dummy_label;
        }
      }
    }
    goto COPY_SPECIAL;
  }
  goto __dyc_dummy_label;
  switch_6_94:  
  if (extended) {
    goto COPY_SPECIAL;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(lastspecial);
}
}
