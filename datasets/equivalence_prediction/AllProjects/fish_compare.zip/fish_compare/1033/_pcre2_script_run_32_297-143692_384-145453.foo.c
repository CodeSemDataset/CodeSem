#include "../include/dycfoo.h"
#include "../include/pcre2_script_run.i.hd.c.h"
void __dyc_foo(void) 
{ int require_script ;
  uint8_t intersection_list[50] ;
  uint8_t const   *require_list ;
  uint32_t chspecial ;
  uint8_t const   *clist ;
  uint8_t const   *rlist ;
  uint8_t const   *list___0 ;
  int i ;
  int tmp___1 ;

  {
  require_script = __dyc_readpre_byte();
  require_list = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  chspecial = (uint32_t )__dyc_readpre_byte();
  list___0 = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  clist = 0;
  rlist = 0;
  i = 0;
  tmp___1 = 0;
  if (chspecial == 0U) {
    goto __dyc_dummy_label;
  }
  if (chspecial == 1U) {
    require_script = -99996;
  } else {
    if (chspecial == 6U) {
      require_script = -99997;
    }
  }
  goto __dyc_dummy_label;
  while (1) {
    while_8_continue:  ;
    if (! ((int const   )*list___0 != 0)) {
      goto while_8_break;
    }
    if ((int const   )*list___0 == 27) {
      goto while_8_break;
    } else {
      if ((int const   )*list___0 == 30) {
        goto while_8_break;
      }
    }
    list___0 ++;
  }
  while_8_break:  ;
  if ((int const   )*list___0 == 0) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  while (1) {
    while_9_continue:  ;
    if (! ((int const   )*list___0 != 0)) {
      goto while_9_break;
    }
    if ((int const   )*list___0 == 4) {
      goto while_9_break;
    }
    list___0 ++;
  }
  while_9_break:  ;
  if ((int const   )*list___0 == 0) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  while (1) {
    while_10_continue:  ;
    if (! ((int const   )*list___0 != 0)) {
      goto while_10_break;
    }
    if ((int const   )*list___0 == 24) {
      goto while_10_break;
    }
    list___0 ++;
  }
  while_10_break:  ;
  if ((int const   )*list___0 == 0) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  switch_5_neg_99994:  
  i = 0;
  rlist = require_list;
  while (1) {
    while_11_continue:  ;
    if (! ((int const   )*rlist != 0)) {
      goto while_11_break;
    }
    clist = list___0;
    {
    while (1) {
      while_12_continue:  ;
      if (! ((int const   )*clist != 0)) {
        goto while_12_break;
      }
      if ((int const   )*rlist == (int const   )*clist) {
        tmp___1 = i;
        i ++;
        intersection_list[tmp___1] = (unsigned char )*rlist;
        goto while_12_break;
      }
      clist ++;
    }
    while_12_break:  ;
    }
    rlist ++;
  }
  while_11_break:  ;
  if (i == 0) {
    goto __dyc_dummy_label;
  }
  if (i == 1) {
    require_script = (int )intersection_list[0];
  } else {
    intersection_list[i] = (unsigned char)0;
    require_list = (uint8_t const   *)(intersection_list);
  }
  goto __dyc_dummy_label;
  switch_5_default:  ;
  while (1) {
    while_13_continue:  ;
    if (! ((int const   )*list___0 != 0)) {
      goto while_13_break;
    }
    if ((int const   )*list___0 == (int const   )require_script) {
      goto while_13_break;
    }
    list___0 ++;
  }
  while_13_break:  ;
  if ((int const   )*list___0 == 0) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(require_script);
  __dyc_print_ptr__typdef_uint8_t(require_list);
}
}
