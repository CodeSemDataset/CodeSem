#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   autoposstab[17][21] ;
  uint8_t const   propposstab[11][11] ;
  uint8_t const   catposstab[7][30] ;
  uint8_t const   posspropstab[3][4] ;
  uint32_t list[8] ;
  BOOL accepted ;
  uint32_t leftop ;
  uint32_t rightop ;
  int n ;
  uint8_t const   *p ;
  BOOL same ;
  BOOL lisprop ;
  BOOL risprop ;
  BOOL bothprop ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  uint32_t const   *base_list ;

  {
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  accepted = 0;
  leftop = 0;
  rightop = 0;
  n = 0;
  p = 0;
  same = 0;
  lisprop = 0;
  risprop = 0;
  bothprop = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  leftop = (unsigned int )*(base_list + 0);
  rightop = list[0];
  accepted = 0;
  if (leftop == 16U) {
    goto _L___0;
  } else {
    if (leftop == 15U) {
      _L___0:  
      if (rightop == 24U) {
        accepted = 1;
      } else {
        if (rightop == 16U) {
          goto _L;
        } else {
          if (rightop == 15U) {
            _L:  
            same = leftop == rightop;
            lisprop = leftop == 16U;
            risprop = rightop == 16U;
            if (lisprop) {
              if (risprop) {
                tmp___7 = 1;
              } else {
                tmp___7 = 0;
              }
            } else {
              tmp___7 = 0;
            }
            bothprop = tmp___7;
            n = (int )propposstab[*(base_list + 2)][list[2]];
            if (n == 0) {
              goto switch_16_0;
            } else {
              if (n == 1) {
                goto switch_16_1;
              } else {
                if (n == 2) {
                  goto switch_16_2;
                } else {
                  if (n == 3) {
                    goto switch_16_3;
                  } else {
                    if (n == 4) {
                      goto switch_16_4;
                    } else {
                      if (n == 5) {
                        goto switch_16_5;
                      } else {
                        if (n == 6) {
                          goto switch_16_6;
                        } else {
                          if (n == 7) {
                            goto switch_16_6;
                          } else {
                            if (n == 8) {
                              goto switch_16_6;
                            } else {
                              if (n == 9) {
                                goto switch_16_9;
                              } else {
                                if (n == 10) {
                                  goto switch_16_9;
                                } else {
                                  if (n == 11) {
                                    goto switch_16_9;
                                  } else {
                                    if (n == 12) {
                                      goto switch_16_12;
                                    } else {
                                      if (n == 13) {
                                        goto switch_16_12;
                                      } else {
                                        if (n == 14) {
                                          goto switch_16_12;
                                        } else {
                                          if (n == 15) {
                                            goto switch_16_15;
                                          } else {
                                            if (n == 16) {
                                              goto switch_16_15;
                                            } else {
                                              if (n == 17) {
                                                goto switch_16_15;
                                              } else {
                                                if (0) {
                                                  switch_16_0:  
                                                  goto switch_16_break;
                                                  switch_16_1:  
                                                  accepted = bothprop;
                                                  goto switch_16_break;
                                                  switch_16_2:  
                                                  accepted = (*(base_list + 3) == (uint32_t const   )list[3]) != same;
                                                  goto switch_16_break;
                                                  switch_16_3:  
                                                  accepted = ! same;
                                                  goto switch_16_break;
                                                  switch_16_4:  
                                                  if (risprop) {
                                                    if ((int const   )catposstab[*(base_list + 3)][list[3]] == (int const   )same) {
                                                      tmp___8 = 1;
                                                    } else {
                                                      tmp___8 = 0;
                                                    }
                                                  } else {
                                                    tmp___8 = 0;
                                                  }
                                                  accepted = tmp___8;
                                                  goto switch_16_break;
                                                  switch_16_5:  
                                                  if (lisprop) {
                                                    if ((int const   )catposstab[list[3]][*(base_list + 3)] == (int const   )same) {
                                                      tmp___9 = 1;
                                                    } else {
                                                      tmp___9 = 0;
                                                    }
                                                  } else {
                                                    tmp___9 = 0;
                                                  }
                                                  accepted = tmp___9;
                                                  goto switch_16_break;
                                                  switch_16_6:  
                                                  switch_16_7:  
                                                  switch_16_8:  
                                                  p = posspropstab[n - 6];
                                                  if (risprop) {
                                                    if (list[3] != (uint32_t )*(p + 0)) {
                                                      if (list[3] != (uint32_t )*(p + 1)) {
                                                        if (list[3] != (uint32_t )*(p + 2)) {
                                                          tmp___10 = 1;
                                                        } else {
                                                          if (! lisprop) {
                                                            tmp___10 = 1;
                                                          } else {
                                                            tmp___10 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___10 = 0;
                                                      }
                                                    } else {
                                                      tmp___10 = 0;
                                                    }
                                                    if (lisprop == tmp___10) {
                                                      tmp___11 = 1;
                                                    } else {
                                                      tmp___11 = 0;
                                                    }
                                                  } else {
                                                    tmp___11 = 0;
                                                  }
                                                  accepted = tmp___11;
                                                  goto switch_16_break;
                                                  switch_16_9:  
                                                  switch_16_10:  
                                                  switch_16_11:  
                                                  p = posspropstab[n - 9];
                                                  if (lisprop) {
                                                    if (*(base_list + 3) != (uint32_t const   )*(p + 0)) {
                                                      if (*(base_list + 3) != (uint32_t const   )*(p + 1)) {
                                                        if (*(base_list + 3) != (uint32_t const   )*(p + 2)) {
                                                          tmp___12 = 1;
                                                        } else {
                                                          if (! risprop) {
                                                            tmp___12 = 1;
                                                          } else {
                                                            tmp___12 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___12 = 0;
                                                      }
                                                    } else {
                                                      tmp___12 = 0;
                                                    }
                                                    if (risprop == tmp___12) {
                                                      tmp___13 = 1;
                                                    } else {
                                                      tmp___13 = 0;
                                                    }
                                                  } else {
                                                    tmp___13 = 0;
                                                  }
                                                  accepted = tmp___13;
                                                  goto switch_16_break;
                                                  switch_16_12:  
                                                  switch_16_13:  
                                                  switch_16_14:  
                                                  p = posspropstab[n - 12];
                                                  if (risprop) {
                                                    if (catposstab[*(p + 0)][list[3]]) {
                                                      if (catposstab[*(p + 1)][list[3]]) {
                                                        if (list[3] != (uint32_t )*(p + 3)) {
                                                          tmp___14 = 1;
                                                        } else {
                                                          if (! lisprop) {
                                                            tmp___14 = 1;
                                                          } else {
                                                            tmp___14 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___14 = 0;
                                                      }
                                                    } else {
                                                      tmp___14 = 0;
                                                    }
                                                    if (lisprop == tmp___14) {
                                                      tmp___15 = 1;
                                                    } else {
                                                      tmp___15 = 0;
                                                    }
                                                  } else {
                                                    tmp___15 = 0;
                                                  }
                                                  accepted = tmp___15;
                                                  goto switch_16_break;
                                                  switch_16_15:  
                                                  switch_16_16:  
                                                  switch_16_17:  
                                                  p = posspropstab[n - 15];
                                                  if (lisprop) {
                                                    if (catposstab[*(p + 0)][*(base_list + 3)]) {
                                                      if (catposstab[*(p + 1)][*(base_list + 3)]) {
                                                        if (*(base_list + 3) != (uint32_t const   )*(p + 3)) {
                                                          tmp___16 = 1;
                                                        } else {
                                                          if (! risprop) {
                                                            tmp___16 = 1;
                                                          } else {
                                                            tmp___16 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___16 = 0;
                                                      }
                                                    } else {
                                                      tmp___16 = 0;
                                                    }
                                                    if (risprop == tmp___16) {
                                                      tmp___17 = 1;
                                                    } else {
                                                      tmp___17 = 0;
                                                    }
                                                  } else {
                                                    tmp___17 = 0;
                                                  }
                                                  accepted = tmp___17;
                                                  goto switch_16_break;
                                                } else {
                                                  switch_16_break:  ;
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if (leftop >= 6U) {
        if (leftop <= 22U) {
          if (rightop >= 6U) {
            if (rightop <= 26U) {
              if (autoposstab[leftop - 6U][rightop - 6U]) {
                tmp___18 = 1;
              } else {
                tmp___18 = 0;
              }
            } else {
              tmp___18 = 0;
            }
          } else {
            tmp___18 = 0;
          }
        } else {
          tmp___18 = 0;
        }
      } else {
        tmp___18 = 0;
      }
      accepted = tmp___18;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(accepted);
  __dyc_printpre_byte(rightop);
  __dyc_print_ptr__typdef_uint8_t(p);
  __dyc_printpre_byte(same);
  __dyc_printpre_byte(risprop);
  __dyc_printpre_byte(bothprop);
}
}
