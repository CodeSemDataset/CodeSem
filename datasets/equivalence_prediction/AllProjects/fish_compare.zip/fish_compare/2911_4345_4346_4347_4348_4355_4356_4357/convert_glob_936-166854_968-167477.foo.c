#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ pcre2_output_context out ;
  PCRE2_SPTR32 pattern_end ;
  BOOL no_wildsep ;
  BOOL in_atomic ;
  BOOL after_starstar ;
  BOOL no_slash_z ;
  BOOL is_start ;
  PCRE2_SPTR32 pattern ;

  {
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  no_wildsep = __dyc_readpre_byte();
  after_starstar = __dyc_readpre_byte();
  is_start = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  memset(& out, 0, sizeof(pcre2_output_context ));
  in_atomic = 0;
  no_slash_z = 0;
  if (no_wildsep) {
    if ((unsigned long )pattern >= (unsigned long )pattern_end) {
      no_slash_z = 1;
      goto __dyc_dummy_label;
    }
    if (is_start) {
      goto __dyc_dummy_label;
    }
  }
  if (! is_start) {
    if (after_starstar) {
      {
      out.out_str[0] = (unsigned char )'(';
      out.out_str[1] = (unsigned char )'?';
      out.out_str[2] = (unsigned char )'>';

      in_atomic = 1;
      }
    } else {
      {

      }
    }
  }
  if (no_wildsep) {
    {

    }
  } else {
    {

    }
  }
  out.out_str[0] = (unsigned char )'*';
  out.out_str[1] = (unsigned char )'?';
  __dyc_dummy_label:  ;
  __dyc_print_comp_85pcre2_output_context(out);
  __dyc_printpre_byte(in_atomic);
  __dyc_printpre_byte(no_slash_z);
}
}
