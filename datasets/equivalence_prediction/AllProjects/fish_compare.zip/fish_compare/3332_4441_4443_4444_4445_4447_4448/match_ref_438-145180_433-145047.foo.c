#include "../include/dycfoo.h"
#include "../include/pcre2_match.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 p ;
  size_t length ;
  PCRE2_SPTR32 eptr ;
  uint32_t cc ;
  uint32_t cp ;
  uint32_t tmp___4 ;
  uint32_t tmp___5 ;
  match_block_32 *mb ;

  {
  p = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  length = (size_t )__dyc_readpre_byte();
  eptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  mb = __dyc_read_ptr__typdef_match_block_32();
  cc = 0;
  cp = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  cc = (unsigned int )*eptr;
  cp = (unsigned int )*p;
  if (cp <= 255U) {
    tmp___4 = (unsigned int )*(mb->lcc + cp);
  } else {
    tmp___4 = cp;
  }
  if (cc <= 255U) {
    tmp___5 = (unsigned int )*(mb->lcc + cc);
  } else {
    tmp___5 = cc;
  }
  if (tmp___4 != tmp___5) {
    goto __dyc_dummy_label;
  }
  p ++;
  eptr ++;
  length --;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(length);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(eptr);
}
}
