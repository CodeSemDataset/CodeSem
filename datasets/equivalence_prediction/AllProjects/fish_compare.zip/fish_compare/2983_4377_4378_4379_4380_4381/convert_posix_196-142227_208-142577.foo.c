#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ char *s ;
  PCRE2_SPTR32 posix ;
  PCRE2_UCHAR32 *p ;
  PCRE2_UCHAR32 *endp ;
  uint32_t posix_state ;
  uint32_t c ;
  PCRE2_UCHAR32 *tmp___2 ;
  size_t plength ;

  {
  posix = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  p = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  endp = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  c = (uint32_t )__dyc_readpre_byte();
  plength = (size_t )__dyc_readpre_byte();
  s = 0;
  posix_state = 0;
  tmp___2 = 0;
  posix_state = 3U;
  if (c == 58U) {
    if (plength > 0UL) {
      if (*posix == 93U) {
        s = (char *)":]";
        {
        while (1) {
          while_4_continue:  ;
          if (! ((int )*s != 0)) {
            goto while_4_break;
          }
          if ((unsigned long )p >= (unsigned long )endp) {
            goto __dyc_dummy_label;
          }
          tmp___2 = p;
          p ++;
          *tmp___2 = (unsigned int )*s;
          s ++;
        }
        while_4_break:  ;
        }
        plength --;
        posix ++;
        goto __dyc_dummy_label;
      }
    }
  }
  switch_3_3:  
  if (c == 91U) {
    posix_state = 4U;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(posix);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(posix_state);
  __dyc_printpre_byte(plength);
}
}
