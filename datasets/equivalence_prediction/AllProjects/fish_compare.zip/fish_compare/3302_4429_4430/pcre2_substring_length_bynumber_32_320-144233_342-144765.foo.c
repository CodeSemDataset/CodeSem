#include "../include/dycfoo.h"
#include "../include/pcre2_substring.i.hd.c.h"
void __dyc_foo(void) 
{ size_t left ;
  size_t right ;
  int count ;
  pcre2_match_data_32 *match_data ;
  uint32_t stringnumber ;

  {
  count = __dyc_readpre_byte();
  match_data = __dyc_read_ptr__typdef_pcre2_match_data_32();
  stringnumber = (uint32_t )__dyc_readpre_byte();
  left = 0;
  right = 0;
  if (count == -2) {
    if (stringnumber > 0U) {
      goto __dyc_dummy_label;
    }
    count = 0;
  } else {
    if (count < 0) {
      goto __dyc_dummy_label;
    }
  }
  if ((int )match_data->matchedby != 1) {
    if (stringnumber > (uint32_t )(match_data->code)->top_bracket) {
      goto __dyc_dummy_label;
    }
    if (stringnumber >= (uint32_t )match_data->oveccount) {
      goto __dyc_dummy_label;
    }
    if (match_data->ovector[stringnumber * 2U] == 0xffffffffUL) {
      goto __dyc_dummy_label;
    }
  } else {
    if (stringnumber >= (uint32_t )match_data->oveccount) {
      goto __dyc_dummy_label;
    }
    if (count != 0) {
      if (stringnumber >= (unsigned int )count) {
        goto __dyc_dummy_label;
      }
    }
  }
  left = match_data->ovector[stringnumber * 2U];
  right = match_data->ovector[stringnumber * 2U + 1U];
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(left);
  __dyc_printpre_byte(right);
  __dyc_printpre_byte(count);
}
}
