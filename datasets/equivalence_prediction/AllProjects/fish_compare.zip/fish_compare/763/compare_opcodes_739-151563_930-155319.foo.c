#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   autoposstab[17][21] ;
  uint8_t const   propposstab[11][11] ;
  uint8_t const   catposstab[7][30] ;
  uint8_t const   posspropstab[3][4] ;
  uint32_t list[8] ;
  uint32_t const   *list_ptr ;
  PCRE2_SPTR32 xclass_flags ;
  uint8_t const   *set1 ;
  uint8_t const   *set2 ;
  uint8_t const   *set_end ;
  BOOL accepted ;
  BOOL invert_bits ;
  PCRE2_SPTR32 tmp___1 ;
  PCRE2_SPTR32 tmp___2 ;
  uint8_t const   *tmp___3 ;
  uint8_t const   *tmp___4 ;
  uint8_t const   *tmp___5 ;
  uint8_t const   *tmp___6 ;
  uint32_t leftop ;
  uint32_t rightop ;
  int n ;
  uint8_t const   *p ;
  BOOL same ;
  BOOL lisprop ;
  BOOL risprop ;
  BOOL bothprop ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  PCRE2_SPTR32 code ;
  compile_block_32 const   *cb ;
  uint32_t const   *base_list ;
  PCRE2_SPTR32 base_end ;

  {
  list_ptr = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  set1 = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  invert_bits = __dyc_readpre_byte();
  code = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  cb = (compile_block_32 const   *)__dyc_read_ptr__typdef_compile_block_32();
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  base_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  xclass_flags = 0;
  set2 = 0;
  set_end = 0;
  accepted = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  leftop = 0;
  rightop = 0;
  n = 0;
  p = 0;
  same = 0;
  lisprop = 0;
  risprop = 0;
  bothprop = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  tmp___16 = 0;
  tmp___17 = 0;
  tmp___18 = 0;
  if ((int )*(list_ptr + 0) == 110) {
    goto switch_13_110;
  } else {
    if ((int )*(list_ptr + 0) == 111) {
      goto switch_13_110;
    } else {
      if ((int )*(list_ptr + 0) == 112) {
        goto switch_13_112;
      } else {
        if ((int )*(list_ptr + 0) == 6) {
          goto switch_13_6;
        } else {
          if ((int )*(list_ptr + 0) == 7) {
            goto switch_13_7;
          } else {
            if ((int )*(list_ptr + 0) == 8) {
              goto switch_13_8;
            } else {
              if ((int )*(list_ptr + 0) == 9) {
                goto switch_13_9;
              } else {
                if ((int )*(list_ptr + 0) == 10) {
                  goto switch_13_10;
                } else {
                  if ((int )*(list_ptr + 0) == 11) {
                    goto switch_13_11;
                  } else {
                    {
                    goto switch_13_default;
                    if (0) {
                      switch_13_110:  
                      switch_13_111:  
                      if ((unsigned long )list_ptr == (unsigned long )(list)) {
                        tmp___1 = code;
                      } else {
                        tmp___1 = base_end;
                      }
                      set2 = (uint8_t const   *)((uint8_t *)(tmp___1 - *(list_ptr + 2)));
                      goto switch_13_break;
                      switch_13_112:  
                      if ((unsigned long )list_ptr == (unsigned long )(list)) {
                        tmp___2 = code;
                      } else {
                        tmp___2 = base_end;
                      }
                      xclass_flags = (tmp___2 - *(list_ptr + 2)) + 1;
                      if ((*xclass_flags & 4U) != 0U) {
                        goto __dyc_dummy_label;
                      }
                      if ((*xclass_flags & 2U) == 0U) {
                        if (list[1] == 0U) {
                          goto __dyc_dummy_label;
                        }
                        goto __dyc_dummy_label;
                      }
                      set2 = (uint8_t const   *)((uint8_t *)(xclass_flags + 1));
                      goto switch_13_break;
                      switch_13_6:  
                      invert_bits = 1;
                      switch_13_7:  
                      set2 = (uint8_t const   *)((uint8_t *)(cb->cbits + 64));
                      goto switch_13_break;
                      switch_13_8:  
                      invert_bits = 1;
                      switch_13_9:  
                      set2 = (uint8_t const   *)((uint8_t *)(cb->cbits + 0));
                      goto switch_13_break;
                      switch_13_10:  
                      invert_bits = 1;
                      switch_13_11:  
                      set2 = (uint8_t const   *)((uint8_t *)(cb->cbits + 160));
                      goto switch_13_break;
                      switch_13_default:  ;
                      goto __dyc_dummy_label;
                    } else {
                      switch_13_break:  ;
                    }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  set_end = set1 + 32;
  if (invert_bits) {
    {
    while (1) {
      while_14_continue:  ;
      tmp___3 = set1;
      set1 ++;
      tmp___4 = set2;
      set2 ++;
      if (((int const   )*tmp___3 & ~ ((int const   )*tmp___4)) != 0) {
        goto __dyc_dummy_label;
      }
      if (! ((unsigned long )set1 < (unsigned long )set_end)) {
        goto while_14_break;
      }
    }
    while_14_break:  ;
    }
  } else {
    {
    while (1) {
      while_15_continue:  ;
      tmp___5 = set1;
      set1 ++;
      tmp___6 = set2;
      set2 ++;
      if (((int const   )*tmp___5 & (int const   )*tmp___6) != 0) {
        goto __dyc_dummy_label;
      }
      if (! ((unsigned long )set1 < (unsigned long )set_end)) {
        goto while_15_break;
      }
    }
    while_15_break:  ;
    }
  }
  if (list[1] == 0U) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  leftop = (unsigned int )*(base_list + 0);
  rightop = list[0];
  accepted = 0;
  if (leftop == 16U) {
    goto _L___0;
  } else {
    if (leftop == 15U) {
      _L___0:  
      if (rightop == 24U) {
        accepted = 1;
      } else {
        if (rightop == 16U) {
          goto _L;
        } else {
          if (rightop == 15U) {
            _L:  
            same = leftop == rightop;
            lisprop = leftop == 16U;
            risprop = rightop == 16U;
            if (lisprop) {
              if (risprop) {
                tmp___7 = 1;
              } else {
                tmp___7 = 0;
              }
            } else {
              tmp___7 = 0;
            }
            bothprop = tmp___7;
            n = (int )propposstab[*(base_list + 2)][list[2]];
            if (n == 0) {
              goto switch_16_0;
            } else {
              if (n == 1) {
                goto switch_16_1;
              } else {
                if (n == 2) {
                  goto switch_16_2;
                } else {
                  if (n == 3) {
                    goto switch_16_3;
                  } else {
                    if (n == 4) {
                      goto switch_16_4;
                    } else {
                      if (n == 5) {
                        goto switch_16_5;
                      } else {
                        if (n == 6) {
                          goto switch_16_6;
                        } else {
                          if (n == 7) {
                            goto switch_16_6;
                          } else {
                            if (n == 8) {
                              goto switch_16_6;
                            } else {
                              if (n == 9) {
                                goto switch_16_9;
                              } else {
                                if (n == 10) {
                                  goto switch_16_9;
                                } else {
                                  if (n == 11) {
                                    goto switch_16_9;
                                  } else {
                                    if (n == 12) {
                                      goto switch_16_12;
                                    } else {
                                      if (n == 13) {
                                        goto switch_16_12;
                                      } else {
                                        if (n == 14) {
                                          goto switch_16_12;
                                        } else {
                                          if (n == 15) {
                                            goto switch_16_15;
                                          } else {
                                            if (n == 16) {
                                              goto switch_16_15;
                                            } else {
                                              if (n == 17) {
                                                goto switch_16_15;
                                              } else {
                                                if (0) {
                                                  switch_16_0:  
                                                  goto switch_16_break;
                                                  switch_16_1:  
                                                  accepted = bothprop;
                                                  goto switch_16_break;
                                                  switch_16_2:  
                                                  accepted = (*(base_list + 3) == (uint32_t const   )list[3]) != same;
                                                  goto switch_16_break;
                                                  switch_16_3:  
                                                  accepted = ! same;
                                                  goto switch_16_break;
                                                  switch_16_4:  
                                                  if (risprop) {
                                                    if ((int const   )catposstab[*(base_list + 3)][list[3]] == (int const   )same) {
                                                      tmp___8 = 1;
                                                    } else {
                                                      tmp___8 = 0;
                                                    }
                                                  } else {
                                                    tmp___8 = 0;
                                                  }
                                                  accepted = tmp___8;
                                                  goto switch_16_break;
                                                  switch_16_5:  
                                                  if (lisprop) {
                                                    if ((int const   )catposstab[list[3]][*(base_list + 3)] == (int const   )same) {
                                                      tmp___9 = 1;
                                                    } else {
                                                      tmp___9 = 0;
                                                    }
                                                  } else {
                                                    tmp___9 = 0;
                                                  }
                                                  accepted = tmp___9;
                                                  goto switch_16_break;
                                                  switch_16_6:  
                                                  switch_16_7:  
                                                  switch_16_8:  
                                                  p = posspropstab[n - 6];
                                                  if (risprop) {
                                                    if (list[3] != (uint32_t )*(p + 0)) {
                                                      if (list[3] != (uint32_t )*(p + 1)) {
                                                        if (list[3] != (uint32_t )*(p + 2)) {
                                                          tmp___10 = 1;
                                                        } else {
                                                          if (! lisprop) {
                                                            tmp___10 = 1;
                                                          } else {
                                                            tmp___10 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___10 = 0;
                                                      }
                                                    } else {
                                                      tmp___10 = 0;
                                                    }
                                                    if (lisprop == tmp___10) {
                                                      tmp___11 = 1;
                                                    } else {
                                                      tmp___11 = 0;
                                                    }
                                                  } else {
                                                    tmp___11 = 0;
                                                  }
                                                  accepted = tmp___11;
                                                  goto switch_16_break;
                                                  switch_16_9:  
                                                  switch_16_10:  
                                                  switch_16_11:  
                                                  p = posspropstab[n - 9];
                                                  if (lisprop) {
                                                    if (*(base_list + 3) != (uint32_t const   )*(p + 0)) {
                                                      if (*(base_list + 3) != (uint32_t const   )*(p + 1)) {
                                                        if (*(base_list + 3) != (uint32_t const   )*(p + 2)) {
                                                          tmp___12 = 1;
                                                        } else {
                                                          if (! risprop) {
                                                            tmp___12 = 1;
                                                          } else {
                                                            tmp___12 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___12 = 0;
                                                      }
                                                    } else {
                                                      tmp___12 = 0;
                                                    }
                                                    if (risprop == tmp___12) {
                                                      tmp___13 = 1;
                                                    } else {
                                                      tmp___13 = 0;
                                                    }
                                                  } else {
                                                    tmp___13 = 0;
                                                  }
                                                  accepted = tmp___13;
                                                  goto switch_16_break;
                                                  switch_16_12:  
                                                  switch_16_13:  
                                                  switch_16_14:  
                                                  p = posspropstab[n - 12];
                                                  if (risprop) {
                                                    if (catposstab[*(p + 0)][list[3]]) {
                                                      if (catposstab[*(p + 1)][list[3]]) {
                                                        if (list[3] != (uint32_t )*(p + 3)) {
                                                          tmp___14 = 1;
                                                        } else {
                                                          if (! lisprop) {
                                                            tmp___14 = 1;
                                                          } else {
                                                            tmp___14 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___14 = 0;
                                                      }
                                                    } else {
                                                      tmp___14 = 0;
                                                    }
                                                    if (lisprop == tmp___14) {
                                                      tmp___15 = 1;
                                                    } else {
                                                      tmp___15 = 0;
                                                    }
                                                  } else {
                                                    tmp___15 = 0;
                                                  }
                                                  accepted = tmp___15;
                                                  goto switch_16_break;
                                                  switch_16_15:  
                                                  switch_16_16:  
                                                  switch_16_17:  
                                                  p = posspropstab[n - 15];
                                                  if (lisprop) {
                                                    if (catposstab[*(p + 0)][*(base_list + 3)]) {
                                                      if (catposstab[*(p + 1)][*(base_list + 3)]) {
                                                        if (*(base_list + 3) != (uint32_t const   )*(p + 3)) {
                                                          tmp___16 = 1;
                                                        } else {
                                                          if (! risprop) {
                                                            tmp___16 = 1;
                                                          } else {
                                                            tmp___16 = 0;
                                                          }
                                                        }
                                                      } else {
                                                        tmp___16 = 0;
                                                      }
                                                    } else {
                                                      tmp___16 = 0;
                                                    }
                                                    if (risprop == tmp___16) {
                                                      tmp___17 = 1;
                                                    } else {
                                                      tmp___17 = 0;
                                                    }
                                                  } else {
                                                    tmp___17 = 0;
                                                  }
                                                  accepted = tmp___17;
                                                  goto switch_16_break;
                                                } else {
                                                  switch_16_break:  ;
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if (leftop >= 6U) {
        if (leftop <= 22U) {
          if (rightop >= 6U) {
            if (rightop <= 26U) {
              if (autoposstab[leftop - 6U][rightop - 6U]) {
                tmp___18 = 1;
              } else {
                tmp___18 = 0;
              }
            } else {
              tmp___18 = 0;
            }
          } else {
            tmp___18 = 0;
          }
        } else {
          tmp___18 = 0;
        }
      } else {
        tmp___18 = 0;
      }
      accepted = tmp___18;
    }
  }
  if (! accepted) {
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(set1);
  __dyc_print_ptr__typdef_uint8_t(set2);
  __dyc_print_ptr__typdef_uint8_t(set_end);
  __dyc_printpre_byte(rightop);
  __dyc_print_ptr__typdef_uint8_t(p);
  __dyc_printpre_byte(same);
  __dyc_printpre_byte(risprop);
  __dyc_printpre_byte(bothprop);
}
}
