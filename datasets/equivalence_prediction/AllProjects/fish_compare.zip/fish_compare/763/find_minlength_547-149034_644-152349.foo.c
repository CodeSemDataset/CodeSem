#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ int branchlength ;
  BOOL had_recurse ;
  BOOL dupcapused ;
  PCRE2_UCHAR32 *cc ;
  recurse_check this_recurse ;
  int d ;
  int min ;
  int recno ;
  PCRE2_UCHAR32 *cs ;
  PCRE2_UCHAR32 *ce ;
  int i___0 ;
  PCRE2_SPTR32 tmp___5 ;
  recurse_check *r___0 ;
  PCRE2_SPTR32 tmp___6 ;
  pcre2_real_code_32 const   *re ;
  PCRE2_SPTR32 startcode ;
  recurse_check *recurses ;
  int *backref_cache ;
  PCRE2_SPTR32 __dyc_funcallvar_6 ;
  PCRE2_SPTR32 __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;

  {
  branchlength = __dyc_readpre_byte();
  dupcapused = __dyc_readpre_byte();
  cc = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  re = (pcre2_real_code_32 const   *)__dyc_read_ptr__typdef_pcre2_real_code_32();
  startcode = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  recurses = __dyc_read_ptr__typdef_recurse_check();
  backref_cache = __dyc_read_ptr__int();
  __dyc_funcallvar_6 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_7 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  had_recurse = 0;
  memset(& this_recurse, 0, sizeof(recurse_check ));
  d = 0;
  min = 0;
  recno = 0;
  cs = 0;
  ce = 0;
  i___0 = 0;
  tmp___5 = 0;
  r___0 = 0;
  tmp___6 = 0;
  switch_1_113:  
  switch_1_114:  
  recno = (int )*(cc + 1);
  if (recno <= *(backref_cache + 0)) {
    if (*(backref_cache + recno) >= 0) {
      d = *(backref_cache + recno);
    } else {
      goto _L___5;
    }
  } else {
    _L___5:  
    d = 0;
    if ((re->overall_options & 512U) == 0U) {
      {
      tmp___5 = __dyc_funcallvar_6;
      cs = (PCRE2_UCHAR32 *)tmp___5;
      ce = cs;
      }
      if ((unsigned long )cs == (unsigned long )((void *)0)) {
        goto __dyc_dummy_label;
      }
      {
      while (1) {
        while_11_continue:  ;
        ce += *(ce + 1);
        if (! (*ce == 120U)) {
          goto while_11_break;
        }
      }
      while_11_break:  ;
      }
      if (! dupcapused) {
        goto _L___4;
      } else {
        {
        tmp___6 = __dyc_funcallvar_7;
        }
        if ((unsigned long )((PCRE2_UCHAR32 *)tmp___6) == (unsigned long )((void *)0)) {
          _L___4:  
          if ((unsigned long )cc > (unsigned long )cs) {
            if ((unsigned long )cc < (unsigned long )ce) {
              had_recurse = 1;
            } else {
              goto _L___3;
            }
          } else {
            _L___3:  
            r___0 = recurses;
            r___0 = recurses;
            {
            while (1) {
              while_12_continue:  ;
              if (! ((unsigned long )r___0 != (unsigned long )((void *)0))) {
                goto while_12_break;
              }
              if ((unsigned long )r___0->group == (unsigned long )cs) {
                goto while_12_break;
              }
              r___0 = r___0->prev;
            }
            while_12_break:  ;
            }
            if ((unsigned long )r___0 != (unsigned long )((void *)0)) {
              had_recurse = 1;
            } else {
              {
              this_recurse.prev = recurses;
              this_recurse.group = (PCRE2_UCHAR32 const   *)cs;
              d = __dyc_funcallvar_8;
              }
              if (d < 0) {
                goto __dyc_dummy_label;
              }
            }
          }
        }
      }
    }
    *(backref_cache + recno) = d;
    i___0 = *(backref_cache + 0) + 1;
    {
    while (1) {
      while_13_continue:  ;
      if (! (i___0 < recno)) {
        goto while_13_break;
      }
      *(backref_cache + i___0) = -1;
      i___0 ++;
    }
    while_13_break:  ;
    }
    *(backref_cache + 0) = recno;
  }
  cc += 2;
  REPEAT_BACK_REFERENCE: 
  if ((int )*cc == 98) {
    goto switch_14_98;
  } else {
    if ((int )*cc == 99) {
      goto switch_14_98;
    } else {
      if ((int )*cc == 102) {
        goto switch_14_98;
      } else {
        if ((int )*cc == 103) {
          goto switch_14_98;
        } else {
          if ((int )*cc == 106) {
            goto switch_14_98;
          } else {
            if ((int )*cc == 108) {
              goto switch_14_98;
            } else {
              if ((int )*cc == 100) {
                goto switch_14_100;
              } else {
                if ((int )*cc == 101) {
                  goto switch_14_100;
                } else {
                  if ((int )*cc == 107) {
                    goto switch_14_100;
                  } else {
                    if ((int )*cc == 104) {
                      goto switch_14_104;
                    } else {
                      if ((int )*cc == 105) {
                        goto switch_14_104;
                      } else {
                        if ((int )*cc == 109) {
                          goto switch_14_104;
                        } else {
                          {
                          goto switch_14_default;
                          if (0) {
                            switch_14_98:  
                            switch_14_99:  
                            switch_14_102:  
                            switch_14_103:  
                            switch_14_106:  
                            switch_14_108:  
                            min = 0;
                            cc ++;
                            goto switch_14_break;
                            switch_14_100:  
                            switch_14_101:  
                            switch_14_107:  
                            min = 1;
                            cc ++;
                            goto switch_14_break;
                            switch_14_104:  
                            switch_14_105:  
                            switch_14_109:  
                            min = (int )*(cc + 1);
                            cc += 3;
                            goto switch_14_break;
                            switch_14_default:  
                            min = 1;
                            goto switch_14_break;
                          } else {
                            switch_14_break:  ;
                          }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if (d > 0) {
    if (2147483647 / d < min) {
      branchlength = 65535;
    } else {
      goto _L___6;
    }
  } else {
    _L___6:  
    if (65535 - branchlength < min * d) {
      branchlength = 65535;
    } else {
      branchlength += min * d;
    }
  }
  goto __dyc_dummy_label;
  switch_1_117:  
  ce = (PCRE2_UCHAR32 *)startcode + *(cc + 1);
  cs = ce;
  recno = (int )*(cs + 2);
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(branchlength);
  __dyc_printpre_byte(had_recurse);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(cc);
  __dyc_print_comp_75recurse_check(this_recurse);
  __dyc_printpre_byte(d);
  __dyc_printpre_byte(recno);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ce);
}
}
