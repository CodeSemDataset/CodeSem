#include "../include/dycfoo.h"
#include "../include/pcre2_substring.i.hd.c.h"
void __dyc_foo(void) 
{ uint16_t bot ;
  uint16_t top ;
  uint16_t entrysize ;
  PCRE2_SPTR32 nametable ;
  uint16_t mid ;
  PCRE2_SPTR32 entry ;
  int c ;
  int tmp ;
  PCRE2_SPTR32 first ;
  PCRE2_SPTR32 last ;
  PCRE2_SPTR32 lastentry ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  pcre2_code_32 const   *code ;
  PCRE2_SPTR32 *firstptr ;
  PCRE2_SPTR32 *lastptr ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;

  {
  entrysize = (uint16_t )__dyc_readpre_byte();
  nametable = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  mid = (uint16_t )__dyc_readpre_byte();
  entry = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  tmp = __dyc_readpre_byte();
  code = (pcre2_code_32 const   *)__dyc_read_ptr__typdef_pcre2_code_32();
  firstptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  lastptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  bot = 0;
  top = 0;
  c = 0;
  first = 0;
  last = 0;
  lastentry = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  c = tmp;
  if (c == 0) {
    lastentry = nametable + (int )entrysize * (int )((int const   )code->name_count - 1);
    last = entry;
    first = last;
    {
    while (1) {
      while_6_continue:  ;
      if (! ((unsigned long )first > (unsigned long )nametable)) {
        goto while_6_break;
      }
      {
      tmp___0 = __dyc_funcallvar_2;
      }
      if (tmp___0 != 0) {
        goto while_6_break;
      }
      first -= (int )entrysize;
    }
    while_6_break:  ;
    }
    {
    while (1) {
      while_7_continue:  ;
      if (! ((unsigned long )last < (unsigned long )lastentry)) {
        goto while_7_break;
      }
      {
      tmp___1 = __dyc_funcallvar_3;
      }
      if (tmp___1 != 0) {
        goto while_7_break;
      }
      last += (int )entrysize;
    }
    while_7_break:  ;
    }
    if ((unsigned long )firstptr == (unsigned long )((void *)0)) {
      if ((unsigned long )first == (unsigned long )last) {
        tmp___2 = (int )*(entry + 0);
      } else {
        tmp___2 = -50;
      }
      goto __dyc_dummy_label;
    }
    *firstptr = first;
    *lastptr = last;
    goto __dyc_dummy_label;
  }
  if (c > 0) {
    bot = (unsigned short )((int )mid + 1);
  } else {
    top = mid;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(bot);
  __dyc_printpre_byte(top);
  __dyc_printpre_byte(tmp___2);
}
}
