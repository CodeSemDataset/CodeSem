#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL utf ;
  PCRE2_SPTR32 ptr ;
  uint32_t c ;
  uint32_t cc ;
  BOOL overflow ;
  PCRE2_SPTR32 tmp___6 ;
  PCRE2_SPTR32 tmp___7 ;
  PCRE2_SPTR32 tmp___8 ;
  PCRE2_SPTR32 ptrend ;
  int *errorcodeptr ;
  uint32_t extra_options ;

  {
  utf = __dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  tmp___8 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  errorcodeptr = __dyc_read_ptr__int();
  extra_options = (uint32_t )__dyc_readpre_byte();
  c = 0;
  cc = 0;
  overflow = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  if (*tmp___8 != 123U) {
    ptr --;
    *errorcodeptr = 155;
  } else {
    if ((unsigned long )ptr >= (unsigned long )ptrend) {
      *errorcodeptr = 178;
    } else {
      if (*ptr == 125U) {
        *errorcodeptr = 178;
      } else {
        c = 0U;
        overflow = 0;
        {
        while (1) {
          while_4_continue:  ;
          if ((unsigned long )ptr < (unsigned long )ptrend) {
            if (*ptr >= 48U) {
              if (! (*ptr <= 55U)) {
                goto while_4_break;
              }
            } else {
              goto while_4_break;
            }
          } else {
            goto while_4_break;
          }
          tmp___6 = ptr;
          ptr ++;
          cc = (unsigned int )*tmp___6;
          if (c == 0U) {
            if (cc == 48U) {
              goto while_4_continue;
            }
          }
          if ((long )c >= 536870912L) {
            overflow = 1;
            goto while_4_break;
          }
          c = (c << 3) + (cc - 48U);
          if (utf) {
            if (c > 1114111U) {
              overflow = 1;
              goto while_4_break;
            }
          }
        }
        while_4_break:  ;
        }
        if (overflow) {
          {
          while (1) {
            while_5_continue:  ;
            if ((unsigned long )ptr < (unsigned long )ptrend) {
              if (*ptr >= 48U) {
                if (! (*ptr <= 55U)) {
                  goto while_5_break;
                }
              } else {
                goto while_5_break;
              }
            } else {
              goto while_5_break;
            }
            ptr ++;
          }
          while_5_break:  ;
          }
          *errorcodeptr = 134;
        } else {
          if ((unsigned long )ptr < (unsigned long )ptrend) {
            tmp___7 = ptr;
            ptr ++;
            if (*tmp___7 == 125U) {
              if (utf) {
                if (c >= 55296U) {
                  if (c <= 57343U) {
                    if ((extra_options & 1U) == 0U) {
                      ptr --;
                      *errorcodeptr = 173;
                    }
                  }
                }
              }
            } else {
              ptr --;
              *errorcodeptr = 164;
            }
          } else {
            ptr --;
            *errorcodeptr = 164;
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(cc);
}
}
