#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   xdigitab[256] ;
  BOOL utf ;
  PCRE2_SPTR32 ptr ;
  uint32_t c ;
  uint32_t cc ;
  BOOL overflow ;
  BOOL alt_bsux ;
  PCRE2_SPTR32 tmp___6 ;
  PCRE2_SPTR32 tmp___7 ;
  PCRE2_SPTR32 tmp___8 ;
  uint32_t xc___0 ;
  int tmp___9 ;
  PCRE2_SPTR32 tmp___10 ;
  PCRE2_SPTR32 *ptrptr ;
  PCRE2_SPTR32 ptrend ;
  int *errorcodeptr ;
  uint32_t extra_options ;

  {
  utf = __dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  alt_bsux = __dyc_readpre_byte();
  ptrptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  errorcodeptr = __dyc_read_ptr__int();
  extra_options = (uint32_t )__dyc_readpre_byte();
  c = 0;
  cc = 0;
  overflow = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  xc___0 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  switch_1_111:  
  if ((unsigned long )ptr >= (unsigned long )ptrend) {
    ptr --;
    *errorcodeptr = 155;
  } else {
    tmp___8 = ptr;
    ptr ++;
    if (*tmp___8 != 123U) {
      ptr --;
      *errorcodeptr = 155;
    } else {
      if ((unsigned long )ptr >= (unsigned long )ptrend) {
        *errorcodeptr = 178;
      } else {
        if (*ptr == 125U) {
          *errorcodeptr = 178;
        } else {
          c = 0U;
          overflow = 0;
          {
          while (1) {
            while_4_continue:  ;
            if ((unsigned long )ptr < (unsigned long )ptrend) {
              if (*ptr >= 48U) {
                if (! (*ptr <= 55U)) {
                  goto while_4_break;
                }
              } else {
                goto while_4_break;
              }
            } else {
              goto while_4_break;
            }
            tmp___6 = ptr;
            ptr ++;
            cc = (unsigned int )*tmp___6;
            if (c == 0U) {
              if (cc == 48U) {
                goto while_4_continue;
              }
            }
            if ((long )c >= 536870912L) {
              overflow = 1;
              goto while_4_break;
            }
            c = (c << 3) + (cc - 48U);
            if (utf) {
              if (c > 1114111U) {
                overflow = 1;
                goto while_4_break;
              }
            }
          }
          while_4_break:  ;
          }
          if (overflow) {
            {
            while (1) {
              while_5_continue:  ;
              if ((unsigned long )ptr < (unsigned long )ptrend) {
                if (*ptr >= 48U) {
                  if (! (*ptr <= 55U)) {
                    goto while_5_break;
                  }
                } else {
                  goto while_5_break;
                }
              } else {
                goto while_5_break;
              }
              ptr ++;
            }
            while_5_break:  ;
            }
            *errorcodeptr = 134;
          } else {
            if ((unsigned long )ptr < (unsigned long )ptrend) {
              tmp___7 = ptr;
              ptr ++;
              if (*tmp___7 == 125U) {
                if (utf) {
                  if (c >= 55296U) {
                    if (c <= 57343U) {
                      if ((extra_options & 1U) == 0U) {
                        ptr --;
                        *errorcodeptr = 173;
                      }
                    }
                  }
                }
              } else {
                ptr --;
                *errorcodeptr = 164;
              }
            } else {
              ptr --;
              *errorcodeptr = 164;
            }
          }
        }
      }
    }
  }
  goto __dyc_dummy_label;
  switch_1_120:  
  if (alt_bsux) {
    if (ptrend - ptr < 2) {
      goto __dyc_dummy_label;
    }
    if (*(ptr + 0) <= 255U) {
      cc = (unsigned int )xdigitab[*(ptr + 0)];
    } else {
      cc = 255U;
    }
    if (cc == 255U) {
      goto __dyc_dummy_label;
    }
    if (*(ptr + 1) <= 255U) {
      xc___0 = (unsigned int )xdigitab[*(ptr + 1)];
    } else {
      xc___0 = 255U;
    }
    if (xc___0 == 255U) {
      goto __dyc_dummy_label;
    }
    c = (cc << 4) | xc___0;
    ptr += 2;
  } else {
    if ((unsigned long )ptr < (unsigned long )ptrend) {
      if (*ptr == 123U) {
        COME_FROM_NU: 
        ptr ++;
        if ((unsigned long )ptr >= (unsigned long )ptrend) {
          *errorcodeptr = 178;
          goto __dyc_dummy_label;
        } else {
          if (*ptr == 125U) {
            *errorcodeptr = 178;
            goto __dyc_dummy_label;
          }
        }
        c = 0U;
        overflow = 0;
        {
        while (1) {
          while_6_continue:  ;
          if ((unsigned long )ptr < (unsigned long )ptrend) {
            if (*ptr <= 255U) {
              cc = (unsigned int )xdigitab[*ptr];
            } else {
              cc = 255U;
            }
            if (! (cc != 255U)) {
              goto while_6_break;
            }
          } else {
            goto while_6_break;
          }
          ptr ++;
          if (c == 0U) {
            if (cc == 0U) {
              goto while_6_continue;
            }
          }
          if ((long )c >= 268435456L) {
            overflow = 1;
            goto while_6_break;
          }
          c = (c << 4) | cc;
          if (utf) {
            if (c > 1114111U) {
              overflow = 1;
              goto while_6_break;
            } else {
              goto _L___3;
            }
          } else {
            _L___3:  
            if (! utf) {
              if (c > 4294967295U) {
                overflow = 1;
                goto while_6_break;
              }
            }
          }
        }
        while_6_break:  ;
        }
        if (overflow) {
          {
          while (1) {
            while_7_continue:  ;
            if ((unsigned long )ptr < (unsigned long )ptrend) {
              if (*ptr <= 255U) {
                tmp___9 = (int const   )xdigitab[*ptr];
              } else {
                tmp___9 = (int const   )255;
              }
              if (! (tmp___9 != 255)) {
                goto while_7_break;
              }
            } else {
              goto while_7_break;
            }
            ptr ++;
          }
          while_7_break:  ;
          }
          *errorcodeptr = 134;
        } else {
          if ((unsigned long )ptr < (unsigned long )ptrend) {
            tmp___10 = ptr;
            ptr ++;
            if (*tmp___10 == 125U) {
              if (utf) {
                if (c >= 55296U) {
                  if (c <= 57343U) {
                    if ((extra_options & 1U) == 0U) {
                      ptr --;
                      *errorcodeptr = 173;
                    }
                  }
                }
              }
            } else {
              ptr --;
              *errorcodeptr = 167;
            }
          } else {
            ptr --;
            *errorcodeptr = 167;
          }
        }
      } else {
        goto _L___4;
      }
    } else {
      _L___4:  
      c = 0U;
      if ((unsigned long )ptr >= (unsigned long )ptrend) {
        goto __dyc_dummy_label;
      } else {
        if (*ptr <= 255U) {
          cc = (unsigned int )xdigitab[*ptr];
        } else {
          cc = 255U;
        }
        if (cc == 255U) {
          goto __dyc_dummy_label;
        }
      }
      ptr ++;
      c = cc;
      if ((unsigned long )ptr >= (unsigned long )ptrend) {
        goto __dyc_dummy_label;
      } else {
        if (*ptr <= 255U) {
          cc = (unsigned int )xdigitab[*ptr];
        } else {
          cc = 255U;
        }
        if (cc == 255U) {
          goto __dyc_dummy_label;
        }
      }
      ptr ++;
      c = (c << 4) | cc;
    }
  }
  goto __dyc_dummy_label;
  switch_1_99:  
  if ((unsigned long )ptr >= (unsigned long )ptrend) {
    *errorcodeptr = 102;
    goto __dyc_dummy_label;
  }
  c = (unsigned int )*ptr;
  if (c >= 97U) {
    if (c <= 122U) {
      c -= 32U;
    }
  }
  if (c < 32U) {
    *errorcodeptr = 168;
    goto __dyc_dummy_label;
  } else {
    if (c > 126U) {
      *errorcodeptr = 168;
      goto __dyc_dummy_label;
    }
  }
  c ^= 64U;
  ptr ++;
  goto __dyc_dummy_label;
  switch_1_default:  
  *errorcodeptr = 103;
  *ptrptr = ptr - 1;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(cc);
}
}
