#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL separator_seen ;
  BOOL has_prev_c ;
  PCRE2_SPTR32 pattern ;
  PCRE2_SPTR32 char_start ;
  uint32_t c ;
  uint32_t prev_c ;
  PCRE2_SPTR32 tmp___2 ;
  PCRE2_SPTR32 *from ;
  PCRE2_SPTR32 pattern_end ;
  PCRE2_UCHAR32 separator ;
  PCRE2_UCHAR32 escape ;

  {
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  c = (uint32_t )__dyc_readpre_byte();
  prev_c = (uint32_t )__dyc_readpre_byte();
  from = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  separator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  escape = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  separator_seen = 0;
  has_prev_c = 0;
  char_start = 0;
  tmp___2 = 0;
  if ((unsigned long )pattern >= (unsigned long )pattern_end) {
    goto __dyc_dummy_label;
  }
  if (escape != 0U) {
    if (c == escape) {
      char_start = pattern;
      tmp___2 = pattern;
      pattern ++;
      c = (unsigned int )*tmp___2;
    } else {
      goto _L___0;
    }
  } else {
    _L___0:  
    if (c == 91U) {
      if (*pattern == 58U) {
        *from = pattern;
        goto __dyc_dummy_label;
      }
    }
  }
  if (prev_c > c) {
    *from = pattern;
    goto __dyc_dummy_label;
  }
  if (prev_c < separator) {
    if (separator < c) {
      separator_seen = 1;
    }
  }
  has_prev_c = 0;
  prev_c = 0U;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(separator_seen);
  __dyc_printpre_byte(has_prev_c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(char_start);
  __dyc_printpre_byte(prev_c);
}
}
