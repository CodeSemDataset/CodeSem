#include "../include/dycfoo.h"
#include "../include/pcre2_maketables.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  uint8_t *p ;
  int x ;
  unsigned short const   **tmp___36 ;
  unsigned short const   **tmp___37 ;
  unsigned short const   **tmp___38 ;
  unsigned short const   **tmp___39 ;
  unsigned short const   **tmp___40 ;
  uint8_t *tmp___41 ;
  unsigned short const   **__dyc_funcallvar_20 ;
  unsigned short const   **__dyc_funcallvar_21 ;
  unsigned short const   **__dyc_funcallvar_22 ;
  unsigned short const   **__dyc_funcallvar_23 ;
  unsigned short const   **__dyc_funcallvar_24 ;

  {
  i = __dyc_readpre_byte();
  p = __dyc_read_ptr__typdef_uint8_t();
  __dyc_funcallvar_20 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_21 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_22 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_23 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_24 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  x = 0;
  tmp___36 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  while (1) {
    while_3_continue:  ;
    if (! (i < 256)) {
      goto while_3_break;
    }
    {
    x = 0;
    tmp___36 = __dyc_funcallvar_20;
    }
    if ((int const   )*(*tmp___36 + i) & 8192) {
      x ++;
    }
    {
    tmp___37 = __dyc_funcallvar_21;
    }
    if ((int const   )*(*tmp___37 + i) & 1024) {
      x += 2;
    }
    {
    tmp___38 = __dyc_funcallvar_22;
    }
    if ((int const   )*(*tmp___38 + i) & 512) {
      x += 4;
    }
    {
    tmp___39 = __dyc_funcallvar_23;
    }
    if ((int const   )*(*tmp___39 + i) & 2048) {
      x += 8;
    }
    {
    tmp___40 = __dyc_funcallvar_24;
    }
    if ((int const   )*(*tmp___40 + i) & 8) {
      x += 16;
    } else {
      if (i == 95) {
        x += 16;
      }
    }
    tmp___41 = p;
    p ++;
    *tmp___41 = (unsigned char )x;
    i ++;
  }
  while_3_break:  ;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(p);
}
}
