#include "../include/dycfoo.h"
#include "../include/pcre2_maketables.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  uint8_t *p ;
  unsigned short const   **tmp___28 ;
  unsigned short const   **tmp___29 ;
  unsigned short const   **tmp___30 ;
  unsigned short const   **tmp___31 ;
  unsigned short const   **tmp___32 ;
  unsigned short const   **tmp___33 ;
  unsigned short const   **tmp___34 ;
  unsigned short const   **tmp___35 ;
  unsigned short const   **__dyc_funcallvar_13 ;
  unsigned short const   **__dyc_funcallvar_14 ;
  unsigned short const   **__dyc_funcallvar_15 ;
  unsigned short const   **__dyc_funcallvar_16 ;
  unsigned short const   **__dyc_funcallvar_17 ;
  unsigned short const   **__dyc_funcallvar_18 ;
  unsigned short const   **__dyc_funcallvar_19 ;

  {
  i = __dyc_readpre_byte();
  p = __dyc_read_ptr__typdef_uint8_t();
  tmp___28 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_13 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_14 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_15 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_16 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_17 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_18 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_19 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  if ((int const   )*(*tmp___28 + i) & 512) {
    *(p + (128 + i / 8)) = (unsigned char )((unsigned int )*(p + (128 + i / 8)) | (1U << (i & 7)));
  }
  tmp___29 = __dyc_funcallvar_13;
  if ((int const   )*(*tmp___29 + i) & 8) {
    *(p + (160 + i / 8)) = (unsigned char )((unsigned int )*(p + (160 + i / 8)) | (1U << (i & 7)));
  }
  if (i == 95) {
    *(p + (160 + i / 8)) = (unsigned char )((unsigned int )*(p + (160 + i / 8)) | (1U << (i & 7)));
  }
  tmp___30 = __dyc_funcallvar_14;
  if ((int const   )*(*tmp___30 + i) & 8192) {
    *(p + i / 8) = (unsigned char )((unsigned int )*(p + i / 8) | (1U << (i & 7)));
  }
  tmp___31 = __dyc_funcallvar_15;
  if ((int const   )*(*tmp___31 + i) & 4096) {
    *(p + (32 + i / 8)) = (unsigned char )((unsigned int )*(p + (32 + i / 8)) | (1U << (i & 7)));
  }
  tmp___32 = __dyc_funcallvar_16;
  if ((int const   )*(*tmp___32 + i) & 32768) {
    *(p + (192 + i / 8)) = (unsigned char )((unsigned int )*(p + (192 + i / 8)) | (1U << (i & 7)));
  }
  tmp___33 = __dyc_funcallvar_17;
  if ((int const   )*(*tmp___33 + i) & 16384) {
    *(p + (224 + i / 8)) = (unsigned char )((unsigned int )*(p + (224 + i / 8)) | (1U << (i & 7)));
  }
  tmp___34 = __dyc_funcallvar_18;
  if ((int const   )*(*tmp___34 + i) & 4) {
    *(p + (256 + i / 8)) = (unsigned char )((unsigned int )*(p + (256 + i / 8)) | (1U << (i & 7)));
  }
  tmp___35 = __dyc_funcallvar_19;
  if ((int const   )*(*tmp___35 + i) & 2) {
    *(p + (288 + i / 8)) = (unsigned char )((unsigned int )*(p + (288 + i / 8)) | (1U << (i & 7)));
  }
  i ++;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(i);
}
}
