#include "../include/dycfoo.h"
#include "../include/pcre2_config.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *_pcre2_unicode_version_32 ;
  char const   *v ;
  size_t tmp___1 ;
  char const   *v___0 ;
  char const   *tmp___2 ;
  void *where ;
  size_t __dyc_funcallvar_1 ;
  size_t __dyc_funcallvar_2 ;

  {
  _pcre2_unicode_version_32 = (char const   *)__dyc_read_ptr__char();
  where = __dyc_read_ptr__void();
  __dyc_funcallvar_1 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (size_t )__dyc_readpre_byte();
  v = 0;
  tmp___1 = 0;
  v___0 = 0;
  tmp___2 = 0;
  switch_1_13:  
  *((uint32_t *)where) = 0U;
  goto __dyc_dummy_label;
  switch_1_6:  
  *((uint32_t *)where) = 250U;
  goto __dyc_dummy_label;
  switch_1_8:  
  *((uint32_t *)where) = 0U;
  goto __dyc_dummy_label;
  switch_1_15:  
  *((uint32_t *)where) = 1088U;
  goto __dyc_dummy_label;
  switch_1_10:  
  v = _pcre2_unicode_version_32;
  if ((unsigned long )where == (unsigned long )((void *)0)) {
    {
    tmp___1 = __dyc_funcallvar_1;
    }
  } else {
    {
    tmp___1 = __dyc_funcallvar_2;
    }
  }
  goto __dyc_dummy_label;
  goto __dyc_dummy_label;
  switch_1_9:  
  *((uint32_t *)where) = 1U;
  goto __dyc_dummy_label;
  switch_1_11:  
  if ((int const   )*("Z" + 1) == 0) {
    tmp___2 = "10.36 2020-12-04";
  } else {
    tmp___2 = "10.362020-12-04";
  }
  v___0 = tmp___2;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(v);
  __dyc_printpre_byte(tmp___1);
  __dyc_print_ptr__char(v___0);
}
}
