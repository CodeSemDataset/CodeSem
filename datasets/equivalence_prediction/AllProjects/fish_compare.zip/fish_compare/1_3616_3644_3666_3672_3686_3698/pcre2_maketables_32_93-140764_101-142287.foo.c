#include "../include/dycfoo.h"
#include "../include/pcre2_maketables.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t *yield ;
  int i ;
  uint8_t *p ;
  uint8_t *tmp___2 ;
  int __res ;
  int __attribute__((__leaf__, __gnu_inline__))  tmp___5 ;
  __int32_t const   **tmp___6 ;
  uint8_t *tmp___7 ;
  int __res___2 ;
  int __attribute__((__leaf__, __gnu_inline__))  tmp___19 ;
  __int32_t const   **tmp___20 ;
  int __res___3 ;
  int __attribute__((__leaf__, __gnu_inline__))  tmp___23 ;
  __int32_t const   **tmp___24 ;
  unsigned short const   **tmp___25 ;
  int __attribute__((__leaf__, __gnu_inline__))  __dyc_funcallvar_3 ;
  __int32_t const   **__dyc_funcallvar_4 ;
  unsigned short const   **__dyc_funcallvar_5 ;
  int __attribute__((__leaf__, __gnu_inline__))  __dyc_funcallvar_6 ;
  __int32_t const   **__dyc_funcallvar_7 ;
  int __attribute__((__leaf__, __gnu_inline__))  __dyc_funcallvar_8 ;
  __int32_t const   **__dyc_funcallvar_9 ;

  {
  yield = __dyc_read_ptr__typdef_uint8_t();
  __dyc_funcallvar_3 = (int __attribute__((__leaf__,
  __gnu_inline__))  )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_5 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_6 = (int __attribute__((__leaf__,
  __gnu_inline__))  )__dyc_readpre_byte();
  __dyc_funcallvar_7 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_8 = (int __attribute__((__leaf__,
  __gnu_inline__))  )__dyc_readpre_byte();
  __dyc_funcallvar_9 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  i = 0;
  p = 0;
  tmp___2 = 0;
  __res = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  __res___2 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  __res___3 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  p = yield;
  i = 0;
  while (1) {
    while_0_continue:  ;
    if (! (i < 256)) {
      goto while_0_break;
    }
    tmp___2 = p;
    p ++;
    if (sizeof(int ) > 1UL) {
      {
      tmp___5 = __dyc_funcallvar_3;
      __res = (int )tmp___5;
      }
    } else {
      {
      tmp___6 = __dyc_funcallvar_4;
      __res = (int )*(*tmp___6 + i);
      }
    }
    *tmp___2 = (unsigned char )__res;
    i ++;
  }
  while_0_break:  ;
  i = 0;
  while (1) {
    while_1_continue:  ;
    if (! (i < 256)) {
      goto __dyc_dummy_label;
    }
    {
    tmp___7 = p;
    p ++;
    tmp___25 = __dyc_funcallvar_5;
    }
    if ((int const   )*(*tmp___25 + i) & 512) {
      if (sizeof(int ) > 1UL) {
        {
        tmp___19 = __dyc_funcallvar_6;
        __res___2 = (int )tmp___19;
        }
      } else {
        {
        tmp___20 = __dyc_funcallvar_7;
        __res___2 = (int )*(*tmp___20 + i);
        }
      }
      *tmp___7 = (unsigned char )__res___2;
    } else {
      if (sizeof(int ) > 1UL) {
        {
        tmp___23 = __dyc_funcallvar_8;
        __res___3 = (int )tmp___23;
        }
      } else {
        {
        tmp___24 = __dyc_funcallvar_9;
        __res___3 = (int )*(*tmp___24 + i);
        }
      }
      *tmp___7 = (unsigned char )__res___3;
    }
    i ++;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(p);
}
}
