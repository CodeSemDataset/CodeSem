#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   propposstab[11][11] ;
  uint32_t list[8] ;
  uint32_t leftop ;
  uint32_t rightop ;
  int n ;
  BOOL same ;
  BOOL lisprop ;
  BOOL risprop ;
  BOOL bothprop ;
  int tmp___7 ;
  uint32_t const   *base_list ;

  {
  leftop = (uint32_t )__dyc_readpre_byte();
  rightop = (uint32_t )__dyc_readpre_byte();
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  n = 0;
  same = 0;
  lisprop = 0;
  risprop = 0;
  bothprop = 0;
  tmp___7 = 0;
  _L:  
  same = leftop == rightop;
  lisprop = leftop == 16U;
  risprop = rightop == 16U;
  if (lisprop) {
    if (risprop) {
      tmp___7 = 1;
    } else {
      tmp___7 = 0;
    }
  } else {
    tmp___7 = 0;
  }
  bothprop = tmp___7;
  n = (int )propposstab[*(base_list + 2)][list[2]];
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(n);
  __dyc_printpre_byte(same);
  __dyc_printpre_byte(risprop);
  __dyc_printpre_byte(bothprop);
}
}
