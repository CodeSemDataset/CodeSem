#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ uint32_t c ;
  int yield ;
  BOOL try_next ;
  PCRE2_SPTR32 tcode ;
  int rc ;
  uint32_t const   *p ;
  uint32_t const   *tmp ;
  pcre2_real_code_32 *re ;
  int __dyc_funcallvar_1 ;

  {
  tcode = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  p = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  re = __dyc_read_ptr__typdef_pcre2_real_code_32();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  c = 0;
  yield = 0;
  try_next = 0;
  rc = 0;
  tmp = 0;
  while (1) {
    while_22_continue:  ;
    tmp = p;
    p ++;
    c = (unsigned int )*tmp;
    if (! (c < 4294967295U)) {
      goto while_22_break;
    }
    if (c > 255U) {
      re->start_bitmap[31] = (unsigned char )((unsigned int )re->start_bitmap[31] | (1U << 7));
    } else {
      re->start_bitmap[c / 8U] = (unsigned char )((unsigned int )re->start_bitmap[c / 8U] | (1U << (c & 7U)));
    }
  }
  while_22_break:  ;
  try_next = 0;
  goto __dyc_dummy_label;
  switch_21_5:  
  switch_21_4:  
  tcode ++;
  goto __dyc_dummy_label;
  rc = __dyc_funcallvar_1;
  if (rc == 1) {
    try_next = 0;
  } else {
    if (rc == 2) {
      {
      while (1) {
        while_23_continue:  ;
        tcode += *(tcode + 1);
        if (! (*tcode == 120U)) {
          goto while_23_break;
        }
      }
      while_23_break:  ;
      }
      tcode += 2;
    } else {
      goto __dyc_dummy_label;
    }
  }
  goto __dyc_dummy_label;
  switch_21_120:  
  yield = 2;
  try_next = 0;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(yield);
  __dyc_printpre_byte(try_next);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(tcode);
  __dyc_print_ptr__typdef_uint32_t(p);
}
}
