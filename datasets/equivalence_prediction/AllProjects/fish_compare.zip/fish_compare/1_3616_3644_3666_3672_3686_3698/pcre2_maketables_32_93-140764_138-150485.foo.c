#include "../include/dycfoo.h"
#include "../include/pcre2_maketables.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t *yield ;
  int i ;
  uint8_t *p ;
  uint8_t *tmp___2 ;
  int __res ;
  int __attribute__((__leaf__, __gnu_inline__))  tmp___5 ;
  __int32_t const   **tmp___6 ;
  uint8_t *tmp___7 ;
  int __res___2 ;
  int __attribute__((__leaf__, __gnu_inline__))  tmp___19 ;
  __int32_t const   **tmp___20 ;
  int __res___3 ;
  int __attribute__((__leaf__, __gnu_inline__))  tmp___23 ;
  __int32_t const   **tmp___24 ;
  unsigned short const   **tmp___25 ;
  unsigned short const   **tmp___26 ;
  unsigned short const   **tmp___27 ;
  unsigned short const   **tmp___28 ;
  unsigned short const   **tmp___29 ;
  unsigned short const   **tmp___30 ;
  unsigned short const   **tmp___31 ;
  unsigned short const   **tmp___32 ;
  unsigned short const   **tmp___33 ;
  unsigned short const   **tmp___34 ;
  unsigned short const   **tmp___35 ;
  int x ;
  unsigned short const   **tmp___36 ;
  unsigned short const   **tmp___37 ;
  unsigned short const   **tmp___38 ;
  unsigned short const   **tmp___39 ;
  unsigned short const   **tmp___40 ;
  uint8_t *tmp___41 ;
  int __attribute__((__leaf__, __gnu_inline__))  __dyc_funcallvar_3 ;
  __int32_t const   **__dyc_funcallvar_4 ;
  unsigned short const   **__dyc_funcallvar_5 ;
  int __attribute__((__leaf__, __gnu_inline__))  __dyc_funcallvar_6 ;
  __int32_t const   **__dyc_funcallvar_7 ;
  int __attribute__((__leaf__, __gnu_inline__))  __dyc_funcallvar_8 ;
  __int32_t const   **__dyc_funcallvar_9 ;
  unsigned short const   **__dyc_funcallvar_10 ;
  unsigned short const   **__dyc_funcallvar_11 ;
  unsigned short const   **__dyc_funcallvar_12 ;
  unsigned short const   **__dyc_funcallvar_13 ;
  unsigned short const   **__dyc_funcallvar_14 ;
  unsigned short const   **__dyc_funcallvar_15 ;
  unsigned short const   **__dyc_funcallvar_16 ;
  unsigned short const   **__dyc_funcallvar_17 ;
  unsigned short const   **__dyc_funcallvar_18 ;
  unsigned short const   **__dyc_funcallvar_19 ;
  unsigned short const   **__dyc_funcallvar_20 ;
  unsigned short const   **__dyc_funcallvar_21 ;
  unsigned short const   **__dyc_funcallvar_22 ;
  unsigned short const   **__dyc_funcallvar_23 ;
  unsigned short const   **__dyc_funcallvar_24 ;

  {
  yield = __dyc_read_ptr__typdef_uint8_t();
  __dyc_funcallvar_3 = (int __attribute__((__leaf__,
  __gnu_inline__))  )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_5 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_6 = (int __attribute__((__leaf__,
  __gnu_inline__))  )__dyc_readpre_byte();
  __dyc_funcallvar_7 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_8 = (int __attribute__((__leaf__,
  __gnu_inline__))  )__dyc_readpre_byte();
  __dyc_funcallvar_9 = (__int32_t const   **)__dyc_read_ptr__ptr__typdef___int32_t();
  __dyc_funcallvar_10 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_11 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_12 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_13 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_14 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_15 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_16 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_17 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_18 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_19 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_20 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_21 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_22 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_23 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_24 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  i = 0;
  p = 0;
  tmp___2 = 0;
  __res = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  __res___2 = 0;
  tmp___19 = 0;
  tmp___20 = 0;
  __res___3 = 0;
  tmp___23 = 0;
  tmp___24 = 0;
  tmp___25 = 0;
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  tmp___31 = 0;
  tmp___32 = 0;
  tmp___33 = 0;
  tmp___34 = 0;
  tmp___35 = 0;
  x = 0;
  tmp___36 = 0;
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  tmp___41 = 0;
  p = yield;
  i = 0;
  while (1) {
    while_0_continue:  ;
    if (! (i < 256)) {
      goto while_0_break;
    }
    tmp___2 = p;
    p ++;
    if (sizeof(int ) > 1UL) {
      {
      tmp___5 = __dyc_funcallvar_3;
      __res = (int )tmp___5;
      }
    } else {
      {
      tmp___6 = __dyc_funcallvar_4;
      __res = (int )*(*tmp___6 + i);
      }
    }
    *tmp___2 = (unsigned char )__res;
    i ++;
  }
  while_0_break:  ;
  i = 0;
  while (1) {
    while_1_continue:  ;
    if (! (i < 256)) {
      goto while_1_break;
    }
    {
    tmp___7 = p;
    p ++;
    tmp___25 = __dyc_funcallvar_5;
    }
    if ((int const   )*(*tmp___25 + i) & 512) {
      if (sizeof(int ) > 1UL) {
        {
        tmp___19 = __dyc_funcallvar_6;
        __res___2 = (int )tmp___19;
        }
      } else {
        {
        tmp___20 = __dyc_funcallvar_7;
        __res___2 = (int )*(*tmp___20 + i);
        }
      }
      *tmp___7 = (unsigned char )__res___2;
    } else {
      if (sizeof(int ) > 1UL) {
        {
        tmp___23 = __dyc_funcallvar_8;
        __res___3 = (int )tmp___23;
        }
      } else {
        {
        tmp___24 = __dyc_funcallvar_9;
        __res___3 = (int )*(*tmp___24 + i);
        }
      }
      *tmp___7 = (unsigned char )__res___3;
    }
    i ++;
  }
  while_1_break:  ;

  i = 0;
  while (1) {
    while_2_continue:  ;
    if (! (i < 256)) {
      goto while_2_break;
    }
    {
    tmp___26 = __dyc_funcallvar_10;
    }
    if ((int const   )*(*tmp___26 + i) & 2048) {
      *(p + (64 + i / 8)) = (unsigned char )((unsigned int )*(p + (64 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___27 = __dyc_funcallvar_11;
    }
    if ((int const   )*(*tmp___27 + i) & 256) {
      *(p + (96 + i / 8)) = (unsigned char )((unsigned int )*(p + (96 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___28 = __dyc_funcallvar_12;
    }
    if ((int const   )*(*tmp___28 + i) & 512) {
      *(p + (128 + i / 8)) = (unsigned char )((unsigned int )*(p + (128 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___29 = __dyc_funcallvar_13;
    }
    if ((int const   )*(*tmp___29 + i) & 8) {
      *(p + (160 + i / 8)) = (unsigned char )((unsigned int )*(p + (160 + i / 8)) | (1U << (i & 7)));
    }
    if (i == 95) {
      *(p + (160 + i / 8)) = (unsigned char )((unsigned int )*(p + (160 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___30 = __dyc_funcallvar_14;
    }
    if ((int const   )*(*tmp___30 + i) & 8192) {
      *(p + i / 8) = (unsigned char )((unsigned int )*(p + i / 8) | (1U << (i & 7)));
    }
    {
    tmp___31 = __dyc_funcallvar_15;
    }
    if ((int const   )*(*tmp___31 + i) & 4096) {
      *(p + (32 + i / 8)) = (unsigned char )((unsigned int )*(p + (32 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___32 = __dyc_funcallvar_16;
    }
    if ((int const   )*(*tmp___32 + i) & 32768) {
      *(p + (192 + i / 8)) = (unsigned char )((unsigned int )*(p + (192 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___33 = __dyc_funcallvar_17;
    }
    if ((int const   )*(*tmp___33 + i) & 16384) {
      *(p + (224 + i / 8)) = (unsigned char )((unsigned int )*(p + (224 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___34 = __dyc_funcallvar_18;
    }
    if ((int const   )*(*tmp___34 + i) & 4) {
      *(p + (256 + i / 8)) = (unsigned char )((unsigned int )*(p + (256 + i / 8)) | (1U << (i & 7)));
    }
    {
    tmp___35 = __dyc_funcallvar_19;
    }
    if ((int const   )*(*tmp___35 + i) & 2) {
      *(p + (288 + i / 8)) = (unsigned char )((unsigned int )*(p + (288 + i / 8)) | (1U << (i & 7)));
    }
    i ++;
  }
  while_2_break:  ;
  p += 320;
  i = 0;
  while (1) {
    while_3_continue:  ;
    if (! (i < 256)) {
      goto __dyc_dummy_label;
    }
    {
    x = 0;
    tmp___36 = __dyc_funcallvar_20;
    }
    if ((int const   )*(*tmp___36 + i) & 8192) {
      x ++;
    }
    {
    tmp___37 = __dyc_funcallvar_21;
    }
    if ((int const   )*(*tmp___37 + i) & 1024) {
      x += 2;
    }
    {
    tmp___38 = __dyc_funcallvar_22;
    }
    if ((int const   )*(*tmp___38 + i) & 512) {
      x += 4;
    }
    {
    tmp___39 = __dyc_funcallvar_23;
    }
    if ((int const   )*(*tmp___39 + i) & 2048) {
      x += 8;
    }
    {
    tmp___40 = __dyc_funcallvar_24;
    }
    if ((int const   )*(*tmp___40 + i) & 8) {
      x += 16;
    } else {
      if (i == 95) {
        x += 16;
      }
    }
    tmp___41 = p;
    p ++;
    *tmp___41 = (unsigned char )x;
    i ++;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(p);
}
}
