#include "../include/dycfoo.h"
#include "../include/pcre2_config.i.hd.c.h"
void __dyc_foo(void) 
{ int configured_link_size ;
  char const   *_pcre2_unicode_version_32 ;
  char const   *v ;
  size_t tmp___1 ;
  void *where ;
  size_t __dyc_funcallvar_1 ;
  size_t __dyc_funcallvar_2 ;

  {
  configured_link_size = __dyc_readpre_byte();
  _pcre2_unicode_version_32 = (char const   *)__dyc_read_ptr__char();
  where = __dyc_read_ptr__void();
  __dyc_funcallvar_1 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (size_t )__dyc_readpre_byte();
  v = 0;
  tmp___1 = 0;
  switch_1_7:  
  *((uint32_t *)where) = 10000000U;
  goto __dyc_dummy_label;
  switch_1_12:  
  *((uint32_t *)where) = 20000000U;
  goto __dyc_dummy_label;
  switch_1_1:  
  *((uint32_t *)where) = 0U;
  goto __dyc_dummy_label;
  switch_1_2:  
  goto __dyc_dummy_label;
  switch_1_3:  
  *((uint32_t *)where) = (unsigned int )configured_link_size;
  goto __dyc_dummy_label;
  switch_1_4:  
  *((uint32_t *)where) = 10000000U;
  goto __dyc_dummy_label;
  switch_1_5:  
  *((uint32_t *)where) = 2U;
  goto __dyc_dummy_label;
  switch_1_13:  
  *((uint32_t *)where) = 0U;
  goto __dyc_dummy_label;
  switch_1_6:  
  *((uint32_t *)where) = 250U;
  goto __dyc_dummy_label;
  switch_1_8:  
  *((uint32_t *)where) = 0U;
  goto __dyc_dummy_label;
  switch_1_15:  
  *((uint32_t *)where) = 1088U;
  goto __dyc_dummy_label;
  switch_1_10:  
  v = _pcre2_unicode_version_32;
  if ((unsigned long )where == (unsigned long )((void *)0)) {
    {
    tmp___1 = __dyc_funcallvar_1;
    }
  } else {
    {
    tmp___1 = __dyc_funcallvar_2;
    }
  }
  goto __dyc_dummy_label;
  goto __dyc_dummy_label;
  switch_1_9:  
  *((uint32_t *)where) = 1U;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(v);
  __dyc_printpre_byte(tmp___1);
}
}
