#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint32_t list[8] ;
  uint32_t const   *list_ptr ;
  PCRE2_SPTR32 xclass_flags ;
  uint8_t const   *set1 ;
  uint8_t const   *set2 ;
  uint8_t const   *set_end ;
  BOOL invert_bits ;
  PCRE2_SPTR32 tmp___1 ;
  PCRE2_SPTR32 tmp___2 ;
  PCRE2_SPTR32 code ;
  compile_block_32 const   *cb ;
  uint32_t const   *base_list ;
  PCRE2_SPTR32 base_end ;

  {
  code = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  cb = (compile_block_32 const   *)__dyc_read_ptr__typdef_compile_block_32();
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  base_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  list_ptr = 0;
  xclass_flags = 0;
  set1 = 0;
  set2 = 0;
  set_end = 0;
  invert_bits = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  _L___1:  
  if (*(base_list + 0) == 110U) {
    set1 = (uint8_t const   *)((uint8_t *)(base_end - *(base_list + 2)));
    list_ptr = (uint32_t const   *)(list);
  } else {
    set1 = (uint8_t const   *)((uint8_t *)(code - list[2]));
    list_ptr = base_list;
  }
  invert_bits = 0;
  if ((int )*(list_ptr + 0) == 110) {
    goto switch_13_110;
  } else {
    if ((int )*(list_ptr + 0) == 111) {
      goto switch_13_110;
    } else {
      if ((int )*(list_ptr + 0) == 112) {
        goto switch_13_112;
      } else {
        if ((int )*(list_ptr + 0) == 6) {
          goto switch_13_6;
        } else {
          if ((int )*(list_ptr + 0) == 7) {
            goto switch_13_7;
          } else {
            if ((int )*(list_ptr + 0) == 8) {
              goto switch_13_8;
            } else {
              if ((int )*(list_ptr + 0) == 9) {
                goto switch_13_9;
              } else {
                if ((int )*(list_ptr + 0) == 10) {
                  goto switch_13_10;
                } else {
                  if ((int )*(list_ptr + 0) == 11) {
                    goto switch_13_11;
                  } else {
                    {
                    goto switch_13_default;
                    if (0) {
                      switch_13_110:  
                      switch_13_111:  
                      if ((unsigned long )list_ptr == (unsigned long )(list)) {
                        tmp___1 = code;
                      } else {
                        tmp___1 = base_end;
                      }
                      set2 = (uint8_t const   *)((uint8_t *)(tmp___1 - *(list_ptr + 2)));
                      goto switch_13_break;
                      switch_13_112:  
                      if ((unsigned long )list_ptr == (unsigned long )(list)) {
                        tmp___2 = code;
                      } else {
                        tmp___2 = base_end;
                      }
                      xclass_flags = (tmp___2 - *(list_ptr + 2)) + 1;
                      if ((*xclass_flags & 4U) != 0U) {
                        goto __dyc_dummy_label;
                      }
                      if ((*xclass_flags & 2U) == 0U) {
                        if (list[1] == 0U) {
                          goto __dyc_dummy_label;
                        }
                        goto __dyc_dummy_label;
                      }
                      set2 = (uint8_t const   *)((uint8_t *)(xclass_flags + 1));
                      goto switch_13_break;
                      switch_13_6:  
                      invert_bits = 1;
                      switch_13_7:  
                      set2 = (uint8_t const   *)((uint8_t *)(cb->cbits + 64));
                      goto switch_13_break;
                      switch_13_8:  
                      invert_bits = 1;
                      switch_13_9:  
                      set2 = (uint8_t const   *)((uint8_t *)(cb->cbits + 0));
                      goto switch_13_break;
                      switch_13_10:  
                      invert_bits = 1;
                      switch_13_11:  
                      set2 = (uint8_t const   *)((uint8_t *)(cb->cbits + 160));
                      goto switch_13_break;
                      switch_13_default:  ;
                      goto __dyc_dummy_label;
                    } else {
                      switch_13_break:  ;
                    }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  set_end = set1 + 32;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(set1);
  __dyc_print_ptr__typdef_uint8_t(set2);
  __dyc_print_ptr__typdef_uint8_t(set_end);
  __dyc_printpre_byte(invert_bits);
}
}
