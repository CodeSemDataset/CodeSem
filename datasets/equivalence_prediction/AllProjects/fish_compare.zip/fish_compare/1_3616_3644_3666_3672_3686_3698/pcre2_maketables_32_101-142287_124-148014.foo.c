#include "../include/dycfoo.h"
#include "../include/pcre2_maketables.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  uint8_t *p ;
  unsigned short const   **tmp___26 ;
  unsigned short const   **tmp___27 ;
  unsigned short const   **tmp___28 ;
  unsigned short const   **tmp___29 ;
  unsigned short const   **tmp___30 ;
  unsigned short const   **__dyc_funcallvar_10 ;
  unsigned short const   **__dyc_funcallvar_11 ;
  unsigned short const   **__dyc_funcallvar_12 ;
  unsigned short const   **__dyc_funcallvar_13 ;
  unsigned short const   **__dyc_funcallvar_14 ;

  {
  i = __dyc_readpre_byte();
  p = __dyc_read_ptr__typdef_uint8_t();
  __dyc_funcallvar_10 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_11 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_12 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_13 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_14 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  tmp___26 = 0;
  tmp___27 = 0;
  tmp___28 = 0;
  tmp___29 = 0;
  tmp___30 = 0;
  i ++;
  while_2_continue:  ;
  if (! (i < 256)) {
    goto __dyc_dummy_label;
  }
  tmp___26 = __dyc_funcallvar_10;
  if ((int const   )*(*tmp___26 + i) & 2048) {
    *(p + (64 + i / 8)) = (unsigned char )((unsigned int )*(p + (64 + i / 8)) | (1U << (i & 7)));
  }
  tmp___27 = __dyc_funcallvar_11;
  if ((int const   )*(*tmp___27 + i) & 256) {
    *(p + (96 + i / 8)) = (unsigned char )((unsigned int )*(p + (96 + i / 8)) | (1U << (i & 7)));
  }
  tmp___28 = __dyc_funcallvar_12;
  if ((int const   )*(*tmp___28 + i) & 512) {
    *(p + (128 + i / 8)) = (unsigned char )((unsigned int )*(p + (128 + i / 8)) | (1U << (i & 7)));
  }
  tmp___29 = __dyc_funcallvar_13;
  if ((int const   )*(*tmp___29 + i) & 8) {
    *(p + (160 + i / 8)) = (unsigned char )((unsigned int )*(p + (160 + i / 8)) | (1U << (i & 7)));
  }
  if (i == 95) {
    *(p + (160 + i / 8)) = (unsigned char )((unsigned int )*(p + (160 + i / 8)) | (1U << (i & 7)));
  }
  tmp___30 = __dyc_funcallvar_14;
  if ((int const   )*(*tmp___30 + i) & 8192) {
    *(p + i / 8) = (unsigned char )((unsigned int )*(p + i / 8) | (1U << (i & 7)));
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(i);
}
}
