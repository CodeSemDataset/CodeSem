#include "../include/dycfoo.h"
#include "../include/pcre2_maketables.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  int x ;
  unsigned short const   **tmp___36 ;
  unsigned short const   **tmp___37 ;
  unsigned short const   **tmp___38 ;
  unsigned short const   **tmp___39 ;
  unsigned short const   **tmp___40 ;
  unsigned short const   **__dyc_funcallvar_21 ;
  unsigned short const   **__dyc_funcallvar_22 ;
  unsigned short const   **__dyc_funcallvar_23 ;
  unsigned short const   **__dyc_funcallvar_24 ;

  {
  i = __dyc_readpre_byte();
  x = __dyc_readpre_byte();
  tmp___36 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_21 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_22 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_23 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_24 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  tmp___37 = 0;
  tmp___38 = 0;
  tmp___39 = 0;
  tmp___40 = 0;
  if ((int const   )*(*tmp___36 + i) & 8192) {
    x ++;
  }
  tmp___37 = __dyc_funcallvar_21;
  if ((int const   )*(*tmp___37 + i) & 1024) {
    x += 2;
  }
  tmp___38 = __dyc_funcallvar_22;
  if ((int const   )*(*tmp___38 + i) & 512) {
    x += 4;
  }
  tmp___39 = __dyc_funcallvar_23;
  if ((int const   )*(*tmp___39 + i) & 2048) {
    x += 8;
  }
  tmp___40 = __dyc_funcallvar_24;
  if ((int const   )*(*tmp___40 + i) & 8) {
    x += 16;
  } else {
    if (i == 95) {
      x += 16;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(x);
}
}
