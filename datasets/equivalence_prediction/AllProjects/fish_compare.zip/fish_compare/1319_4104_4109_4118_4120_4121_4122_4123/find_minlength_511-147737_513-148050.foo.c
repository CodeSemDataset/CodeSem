#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL had_recurse ;
  recurse_check this_recurse ;
  PCRE2_UCHAR32 *cs ;
  int dd ;
  recurse_check *r ;
  recurse_check *recurses ;
  int __dyc_funcallvar_5 ;

  {
  cs = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  r = __dyc_read_ptr__typdef_recurse_check();
  recurses = __dyc_read_ptr__typdef_recurse_check();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  had_recurse = 0;
  memset(& this_recurse, 0, sizeof(recurse_check ));
  dd = 0;
  while (1) {
    while_9_continue:  ;
    if (! ((unsigned long )r != (unsigned long )((void *)0))) {
      goto while_9_break;
    }
    if ((unsigned long )r->group == (unsigned long )cs) {
      goto while_9_break;
    }
    r = r->prev;
  }
  while_9_break:  ;
  if ((unsigned long )r != (unsigned long )((void *)0)) {
    had_recurse = 1;
  } else {
    {
    this_recurse.prev = recurses;
    this_recurse.group = (PCRE2_UCHAR32 const   *)cs;
    dd = __dyc_funcallvar_5;
    }
    if (dd < 0) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(had_recurse);
  __dyc_print_comp_75recurse_check(this_recurse);
}
}
