#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL had_recurse ;
  recurse_check this_recurse ;
  int d ;
  PCRE2_UCHAR32 *cs ;
  recurse_check *r___0 ;
  recurse_check *recurses ;
  int __dyc_funcallvar_8 ;

  {
  cs = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  r___0 = __dyc_read_ptr__typdef_recurse_check();
  recurses = __dyc_read_ptr__typdef_recurse_check();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  had_recurse = 0;
  memset(& this_recurse, 0, sizeof(recurse_check ));
  d = 0;
  while (1) {
    while_12_continue:  ;
    if (! ((unsigned long )r___0 != (unsigned long )((void *)0))) {
      goto while_12_break;
    }
    if ((unsigned long )r___0->group == (unsigned long )cs) {
      goto while_12_break;
    }
    r___0 = r___0->prev;
  }
  while_12_break:  ;
  if ((unsigned long )r___0 != (unsigned long )((void *)0)) {
    had_recurse = 1;
  } else {
    {
    this_recurse.prev = recurses;
    this_recurse.group = (PCRE2_UCHAR32 const   *)cs;
    d = __dyc_funcallvar_8;
    }
    if (d < 0) {
      goto __dyc_dummy_label;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(had_recurse);
  __dyc_print_comp_75recurse_check(this_recurse);
}
}
