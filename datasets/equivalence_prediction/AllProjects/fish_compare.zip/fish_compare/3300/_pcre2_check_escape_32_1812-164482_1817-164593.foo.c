#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 ptr ;
  uint32_t c ;
  int i ;
  PCRE2_SPTR32 tmp___4 ;
  int tmp___5 ;
  PCRE2_SPTR32 ptrend ;

  {
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  c = (uint32_t )__dyc_readpre_byte();
  i = __dyc_readpre_byte();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  tmp___4 = 0;
  tmp___5 = 0;
  while (1) {
    while_3_continue:  ;
    tmp___5 = i;
    i ++;
    if (tmp___5 < 2) {
      if ((unsigned long )ptr < (unsigned long )ptrend) {
        if (*ptr >= 48U) {
          if (! (*ptr <= 55U)) {
            goto while_3_break;
          }
        } else {
          goto while_3_break;
        }
      } else {
        goto while_3_break;
      }
    } else {
      goto while_3_break;
    }
    tmp___4 = ptr;
    ptr ++;
    c = (c * 8U + (uint32_t )*tmp___4) - 48U;
  }
  while_3_break:  ;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(i);
}
}
