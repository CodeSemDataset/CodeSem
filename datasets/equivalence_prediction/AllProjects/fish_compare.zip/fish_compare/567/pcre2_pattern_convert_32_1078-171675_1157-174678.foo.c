#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ pcre2_convert_context_32 _pcre2_default_convert_context_32 ;
  int i ;
  int rc ;
  PCRE2_UCHAR32 *use_buffer ;
  size_t use_length ;
  BOOL utf ;
  uint32_t pattype ;
  size_t erroroffset ;
  PCRE2_UCHAR32 *allocated ;
  BOOL dummyrun ;
  int tmp ;
  void *tmp___0 ;
  size_t plength ;
  uint32_t options ;
  PCRE2_UCHAR32 **buffptr ;
  size_t *bufflenptr ;
  pcre2_convert_context_32 *ccontext ;
  size_t __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;
  void *__dyc_funcallvar_5 ;

  {
  _pcre2_default_convert_context_32 = (pcre2_convert_context_32 const   )__dyc_read_comp_63pcre2_real_convert_context_32();
  utf = __dyc_readpre_byte();
  pattype = (uint32_t )__dyc_readpre_byte();
  erroroffset = (size_t )__dyc_readpre_byte();
  plength = (size_t )__dyc_readpre_byte();
  options = (uint32_t )__dyc_readpre_byte();
  buffptr = __dyc_read_ptr__ptr__typdef_PCRE2_UCHAR32();
  bufflenptr = __dyc_read_ptr__typdef_size_t();
  ccontext = __dyc_read_ptr__typdef_pcre2_convert_context_32();
  __dyc_funcallvar_1 = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_read_ptr__void();
  i = 0;
  rc = 0;
  use_buffer = 0;
  use_length = 0;
  allocated = 0;
  dummyrun = 0;
  tmp = 0;
  tmp___0 = 0;
  if (plength == 0xffffffffUL) {
    {
    plength = __dyc_funcallvar_1;
    }
  }
  if ((unsigned long )ccontext == (unsigned long )((void *)0)) {
    ccontext = (pcre2_convert_context_32 *)(& _pcre2_default_convert_context_32);
  }
  if (utf) {
    if ((options & 2U) == 0U) {
      {
      rc = __dyc_funcallvar_2;
      }
      if (rc != 0) {
        *bufflenptr = erroroffset;
        goto __dyc_dummy_label;
      }
    }
  }
  if ((unsigned long )buffptr != (unsigned long )((void *)0)) {
    if ((unsigned long )*buffptr != (unsigned long )((void *)0)) {
      use_buffer = *buffptr;
      use_length = *bufflenptr;
    }
  }
  i = 0;
  while (1) {
    while_24_continue:  ;
    if (! (i < 2)) {
      goto while_24_break;
    }
    if ((unsigned long )buffptr == (unsigned long )((void *)0)) {
      tmp = 1;
    } else {
      if ((unsigned long )*buffptr == (unsigned long )((void *)0)) {
        tmp = 1;
      } else {
        tmp = 0;
      }
    }
    dummyrun = tmp;
    if ((int )pattype == 16U) {
      goto switch_25_16;
    } else {
      if ((int )pattype == 4U) {
        goto switch_25_4;
      } else {
        if ((int )pattype == 8U) {
          goto switch_25_4;
        } else {
          {
          goto switch_25_default;
          if (0) {
            switch_25_16:  
            {
            rc = __dyc_funcallvar_3;
            }
            goto switch_25_break;
            switch_25_4:  
            switch_25_8:  
            {
            rc = __dyc_funcallvar_4;
            }
            goto switch_25_break;
            switch_25_default:  
            *bufflenptr = 0UL;
            goto __dyc_dummy_label;
          } else {
            switch_25_break:  ;
          }
          }
        }
      }
    }
    if (rc != 0) {
      goto __dyc_dummy_label;
    } else {
      if ((unsigned long )buffptr == (unsigned long )((void *)0)) {
        goto __dyc_dummy_label;
      } else {
        if ((unsigned long )*buffptr != (unsigned long )((void *)0)) {
          goto __dyc_dummy_label;
        }
      }
    }
    {
    tmp___0 = __dyc_funcallvar_5;
    allocated = (PCRE2_UCHAR32 *)tmp___0;
    }
    if ((unsigned long )allocated == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
    *buffptr = (PCRE2_UCHAR32 *)((char *)allocated + sizeof(pcre2_memctl ));
    use_buffer = *buffptr;
    use_length = *bufflenptr + 1UL;
    i ++;
  }
  while_24_break:  ;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(use_buffer);
  __dyc_printpre_byte(use_length);
  __dyc_printpre_byte(dummyrun);
  __dyc_printpre_byte(plength);
  __dyc_print_ptr__typdef_pcre2_convert_context_32(ccontext);
}
}
