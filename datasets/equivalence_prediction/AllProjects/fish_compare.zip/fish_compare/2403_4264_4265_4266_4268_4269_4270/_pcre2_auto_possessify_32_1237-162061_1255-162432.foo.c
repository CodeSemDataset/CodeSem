#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 *code ;

  {
  code = __dyc_read_ptr__typdef_PCRE2_UCHAR32();

  switch_29_85:  
  switch_29_86:  
  switch_29_87:  
  switch_29_88:  
  switch_29_89:  
  switch_29_90:  
  switch_29_94:  
  switch_29_95:  
  switch_29_96:  
  if (*(code + 1) == 16U) {
    code += 2;
  } else {
    if (*(code + 1) == 15U) {
      code += 2;
    }
  }
  goto __dyc_dummy_label;
  switch_29_91:  
  switch_29_92:  
  switch_29_93:  
  switch_29_97:  
  if (*(code + 2) == 16U) {
    code += 2;
  } else {
    if (*(code + 2) == 15U) {
      code += 2;
    }
  }
  goto __dyc_dummy_label;
  switch_29_119:  
  code += *(code + 3);
  goto __dyc_dummy_label;
  switch_29_112:  
  code += *(code + 1);
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(code);
}
}
