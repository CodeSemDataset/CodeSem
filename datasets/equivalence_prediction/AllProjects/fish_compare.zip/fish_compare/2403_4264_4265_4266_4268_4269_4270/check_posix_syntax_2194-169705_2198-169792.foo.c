#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 terminator ;
  PCRE2_SPTR32 ptr ;
  PCRE2_SPTR32 *endptr ;

  {
  terminator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  endptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();

  if (*(ptr + 1) == 93U) {
    ptr ++;
  } else {
    if (*(ptr + 1) == 92U) {
      ptr ++;
    } else {
      goto _L___0;
    }
  }
  _L___0:  
  if (*ptr == 91U) {
    if (*(ptr + 1) == (PCRE2_UCHAR32 const   )terminator) {
      goto __dyc_dummy_label;
    } else {
      goto _L;
    }
  } else {
    _L:  
    if (*ptr == 93U) {
      goto __dyc_dummy_label;
    } else {
      if (*ptr == (PCRE2_UCHAR32 const   )terminator) {
        if (*(ptr + 1) == 93U) {
          *endptr = ptr;
          goto __dyc_dummy_label;
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
}
}
