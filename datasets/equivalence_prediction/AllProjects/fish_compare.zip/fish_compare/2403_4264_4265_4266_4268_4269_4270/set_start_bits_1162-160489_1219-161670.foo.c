#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 tcode ;
  int rc ;
  int __dyc_funcallvar_2 ;
  PCRE2_SPTR32 __dyc_funcallvar_3 ;
  PCRE2_SPTR32 __dyc_funcallvar_4 ;
  PCRE2_SPTR32 __dyc_funcallvar_5 ;

  {
  tcode = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  __dyc_funcallvar_3 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_4 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_5 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  rc = 0;
  switch_21_119:  
  tcode += *(tcode + 3);
  goto __dyc_dummy_label;
  while (1) {
    while_24_continue:  ;
    tcode += *(tcode + 1);
    if (! (*tcode == 120U)) {
      goto while_24_break;
    }
  }
  while_24_break:  ;
  tcode += 2;
  goto __dyc_dummy_label;
  tcode ++;
  rc = __dyc_funcallvar_2;
  if (rc == 0) {
    goto __dyc_dummy_label;
  } else {
    if (rc == 3) {
      goto __dyc_dummy_label;
    } else {
      if (rc == 4) {
        goto __dyc_dummy_label;
      }
    }
  }
  while (1) {
    while_25_continue:  ;
    tcode += *(tcode + 1);
    if (! (*tcode == 120U)) {
      goto while_25_break;
    }
  }
  while_25_break:  ;
  tcode += 2;
  goto __dyc_dummy_label;
  switch_21_166:  
  tcode ++;
  while (1) {
    while_26_continue:  ;
    tcode += *(tcode + 1);
    if (! (*tcode == 120U)) {
      goto while_26_break;
    }
  }
  while_26_break:  ;
  tcode += 2;
  goto __dyc_dummy_label;
  tcode = __dyc_funcallvar_3;
  goto __dyc_dummy_label;
  tcode = __dyc_funcallvar_4;
  goto __dyc_dummy_label;
  tcode = __dyc_funcallvar_5;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(tcode);
}
}
