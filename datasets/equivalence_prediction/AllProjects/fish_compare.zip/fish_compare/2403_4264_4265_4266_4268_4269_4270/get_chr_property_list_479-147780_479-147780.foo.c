#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 end ;
  uint32_t *list ;

  {
  end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  list = __dyc_read_ptr__typdef_uint32_t();

  if ((int )*end == 107) {
    goto switch_6_100;
  } else {
    if ((int )*end == 104) {
      goto switch_6_104;
    } else {
      if ((int )*end == 105) {
        goto switch_6_104;
      } else {
        if ((int )*end == 109) {
          goto switch_6_104;
        } else {
          if (0) {
            switch_6_98:  
            switch_6_99:  
            switch_6_102:  
            switch_6_103:  
            switch_6_106:  
            switch_6_108:  
            *(list + 1) = 1U;
            end ++;
            goto switch_6_break;
            switch_6_100:  
            switch_6_101:  
            switch_6_107:  
            end ++;
            goto switch_6_break;
            switch_6_104:  
            switch_6_105:  
            switch_6_109:  
            *(list + 1) = (unsigned int )(*(end + 1) == 0U);
            end += 3;
            goto switch_6_break;
          } else {
            switch_6_break:  ;
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(end);
}
}
