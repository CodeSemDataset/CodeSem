#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL is_negative ;
  BOOL separator_seen ;
  PCRE2_SPTR32 pattern ;
  PCRE2_SPTR32 char_start ;
  uint32_t c ;
  PCRE2_SPTR32 tmp ;
  PCRE2_SPTR32 *from ;
  PCRE2_SPTR32 pattern_end ;
  pcre2_output_context *out ;
  BOOL no_wildsep ;

  {
  is_negative = __dyc_readpre_byte();
  separator_seen = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  from = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  out = __dyc_read_ptr__typdef_pcre2_output_context();
  no_wildsep = __dyc_readpre_byte();
  char_start = 0;
  c = 0;
  tmp = 0;
  char_start = pattern;
  tmp = pattern;
  pattern ++;
  c = (unsigned int )*tmp;
  if (c == 93U) {
    {

    }
    if (! is_negative) {
      if (! no_wildsep) {
        if (separator_seen) {
          {
          out->out_str[0] = (unsigned char )'(';
          out->out_str[1] = (unsigned char )'?';
          out->out_str[2] = (unsigned char )'<';
          out->out_str[3] = (unsigned char )'!';



          }
        }
      }
    }
    *from = pattern;
    goto __dyc_dummy_label;
  }
  if ((unsigned long )pattern >= (unsigned long )pattern_end) {
    goto __dyc_dummy_label;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(char_start);
}
}
