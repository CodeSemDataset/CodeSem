#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 tcode ;
  pcre2_real_code_32 *re ;

  {
  tcode = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  re = __dyc_read_ptr__typdef_pcre2_real_code_32();

  switch_21_85:  
  switch_21_86:  
  switch_21_94:  
  switch_21_89:  
  switch_21_90:  
  switch_21_96:  
  if ((int )*(tcode + 1) == 12) {
    goto switch_27_12;
  } else {
    if ((int )*(tcode + 1) == 13) {
      goto switch_27_12;
    } else {
      if ((int )*(tcode + 1) == 19) {
        goto switch_27_19;
      } else {
        if ((int )*(tcode + 1) == 17) {
          goto switch_27_17;
        } else {
          if ((int )*(tcode + 1) == 21) {
            goto switch_27_17;
          } else {
            if ((int )*(tcode + 1) == 6) {
              goto switch_27_6;
            } else {
              if ((int )*(tcode + 1) == 7) {
                goto switch_27_7;
              } else {
                if ((int )*(tcode + 1) == 8) {
                  goto switch_27_8;
                } else {
                  if ((int )*(tcode + 1) == 9) {
                    goto switch_27_9;
                  } else {
                    if ((int )*(tcode + 1) == 10) {
                      goto switch_27_10;
                    } else {
                      if ((int )*(tcode + 1) == 11) {
                        goto switch_27_11;
                      } else {
                        {
                        goto switch_27_default;
                        if (0) {
                          switch_27_default:  ;
                          switch_27_12:  
                          switch_27_13:  
                          goto __dyc_dummy_label;
                          switch_27_19:  
                          re->start_bitmap[1] = (unsigned char )((unsigned int )re->start_bitmap[1] | (1U << 1));
                          re->start_bitmap[4] = (unsigned char )((unsigned int )re->start_bitmap[4] | 1U);
                          re->start_bitmap[20] = (unsigned char )((unsigned int )re->start_bitmap[20] | 1U);
                          re->start_bitmap[31] = (unsigned char )((unsigned int )re->start_bitmap[31] | (1U << 7));
                          goto switch_27_break;
                          switch_27_17:  
                          switch_27_21:  
                          re->start_bitmap[1] = (unsigned char )((unsigned int )re->start_bitmap[1] | (1U << 2));
                          re->start_bitmap[1] = (unsigned char )((unsigned int )re->start_bitmap[1] | (1U << 3));
                          re->start_bitmap[1] = (unsigned char )((unsigned int )re->start_bitmap[1] | (1U << 4));
                          re->start_bitmap[1] = (unsigned char )((unsigned int )re->start_bitmap[1] | (1U << 5));
                          re->start_bitmap[16] = (unsigned char )((unsigned int )re->start_bitmap[16] | (1U << 5));
                          re->start_bitmap[31] = (unsigned char )((unsigned int )re->start_bitmap[31] | (1U << 7));
                          goto switch_27_break;
                          switch_27_6:  
                          {

                          }
                          goto switch_27_break;
                          switch_27_7:  
                          {

                          }
                          goto switch_27_break;
                          switch_27_8:  
                          {

                          }
                          goto switch_27_break;
                          switch_27_9:  
                          {

                          }
                          goto switch_27_break;
                          switch_27_10:  
                          {

                          }
                          goto switch_27_break;
                          switch_27_11:  
                          {

                          }
                          goto switch_27_break;
                        } else {
                          switch_27_break:  ;
                        }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  tcode += 2;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(tcode);
}
}
