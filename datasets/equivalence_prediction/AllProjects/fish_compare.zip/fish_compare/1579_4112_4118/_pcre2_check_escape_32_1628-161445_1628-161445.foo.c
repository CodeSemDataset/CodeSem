#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   xdigitab[256] ;
  PCRE2_SPTR32 ptr ;
  uint32_t cc ;
  uint32_t xc ;
  PCRE2_SPTR32 hptr ;
  PCRE2_SPTR32 ptrend ;
  int *errorcodeptr ;

  {
  cc = (uint32_t )__dyc_readpre_byte();
  hptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  errorcodeptr = __dyc_read_ptr__int();
  ptr = 0;
  xc = 0;
  while (1) {
    while_2_continue:  ;
    if ((unsigned long )hptr < (unsigned long )ptrend) {
      if (*hptr <= 255U) {
        xc = (unsigned int )xdigitab[*hptr];
      } else {
        xc = 255U;
      }
      if (! (xc != 255U)) {
        goto __dyc_dummy_label;
      }
    } else {
      goto __dyc_dummy_label;
    }
    if ((cc & 4026531840U) != 0U) {
      *errorcodeptr = 177;
      ptr = hptr;
      goto __dyc_dummy_label;
    }
    cc = (cc << 4) | xc;
    hptr ++;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(cc);
}
}
