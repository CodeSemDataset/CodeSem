#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   catposstab[7][30] ;
  uint8_t const   posspropstab[3][4] ;
  uint32_t list[8] ;
  BOOL accepted ;
  int n ;
  uint8_t const   *p ;
  BOOL lisprop ;
  BOOL risprop ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  uint32_t const   *base_list ;

  {
  n = __dyc_readpre_byte();
  lisprop = __dyc_readpre_byte();
  risprop = __dyc_readpre_byte();
  tmp___9 = __dyc_readpre_byte();
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  accepted = 0;
  p = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  tmp___14 = 0;
  tmp___15 = 0;
  accepted = tmp___9;
  goto __dyc_dummy_label;
  switch_16_6:  
  switch_16_7:  
  switch_16_8:  
  p = posspropstab[n - 6];
  if (risprop) {
    if (list[3] != (uint32_t )*(p + 0)) {
      if (list[3] != (uint32_t )*(p + 1)) {
        if (list[3] != (uint32_t )*(p + 2)) {
          tmp___10 = 1;
        } else {
          if (! lisprop) {
            tmp___10 = 1;
          } else {
            tmp___10 = 0;
          }
        }
      } else {
        tmp___10 = 0;
      }
    } else {
      tmp___10 = 0;
    }
    if (lisprop == tmp___10) {
      tmp___11 = 1;
    } else {
      tmp___11 = 0;
    }
  } else {
    tmp___11 = 0;
  }
  accepted = tmp___11;
  goto __dyc_dummy_label;
  switch_16_9:  
  switch_16_10:  
  switch_16_11:  
  p = posspropstab[n - 9];
  if (lisprop) {
    if (*(base_list + 3) != (uint32_t const   )*(p + 0)) {
      if (*(base_list + 3) != (uint32_t const   )*(p + 1)) {
        if (*(base_list + 3) != (uint32_t const   )*(p + 2)) {
          tmp___12 = 1;
        } else {
          if (! risprop) {
            tmp___12 = 1;
          } else {
            tmp___12 = 0;
          }
        }
      } else {
        tmp___12 = 0;
      }
    } else {
      tmp___12 = 0;
    }
    if (risprop == tmp___12) {
      tmp___13 = 1;
    } else {
      tmp___13 = 0;
    }
  } else {
    tmp___13 = 0;
  }
  accepted = tmp___13;
  goto __dyc_dummy_label;
  switch_16_12:  
  switch_16_13:  
  switch_16_14:  
  p = posspropstab[n - 12];
  if (risprop) {
    if (catposstab[*(p + 0)][list[3]]) {
      if (catposstab[*(p + 1)][list[3]]) {
        if (list[3] != (uint32_t )*(p + 3)) {
          tmp___14 = 1;
        } else {
          if (! lisprop) {
            tmp___14 = 1;
          } else {
            tmp___14 = 0;
          }
        }
      } else {
        tmp___14 = 0;
      }
    } else {
      tmp___14 = 0;
    }
    if (lisprop == tmp___14) {
      tmp___15 = 1;
    } else {
      tmp___15 = 0;
    }
  } else {
    tmp___15 = 0;
  }
  accepted = tmp___15;
  goto __dyc_dummy_label;
  switch_16_15:  
  switch_16_16:  
  switch_16_17:  
  p = posspropstab[n - 15];
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(accepted);
  __dyc_print_ptr__typdef_uint8_t(p);
}
}
