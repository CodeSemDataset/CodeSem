#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 c ;
  PCRE2_SPTR32 end ;
  PCRE2_UCHAR32 *repeat_opcode ;
  uint32_t list[8] ;
  BOOL tmp___3 ;
  PCRE2_UCHAR32 *code ;
  PCRE2_SPTR32 __dyc_funcallvar_4 ;
  BOOL __dyc_funcallvar_5 ;

  {
  c = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  code = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_4 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  end = 0;
  repeat_opcode = 0;
  tmp___3 = 0;
  _L:  
  if (c == 112U) {
    repeat_opcode = code + *(code + 1);
  } else {
    repeat_opcode = (code + 1) + 32UL / sizeof(PCRE2_UCHAR32 );
  }
  c = *repeat_opcode;
  if (c >= 98U) {
    if (c <= 105U) {
      {
      end = __dyc_funcallvar_4;
      list[1] = (unsigned int )((c & 1U) == 0U);
      tmp___3 = __dyc_funcallvar_5;
      }
      if (tmp___3) {
        if ((int )c == 98) {
          goto switch_28_98;
        } else {
          if ((int )c == 99) {
            goto switch_28_98;
          } else {
            if ((int )c == 100) {
              goto switch_28_100;
            } else {
              if ((int )c == 101) {
                goto switch_28_100;
              } else {
                if ((int )c == 102) {
                  goto switch_28_102;
                } else {
                  if ((int )c == 103) {
                    goto switch_28_102;
                  } else {
                    if ((int )c == 104) {
                      goto switch_28_104;
                    } else {
                      if ((int )c == 105) {
                        goto switch_28_104;
                      } else {
                        if (0) {
                          switch_28_98:  
                          switch_28_99:  
                          *repeat_opcode = 106U;
                          goto switch_28_break;
                          switch_28_100:  
                          switch_28_101:  
                          *repeat_opcode = 107U;
                          goto switch_28_break;
                          switch_28_102:  
                          switch_28_103:  
                          *repeat_opcode = 108U;
                          goto switch_28_break;
                          switch_28_104:  
                          switch_28_105:  
                          *repeat_opcode = 109U;
                          goto switch_28_break;
                        } else {
                          switch_28_break:  ;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  c = *code;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(end);
}
}
