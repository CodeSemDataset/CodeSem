#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ pcre2_convert_context_32 _pcre2_default_convert_context_32 ;
  uint32_t pattype ;
  PCRE2_SPTR32 pattern ;
  size_t plength ;
  uint32_t options ;
  size_t *bufflenptr ;
  pcre2_convert_context_32 *ccontext ;
  size_t __dyc_funcallvar_1 ;

  {
  _pcre2_default_convert_context_32 = (pcre2_convert_context_32 const   )__dyc_read_comp_63pcre2_real_convert_context_32();
  pattype = (uint32_t )__dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  plength = (size_t )__dyc_readpre_byte();
  options = (uint32_t )__dyc_readpre_byte();
  bufflenptr = __dyc_read_ptr__typdef_size_t();
  ccontext = __dyc_read_ptr__typdef_pcre2_convert_context_32();
  __dyc_funcallvar_1 = (size_t )__dyc_readpre_byte();

  if ((unsigned long )pattern == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  } else {
    if ((unsigned long )bufflenptr == (unsigned long )((void *)0)) {
      goto __dyc_dummy_label;
    }
  }
  if ((options & 4294967168U) != 0U) {
    *bufflenptr = 0UL;
    goto __dyc_dummy_label;
  } else {
    if ((pattype & (~ pattype + 1U)) != pattype) {
      *bufflenptr = 0UL;
      goto __dyc_dummy_label;
    } else {
      if (pattype == 0U) {
        *bufflenptr = 0UL;
        goto __dyc_dummy_label;
      }
    }
  }
  if (plength == 0xffffffffUL) {
    {
    plength = __dyc_funcallvar_1;
    }
  }
  if ((unsigned long )ccontext == (unsigned long )((void *)0)) {
    ccontext = (pcre2_convert_context_32 *)(& _pcre2_default_convert_context_32);
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(plength);
  __dyc_print_ptr__typdef_pcre2_convert_context_32(ccontext);
}
}
