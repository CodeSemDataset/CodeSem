#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   catposstab[7][30] ;
  uint8_t const   posspropstab[3][4] ;
  uint32_t list[8] ;
  BOOL accepted ;
  int n ;
  uint8_t const   *p ;
  BOOL same ;
  BOOL lisprop ;
  BOOL risprop ;
  BOOL bothprop ;
  int tmp___8 ;
  int tmp___9 ;
  uint32_t const   *base_list ;

  {
  n = __dyc_readpre_byte();
  same = __dyc_readpre_byte();
  lisprop = __dyc_readpre_byte();
  risprop = __dyc_readpre_byte();
  bothprop = __dyc_readpre_byte();
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  accepted = 0;
  p = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  switch_16_1:  
  accepted = bothprop;
  goto __dyc_dummy_label;
  switch_16_2:  
  accepted = (*(base_list + 3) == (uint32_t const   )list[3]) != same;
  goto __dyc_dummy_label;
  switch_16_3:  
  accepted = ! same;
  goto __dyc_dummy_label;
  switch_16_4:  
  if (risprop) {
    if ((int const   )catposstab[*(base_list + 3)][list[3]] == (int const   )same) {
      tmp___8 = 1;
    } else {
      tmp___8 = 0;
    }
  } else {
    tmp___8 = 0;
  }
  accepted = tmp___8;
  goto __dyc_dummy_label;
  switch_16_5:  
  if (lisprop) {
    if ((int const   )catposstab[list[3]][*(base_list + 3)] == (int const   )same) {
      tmp___9 = 1;
    } else {
      tmp___9 = 0;
    }
  } else {
    tmp___9 = 0;
  }
  accepted = tmp___9;
  goto __dyc_dummy_label;
  switch_16_6:  
  switch_16_7:  
  switch_16_8:  
  p = posspropstab[n - 6];
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(accepted);
  __dyc_print_ptr__typdef_uint8_t(p);
}
}
