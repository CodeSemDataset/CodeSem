#include "../include/dycfoo.h"
#include "../include/pcre2_serialize.i.hd.c.h"
void __dyc_foo(void) 
{ pcre2_serialized_data const   *data ;
  uint8_t const   *src_bytes ;
  uint8_t *tables ;
  void *tmp___0 ;
  int32_t number_of_codes ;
  uint8_t const   *bytes ;
  void *__dyc_funcallvar_1 ;

  {
  data = (pcre2_serialized_data const   *)__dyc_read_ptr__typdef_pcre2_serialized_data();
  number_of_codes = __dyc_readpre_byte();
  bytes = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  src_bytes = 0;
  tables = 0;
  tmp___0 = 0;
  if (data->number_of_codes <= 0) {
    goto __dyc_dummy_label;
  }
  if (data->magic != 1347564115U) {
    goto __dyc_dummy_label;
  }
  if (data->version != (uint32_t const   )(10 | (36 << 16))) {
    goto __dyc_dummy_label;
  }
  if ((unsigned long )data->config != ((sizeof(PCRE2_UCHAR32 ) | (sizeof(void *) << 8)) | (sizeof(size_t ) << 16))) {
    goto __dyc_dummy_label;
  }
  if (number_of_codes > (int32_t )data->number_of_codes) {
    number_of_codes = (int )data->number_of_codes;
  }
  src_bytes = bytes + sizeof(pcre2_serialized_data );
  tmp___0 = __dyc_funcallvar_1;
  tables = (uint8_t *)tmp___0;
  if ((unsigned long )tables == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }

  *((size_t *)(tables + 1088)) = (unsigned long )number_of_codes;
  src_bytes += 1088;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(src_bytes);
  __dyc_printpre_byte(number_of_codes);
}
}
