#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   catposstab[7][30] ;
  uint8_t const   posspropstab[3][4] ;
  uint32_t list[8] ;
  BOOL accepted ;
  int n ;
  uint8_t const   *p ;
  BOOL same ;
  BOOL lisprop ;
  BOOL risprop ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  uint32_t const   *base_list ;

  {
  n = __dyc_readpre_byte();
  same = __dyc_readpre_byte();
  lisprop = __dyc_readpre_byte();
  risprop = __dyc_readpre_byte();
  tmp___8 = __dyc_readpre_byte();
  base_list = (uint32_t const   *)__dyc_read_ptr__typdef_uint32_t();
  accepted = 0;
  p = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___12 = 0;
  tmp___13 = 0;
  accepted = tmp___8;
  goto __dyc_dummy_label;
  switch_16_5:  
  if (lisprop) {
    if ((int const   )catposstab[list[3]][*(base_list + 3)] == (int const   )same) {
      tmp___9 = 1;
    } else {
      tmp___9 = 0;
    }
  } else {
    tmp___9 = 0;
  }
  accepted = tmp___9;
  goto __dyc_dummy_label;
  switch_16_6:  
  switch_16_7:  
  switch_16_8:  
  p = posspropstab[n - 6];
  if (risprop) {
    if (list[3] != (uint32_t )*(p + 0)) {
      if (list[3] != (uint32_t )*(p + 1)) {
        if (list[3] != (uint32_t )*(p + 2)) {
          tmp___10 = 1;
        } else {
          if (! lisprop) {
            tmp___10 = 1;
          } else {
            tmp___10 = 0;
          }
        }
      } else {
        tmp___10 = 0;
      }
    } else {
      tmp___10 = 0;
    }
    if (lisprop == tmp___10) {
      tmp___11 = 1;
    } else {
      tmp___11 = 0;
    }
  } else {
    tmp___11 = 0;
  }
  accepted = tmp___11;
  goto __dyc_dummy_label;
  switch_16_9:  
  switch_16_10:  
  switch_16_11:  
  p = posspropstab[n - 9];
  if (lisprop) {
    if (*(base_list + 3) != (uint32_t const   )*(p + 0)) {
      if (*(base_list + 3) != (uint32_t const   )*(p + 1)) {
        if (*(base_list + 3) != (uint32_t const   )*(p + 2)) {
          tmp___12 = 1;
        } else {
          if (! risprop) {
            tmp___12 = 1;
          } else {
            tmp___12 = 0;
          }
        }
      } else {
        tmp___12 = 0;
      }
    } else {
      tmp___12 = 0;
    }
    if (risprop == tmp___12) {
      tmp___13 = 1;
    } else {
      tmp___13 = 0;
    }
  } else {
    tmp___13 = 0;
  }
  accepted = tmp___13;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(accepted);
  __dyc_print_ptr__typdef_uint8_t(p);
}
}
