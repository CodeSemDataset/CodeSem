#include "../include/dycfoo.h"
#include "../include/pcre2_auto_possess.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_UCHAR32 c ;
  PCRE2_SPTR32 end ;
  PCRE2_UCHAR32 *repeat_opcode ;
  uint32_t list[8] ;
  PCRE2_UCHAR32 tmp ;
  int tmp___1 ;
  BOOL tmp___2 ;
  BOOL tmp___3 ;
  PCRE2_UCHAR32 *code ;
  PCRE2_UCHAR32 __dyc_funcallvar_1 ;
  PCRE2_SPTR32 __dyc_funcallvar_2 ;
  BOOL __dyc_funcallvar_3 ;
  PCRE2_SPTR32 __dyc_funcallvar_4 ;
  BOOL __dyc_funcallvar_5 ;

  {
  c = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  code = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_1 = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_3 = __dyc_readpre_byte();
  __dyc_funcallvar_4 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  end = 0;
  repeat_opcode = 0;
  tmp = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  if (c <= 97U) {
    {
    tmp = __dyc_funcallvar_1;
    c -= tmp - 33U;
    }
    if (c <= 40U) {
      {
      end = __dyc_funcallvar_2;
      }
    } else {
      end = (PCRE2_UCHAR32 const   *)((void *)0);
    }
    if (c == 33U) {
      tmp___1 = 1;
    } else {
      if (c == 35U) {
        tmp___1 = 1;
      } else {
        if (c == 37U) {
          tmp___1 = 1;
        } else {
          if (c == 39U) {
            tmp___1 = 1;
          } else {
            tmp___1 = 0;
          }
        }
      }
    }
    list[1] = (unsigned int )tmp___1;
    if ((unsigned long )end != (unsigned long )((void *)0)) {
      {
      tmp___2 = __dyc_funcallvar_3;
      }
      if (tmp___2) {
        if ((int )c == 33) {
          goto switch_27_33;
        } else {
          if ((int )c == 34) {
            goto switch_27_34;
          } else {
            if ((int )c == 35) {
              goto switch_27_35;
            } else {
              if ((int )c == 36) {
                goto switch_27_36;
              } else {
                if ((int )c == 37) {
                  goto switch_27_37;
                } else {
                  if ((int )c == 38) {
                    goto switch_27_38;
                  } else {
                    if ((int )c == 39) {
                      goto switch_27_39;
                    } else {
                      if ((int )c == 40) {
                        goto switch_27_40;
                      } else {
                        if (0) {
                          switch_27_33:  
                          *code += 9U;
                          goto switch_27_break;
                          switch_27_34:  
                          *code += 8U;
                          goto switch_27_break;
                          switch_27_35:  
                          *code += 8U;
                          goto switch_27_break;
                          switch_27_36:  
                          *code += 7U;
                          goto switch_27_break;
                          switch_27_37:  
                          *code += 7U;
                          goto switch_27_break;
                          switch_27_38:  
                          *code += 6U;
                          goto switch_27_break;
                          switch_27_39:  
                          *code += 6U;
                          goto switch_27_break;
                          switch_27_40:  
                          *code += 5U;
                          goto switch_27_break;
                        } else {
                          switch_27_break:  ;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    c = *code;
  }
  _L___0:  
  if (c == 110U) {
    goto _L;
  } else {
    if (c == 111U) {
      goto _L;
    } else {
      if (c == 112U) {
        _L:  
        if (c == 112U) {
          repeat_opcode = code + *(code + 1);
        } else {
          repeat_opcode = (code + 1) + 32UL / sizeof(PCRE2_UCHAR32 );
        }
        c = *repeat_opcode;
        if (c >= 98U) {
          if (c <= 105U) {
            {
            end = __dyc_funcallvar_4;
            list[1] = (unsigned int )((c & 1U) == 0U);
            tmp___3 = __dyc_funcallvar_5;
            }
            if (tmp___3) {
              if ((int )c == 98) {
                goto switch_28_98;
              } else {
                if ((int )c == 99) {
                  goto switch_28_98;
                } else {
                  if ((int )c == 100) {
                    goto switch_28_100;
                  } else {
                    if ((int )c == 101) {
                      goto switch_28_100;
                    } else {
                      if ((int )c == 102) {
                        goto switch_28_102;
                      } else {
                        if ((int )c == 103) {
                          goto switch_28_102;
                        } else {
                          if ((int )c == 104) {
                            goto switch_28_104;
                          } else {
                            if ((int )c == 105) {
                              goto switch_28_104;
                            } else {
                              if (0) {
                                switch_28_98:  
                                switch_28_99:  
                                *repeat_opcode = 106U;
                                goto switch_28_break;
                                switch_28_100:  
                                switch_28_101:  
                                *repeat_opcode = 107U;
                                goto switch_28_break;
                                switch_28_102:  
                                switch_28_103:  
                                *repeat_opcode = 108U;
                                goto switch_28_break;
                                switch_28_104:  
                                switch_28_105:  
                                *repeat_opcode = 109U;
                                goto switch_28_break;
                              } else {
                                switch_28_break:  ;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        c = *code;
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(end);
}
}
