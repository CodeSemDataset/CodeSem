#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned short const   **tmp___0 ;
  int tmp___1 ;
  unsigned short const   **tmp___2 ;
  unsigned short const   **tmp___3 ;
  unsigned short const   **tmp___4 ;
  unsigned short const   **tmp___5 ;
  unsigned short const   **tmp___6 ;
  unsigned short const   **tmp___7 ;
  PCRE2_UCHAR32 c ;
  unsigned short const   **__dyc_funcallvar_2 ;
  unsigned short const   **__dyc_funcallvar_3 ;
  unsigned short const   **__dyc_funcallvar_4 ;
  unsigned short const   **__dyc_funcallvar_5 ;
  unsigned short const   **__dyc_funcallvar_6 ;
  unsigned short const   **__dyc_funcallvar_7 ;
  unsigned short const   **__dyc_funcallvar_8 ;

  {
  c = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  __dyc_funcallvar_2 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_3 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_4 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_5 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_6 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_7 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_8 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___0 = __dyc_funcallvar_2;
  goto __dyc_dummy_label;
  switch_18_3:  
  goto __dyc_dummy_label;
  switch_18_4:  
  if (c == 9U) {
    tmp___1 = 1;
  } else {
    if (c == 32U) {
      tmp___1 = 1;
    } else {
      tmp___1 = 0;
    }
  }
  goto __dyc_dummy_label;
  tmp___2 = __dyc_funcallvar_3;
  goto __dyc_dummy_label;
  tmp___3 = __dyc_funcallvar_4;
  goto __dyc_dummy_label;
  tmp___4 = __dyc_funcallvar_5;
  goto __dyc_dummy_label;
  tmp___5 = __dyc_funcallvar_6;
  goto __dyc_dummy_label;
  tmp___6 = __dyc_funcallvar_7;
  goto __dyc_dummy_label;
  tmp___7 = __dyc_funcallvar_8;
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__ptr__short(tmp___0);
  __dyc_printpre_byte(tmp___1);
  __dyc_print_ptr__ptr__short(tmp___2);
  __dyc_print_ptr__ptr__short(tmp___3);
  __dyc_print_ptr__ptr__short(tmp___4);
  __dyc_print_ptr__ptr__short(tmp___5);
  __dyc_print_ptr__ptr__short(tmp___6);
  __dyc_print_ptr__ptr__short(tmp___7);
}
}
