#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ unsigned short const   **tmp___3 ;
  unsigned short const   **tmp___4 ;
  unsigned short const   **tmp___5 ;
  unsigned short const   **tmp___6 ;
  unsigned short const   **tmp___7 ;
  unsigned short const   **tmp___8 ;
  unsigned short const   **tmp___9 ;
  unsigned short const   **tmp___10 ;
  int tmp___11 ;
  PCRE2_UCHAR32 c ;
  unsigned short const   **__dyc_funcallvar_4 ;
  unsigned short const   **__dyc_funcallvar_5 ;
  unsigned short const   **__dyc_funcallvar_6 ;
  unsigned short const   **__dyc_funcallvar_7 ;
  unsigned short const   **__dyc_funcallvar_8 ;
  unsigned short const   **__dyc_funcallvar_9 ;
  unsigned short const   **__dyc_funcallvar_10 ;
  unsigned short const   **__dyc_funcallvar_11 ;

  {
  c = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  __dyc_funcallvar_4 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_5 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_6 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_7 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_8 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_9 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_10 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  __dyc_funcallvar_11 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  tmp___10 = 0;
  tmp___11 = 0;
  tmp___3 = __dyc_funcallvar_4;
  goto __dyc_dummy_label;
  tmp___4 = __dyc_funcallvar_5;
  goto __dyc_dummy_label;
  tmp___5 = __dyc_funcallvar_6;
  goto __dyc_dummy_label;
  tmp___6 = __dyc_funcallvar_7;
  goto __dyc_dummy_label;
  tmp___7 = __dyc_funcallvar_8;
  goto __dyc_dummy_label;
  tmp___8 = __dyc_funcallvar_9;
  goto __dyc_dummy_label;
  tmp___9 = __dyc_funcallvar_10;
  goto __dyc_dummy_label;
  tmp___10 = __dyc_funcallvar_11;
  if ((int const   )*(*tmp___10 + (int )c) & 8) {
    tmp___11 = 1;
  } else {
    if (c == 95U) {
      tmp___11 = 1;
    } else {
      tmp___11 = 0;
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__ptr__short(tmp___3);
  __dyc_print_ptr__ptr__short(tmp___4);
  __dyc_print_ptr__ptr__short(tmp___5);
  __dyc_print_ptr__ptr__short(tmp___6);
  __dyc_print_ptr__ptr__short(tmp___7);
  __dyc_print_ptr__ptr__short(tmp___8);
  __dyc_print_ptr__ptr__short(tmp___9);
  __dyc_printpre_byte(tmp___11);
}
}
