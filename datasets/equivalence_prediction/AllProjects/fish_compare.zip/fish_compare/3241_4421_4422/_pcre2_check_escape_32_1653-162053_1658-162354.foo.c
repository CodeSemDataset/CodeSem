#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t const   xdigitab[256] ;
  PCRE2_SPTR32 ptr ;
  uint32_t c ;
  uint32_t cc ;
  uint32_t xc ;

  {
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  cc = (uint32_t )__dyc_readpre_byte();
  xc = (uint32_t )__dyc_readpre_byte();
  c = 0;
  if (xc == 255U) {
    goto __dyc_dummy_label;
  }
  cc = (cc << 4) | xc;
  if (*(ptr + 2) <= 255U) {
    xc = (unsigned int )xdigitab[*(ptr + 2)];
  } else {
    xc = 255U;
  }
  if (xc == 255U) {
    goto __dyc_dummy_label;
  }
  cc = (cc << 4) | xc;
  if (*(ptr + 3) <= 255U) {
    xc = (unsigned int )xdigitab[*(ptr + 3)];
  } else {
    xc = 255U;
  }
  if (xc == 255U) {
    goto __dyc_dummy_label;
  }
  c = (cc << 4) | xc;
  ptr += 4;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(cc);
}
}
