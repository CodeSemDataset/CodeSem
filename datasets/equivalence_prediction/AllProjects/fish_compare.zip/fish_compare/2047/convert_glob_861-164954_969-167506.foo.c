#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ pcre2_output_context out ;
  PCRE2_SPTR32 pattern_end ;
  PCRE2_UCHAR32 separator ;
  PCRE2_UCHAR32 escape ;
  BOOL no_wildsep ;
  BOOL no_starstar ;
  BOOL in_atomic ;
  BOOL after_starstar ;
  BOOL no_slash_z ;
  BOOL is_start ;
  BOOL after_separator ;
  int tmp___2 ;
  PCRE2_SPTR32 pattern ;

  {
  pattern_end = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  separator = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  escape = (PCRE2_UCHAR32 )__dyc_readpre_byte();
  no_wildsep = __dyc_readpre_byte();
  no_starstar = __dyc_readpre_byte();
  after_starstar = __dyc_readpre_byte();
  is_start = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  memset(& out, 0, sizeof(pcre2_output_context ));
  in_atomic = 0;
  no_slash_z = 0;
  after_separator = 0;
  tmp___2 = 0;
  if (! no_starstar) {
    if ((unsigned long )pattern < (unsigned long )pattern_end) {
      if (*pattern == 42U) {
        if (is_start) {
          tmp___2 = 1;
        } else {
          if (*(pattern + -2) == (PCRE2_UCHAR32 const   )separator) {
            tmp___2 = 1;
          } else {
            tmp___2 = 0;
          }
        }
        after_separator = tmp___2;
        {
        while (1) {
          while_22_continue:  ;
          pattern ++;
          if ((unsigned long )pattern < (unsigned long )pattern_end) {
            if (! (*pattern == 42U)) {
              goto while_22_break;
            }
          } else {
            goto while_22_break;
          }
        }
        while_22_break:  ;
        }
        if ((unsigned long )pattern >= (unsigned long )pattern_end) {
          no_slash_z = 1;
          goto __dyc_dummy_label;
        }
        after_starstar = 1;
        if (after_separator) {
          if (escape != 0U) {
            if (*pattern == (PCRE2_UCHAR32 const   )escape) {
              if ((unsigned long )(pattern + 1) < (unsigned long )pattern_end) {
                if (*(pattern + 1) == (PCRE2_UCHAR32 const   )separator) {
                  pattern ++;
                }
              }
            }
          }
        }
        if (is_start) {
          if (*pattern != (PCRE2_UCHAR32 const   )separator) {
            goto __dyc_dummy_label;
          }
          {
          out.out_str[0] = (unsigned char )'(';
          out.out_str[1] = (unsigned char )'?';
          out.out_str[2] = (unsigned char )':';
          out.out_str[3] = (unsigned char )'\\';
          out.out_str[4] = (unsigned char )'A';
          out.out_str[5] = (unsigned char )'|';



          pattern ++;
          }
          goto __dyc_dummy_label;
        }
        {

        }
        if (! after_separator) {
          {
          out.out_str[0] = (unsigned char )'.';
          out.out_str[1] = (unsigned char )'*';
          out.out_str[2] = (unsigned char )'?';

          }
          goto __dyc_dummy_label;
        } else {
          if (*pattern != (PCRE2_UCHAR32 const   )separator) {
            {
            out.out_str[0] = (unsigned char )'.';
            out.out_str[1] = (unsigned char )'*';
            out.out_str[2] = (unsigned char )'?';

            }
            goto __dyc_dummy_label;
          }
        }
        {
        out.out_str[0] = (unsigned char )'(';
        out.out_str[1] = (unsigned char )'?';
        out.out_str[2] = (unsigned char )':';
        out.out_str[3] = (unsigned char )'.';
        out.out_str[4] = (unsigned char )'*';
        out.out_str[5] = (unsigned char )'?';


        out.out_str[0] = (unsigned char )')';
        out.out_str[1] = (unsigned char )'?';
        out.out_str[2] = (unsigned char )'?';

        pattern ++;
        }
        goto __dyc_dummy_label;
      }
    }
  }
  if ((unsigned long )pattern < (unsigned long )pattern_end) {
    if (*pattern == 42U) {
      {
      while (1) {
        while_23_continue:  ;
        pattern ++;
        if ((unsigned long )pattern < (unsigned long )pattern_end) {
          if (! (*pattern == 42U)) {
            goto while_23_break;
          }
        } else {
          goto while_23_break;
        }
      }
      while_23_break:  ;
      }
    }
  }
  if (no_wildsep) {
    if ((unsigned long )pattern >= (unsigned long )pattern_end) {
      no_slash_z = 1;
      goto __dyc_dummy_label;
    }
    if (is_start) {
      goto __dyc_dummy_label;
    }
  }
  if (! is_start) {
    if (after_starstar) {
      {
      out.out_str[0] = (unsigned char )'(';
      out.out_str[1] = (unsigned char )'?';
      out.out_str[2] = (unsigned char )'>';

      in_atomic = 1;
      }
    } else {
      {

      }
    }
  }
  if (no_wildsep) {
    {

    }
  } else {
    {

    }
  }
  out.out_str[0] = (unsigned char )'*';
  out.out_str[1] = (unsigned char )'?';
  if ((unsigned long )pattern >= (unsigned long )pattern_end) {
    out.out_str[1] = (unsigned char )'+';
  }
  __dyc_dummy_label:  ;
  __dyc_print_comp_85pcre2_output_context(out);
  __dyc_printpre_byte(in_atomic);
  __dyc_printpre_byte(after_starstar);
  __dyc_printpre_byte(no_slash_z);
  __dyc_printpre_byte(after_separator);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern);
}
}
