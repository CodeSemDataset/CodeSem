#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ PCRE2_SPTR32 p ;
  BOOL yield ;
  int32_t min ;
  int32_t max ;
  BOOL tmp ;
  PCRE2_SPTR32 tmp___0 ;
  BOOL tmp___1 ;
  PCRE2_SPTR32 *ptrptr ;
  PCRE2_SPTR32 ptrend ;
  uint32_t *minp ;
  uint32_t *maxp ;
  int *errorcodeptr ;
  BOOL __dyc_funcallvar_1 ;
  BOOL __dyc_funcallvar_2 ;

  {
  ptrptr = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  minp = __dyc_read_ptr__typdef_uint32_t();
  maxp = __dyc_read_ptr__typdef_uint32_t();
  errorcodeptr = __dyc_read_ptr__int();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  p = 0;
  yield = 0;
  min = 0;
  max = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  p = *ptrptr;
  yield = 0;
  min = 0;
  max = (int32_t )65536U;
  tmp = __dyc_funcallvar_1;
  if (! tmp) {
    goto __dyc_dummy_label;
  }
  if ((unsigned long )p >= (unsigned long )ptrend) {
    goto __dyc_dummy_label;
  }
  if (*p == 125U) {
    p ++;
    max = min;
  } else {
    tmp___0 = p;
    p ++;
    if (*tmp___0 != 44U) {
      goto __dyc_dummy_label;
    } else {
      if ((unsigned long )p >= (unsigned long )ptrend) {
        goto __dyc_dummy_label;
      }
    }
    if (*p != 125U) {
      {
      tmp___1 = __dyc_funcallvar_2;
      }
      if (tmp___1) {
        if ((unsigned long )p >= (unsigned long )ptrend) {
          goto __dyc_dummy_label;
        } else {
          if (*p != 125U) {
            goto __dyc_dummy_label;
          }
        }
      } else {
        goto __dyc_dummy_label;
      }
      if (max < min) {
        *errorcodeptr = 104;
        goto __dyc_dummy_label;
      }
    }
    p ++;
  }
  yield = 1;
  if ((unsigned long )minp != (unsigned long )((void *)0)) {
    *minp = (unsigned int )min;
  }
  if ((unsigned long )maxp != (unsigned long )((void *)0)) {
    *maxp = (unsigned int )max;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(yield);
  __dyc_printpre_byte(min);
  __dyc_printpre_byte(max);
}
}
