#include "../include/dycfoo.h"
#include "../include/pcre2_compile.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL utf ;
  PCRE2_SPTR32 ptr ;
  uint32_t c ;
  uint32_t cc ;
  BOOL overflow ;
  PCRE2_SPTR32 tmp___6 ;
  PCRE2_SPTR32 ptrend ;
  int *errorcodeptr ;

  {
  utf = __dyc_readpre_byte();
  ptr = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  ptrend = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  errorcodeptr = __dyc_read_ptr__int();
  c = 0;
  cc = 0;
  overflow = 0;
  tmp___6 = 0;
  *errorcodeptr = 178;
  c = 0U;
  overflow = 0;
  while (1) {
    while_4_continue:  ;
    if ((unsigned long )ptr < (unsigned long )ptrend) {
      if (*ptr >= 48U) {
        if (! (*ptr <= 55U)) {
          goto __dyc_dummy_label;
        }
      } else {
        goto __dyc_dummy_label;
      }
    } else {
      goto __dyc_dummy_label;
    }
    tmp___6 = ptr;
    ptr ++;
    cc = (unsigned int )*tmp___6;
    if (c == 0U) {
      if (cc == 48U) {
        goto while_4_continue;
      }
    }
    if ((long )c >= 536870912L) {
      overflow = 1;
      goto __dyc_dummy_label;
    }
    c = (c << 3) + (cc - 48U);
    if (utf) {
      if (c > 1114111U) {
        overflow = 1;
        goto __dyc_dummy_label;
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ptr);
  __dyc_printpre_byte(c);
  __dyc_printpre_byte(cc);
  __dyc_printpre_byte(overflow);
}
}
