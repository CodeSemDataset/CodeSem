#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL is_negative ;
  BOOL separator_seen ;
  BOOL has_prev_c ;
  PCRE2_SPTR32 pattern ;
  uint32_t prev_c ;
  int class_index ;
  BOOL tmp___0 ;
  PCRE2_SPTR32 *from ;
  int __dyc_funcallvar_1 ;
  BOOL __dyc_funcallvar_2 ;

  {
  is_negative = __dyc_readpre_byte();
  pattern = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  from = __dyc_read_ptr__typdef_PCRE2_SPTR32();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  separator_seen = 0;
  has_prev_c = 0;
  prev_c = 0;
  class_index = 0;
  tmp___0 = 0;
  *from = pattern;
  class_index = __dyc_funcallvar_1;
  if (class_index != 0) {
    pattern = *from;
    has_prev_c = 0;
    prev_c = 0U;
    if (! is_negative) {
      {
      tmp___0 = __dyc_funcallvar_2;
      }
      if (tmp___0) {
        separator_seen = 1;
      }
    }
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(separator_seen);
  __dyc_printpre_byte(has_prev_c);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(pattern);
  __dyc_printpre_byte(prev_c);
}
}
