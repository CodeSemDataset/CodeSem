#include "../include/dycfoo.h"
#include "../include/pcre2_convert.i.hd.c.h"
void __dyc_foo(void) 
{ char *s ;
  PCRE2_SPTR32 posix ;
  PCRE2_UCHAR32 *p ;
  PCRE2_UCHAR32 *endp ;
  uint32_t posix_state ;
  uint32_t c ;
  unsigned short const   **tmp___1 ;
  PCRE2_UCHAR32 *tmp___2 ;
  PCRE2_UCHAR32 *tmp___3 ;
  size_t plength ;
  unsigned short const   **__dyc_funcallvar_1 ;

  {
  posix = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  p = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  endp = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  posix_state = (uint32_t )__dyc_readpre_byte();
  c = (uint32_t )__dyc_readpre_byte();
  plength = (size_t )__dyc_readpre_byte();
  __dyc_funcallvar_1 = (unsigned short const   **)__dyc_read_ptr__ptr__short();
  s = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  tmp___3 = 0;
  if ((int )posix_state == 5) {
    goto switch_3_5;
  } else {
    if ((int )posix_state == 3) {
      goto switch_3_3;
    } else {
      if ((int )posix_state == 4) {
        goto switch_3_4;
      } else {
        if (0) {
          switch_3_5:  
          if (c <= 127U) {
            {
            tmp___1 = __dyc_funcallvar_1;
            }
            if ((int const   )*(*tmp___1 + (int )c) & 512) {
              goto switch_3_break;
            }
          }
          posix_state = 3U;
          if (c == 58U) {
            if (plength > 0UL) {
              if (*posix == 93U) {
                s = (char *)":]";
                {
                while (1) {
                  while_4_continue:  ;
                  if (! ((int )*s != 0)) {
                    goto while_4_break;
                  }
                  if ((unsigned long )p >= (unsigned long )endp) {
                    goto __dyc_dummy_label;
                  }
                  tmp___2 = p;
                  p ++;
                  *tmp___2 = (unsigned int )*s;
                  s ++;
                }
                while_4_break:  ;
                }
                plength --;
                posix ++;
                goto __dyc_dummy_label;
              }
            }
          }
          switch_3_3:  
          if (c == 91U) {
            posix_state = 4U;
          }
          goto switch_3_break;
          switch_3_4:  
          if (c == 58U) {
            posix_state = 5U;
          }
          goto switch_3_break;
        } else {
          switch_3_break:  ;
        }
      }
    }
  }
  if (c == 92U) {
    s = (char *)"\\";
    {
    while (1) {
      while_5_continue:  ;
      if (! ((int )*s != 0)) {
        goto while_5_break;
      }
      if ((unsigned long )p >= (unsigned long )endp) {
        goto __dyc_dummy_label;
      }
      tmp___3 = p;
      p ++;
      *tmp___3 = (unsigned int )*s;
      s ++;
    }
    while_5_break:  ;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(posix);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(p);
  __dyc_printpre_byte(posix_state);
  __dyc_printpre_byte(plength);
}
}
