#include "../include/dycfoo.h"
#include "../include/pcre2_study.i.hd.c.h"
void __dyc_foo(void) 
{ BOOL had_recurse ;
  BOOL dupcapused ;
  PCRE2_UCHAR32 *cc ;
  recurse_check this_recurse ;
  int d ;
  PCRE2_UCHAR32 *cs ;
  PCRE2_UCHAR32 *ce ;
  recurse_check *r___0 ;
  PCRE2_SPTR32 tmp___6 ;
  recurse_check *recurses ;
  PCRE2_SPTR32 __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;

  {
  dupcapused = __dyc_readpre_byte();
  cc = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  cs = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  recurses = __dyc_read_ptr__typdef_recurse_check();
  __dyc_funcallvar_7 = __dyc_read_ptr__typdef_PCRE2_UCHAR32();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  had_recurse = 0;
  memset(& this_recurse, 0, sizeof(recurse_check ));
  d = 0;
  ce = 0;
  r___0 = 0;
  tmp___6 = 0;
  ce = cs;
  if ((unsigned long )cs == (unsigned long )((void *)0)) {
    goto __dyc_dummy_label;
  }
  while (1) {
    while_11_continue:  ;
    ce += *(ce + 1);
    if (! (*ce == 120U)) {
      goto while_11_break;
    }
  }
  while_11_break:  ;
  if (! dupcapused) {
    goto _L___4;
  } else {
    {
    tmp___6 = __dyc_funcallvar_7;
    }
    if ((unsigned long )((PCRE2_UCHAR32 *)tmp___6) == (unsigned long )((void *)0)) {
      _L___4:  
      if ((unsigned long )cc > (unsigned long )cs) {
        if ((unsigned long )cc < (unsigned long )ce) {
          had_recurse = 1;
        } else {
          goto _L___3;
        }
      } else {
        _L___3:  
        r___0 = recurses;
        r___0 = recurses;
        {
        while (1) {
          while_12_continue:  ;
          if (! ((unsigned long )r___0 != (unsigned long )((void *)0))) {
            goto while_12_break;
          }
          if ((unsigned long )r___0->group == (unsigned long )cs) {
            goto while_12_break;
          }
          r___0 = r___0->prev;
        }
        while_12_break:  ;
        }
        if ((unsigned long )r___0 != (unsigned long )((void *)0)) {
          had_recurse = 1;
        } else {
          {
          this_recurse.prev = recurses;
          this_recurse.group = (PCRE2_UCHAR32 const   *)cs;
          d = __dyc_funcallvar_8;
          }
          if (d < 0) {
            goto __dyc_dummy_label;
          }
        }
      }
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(had_recurse);
  __dyc_print_comp_75recurse_check(this_recurse);
  __dyc_print_ptr__typdef_PCRE2_UCHAR32(ce);
}
}
