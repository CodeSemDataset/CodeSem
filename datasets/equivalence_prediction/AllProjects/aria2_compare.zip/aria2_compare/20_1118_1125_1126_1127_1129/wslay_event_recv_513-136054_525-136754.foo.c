#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ ssize_t r ;
  int new_frame ;

  {
  r = (ssize_t )__dyc_readpre_byte();
  new_frame = 0;
  if (r != 0L) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;

  new_frame = 1;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(new_frame);
}
}
