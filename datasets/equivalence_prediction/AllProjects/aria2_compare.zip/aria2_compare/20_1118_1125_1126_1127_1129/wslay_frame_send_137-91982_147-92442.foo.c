#include "../include/dycfoo.h"
#include "../include/wslay_frame.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t temp[4096] ;
  uint8_t const   *datamark ;
  uint8_t const   *datalimit ;
  size_t datalen ;
  uint8_t const   *writelimit ;
  unsigned long tmp___1 ;
  size_t writelen ;
  ssize_t r___0 ;
  size_t i ;
  wslay_frame_context_ptr ctx ;
  ssize_t __dyc_funcallvar_4 ;

  {
  datamark = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  datalimit = (uint8_t const   *)__dyc_read_ptr__typdef_uint8_t();
  ctx = __dyc_read_ptr__comp_30wslay_frame_context();
  __dyc_funcallvar_4 = (ssize_t )__dyc_readpre_byte();
  datalen = 0;
  writelimit = 0;
  tmp___1 = 0;
  writelen = 0;
  r___0 = 0;
  i = 0;
  if (! ((unsigned long )datamark < (unsigned long )datalimit)) {
    goto __dyc_dummy_label;
  }
  datalen = (unsigned long )(datalimit - datamark);
  if (sizeof(uint8_t [4096]) < datalen) {
    tmp___1 = sizeof(uint8_t [4096]);
  } else {
    tmp___1 = datalen;
  }
  writelimit = datamark + tmp___1;
  writelen = (unsigned long )(writelimit - datamark);
  i = 0UL;
  while (1) {
    while_1_continue:  ;
    if (! (i < writelen)) {
      goto while_1_break;
    }
    temp[i] = (unsigned char )((int const   )*(datamark + i) ^ (int const   )ctx->omaskkey[(ctx->opayloadoff + i) % 4UL]);
    i ++;
  }
  while_1_break:  ;
  r___0 = __dyc_funcallvar_4;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(r___0);
}
}
