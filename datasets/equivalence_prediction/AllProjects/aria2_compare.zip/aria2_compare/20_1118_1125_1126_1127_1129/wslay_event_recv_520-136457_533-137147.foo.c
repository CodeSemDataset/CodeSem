#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ struct wslay_frame_iocb iocb ;
  ssize_t r ;
  int new_frame ;
  int tmp___1 ;
  int tmp___2 ;
  wslay_event_context_ptr ctx ;
  int __dyc_funcallvar_4 ;
  int __dyc_funcallvar_5 ;

  {
  iocb = __dyc_read_comp_29wslay_frame_iocb();
  ctx = __dyc_read_ptr__comp_31wslay_event_context();
  __dyc_funcallvar_4 = __dyc_readpre_byte();
  __dyc_funcallvar_5 = __dyc_readpre_byte();
  r = 0;
  new_frame = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  if ((int )iocb.opcode == 1) {
    {

    new_frame = 1;
    }
  } else {
    if ((int )iocb.opcode == 2) {
      {

      new_frame = 1;
      }
    } else {
      if ((int )iocb.opcode == 8) {
        {

        new_frame = 1;
        }
      } else {
        if ((int )iocb.opcode == 9) {
          {

          new_frame = 1;
          }
        } else {
          if ((int )iocb.opcode == 10) {
            {

            new_frame = 1;
            }
          } else {
            {
            tmp___1 = __dyc_funcallvar_4;
            r = (long )tmp___1;
            }
            if (r != 0L) {
              goto __dyc_dummy_label;
            }
            goto __dyc_dummy_label;
          }
        }
      }
    }
  }
  if (ctx->ipayloadlen == 0UL) {
    if (ctx->ipayloadoff == 0UL) {
      if ((int )iocb.opcode == 0) {
        (ctx->imsg)->fin = iocb.fin;
      } else {
        if ((int )iocb.opcode == 8) {
          {
          ctx->imsg = & ctx->imsgs[1];

          }
        } else {
          if ((int )iocb.opcode == 9) {
            {
            ctx->imsg = & ctx->imsgs[1];

            }
          } else {
            if ((int )iocb.opcode == 10) {
              {
              ctx->imsg = & ctx->imsgs[1];

              }
            } else {
              {
              tmp___2 = __dyc_funcallvar_5;
              r = (long )tmp___2;
              }
              if (r != 0L) {
                goto __dyc_dummy_label;
              }
              goto __dyc_dummy_label;
            }
          }
        }
      }
      new_frame = 1;
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(new_frame);
}
}
