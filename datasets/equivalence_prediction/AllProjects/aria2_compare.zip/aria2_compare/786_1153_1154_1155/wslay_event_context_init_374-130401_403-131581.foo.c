#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ int (*wslay_event_frame_genmask_callback)(uint8_t *buf , size_t len ,
                                            void *user_data ) ;
  int i ;
  int r ;
  struct wslay_frame_callbacks frame_callbacks ;
  void *tmp ;
  wslay_event_context_ptr *ctx ;
  void *user_data ;
  void *__dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;

  {
  ctx = __dyc_read_ptr__typdef_wslay_event_context_ptr();
  user_data = __dyc_read_ptr__void();
  __dyc_funcallvar_1 = __dyc_read_ptr__void();
  __dyc_funcallvar_2 = __dyc_readpre_byte();
  i = 0;
  r = 0;
  memset(& frame_callbacks, 0, sizeof(struct wslay_frame_callbacks ));
  tmp = 0;
  frame_callbacks.genmask_callback = & wslay_event_frame_genmask_callback;
  tmp = __dyc_funcallvar_1;
  *ctx = (struct wslay_event_context *)tmp;
  if (! *ctx) {
    goto __dyc_dummy_label;
  }

  (*ctx)->user_data = user_data;
  (*ctx)->frame_user_data.ctx = *ctx;
  (*ctx)->frame_user_data.user_data = user_data;
  r = __dyc_funcallvar_2;
  if (r != 0) {
    {

    }
    goto __dyc_dummy_label;
  }
  (*ctx)->write_enabled = (unsigned char)1;
  (*ctx)->read_enabled = (*ctx)->write_enabled;


  (*ctx)->queued_msg_count = 0UL;
  (*ctx)->queued_msg_length = 0UL;
  i = 0;
  while (1) {
    while_2_continue:  ;
    if (! (i < 2)) {
      goto while_2_break;
    }
    {


    i ++;
    }
  }
  while_2_break:  ;
  (*ctx)->imsg = & (*ctx)->imsgs[0];
  (*ctx)->obuflimit = (*ctx)->obuf;
  (*ctx)->obufmark = (*ctx)->obuflimit;
  (*ctx)->status_code_sent = (unsigned short)1006;
  (*ctx)->status_code_recv = (unsigned short)1006;
  (*ctx)->max_recv_msg_length = (unsigned long )((1U << 31) - 1U);
  __dyc_dummy_label:  ;
  __dyc_print_comp_28wslay_frame_callbacks(frame_callbacks);
}
}
