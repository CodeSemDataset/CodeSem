#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ int state ;
  char const   *path_last ;
  char const   *query_first ;
  char const   *last_slash ;
  char const   *p ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  state = 0;
  path_last = 0;
  query_first = 0;
  last_slash = 0;
  switch_1_15:  
  if ((int )*p == 47) {
    goto switch_12_47;
  } else {
    if ((int )*p == 63) {
      goto switch_12_63;
    } else {
      if ((int )*p == 35) {
        goto switch_12_35;
      } else {
        if (0) {
          switch_12_47:  
          last_slash = p;
          goto switch_12_break;
          switch_12_63:  
          path_last = p;
          state = 16;
          goto switch_12_break;
          switch_12_35:  
          path_last = p;
          state = 18;
          goto switch_12_break;
        } else {
          switch_12_break:  ;
        }
      }
    }
  }
  goto __dyc_dummy_label;
  switch_1_16:  
  query_first = p;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(state);
  __dyc_print_ptr__char(path_last);
  __dyc_print_ptr__char(query_first);
  __dyc_print_ptr__char(last_slash);
}
}
