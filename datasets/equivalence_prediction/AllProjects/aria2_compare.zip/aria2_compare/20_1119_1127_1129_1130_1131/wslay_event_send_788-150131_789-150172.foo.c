#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ ssize_t r ;
  uint16_t status_code ;
  unsigned short __v ;
  unsigned short __x ;
  wslay_event_context_ptr ctx ;

  {
  r = (ssize_t )__dyc_readpre_byte();
  __v = (unsigned short )__dyc_readpre_byte();
  ctx = __dyc_read_ptr__comp_31wslay_event_context();
  status_code = 0;
  __x = 0;
  ctx->opayloadoff += (unsigned long )r;
  if (ctx->opayloadoff == ctx->opayloadlen) {
    (ctx->queued_msg_count) --;
    ctx->queued_msg_length -= (ctx->omsg)->data_length;
    if ((int )(ctx->omsg)->opcode == 8) {
      status_code = (uint16_t )0;
      ctx->write_enabled = (unsigned char)0;
      ctx->close_status = (unsigned char )((int )ctx->close_status | 4);
      if ((ctx->omsg)->data_length >= 2UL) {
        {

        __x = status_code;

        status_code = __v;
        }
      }
      if ((int )status_code == 0) {
        ctx->status_code_sent = (unsigned short)1005;
      } else {
        ctx->status_code_sent = status_code;
      }
    }
    {

    ctx->omsg = (struct wslay_event_omsg *)((void *)0);
    }
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(__x);
}
}
