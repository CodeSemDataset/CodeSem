#include "../include/dycfoo.h"
#include "../include/wslay_frame.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t fin ;
  uint8_t opcode ;
  uint8_t rsv ;
  uint8_t payloadlen ;
  wslay_frame_context_ptr ctx ;

  {
  ctx = __dyc_read_ptr__comp_30wslay_frame_context();
  fin = 0;
  opcode = 0;
  rsv = 0;
  payloadlen = 0;
  if ((unsigned long )(ctx->ibuflimit - ctx->ibufmark) < ctx->ireqread) {
    goto __dyc_dummy_label;
  }
  fin = (unsigned char )(((int )*(ctx->ibufmark + 0) >> 7) & 1);
  rsv = (unsigned char )(((int )*(ctx->ibufmark + 0) >> 4) & 7);
  opcode = (unsigned char )((unsigned int )*(ctx->ibufmark + 0) & 15U);
  ctx->iom.opcode = opcode;
  ctx->iom.fin = fin;
  ctx->iom.rsv = rsv;
  (ctx->ibufmark) ++;
  ctx->imask = (unsigned char )(((int )*(ctx->ibufmark + 0) >> 7) & 1);
  payloadlen = (unsigned char )((unsigned int )*(ctx->ibufmark + 0) & 127U);
  (ctx->ibufmark) ++;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(payloadlen);
}
}
