#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ int state ;
  char const   *host_first ;
  char const   *host_last ;
  char const   *path_first ;
  char const   *last_slash ;
  char const   *p ;
  uint8_t flags ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  flags = (uint8_t )__dyc_readpre_byte();
  state = 0;
  host_first = 0;
  host_last = 0;
  path_first = 0;
  last_slash = 0;
  switch_1_9:  
  if ((int )*p == 58) {
    goto switch_9_58;
  } else {
    if ((int )*p == 47) {
      goto switch_9_47;
    } else {
      if ((int )*p == 63) {
        goto switch_9_63;
      } else {
        if ((int )*p == 35) {
          goto switch_9_35;
        } else {
          if (0) {
            switch_9_58:  
            host_last = p;
            state = 13;
            goto switch_9_break;
            switch_9_47:  
            last_slash = p;
            path_first = last_slash;
            host_last = path_first;
            state = 15;
            goto switch_9_break;
            switch_9_63:  
            host_last = p;
            state = 16;
            goto switch_9_break;
            switch_9_35:  
            host_last = p;
            state = 18;
            goto switch_9_break;
          } else {
            switch_9_break:  ;
          }
        }
      }
    }
  }
  goto __dyc_dummy_label;
  switch_1_10:  
  if ((int const   )*p == 93) {
    goto __dyc_dummy_label;
  }
  host_first = p;
  state = 11;
  goto __dyc_dummy_label;
  switch_1_11:  
  if ((int const   )*p == 93) {
    flags = (unsigned char )((int )flags | 1);
    host_last = p;
    state = 12;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(state);
  __dyc_print_ptr__char(host_first);
  __dyc_print_ptr__char(host_last);
  __dyc_printpre_byte(flags);
}
}
