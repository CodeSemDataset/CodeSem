#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ struct wslay_frame_iocb iocb ;
  ssize_t r ;
  int new_frame ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  size_t i ;
  int tmp___6 ;
  uint32_t tmp___7 ;
  struct wslay_event_byte_chunk *chunk ;
  struct wslay_queue_entry *tmp___8 ;
  int tmp___9 ;
  wslay_event_context_ptr ctx ;
  int __dyc_funcallvar_6 ;
  int __dyc_funcallvar_7 ;
  int __dyc_funcallvar_8 ;
  uint32_t __dyc_funcallvar_9 ;
  int __dyc_funcallvar_10 ;
  int __dyc_funcallvar_11 ;
  struct wslay_queue_entry *__dyc_funcallvar_12 ;
  struct wslay_queue_entry *__dyc_funcallvar_13 ;

  {
  iocb = __dyc_read_comp_29wslay_frame_iocb();
  new_frame = __dyc_readpre_byte();
  ctx = __dyc_read_ptr__comp_31wslay_event_context();
  __dyc_funcallvar_6 = __dyc_readpre_byte();
  __dyc_funcallvar_7 = __dyc_readpre_byte();
  __dyc_funcallvar_8 = __dyc_readpre_byte();
  __dyc_funcallvar_9 = (uint32_t )__dyc_readpre_byte();
  __dyc_funcallvar_10 = __dyc_readpre_byte();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_read_ptr__comp_39wslay_queue_entry();
  __dyc_funcallvar_13 = __dyc_read_ptr__comp_39wslay_queue_entry();
  r = 0;
  tmp___3 = 0;
  tmp___4 = 0;
  tmp___5 = 0;
  i = 0;
  tmp___6 = 0;
  tmp___7 = 0;
  chunk = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  if (new_frame) {
    if ((ctx->imsg)->msg_length + iocb.payload_length > ctx->max_recv_msg_length) {
      {
      tmp___3 = __dyc_funcallvar_6;
      r = (long )tmp___3;
      }
      if (r != 0L) {
        goto __dyc_dummy_label;
      }
      goto __dyc_dummy_label;
    }
    {
    ctx->ipayloadlen = iocb.payload_length;

    tmp___5 = __dyc_funcallvar_7;
    }
    if (tmp___5) {
      if (((int )iocb.opcode >> 3) & 1) {
        _L___2:  
        {
        tmp___4 = __dyc_funcallvar_8;
        r = (long )tmp___4;
        }
        if (r != 0L) {
          ctx->read_enabled = (unsigned char)0;
          goto __dyc_dummy_label;
        }
      }
    } else {
      goto _L___2;
    }
  }
  if (! (((int )(ctx->imsg)->rsv >> 2) & 1)) {
    if ((int )(ctx->imsg)->opcode == 1) {
      goto _L___3;
    } else {
      goto _L___4;
    }
  } else {
    _L___4:  
    if ((int )(ctx->imsg)->opcode == 8) {
      _L___3:  
      if ((int )(ctx->imsg)->opcode == 8) {
        i = 2UL;
      } else {
        i = 0UL;
      }
      {
      while (1) {
        while_7_continue:  ;
        if (! (i < iocb.data_length)) {
          goto while_7_break;
        }
        {
        tmp___7 = __dyc_funcallvar_9;
        }
        if (tmp___7 == 12U) {
          {
          tmp___6 = __dyc_funcallvar_10;
          r = (long )tmp___6;
          }
          if (r != 0L) {
            goto __dyc_dummy_label;
          }
          goto while_7_break;
        }
        i ++;
      }
      while_7_break:  ;
      }
    }
  }
  if ((ctx->imsg)->utf8state == 12U) {
    goto __dyc_dummy_label;
  }

  if (iocb.data_length > 0UL) {
    {
    tmp___9 = __dyc_funcallvar_11;
    }
    if (tmp___9) {
      if (((int )iocb.opcode >> 3) & 1) {
        {
        tmp___8 = __dyc_funcallvar_12;
        chunk = (struct wslay_event_byte_chunk *)((void *)((char *)tmp___8 - (unsigned int )(& ((struct wslay_event_byte_chunk *)0)->qe)));

        }
      }
    } else {
      {
      tmp___8 = __dyc_funcallvar_13;
      chunk = (struct wslay_event_byte_chunk *)((void *)((char *)tmp___8 - (unsigned int )(& ((struct wslay_event_byte_chunk *)0)->qe)));

      }
    }
    ctx->ipayloadoff += iocb.data_length;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__comp_41wslay_event_byte_chunk(chunk);
}
}
