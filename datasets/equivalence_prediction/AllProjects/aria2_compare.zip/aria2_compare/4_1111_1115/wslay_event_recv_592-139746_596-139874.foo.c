#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ struct wslay_frame_iocb iocb ;
  struct wslay_event_byte_chunk *chunk ;
  struct wslay_queue_entry *tmp___8 ;
  int tmp___9 ;
  wslay_event_context_ptr ctx ;
  int __dyc_funcallvar_11 ;
  struct wslay_queue_entry *__dyc_funcallvar_12 ;
  struct wslay_queue_entry *__dyc_funcallvar_13 ;

  {
  iocb = __dyc_read_comp_29wslay_frame_iocb();
  ctx = __dyc_read_ptr__comp_31wslay_event_context();
  __dyc_funcallvar_11 = __dyc_readpre_byte();
  __dyc_funcallvar_12 = __dyc_read_ptr__comp_39wslay_queue_entry();
  __dyc_funcallvar_13 = __dyc_read_ptr__comp_39wslay_queue_entry();
  chunk = 0;
  tmp___8 = 0;
  tmp___9 = 0;
  if ((ctx->imsg)->utf8state == 12U) {
    goto __dyc_dummy_label;
  }

  if (iocb.data_length > 0UL) {
    {
    tmp___9 = __dyc_funcallvar_11;
    }
    if (tmp___9) {
      if (((int )iocb.opcode >> 3) & 1) {
        {
        tmp___8 = __dyc_funcallvar_12;
        chunk = (struct wslay_event_byte_chunk *)((void *)((char *)tmp___8 - (unsigned int )(& ((struct wslay_event_byte_chunk *)0)->qe)));

        }
      }
    } else {
      {
      tmp___8 = __dyc_funcallvar_13;
      chunk = (struct wslay_event_byte_chunk *)((void *)((char *)tmp___8 - (unsigned int )(& ((struct wslay_event_byte_chunk *)0)->qe)));

      }
    }
    ctx->ipayloadoff += iocb.data_length;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__comp_41wslay_event_byte_chunk(chunk);
}
}
