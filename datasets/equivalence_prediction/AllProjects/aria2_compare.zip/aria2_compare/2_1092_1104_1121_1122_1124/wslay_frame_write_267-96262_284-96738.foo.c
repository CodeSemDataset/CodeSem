#include "../include/dycfoo.h"
#include "../include/wslay_frame.i.hd.c.h"
void __dyc_foo(void) 
{ uint8_t *buf_last ;
  size_t i ;
  size_t writelen ;
  size_t tmp___1 ;
  uint8_t *tmp___2 ;
  wslay_frame_context_ptr ctx ;
  struct wslay_frame_iocb *iocb ;
  size_t buflen ;
  size_t *pwpayloadlen ;

  {
  buf_last = __dyc_read_ptr__typdef_uint8_t();
  ctx = __dyc_read_ptr__comp_30wslay_frame_context();
  iocb = __dyc_read_ptr__comp_29wslay_frame_iocb();
  buflen = (size_t )__dyc_readpre_byte();
  pwpayloadlen = __dyc_read_ptr__typdef_size_t();
  i = 0;
  writelen = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  switch_2_3:  
  if (iocb->data_length > 0UL) {
    if (buflen < iocb->data_length) {
      tmp___1 = buflen;
    } else {
      tmp___1 = iocb->data_length;
    }
    writelen = tmp___1;
    if (ctx->omask) {
      i = 0UL;
      {
      while (1) {
        while_3_continue:  ;
        if (! (i < writelen)) {
          goto while_3_break;
        }
        tmp___2 = buf_last;
        buf_last ++;
        *tmp___2 = (unsigned char )((int const   )*(iocb->data + i) ^ (int const   )ctx->omaskkey[(ctx->opayloadoff + i) % 4UL]);
        i ++;
      }
      while_3_break:  ;
      }
    } else {
      {

      buf_last += writelen;
      }
    }
    ctx->opayloadoff += writelen;
    *pwpayloadlen = writelen;
  }
  if (ctx->opayloadoff == ctx->opayloadlen) {
    ctx->ostate = 0;
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__typdef_uint8_t(buf_last);
}
}
