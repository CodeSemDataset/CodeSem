#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ char const   *host_last ;
  char const   *path_last ;
  char const   *query_first ;
  char const   *query_last ;
  char const   *fragment_first ;
  char const   *fragment_last ;
  char const   *passwd_first ;
  char const   *passwd_last ;
  char const   *p ;
  int32_t port ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  port = __dyc_readpre_byte();
  host_last = 0;
  path_last = 0;
  query_first = 0;
  query_last = 0;
  fragment_first = 0;
  fragment_last = 0;
  passwd_first = 0;
  passwd_last = 0;
  passwd_last = (char const   *)((void *)0);
  passwd_first = passwd_last;
  goto __dyc_dummy_label;
  switch_13_8:  
  goto __dyc_dummy_label;
  switch_13_9:  
  host_last = p;
  goto __dyc_dummy_label;
  switch_13_10:  
  switch_13_11:  
  goto __dyc_dummy_label;
  switch_13_12:  
  goto __dyc_dummy_label;
  switch_13_13:  
  goto __dyc_dummy_label;
  switch_13_14:  
  if (port == -1) {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  switch_13_15:  
  path_last = p;
  goto __dyc_dummy_label;
  switch_13_16:  
  query_last = p;
  query_first = query_last;
  goto __dyc_dummy_label;
  switch_13_17:  
  query_last = p;
  goto __dyc_dummy_label;
  switch_13_18:  
  fragment_last = p;
  fragment_first = fragment_last;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(host_last);
  __dyc_print_ptr__char(path_last);
  __dyc_print_ptr__char(query_first);
  __dyc_print_ptr__char(query_last);
  __dyc_print_ptr__char(fragment_first);
  __dyc_print_ptr__char(passwd_first);
}
}
