#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ int state ;
  char const   *user_first ;
  char const   *p ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  state = 0;
  user_first = 0;
  switch_1_3:  
  if ((int const   )*p == 47) {
    state = 4;
  } else {
    goto __dyc_dummy_label;
  }
  goto __dyc_dummy_label;
  switch_1_4:  
  if ((int )*p == 64) {
    goto switch_2_64;
  } else {
    if ((int )*p == 58) {
      goto switch_2_64;
    } else {
      if ((int )*p == 47) {
        goto switch_2_64;
      } else {
        if ((int )*p == 91) {
          goto switch_2_91;
        } else {
          {
          goto switch_2_default;
          if (0) {
            switch_2_64:  
            switch_2_58:  
            switch_2_47:  
            goto __dyc_dummy_label;
            switch_2_91:  
            state = 10;
            goto switch_2_break;
            switch_2_default:  
            user_first = p;
            state = 5;
          } else {
            switch_2_break:  ;
          }
          }
        }
      }
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(state);
  __dyc_print_ptr__char(user_first);
}
}
