#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ int state ;
  char const   *scheme_first ;
  char const   *scheme_last ;
  char const   *host_first ;
  char const   *host_last ;
  char const   *path_first ;
  char const   *path_last ;
  char const   *query_first ;
  char const   *query_last ;
  char const   *fragment_first ;
  char const   *user_first ;
  char const   *user_last ;
  char const   *passwd_first ;
  char const   *passwd_last ;
  char const   *last_atmark ;
  char const   *last_slash ;
  char const   *p ;
  int32_t port ;
  uint8_t flags ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int __dyc_funcallvar_1 ;
  int __dyc_funcallvar_2 ;
  int __dyc_funcallvar_3 ;
  int __dyc_funcallvar_4 ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  state = 0;
  scheme_first = 0;
  scheme_last = 0;
  host_first = 0;
  host_last = 0;
  path_first = 0;
  path_last = 0;
  query_first = 0;
  query_last = 0;
  fragment_first = 0;
  user_first = 0;
  user_last = 0;
  passwd_first = 0;
  passwd_last = 0;
  last_atmark = 0;
  last_slash = 0;
  port = 0;
  flags = 0;
  tmp = 0;
  tmp___0 = 0;
  tmp___1 = 0;
  tmp___2 = 0;
  __dyc_funcallvar_1 = 0;
  __dyc_funcallvar_2 = 0;
  __dyc_funcallvar_3 = 0;
  __dyc_funcallvar_4 = 0;
  if (0) {
    switch_1_0:  
    scheme_first = p;
    state = 1;
    goto switch_1_break;
    switch_1_1:  
    if ((int const   )*p == 58) {
      scheme_last = p;
      state = 2;
    }
    goto switch_1_break;
    switch_1_2:  
    if ((int const   )*p == 47) {
      state = 3;
    } else {
      goto __dyc_dummy_label;
    }
    goto switch_1_break;
    switch_1_3:  
    if ((int const   )*p == 47) {
      state = 4;
    } else {
      goto __dyc_dummy_label;
    }
    goto switch_1_break;
    switch_1_4:  
    if ((int )*p == 64) {
      goto switch_2_64;
    } else {
      if ((int )*p == 58) {
        goto switch_2_64;
      } else {
        if ((int )*p == 47) {
          goto switch_2_64;
        } else {
          if ((int )*p == 91) {
            goto switch_2_91;
          } else {
            {
            goto switch_2_default;
            if (0) {
              switch_2_64:  
              switch_2_58:  
              switch_2_47:  
              goto __dyc_dummy_label;
              switch_2_91:  
              state = 10;
              goto switch_2_break;
              switch_2_default:  
              user_first = p;
              state = 5;
            } else {
              switch_2_break:  ;
            }
            }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_5:  
    if ((int )*p == 64) {
      goto switch_3_64;
    } else {
      if ((int )*p == 58) {
        goto switch_3_58;
      } else {
        if ((int )*p == 91) {
          goto switch_3_91;
        } else {
          if ((int )*p == 47) {
            goto switch_3_47;
          } else {
            if ((int )*p == 63) {
              goto switch_3_47;
            } else {
              if ((int )*p == 35) {
                goto switch_3_47;
              } else {
                if (0) {
                  switch_3_64:  
                  last_atmark = p;
                  goto switch_3_break;
                  switch_3_58:  
                  user_last = p;
                  state = 6;
                  goto switch_3_break;
                  switch_3_91:  
                  if ((unsigned long )last_atmark == (unsigned long )(p - 1)) {
                    user_last = last_atmark;
                    state = 10;
                  } else {
                    goto __dyc_dummy_label;
                  }
                  goto switch_3_break;
                  switch_3_47:  
                  switch_3_63:  
                  switch_3_35:  
                  if (last_atmark) {
                    host_first = last_atmark + 1;
                    host_last = p;
                    user_last = last_atmark;
                  } else {
                    host_first = user_first;
                    host_last = p;
                    user_last = (char const   *)((void *)0);
                    user_first = user_last;
                  }
                  if ((int )*p == 47) {
                    goto switch_4_47;
                  } else {
                    if ((int )*p == 63) {
                      goto switch_4_63;
                    } else {
                      if ((int )*p == 35) {
                        goto switch_4_35;
                      } else {
                        if (0) {
                          switch_4_47:  
                          last_slash = p;
                          path_first = last_slash;
                          state = 15;
                          goto switch_4_break;
                          switch_4_63:  
                          state = 16;
                          goto switch_4_break;
                          switch_4_35:  
                          state = 18;
                          goto switch_4_break;
                        } else {
                          switch_4_break:  ;
                        }
                      }
                    }
                  }
                  goto switch_3_break;
                } else {
                  switch_3_break:  ;
                }
              }
            }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_6:  
    passwd_first = p;
    if ((int )*p == 64) {
      goto switch_5_64;
    } else {
      if ((int )*p == 47) {
        goto switch_5_47;
      } else {
        {
        goto switch_5_default;
        if (0) {
          switch_5_64:  
          last_atmark = p;
          passwd_last = last_atmark;
          state = 8;
          goto switch_5_break;
          switch_5_47:  
          goto __dyc_dummy_label;
          switch_5_default:  
          {
          tmp = __dyc_funcallvar_1;
          }
          if (tmp) {
            port = (int )((int const   )*p - 48);
          }
          state = 7;
        } else {
          switch_5_break:  ;
        }
        }
      }
    }
    goto switch_1_break;
    switch_1_7:  
    if ((int )*p == 64) {
      goto switch_6_64;
    } else {
      if ((int )*p == 91) {
        goto switch_6_91;
      } else {
        if ((int )*p == 47) {
          goto switch_6_47;
        } else {
          if ((int )*p == 63) {
            goto switch_6_47;
          } else {
            if ((int )*p == 35) {
              goto switch_6_47;
            } else {
              {
              goto switch_6_default;
              if (0) {
                switch_6_64:  
                last_atmark = p;
                passwd_last = last_atmark;
                port = -1;
                state = 8;
                goto switch_6_break;
                switch_6_91:  
                goto __dyc_dummy_label;
                switch_6_47:  
                switch_6_63:  
                switch_6_35:  
                if (port == -1) {
                  goto __dyc_dummy_label;
                }
                if (last_atmark) {
                  host_first = last_atmark + 1;
                  host_last = passwd_first - 1;
                  user_last = last_atmark;
                } else {
                  host_first = user_first;
                  host_last = passwd_first - 1;
                  user_last = (char const   *)((void *)0);
                  user_first = user_last;
                }
                passwd_last = (char const   *)((void *)0);
                passwd_first = passwd_last;
                if ((int )*p == 47) {
                  goto switch_7_47;
                } else {
                  if ((int )*p == 63) {
                    goto switch_7_63;
                  } else {
                    if ((int )*p == 35) {
                      goto switch_7_35;
                    } else {
                      if (0) {
                        switch_7_47:  
                        last_slash = p;
                        path_first = last_slash;
                        state = 15;
                        goto switch_7_break;
                        switch_7_63:  
                        state = 16;
                        goto switch_7_break;
                        switch_7_35:  
                        state = 18;
                        goto switch_7_break;
                      } else {
                        switch_7_break:  ;
                      }
                    }
                  }
                }
                goto switch_6_break;
                switch_6_default:  ;
                if (port != -1) {
                  {
                  tmp___0 = __dyc_funcallvar_2;
                  }
                  if (tmp___0) {
                    port *= 10;
                    port += (int32_t )((int const   )*p - 48);
                    if (port > 65535) {
                      port = -1;
                    }
                  } else {
                    port = -1;
                  }
                }
                goto switch_6_break;
              } else {
                switch_6_break:  ;
              }
              }
            }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_8:  
    if ((int )*p == 58) {
      goto switch_8_58;
    } else {
      if ((int )*p == 47) {
        goto switch_8_58;
      } else {
        if ((int )*p == 91) {
          goto switch_8_91;
        } else {
          {
          goto switch_8_default;
          if (0) {
            switch_8_58:  
            switch_8_47:  
            goto __dyc_dummy_label;
            switch_8_91:  
            state = 10;
            goto switch_8_break;
            switch_8_default:  
            host_first = p;
            state = 9;
            goto switch_8_break;
          } else {
            switch_8_break:  ;
          }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_9:  
    if ((int )*p == 58) {
      goto switch_9_58;
    } else {
      if ((int )*p == 47) {
        goto switch_9_47;
      } else {
        if ((int )*p == 63) {
          goto switch_9_63;
        } else {
          if ((int )*p == 35) {
            goto switch_9_35;
          } else {
            if (0) {
              switch_9_58:  
              host_last = p;
              state = 13;
              goto switch_9_break;
              switch_9_47:  
              last_slash = p;
              path_first = last_slash;
              host_last = path_first;
              state = 15;
              goto switch_9_break;
              switch_9_63:  
              host_last = p;
              state = 16;
              goto switch_9_break;
              switch_9_35:  
              host_last = p;
              state = 18;
              goto switch_9_break;
            } else {
              switch_9_break:  ;
            }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_10:  
    if ((int const   )*p == 93) {
      goto __dyc_dummy_label;
    }
    host_first = p;
    state = 11;
    goto switch_1_break;
    switch_1_11:  
    if ((int const   )*p == 93) {
      flags = (unsigned char )((int )flags | 1);
      host_last = p;
      state = 12;
    }
    goto switch_1_break;
    switch_1_12:  
    if ((int )*p == 58) {
      goto switch_10_58;
    } else {
      if ((int )*p == 47) {
        goto switch_10_47;
      } else {
        if ((int )*p == 63) {
          goto switch_10_63;
        } else {
          if ((int )*p == 35) {
            goto switch_10_35;
          } else {
            {
            goto switch_10_default;
            if (0) {
              switch_10_58:  
              state = 13;
              goto switch_10_break;
              switch_10_47:  
              last_slash = p;
              path_first = last_slash;
              state = 15;
              goto switch_10_break;
              switch_10_63:  
              state = 16;
              goto switch_10_break;
              switch_10_35:  
              state = 18;
              goto switch_10_break;
              switch_10_default:  ;
              goto __dyc_dummy_label;
            } else {
              switch_10_break:  ;
            }
            }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_13:  
    {
    tmp___1 = __dyc_funcallvar_3;
    }
    if (tmp___1) {
      port = (int )((int const   )*p - 48);
      state = 14;
    } else {
      goto __dyc_dummy_label;
    }
    goto switch_1_break;
    switch_1_14:  
    if ((int )*p == 47) {
      goto switch_11_47;
    } else {
      if ((int )*p == 63) {
        goto switch_11_63;
      } else {
        if ((int )*p == 35) {
          goto switch_11_35;
        } else {
          {
          goto switch_11_default;
          if (0) {
            switch_11_47:  
            last_slash = p;
            path_first = last_slash;
            state = 15;
            goto switch_11_break;
            switch_11_63:  
            state = 16;
            goto switch_11_break;
            switch_11_35:  
            state = 18;
            goto switch_11_break;
            switch_11_default:  
            {
            tmp___2 = __dyc_funcallvar_4;
            }
            if (tmp___2) {
              port *= 10;
              port += (int32_t )((int const   )*p - 48);
              if (port > 65535) {
                goto __dyc_dummy_label;
              }
            } else {
              goto __dyc_dummy_label;
            }
          } else {
            switch_11_break:  ;
          }
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_15:  
    if ((int )*p == 47) {
      goto switch_12_47;
    } else {
      if ((int )*p == 63) {
        goto switch_12_63;
      } else {
        if ((int )*p == 35) {
          goto switch_12_35;
        } else {
          if (0) {
            switch_12_47:  
            last_slash = p;
            goto switch_12_break;
            switch_12_63:  
            path_last = p;
            state = 16;
            goto switch_12_break;
            switch_12_35:  
            path_last = p;
            state = 18;
            goto switch_12_break;
          } else {
            switch_12_break:  ;
          }
        }
      }
    }
    goto switch_1_break;
    switch_1_16:  
    query_first = p;
    if ((int const   )*p == 35) {
      query_last = p;
      state = 18;
    } else {
      state = 17;
    }
    goto switch_1_break;
    switch_1_17:  
    if ((int const   )*p == 35) {
      query_last = p;
      state = 18;
    }
    goto switch_1_break;
    switch_1_18:  
    fragment_first = p;
    state = 19;
    goto switch_1_break;
    switch_1_19:  
    goto switch_1_break;
  } else {
    switch_1_break:  ;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(state);
  __dyc_print_ptr__char(scheme_first);
}
}
