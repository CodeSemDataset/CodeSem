#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ int state ;
  char const   *host_last ;
  char const   *path_first ;
  char const   *last_slash ;
  char const   *p ;

  {
  p = (char const   *)__dyc_read_ptr__char();
  state = 0;
  host_last = 0;
  path_first = 0;
  last_slash = 0;
  if (0) {
    switch_9_58:  
    host_last = p;
    state = 13;
    goto switch_9_break;
    switch_9_47:  
    last_slash = p;
    path_first = last_slash;
    host_last = path_first;
    state = 15;
    goto switch_9_break;
    switch_9_63:  
    host_last = p;
    state = 16;
    goto switch_9_break;
    switch_9_35:  
    host_last = p;
    state = 18;
    goto switch_9_break;
  } else {
    switch_9_break:  ;
  }
  __dyc_dummy_label:  ;
  __dyc_printpre_byte(state);
  __dyc_print_ptr__char(host_last);
}
}
