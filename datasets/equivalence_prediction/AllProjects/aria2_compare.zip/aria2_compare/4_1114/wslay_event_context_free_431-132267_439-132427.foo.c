#include "../include/dycfoo.h"
#include "../include/wslay_event.i.hd.c.h"
void __dyc_foo(void) 
{ int i ;
  struct wslay_event_omsg *omsg ;
  struct wslay_queue_entry *tmp ;
  int tmp___0 ;
  wslay_event_context_ptr ctx ;
  int __dyc_funcallvar_1 ;
  struct wslay_queue_entry *__dyc_funcallvar_2 ;

  {
  ctx = __dyc_read_ptr__comp_31wslay_event_context();
  __dyc_funcallvar_1 = __dyc_readpre_byte();
  __dyc_funcallvar_2 = __dyc_read_ptr__comp_39wslay_queue_entry();
  i = 0;
  omsg = 0;
  tmp = 0;
  tmp___0 = 0;
  if (! ctx) {
    goto __dyc_dummy_label;
  }
  i = 0;
  while (1) {
    while_3_continue:  ;
    if (! (i < 2)) {
      goto while_3_break;
    }
    {


    i ++;
    }
  }
  while_3_break:  ;
  while (1) {
    while_4_continue:  ;
    {
    tmp___0 = __dyc_funcallvar_1;
    }
    if (tmp___0) {
      goto __dyc_dummy_label;
    }
    {
    tmp = __dyc_funcallvar_2;
    omsg = (struct wslay_event_omsg *)((void *)((char *)tmp - (unsigned int )(& ((struct wslay_event_omsg *)0)->qe)));


    }
  }
  __dyc_dummy_label:  ;
  __dyc_print_ptr__comp_43wslay_event_omsg(omsg);
}
}
