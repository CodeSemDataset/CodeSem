#include "../include/dycfoo.h"
#include "../include/uri_split.i.hd.c.h"
void __dyc_foo(void) 
{ int state ;
  char const   *host_first ;
  char const   *host_last ;
  char const   *path_last ;
  char const   *query_first ;
  char const   *query_last ;
  char const   *fragment_first ;
  char const   *fragment_last ;
  char const   *user_first ;
  char const   *user_last ;
  char const   *passwd_first ;
  char const   *passwd_last ;
  char const   *last_atmark ;
  char const   *last_slash ;
  char const   *p ;
  int32_t port ;
  uint8_t flags ;
  uri_split_result *res ;

  {
  state = __dyc_readpre_byte();
  path_last = (char const   *)__dyc_read_ptr__char();
  user_first = (char const   *)__dyc_read_ptr__char();
  passwd_first = (char const   *)__dyc_read_ptr__char();
  last_atmark = (char const   *)__dyc_read_ptr__char();
  last_slash = (char const   *)__dyc_read_ptr__char();
  p = (char const   *)__dyc_read_ptr__char();
  port = __dyc_readpre_byte();
  flags = (uint8_t )__dyc_readpre_byte();
  res = __dyc_read_ptr__typdef_uri_split_result();
  host_first = 0;
  host_last = 0;
  query_first = 0;
  query_last = 0;
  fragment_first = 0;
  fragment_last = 0;
  user_last = 0;
  passwd_last = 0;
  if (state == 0) {
    goto switch_13_0;
  } else {
    if (state == 1) {
      goto switch_13_0;
    } else {
      if (state == 2) {
        goto switch_13_0;
      } else {
        if (state == 3) {
          goto switch_13_0;
        } else {
          if (state == 4) {
            goto switch_13_4;
          } else {
            if (state == 5) {
              goto switch_13_5;
            } else {
              if (state == 6) {
                goto switch_13_6;
              } else {
                if (state == 7) {
                  goto switch_13_7;
                } else {
                  if (state == 8) {
                    goto switch_13_8;
                  } else {
                    if (state == 9) {
                      goto switch_13_9;
                    } else {
                      if (state == 10) {
                        goto switch_13_10;
                      } else {
                        if (state == 11) {
                          goto switch_13_10;
                        } else {
                          if (state == 12) {
                            goto switch_13_12;
                          } else {
                            if (state == 13) {
                              goto switch_13_13;
                            } else {
                              if (state == 14) {
                                goto switch_13_14;
                              } else {
                                if (state == 15) {
                                  goto switch_13_15;
                                } else {
                                  if (state == 16) {
                                    goto switch_13_16;
                                  } else {
                                    if (state == 17) {
                                      goto switch_13_17;
                                    } else {
                                      if (state == 18) {
                                        goto switch_13_18;
                                      } else {
                                        if (state == 19) {
                                          goto switch_13_19;
                                        } else {
                                          {
                                          goto switch_13_default;
                                          if (0) {
                                            switch_13_0:  
                                            switch_13_1:  
                                            switch_13_2:  
                                            switch_13_3:  
                                            goto __dyc_dummy_label;
                                            switch_13_4:  
                                            goto __dyc_dummy_label;
                                            switch_13_5:  
                                            if (last_atmark) {
                                              host_first = last_atmark + 1;
                                              host_last = p;
                                              if ((unsigned long )host_first == (unsigned long )host_last) {
                                                goto __dyc_dummy_label;
                                              }
                                              user_last = last_atmark;
                                            } else {
                                              host_first = user_first;
                                              host_last = p;
                                              user_last = (char const   *)((void *)0);
                                              user_first = user_last;
                                            }
                                            goto switch_13_break;
                                            switch_13_6:  
                                            goto __dyc_dummy_label;
                                            switch_13_7:  
                                            if (port == -1) {
                                              goto __dyc_dummy_label;
                                            }
                                            if (last_atmark) {
                                              host_first = last_atmark + 1;
                                              host_last = passwd_first - 1;
                                              user_last = last_atmark;
                                            } else {
                                              host_first = user_first;
                                              host_last = passwd_first - 1;
                                              user_last = (char const   *)((void *)0);
                                              user_first = user_last;
                                            }
                                            passwd_last = (char const   *)((void *)0);
                                            passwd_first = passwd_last;
                                            goto switch_13_break;
                                            switch_13_8:  
                                            goto __dyc_dummy_label;
                                            switch_13_9:  
                                            host_last = p;
                                            goto switch_13_break;
                                            switch_13_10:  
                                            switch_13_11:  
                                            goto __dyc_dummy_label;
                                            switch_13_12:  
                                            goto switch_13_break;
                                            switch_13_13:  
                                            goto __dyc_dummy_label;
                                            switch_13_14:  
                                            if (port == -1) {
                                              goto __dyc_dummy_label;
                                            }
                                            goto switch_13_break;
                                            switch_13_15:  
                                            path_last = p;
                                            goto switch_13_break;
                                            switch_13_16:  
                                            query_last = p;
                                            query_first = query_last;
                                            goto switch_13_break;
                                            switch_13_17:  
                                            query_last = p;
                                            goto switch_13_break;
                                            switch_13_18:  
                                            fragment_last = p;
                                            fragment_first = fragment_last;
                                            goto switch_13_break;
                                            switch_13_19:  
                                            fragment_last = p;
                                            goto switch_13_break;
                                            switch_13_default:  ;
                                            goto __dyc_dummy_label;
                                          } else {
                                            switch_13_break:  ;
                                          }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if (res) {
    {
    res->field_set = (unsigned short)0;
    res->port = (unsigned short)0;
    res->flags = flags;







    }
    if ((int )res->field_set & (1 << 7)) {
      {

      }
    }
    if (last_slash) {
      if ((unsigned long )(last_slash + 1) != (unsigned long )path_last) {
        {

        }
      }
    }
    if (port != -1) {
      res->field_set = (unsigned short )((int )res->field_set | (1 << 2));
      res->port = (unsigned short )port;
    }
  }
  goto __dyc_dummy_label;
  __dyc_dummy_label:  ;
  __dyc_print_ptr__char(host_first);
  __dyc_print_ptr__char(host_last);
  __dyc_print_ptr__char(path_last);
  __dyc_print_ptr__char(query_first);
  __dyc_print_ptr__char(query_last);
  __dyc_print_ptr__char(fragment_first);
  __dyc_print_ptr__char(fragment_last);
  __dyc_print_ptr__char(user_first);
  __dyc_print_ptr__char(user_last);
  __dyc_print_ptr__char(passwd_first);
}
}
